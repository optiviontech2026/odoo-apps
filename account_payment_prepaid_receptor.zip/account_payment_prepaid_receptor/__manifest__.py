{
    'name': 'Payment Prepared By / Receptor By',
    'version': '19.0.1.1.0',
    'category': 'Accounting/Accounting',
    'summary': 'Adds "Prepared By" and "Receptor By" to payments and prints '
               'Sent By / Received By signatures on the payment receipt',
    'description': """
Payment Prepared By / Receptor By
=================================
Adds two fields on customer and vendor payments:

* **Prepared By** - the user on the company side who prepared the payment
  (selected from users, defaults to the user preparing it).
* **Receptor By** - the person on the customer / vendor side.

The printed Payment Receipt shows a signature block whose labels follow the
payment type:

=================  ===============  ===============
Payment type       Prepared By      Receptor By
=================  ===============  ===============
Send (outbound)    Sent By          Received By
Receive (inbound)  Received By      Sent By
=================  ===============  ===============

The fields are also available on the "Register Payment" wizard opened from
invoices and bills, and are copied to the payments it creates.
""",
    'author': 'Optivion Tech',
    'license': 'LGPL-3',
    'depends': ['account'],
    'data': [
        'views/account_payment_views.xml',
        'wizard/account_payment_register_views.xml',
        'report/report_payment_receipt.xml',
    ],
    'post_init_hook': 'post_init_hook',
    'installable': True,
    'application': False,
}
