def post_init_hook(env):
    """On install, existing payments get the user who created them."""
    env.cr.execute("""
        UPDATE account_payment
           SET prepared_by_id = create_uid
         WHERE prepared_by_id IS NULL
           AND create_uid IS NOT NULL
    """)
