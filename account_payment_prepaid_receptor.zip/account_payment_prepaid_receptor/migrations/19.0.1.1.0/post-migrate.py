def migrate(cr, version):
    """Upgrade from 1.0 (free-text "Prepaid By") to 1.1 ("Prepared By" user).

    1. If the old text matches a user's name exactly, use that user.
    2. Otherwise use the user who created the payment.
    The old text column is left in the database untouched.
    """
    if not version:
        return

    cr.execute("""
        SELECT 1
          FROM information_schema.columns
         WHERE table_name = 'account_payment'
           AND column_name = 'prepaid_by'
    """)
    if cr.fetchone():
        cr.execute("""
            UPDATE account_payment p
               SET prepared_by_id = u.id
              FROM res_users u
              JOIN res_partner rp ON rp.id = u.partner_id
             WHERE p.prepared_by_id IS NULL
               AND p.prepaid_by IS NOT NULL
               AND lower(trim(rp.name)) = lower(trim(p.prepaid_by))
               AND u.share IS NOT TRUE
        """)

    cr.execute("""
        UPDATE account_payment
           SET prepared_by_id = create_uid
         WHERE prepared_by_id IS NULL
           AND create_uid IS NOT NULL
    """)
