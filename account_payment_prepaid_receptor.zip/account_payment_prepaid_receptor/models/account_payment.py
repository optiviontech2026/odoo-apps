from odoo import api, fields, models


class AccountPayment(models.Model):
    _inherit = 'account.payment'

    # No `default=` on purpose: Odoo would write the installing user on every
    # existing payment. The current user is proposed through default_get()
    # instead, and existing payments are filled from their creator
    # (see hooks.py and the migration script).
    prepared_by_id = fields.Many2one(
        'res.users',
        string="Prepared By",
        tracking=True,
        copy=False,
        ondelete='restrict',
        domain="[('share', '=', False), ('company_ids', 'in', company_id)]",
        help="User on the company side who prepared this payment.\n"
             "Printed as 'Sent By' on Send payments and as 'Received By' "
             "on Receive payments.",
    )
    receptor_by = fields.Char(
        string="Receptor By",
        tracking=True,
        copy=False,
        help="Person on the customer / vendor side.\n"
             "Printed as 'Received By' on Send payments and as 'Sent By' "
             "on Receive payments.",
    )

    @api.model
    def default_get(self, fields):
        values = super().default_get(fields)
        if 'prepared_by_id' in fields and not values.get('prepared_by_id'):
            values['prepared_by_id'] = self.env.user.id
        return values
