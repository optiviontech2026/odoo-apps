from odoo import fields, models


class AccountPaymentRegister(models.TransientModel):
    _inherit = 'account.payment.register'

    prepared_by_id = fields.Many2one(
        'res.users',
        string="Prepared By",
        default=lambda self: self.env.user,
        domain="[('share', '=', False), ('company_ids', 'in', company_id)]",
        help="User on the company side who prepared this payment.",
    )
    receptor_by = fields.Char(
        string="Receptor By",
        help="Person on the customer / vendor side. Only available when all "
             "selected documents belong to the same customer / vendor.",
    )

    def _create_payment_vals_from_wizard(self, batch_result):
        # Single payment edited directly in the wizard.
        payment_vals = super()._create_payment_vals_from_wizard(batch_result)
        payment_vals.update({
            'prepared_by_id': self.prepared_by_id.id,
            'receptor_by': self.receptor_by,
        })
        return payment_vals

    def _create_payment_vals_from_batch(self, batch_result):
        # One payment per batch / per document.
        payment_vals = super()._create_payment_vals_from_batch(batch_result)
        payment_vals['prepared_by_id'] = self.prepared_by_id.id
        # The receptor is a person of the customer / vendor, so only copy it
        # when every payment created goes to the same partner.
        if self.can_edit_wizard:
            payment_vals['receptor_by'] = self.receptor_by
        return payment_vals
