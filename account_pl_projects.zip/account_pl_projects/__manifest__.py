{
    'name': 'Profit & Loss by Main Project / Project',
    'author': 'Optivion Tech',
    'version': '19.0.1.0.0',
    'category': 'Accounting/Accounting',
    'summary': 'Profit & Loss grouped by Main Project and Project, set on the chart of accounts, with full drill-down',
    'description': """
Adds Main Project and Project to the chart of accounts and a Profit & Loss report
grouped Main Project > Project > Account, with drill-down to journal items.
    """,
    'depends': ['account'],
    'external_dependencies': {'python': ['xlsxwriter']},
    'data': [
        'security/ir.model.access.csv',
        'views/project_views.xml',
        'views/account_views.xml',
        'views/pl_report_views.xml',
        'report/pl_report_templates.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'account_pl_projects/static/src/scss/pl_report.scss',
        ],
    },
    'installable': True,
    'application': False,
    'license': 'LGPL-3',
}
