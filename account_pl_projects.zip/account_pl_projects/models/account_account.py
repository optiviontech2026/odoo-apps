from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class AccountAccount(models.Model):
    _inherit = 'account.account'

    main_project_id = fields.Many2one(
        'pl.main.project', string='Main Project', index=True, ondelete='restrict')
    project_id = fields.Many2one(
        'pl.project', string='Project', index=True, ondelete='restrict',
        domain="[('main_project_id', '=', main_project_id)]")

    @api.onchange('main_project_id')
    def _onchange_main_project_id(self):
        if self.project_id and self.project_id.main_project_id != self.main_project_id:
            self.project_id = False

    @api.onchange('project_id')
    def _onchange_project_id(self):
        if self.project_id:
            self.main_project_id = self.project_id.main_project_id

    @api.constrains('main_project_id', 'project_id')
    def _check_project_matches_main(self):
        for rec in self:
            if rec.project_id and rec.project_id.main_project_id != rec.main_project_id:
                raise ValidationError(_(
                    "Project '%(p)s' does not belong to Main Project '%(m)s'.",
                    p=rec.project_id.name, m=rec.main_project_id.display_name or '-'))
