import re

from markupsafe import Markup

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

from .. import pl_export

# Odoo P&L account types -> report column
COLUMNS = {
    'income': 'amount_income',
    'income_other': 'amount_other_income',
    'expense_direct_cost': 'amount_cost',
    'expense': 'amount_expense',
    'expense_depreciation': 'amount_depreciation',
}
CREDIT_TYPES = ('income', 'income_other')
COLUMN_NAMES = list(COLUMNS.values())


def _net(s):
    return (s['amount_income'] + s['amount_other_income']
            - s['amount_cost'] - s['amount_expense'] - s['amount_depreciation'])


class PLReportWizard(models.TransientModel):
    _name = 'pl.report.wizard'
    _description = 'Profit & Loss by Project - Options'

    date_from = fields.Date(required=True, default=lambda s: fields.Date.today().replace(month=1, day=1))
    date_to = fields.Date(required=True, default=fields.Date.context_today)
    posted_only = fields.Boolean(string='Posted entries only', default=True)
    company_ids = fields.Many2many('res.company', string='Companies',
                                   default=lambda s: s.env.companies)
    line_ids = fields.One2many('pl.report.line', 'report_id')
    company_name = fields.Char(string='Company name', default=lambda s: s.env.company.name)
    report_title = fields.Char(string='Report title', default='Income Statement')
    rounding = fields.Selection([
        ('d2', '2 decimals (no rounding)'), ('d0', 'Whole numbers'),
        ('10', 'Nearest 10'), ('100', 'Nearest 100'), ('1000', 'Nearest 1,000'),
    ], string='Amount rounding', default='d2', required=True)

    @api.constrains('date_from', 'date_to')
    def _check_dates(self):
        for rec in self:
            if rec.date_from > rec.date_to:
                raise ValidationError(_("'Date from' must be before 'Date to'."))

    def _pl_groups(self):
        """Balance per P&L account for the selected period."""
        self.ensure_one()
        companies = self.company_ids or self.env.companies
        domain = [
            ('company_id', 'in', companies.ids),
            ('date', '>=', self.date_from), ('date', '<=', self.date_to),
            ('account_id.account_type', 'in', list(COLUMNS)),
            ('parent_state', '=', 'posted') if self.posted_only else ('parent_state', '!=', 'cancel'),
        ]
        return self.env['account.move.line']._read_group(
            domain, groupby=['account_id'], aggregates=['balance:sum'])

    # ------------------------------------------------------------ exports
    @property
    def period_label(self):
        return '%s to %s' % (self.date_from, self.date_to)

    def export_name(self):
        """File name without extension: P&L - Company - Period."""
        self.ensure_one()
        name = ' - '.join(p for p in ['P&L', self.company_name, self.period_label] if p)
        return re.sub(r'[\\/:*?"<>|]', '-', name)

    def get_export_data(self):
        """Account-based data (Main Project > Project > Account) for PDF / Excel."""
        self.ensure_one()
        items = []
        for account, balance in self._pl_groups():
            main, proj = account.main_project_id, account.project_id
            items.append({
                'main_id': main.id, 'main': main.name, 'main_seq': main.sequence,
                'proj_id': proj.id, 'proj': proj.name, 'proj_seq': proj.sequence,
                'code': account.code or '', 'name': account.name,
                'type': account.account_type, 'balance': balance,
            })
        currency = self.env.company.currency_id.name or ''
        fd = lambda d: d.strftime('%d %b %Y')
        rounding_label = dict(self._fields['rounding'].selection)[self.rounding]
        sub = ' · '.join([
            _('For the period %(a)s to %(b)s', a=fd(self.date_from), b=fd(self.date_to)),
            _('Currency: %s', currency), _('Rounding: %s', rounding_label)])
        meta = {'company': self.company_name or self.env.company.name,
                'title': self.report_title or _('Income Statement'),
                'sub': sub, 'currency': currency, 'rounding': self.rounding}
        data = pl_export.build_data(items, meta, unassigned=_('Unassigned'))
        data['charts'] = {k: Markup(v) for k, v in pl_export.svg_charts(data).items()}
        return data

    def action_export_pdf(self):
        self.ensure_one()
        return self.env.ref('account_pl_projects.action_report_pl_project').report_action(self)

    def action_export_xlsx(self):
        self.ensure_one()
        content = pl_export.build_xlsx(self.get_export_data())
        att = self.env['ir.attachment'].create({
            'name': self.export_name() + '.xlsx', 'raw': content, 'type': 'binary',
            'res_model': self._name, 'res_id': self.id,
            'mimetype': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        })
        return {'type': 'ir.actions.act_url',
                'url': '/web/content/%d?download=true' % att.id, 'target': 'self'}

    def _line_vals(self, level, name, sums, seq, parent=None, main=None, project=None, account=None):
        vals = dict(sums)
        vals.update({
            'report_id': self.id, 'level': level,
            'name': {'project': '\u2003', 'account': '\u2003\u2003'}.get(level, '') + name,
            'sequence': seq,
            'parent_id': parent.id if parent else False,
            'main_project_id': main or False, 'project_id': project or False,
            'account_id': account.id if account else False,
            'amount_net': _net(sums),
        })
        return vals

    def action_generate(self):
        self.ensure_one()
        self.line_ids.unlink()
        groups = self._pl_groups()

        # tree[main_id][project_id] = [(account, column, amount)]
        tree = {}
        for account, balance in groups:
            col = COLUMNS[account.account_type]
            amount = -balance if account.account_type in CREDIT_TYPES else balance
            tree.setdefault(account.main_project_id.id or 0, {}) \
                .setdefault(account.project_id.id or 0, []).append((account, col, amount))

        Line = self.env['pl.report.line']
        mains = self.env['pl.main.project'].browse([k for k in tree if k])
        projects = self.env['pl.project'].browse([p for sub in tree.values() for p in sub if p])
        main_by_id = {m.id: m for m in mains}
        proj_by_id = {p.id: p for p in projects}

        def sums_of(items):
            s = dict.fromkeys(COLUMN_NAMES, 0.0)
            for _acc, col, amt in items:
                s[col] += amt
            return s

        total = dict.fromkeys(COLUMN_NAMES, 0.0)
        seq = 0
        for mid in sorted(tree, key=lambda k: (k == 0, main_by_id[k].sequence if k else 0,
                                                main_by_id[k].name if k else '')):
            sub = tree[mid]
            all_items = [i for items in sub.values() for i in items]
            seq += 1
            main_line = Line.create(self._line_vals(
                'main', main_by_id[mid].name if mid else _('Unassigned'),
                sums_of(all_items), seq, main=mid))
            for col, amt in sums_of(all_items).items():
                total[col] += amt
            for pid in sorted(sub, key=lambda k: (k == 0, proj_by_id[k].sequence if k else 0,
                                                  proj_by_id[k].name if k else '')):
                items = sub[pid]
                seq += 1
                proj_line = Line.create(self._line_vals(
                    'project', proj_by_id[pid].name if pid else _('Unassigned'),
                    sums_of(items), seq, parent=main_line, main=mid, project=pid))
                for acc, col, amt in sorted(items, key=lambda i: i[0].code or ''):
                    seq += 1
                    s = dict.fromkeys(COLUMN_NAMES, 0.0)
                    s[col] = amt
                    Line.create(self._line_vals(
                        'account', acc.display_name, s, seq, parent=proj_line,
                        main=mid, project=pid, account=acc))
        Line.create(self._line_vals('total', _('TOTAL'), total, seq + 1))

        return {
            'type': 'ir.actions.act_window',
            'name': _('Profit & Loss by Project'),
            'res_model': 'pl.report.line',
            'views': [(self.env.ref('account_pl_projects.pl_report_line_list').id, 'list')],
            'domain': [('report_id', '=', self.id), ('parent_id', '=', False)],
            'target': 'current',
        }


class PLReportLine(models.TransientModel):
    _name = 'pl.report.line'
    _description = 'Profit & Loss by Project - Line'
    _order = 'sequence, id'

    report_id = fields.Many2one('pl.report.wizard', required=True, ondelete='cascade', index=True)
    parent_id = fields.Many2one('pl.report.line', ondelete='cascade', index=True)
    sequence = fields.Integer()
    level = fields.Selection([('main', 'Main Project'), ('project', 'Project'),
                              ('account', 'Account'), ('total', 'Total')], required=True)
    name = fields.Char(required=True)
    main_project_id = fields.Many2one('pl.main.project')
    project_id = fields.Many2one('pl.project')
    account_id = fields.Many2one('account.account')
    currency_id = fields.Many2one('res.currency', default=lambda s: s.env.company.currency_id)
    amount_income = fields.Monetary(string='Income', currency_field='currency_id')
    amount_other_income = fields.Monetary(string='Other Income', currency_field='currency_id')
    amount_cost = fields.Monetary(string='Cost of Revenue', currency_field='currency_id')
    amount_expense = fields.Monetary(string='Expenses', currency_field='currency_id')
    amount_depreciation = fields.Monetary(string='Depreciation', currency_field='currency_id')
    amount_net = fields.Monetary(string='Net Profit', currency_field='currency_id')

    def _children_action(self):
        return {
            'type': 'ir.actions.act_window',
            'name': (self.name or '').strip(),
            'res_model': 'pl.report.line',
            'views': [(self.env.ref('account_pl_projects.pl_report_line_list').id, 'list')],
            'domain': [('parent_id', '=', self.id)],
        }

    def _move_lines_action(self, domain_extra, name):
        rep = self.report_id
        domain = [
            ('date', '>=', rep.date_from), ('date', '<=', rep.date_to),
            ('company_id', 'in', (rep.company_ids or self.env.companies).ids),
            ('parent_state', '=', 'posted') if rep.posted_only else ('parent_state', '!=', 'cancel'),
        ] + domain_extra
        return {
            'type': 'ir.actions.act_window',
            'name': name,
            'res_model': 'account.move.line',
            'views': [(False, 'list'), (False, 'form')],
            'domain': domain,
        }

    def action_drill(self):
        """Main Project -> Projects -> Accounts -> Journal Items."""
        self.ensure_one()
        if self.level in ('main', 'project'):
            return self._children_action()
        if self.level == 'account':
            return self._move_lines_action([('account_id', '=', self.account_id.id)],
                                           self.account_id.display_name)
        # total: all P&L journal items of the report
        account_ids = self.search([('report_id', '=', self.report_id.id),
                                   ('level', '=', 'account')]).account_id.ids
        return self._move_lines_action([('account_id', 'in', account_ids)], _('Journal Items'))
