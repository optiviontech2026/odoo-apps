from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class PLMainProject(models.Model):
    _name = 'pl.main.project'
    _description = 'P&L Main Project'
    _order = 'sequence, name'

    name = fields.Char(required=True)
    code = fields.Char()
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    project_ids = fields.One2many('pl.project', 'main_project_id', string='Projects')
    account_count = fields.Integer(compute='_compute_account_count')

    @api.constrains('name')
    def _check_name_unique(self):
        for rec in self:
            if self.with_context(active_test=False).search_count(
                    [('name', '=ilike', rec.name), ('id', '!=', rec.id)]):
                raise ValidationError(_("A Main Project named '%s' already exists.", rec.name))

    def _compute_account_count(self):
        data = self.env['account.account']._read_group(
            [('main_project_id', 'in', self.ids)], ['main_project_id'], ['__count'])
        counts = {main.id: count for main, count in data}
        for rec in self:
            rec.account_count = counts.get(rec.id, 0)

    def action_view_accounts(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': _('Accounts'),
            'res_model': 'account.account',
            'view_mode': 'list,form',
            'domain': [('main_project_id', '=', self.id)],
        }


class PLProject(models.Model):
    _name = 'pl.project'
    _description = 'P&L Project'
    _order = 'main_project_id, sequence, name'

    name = fields.Char(required=True)
    code = fields.Char()
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    main_project_id = fields.Many2one('pl.main.project', string='Main Project',
                                      required=True, index=True, ondelete='restrict')
    account_count = fields.Integer(compute='_compute_account_count')

    @api.constrains('name', 'main_project_id')
    def _check_name_unique(self):
        for rec in self:
            if self.with_context(active_test=False).search_count([
                    ('name', '=ilike', rec.name),
                    ('main_project_id', '=', rec.main_project_id.id),
                    ('id', '!=', rec.id)]):
                raise ValidationError(_(
                    "Project '%(p)s' already exists under Main Project '%(m)s'.",
                    p=rec.name, m=rec.main_project_id.name))

    def _compute_account_count(self):
        data = self.env['account.account']._read_group(
            [('project_id', 'in', self.ids)], ['project_id'], ['__count'])
        counts = {proj.id: count for proj, count in data}
        for rec in self:
            rec.account_count = counts.get(rec.id, 0)

    def action_view_accounts(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': _('Accounts'),
            'res_model': 'account.account',
            'view_mode': 'list,form',
            'domain': [('project_id', '=', self.id)],
        }

    @api.depends('name', 'main_project_id.name')
    def _compute_display_name(self):
        for rec in self:
            rec.display_name = rec.name
