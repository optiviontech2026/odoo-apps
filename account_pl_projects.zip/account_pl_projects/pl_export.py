"""Pure-python helpers (no Odoo imports) that build the P&L export data,
the Excel file (xlsxwriter, native charts) and the SVG charts used in the PDF.

Amounts are shown as their effect on profit: income positive, costs and
expenses negative (in parentheses). Lines are accounts, not account types.
"""
import io
import math
from xml.sax.saxutils import escape

INCOME_TYPES = {'income', 'income_other'}
COST_TYPES = {'expense_direct_cost'}
GREEN, TINT, RED = '#1f5c4a', '#e4efe9', '#a63d2f'
PALETTE = ['#1f5c4a', '#c2842b', '#3f6fa3', '#a63d2f', '#7a5aa6', '#5a9a8a', '#b5a642',
           '#8a6a55', '#4c8f3f', '#c26b8a', '#6b7a8f', '#d0a15a', '#2f8f9a', '#999999']


def make_rounder(mode):
    if mode == 'd2':
        return lambda x: round(x, 2)
    if mode == 'd0':
        return lambda x: math.copysign(math.floor(abs(x) + 0.5), x)
    step = float(mode)
    return lambda x: math.copysign(math.floor(abs(x) / step + 0.5) * step, x)


def fmt(v, dec):
    v = round(v, dec)
    if v == 0:
        v = 0.0
    s = f"{abs(v):,.{dec}f}"
    return f"({s})" if v < 0 else s


def build_data(items, meta, unassigned='Unassigned'):
    """items: dicts with main_id, main, main_seq, proj_id, proj, proj_seq,
    code, name, type, balance (debit - credit)."""
    R = make_rounder(meta['rounding'])
    dec = 2 if meta['rounding'] == 'd2' else 0
    mains = {}
    for it in items:
        mid, pid = it['main_id'] or 0, it['proj_id'] or 0
        m = mains.setdefault(mid, {'name': it['main'] if mid else unassigned,
                                   'seq': it['main_seq'] if mid else 0, 'projects': {}})
        p = m['projects'].setdefault(pid, {'name': it['proj'] if pid else unassigned,
                                           'seq': it['proj_seq'] if pid else 0, 'accounts': []})
        p['accounts'].append({'code': it['code'] or '', 'name': it['name'] or '',
                              'type': it['type'], 'amount': R(-it['balance'])})

    def key(k, d):
        return (k == 0, d[k]['seq'], d[k]['name'])

    rows, detail, summary = [], [], []
    tot = {'income': 0.0, 'cost': 0.0, 'expense': 0.0, 'net': 0.0}

    def add(k, label, code='', v=None, ind=0):
        rows.append({'k': k, 'l': label, 'pad': ' ' * ind + label, 'c': code, 'v': v,
                     'txt': '' if v is None else fmt(v, dec),
                     'neg': v is not None and round(v, dec) < 0, 'ind': ind})

    def parts(accs):
        s = {'income': 0.0, 'cost': 0.0, 'expense': 0.0, 'net': 0.0}
        for a in accs:
            s['net'] += a['amount']
            if a['type'] in INCOME_TYPES:
                s['income'] += a['amount']
            elif a['type'] in COST_TYPES:
                s['cost'] -= a['amount']
            else:
                s['expense'] -= a['amount']
        return s

    for mid in sorted(mains, key=lambda k: key(k, mains)):
        m = mains[mid]
        all_accs = [a for p in m['projects'].values() for a in p['accounts']]
        add('h0', 'Main Project: ' + m['name'])
        for pid in sorted(m['projects'], key=lambda k: key(k, m['projects'])):
            p = m['projects'][pid]
            add('h1', 'Project: ' + p['name'])
            for a in sorted(p['accounts'], key=lambda a: a['code']):
                add('a', a['name'], a['code'], a['amount'], 1)
                detail.append([m['name'], p['name'], a['code'], a['name'], a['amount']])
            add('tot', 'Total ' + p['name'], '', parts(p['accounts'])['net'], 0)
        s = parts(all_accs)
        add('net', 'Net Profit — ' + m['name'], '', s['net'])
        summary.append(dict(s, name=m['name']))
        for k in tot:
            tot[k] += s[k]
    if rows:
        add('net', 'Net Profit — All Main Projects', '', tot['net'])
    return {'meta': dict(meta, dec=dec), 'rows': rows, 'detail': detail,
            'mains': summary, 'total': tot}


# ------------------------------------------------------------------ Excel
def build_xlsx(data):
    import xlsxwriter
    meta, dec = data['meta'], data['meta']['dec']
    nf = '#,##0.00;[Red](#,##0.00)' if dec else '#,##0;[Red](#,##0)'
    bio = io.BytesIO()
    wb = xlsxwriter.Workbook(bio, {'in_memory': True})
    s1 = wb.add_worksheet('Income Statement')
    s4 = wb.add_worksheet('Charts')
    s3 = wb.add_worksheet('Summary by Main Project')
    s2 = wb.add_worksheet('Detail')
    cur = ' (%s)' % meta['currency'] if meta.get('currency') else ''
    cache = {}

    def F(**kw):
        k = tuple(sorted(kw.items()))
        if k not in cache:
            cache[k] = wb.add_format(dict({'font_size': 10}, **kw))
        return cache[k]

    head = dict(bold=True, font_color='#FFFFFF', bg_color=GREEN)
    s1.set_column(0, 0, 60); s1.set_column(1, 1, 12); s1.set_column(2, 2, 20)
    s1.write(0, 0, meta['company'], F(bold=True, font_size=16))
    s1.write(1, 0, meta['title'], F(bold=True, font_size=12))
    s1.write(2, 0, meta['sub'], F(italic=True, font_size=9))
    for c, t in enumerate(['Description', 'Code', 'Amount' + cur]):
        s1.write(4, c, t, F(align='right' if c == 2 else 'left', **head))
    r = 5
    for row in data['rows']:
        k = row['k']
        base = {'h0': dict(head), 'h1': dict(bold=True, bg_color=TINT),
                'tot': dict(bold=True, top=1), 'net': dict(bold=True, bg_color=TINT, top=2),
                'a': {}}[k]
        s1.write(r, 0, row['l'], F(indent=row['ind'], **base))
        s1.write(r, 1, row['c'], F(font_color='#6b726d' if k == 'a' else base.get('font_color', '#000000'),
                                   **{x: y for x, y in base.items() if x != 'font_color'}))
        if row['v'] is None:
            s1.write_blank(r, 2, None, F(**base))
        else:
            s1.write_number(r, 2, row['v'], F(num_format=nf, **base))
        r += 1
    s1.freeze_panes(5, 0)
    s1.set_paper(9); s1.fit_to_pages(1, 0); s1.repeat_rows(4)
    for ws in (s2, s3, s4):
        ws.set_paper(9); ws.set_landscape(); ws.fit_to_pages(1, 0)

    # summary (also chart data)
    s3.set_column(0, 0, 28); s3.set_column(1, 4, 20); s3.set_column(7, 8, 20)
    for c, t in enumerate(['Main Project', 'Income' + cur, 'Cost of Revenue' + cur,
                           'Expenses incl. depreciation' + cur, 'Net Profit' + cur]):
        s3.write(0, c, t, F(**head))
    mains = data['mains']
    for i, m in enumerate(mains, start=1):
        s3.write(i, 0, m['name'], F())
        for c, key in enumerate(['income', 'cost', 'expense', 'net'], start=1):
            s3.write_number(i, c, m[key], F(num_format=nf))
    n = len(mains)
    if n:
        t = data['total']
        s3.write(n + 1, 0, 'TOTAL', F(bold=True, top=1))
        for c, key in enumerate(['income', 'cost', 'expense', 'net'], start=1):
            s3.write_number(n + 1, c, t[key], F(num_format=nf, bold=True, top=1))
    pos = [m for m in mains if m['income'] > 0]
    s3.write(0, 7, 'Main Project', F(**head)); s3.write(0, 8, 'Income share', F(**head))
    for i, m in enumerate(pos, start=1):
        s3.write(i, 7, m['name'], F()); s3.write_number(i, 8, m['income'], F(num_format=nf))

    S = "'Summary by Main Project'"
    if n:
        c1 = wb.add_chart({'type': 'bar'})
        c1.add_series({'name': 'Net Profit', 'categories': [S[1:-1], 1, 0, n, 0],
                       'values': [S[1:-1], 1, 4, n, 4], 'fill': {'color': GREEN},
                       'invert_if_negative': True, 'invert_if_negative_color': RED})
        c1.set_title({'name': 'Net profit by Main Project' + cur, 'name_font': {'size': 12}})
        c1.set_y_axis({'label_position': 'low', 'reverse': True})
        c1.set_x_axis({'num_format': '#,##0'})
        c1.set_legend({'none': True}); c1.set_size({'width': 800, 'height': 340})
        s4.insert_chart('B2', c1)
        if pos:
            c2 = wb.add_chart({'type': 'pie'})
            c2.add_series({'name': 'Income share', 'categories': [S[1:-1], 1, 7, len(pos), 7],
                           'values': [S[1:-1], 1, 8, len(pos), 8],
                           'data_labels': {'percentage': True},
                           'points': [{'fill': {'color': PALETTE[i % len(PALETTE)]}} for i in range(len(pos))]})
            c2.set_title({'name': 'Income share by Main Project', 'name_font': {'size': 12}})
            c2.set_size({'width': 800, 'height': 340})
            s4.insert_chart('B21', c2)
        c3 = wb.add_chart({'type': 'column'})
        for col, name, color in [(1, 'Income', GREEN), (2, 'Cost of Revenue', '#c2842b'),
                                 (3, 'Expenses incl. depreciation', '#3f6fa3')]:
            c3.add_series({'name': name, 'categories': [S[1:-1], 1, 0, n, 0],
                           'values': [S[1:-1], 1, col, n, col], 'fill': {'color': color}})
        c3.set_title({'name': 'Income vs Cost of Revenue vs Expenses' + cur, 'name_font': {'size': 12}})
        c3.set_y_axis({'num_format': '#,##0'})
        c3.set_x_axis({'label_position': 'low'})
        c3.set_size({'width': 800, 'height': 360})
        s4.insert_chart('B40', c3)

    s2.set_column(0, 1, 26); s2.set_column(2, 2, 10); s2.set_column(3, 3, 55); s2.set_column(4, 4, 20)
    for c, t in enumerate(['Main Project', 'Project', 'Code', 'Account', 'Amount' + cur]):
        s2.write(0, c, t, F(**head))
    for i, d in enumerate(data['detail'], start=1):
        for c in range(4):
            s2.write(i, c, d[c], F())
        s2.write_number(i, 4, d[4], F(num_format=nf))
    s2.autofilter(0, 0, max(len(data['detail']), 1), 4)
    wb.close()
    return bio.getvalue()


# ------------------------------------------------------------------ SVG charts
def _short(v):
    a = abs(v)
    for lim, suf in ((1e9, 'B'), (1e6, 'M'), (1e3, 'K')):
        if a >= lim:
            return f"{v / lim:.1f}{suf}"
    return f"{v:.0f}"


def _iso(s):
    return s


def _cut(s, n=22):
    return s if len(s) <= n else s[:n - 1] + '…'


def _svg(w, h, title, body):
    return ('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d" '
            'style="font-family:inherit;font-size:11px">'
            '<rect width="%d" height="%d" fill="#ffffff"/>'
            '<text x="%d" y="18" text-anchor="middle" font-size="13" font-weight="bold" fill="#1d2421">%s</text>%s</svg>'
            % (w, h, w, h, w, h, w // 2, escape(title), body))


def svg_net(mains, dec, cur):
    W, left, right, rh = 620, 150, 80, 24
    H = 36 + rh * len(mains) + 8
    vals = [m['net'] for m in mains]
    lo, hi = min(0, min(vals)), max(0, max(vals))
    pad = 95 if lo < 0 else 0
    sc = (W - left - pad - right) / ((hi - lo) or 1)
    x0 = left + pad + (-lo) * sc
    b = []
    for i, m in enumerate(mains):
        y = 32 + i * rh
        v = m['net']
        x = min(x0, x0 + v * sc)
        wd = max(abs(v) * sc, 1)
        b.append('<text x="%.1f" y="%.1f" text-anchor="end" fill="#1d2421">%s</text>' % (left - 6, y + 14, escape(_iso(_cut(m['name'])))))
        b.append('<rect x="%.1f" y="%d" width="%.1f" height="16" fill="%s"/>' % (x, y + 3, wd, RED if v < 0 else GREEN))
        tx = x0 + v * sc + (4 if v >= 0 else -4)
        b.append('<text x="%.1f" y="%.1f" text-anchor="%s" fill="#1d2421">%s</text>' % (tx, y + 15, 'start' if v >= 0 else 'end', fmt(v, dec)))
    b.append('<line x1="%.1f" y1="28" x2="%.1f" y2="%d" stroke="#999"/>' % (x0, x0, H - 6))
    return _svg(W, H, 'Net profit by Main Project' + (' (%s)' % cur if cur else ''), ''.join(b))


def svg_pie(mains, cur):
    pos = [m for m in mains if m['income'] > 0]
    if not pos:
        return ''
    W, H, cx, cy, r = 620, 260, 150, 140, 100
    total = sum(m['income'] for m in pos)
    b, ang = [], -math.pi / 2
    for i, m in enumerate(pos):
        col = PALETTE[i % len(PALETTE)]
        frac = m['income'] / total
        if len(pos) == 1:
            b.append('<circle cx="%d" cy="%d" r="%d" fill="%s"/>' % (cx, cy, r, col))
        else:
            a2 = ang + frac * 2 * math.pi
            x1, y1, x2, y2 = cx + r * math.cos(ang), cy + r * math.sin(ang), cx + r * math.cos(a2), cy + r * math.sin(a2)
            b.append('<path d="M%d,%d L%.1f,%.1f A%d,%d 0 %d 1 %.1f,%.1f Z" fill="%s" stroke="#fff"/>'
                     % (cx, cy, x1, y1, r, r, 1 if frac > 0.5 else 0, x2, y2, col))
            ang = a2
        ly = 50 + i * 18
        b.append('<rect x="290" y="%d" width="10" height="10" fill="%s"/>' % (ly, col))
        b.append('<text x="306" y="%d" fill="#1d2421">%s — %.1f%%</text>' % (ly + 9, escape(_iso(_cut(m['name'], 30))), frac * 100))
    return _svg(W, max(H, 60 + len(pos) * 18), 'Income share by Main Project', ''.join(b))


def svg_grouped(mains, cur):
    W, H, left, bottom, top = 620, 300, 56, 70, 52
    series = [('Income', 'income', GREEN), ('Cost of Revenue', 'cost', '#c2842b'),
              ('Expenses + Depreciation', 'expense', '#3f6fa3')]
    mx = max([max(m[k], 0) for m in mains for _n, k, _c in series] + [1])
    ph = H - top - bottom
    gw = (W - left - 10) / len(mains)
    bw = min(gw / 4, 26)
    b = []
    for t in range(5):
        y = top + ph - ph * t / 4
        b.append('<line x1="%d" y1="%.1f" x2="%d" y2="%.1f" stroke="#ddd6c6"/>' % (left, y, W - 10, y))
        b.append('<text x="%d" y="%.1f" text-anchor="end" fill="#6b726d">%s</text>' % (left - 4, y + 4, _short(mx * t / 4)))
    for i, m in enumerate(mains):
        gx = left + i * gw + gw / 2 - bw * 1.5
        for j, (_n, k, col) in enumerate(series):
            hh = max(m[k], 0) / mx * ph
            b.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="%s"/>' % (gx + j * bw, top + ph - hh, bw - 2, hh, col))
        b.append('<text x="%.1f" y="%d" text-anchor="middle" fill="#1d2421">%s</text>' % (left + i * gw + gw / 2, H - bottom + 16, escape(_iso(_cut(m['name'], 14)))))
    for j, (name, _k, col) in enumerate(series):
        lx = 60 + j * 180
        b.append('<rect x="%d" y="28" width="10" height="10" fill="%s"/><text x="%d" y="37" fill="#1d2421">%s</text>' % (lx, col, lx + 14, escape(name)))
    return _svg(W, H, 'Income vs Cost of Revenue vs Expenses' + (' (%s)' % cur if cur else ''), ''.join(b))


def svg_charts(data):
    mains, meta = data['mains'], data['meta']
    if not mains:
        return {}
    out = {'net': svg_net(mains, meta['dec'], meta['currency']), 'pie': svg_pie(mains, meta['currency']),
           'grouped': svg_grouped(mains, meta['currency'])}
    return {k: v for k, v in out.items() if v}
