{
    'name': 'Cash Internal Transfer',
    'version': '19.0.1.0.0',
    'category': 'Accounting/Accounting',
    'summary': 'Transfer money between cash/bank journals of the same currency '
               'from the payment form, with a signed transfer voucher',
    'description': """
Cash Internal Transfer
======================
Adds a "Cash Internal Transfer" checkbox to the payment form.

When it is ticked:

* the partner fields are hidden and a "Transfer To" journal is shown,
* only journals with the same currency can be selected,
* confirming the payment creates and posts the matching receipt in the
  receiving journal, both through the company's Internal Transfer account,
  and reconciles the two transfer lines,
* reset to draft, cancel and delete are applied to both sides together,
* a Cash Transfer Voucher can be printed with "Prepared By" and
  "Receiver" names and a signature line for each.
""",
    'author': 'Optivion Tech',
    'license': 'LGPL-3',
    'depends': ['account'],
    'data': [
        'views/account_payment_views.xml',
        'report/cash_transfer_report.xml',
        'report/cash_transfer_templates.xml',
    ],
    'installable': True,
    'application': False,
}
