from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.tools.misc import formatLang

# Fields copied to the other side of the transfer whenever one side is edited.
CASH_TRANSFER_SYNC_FIELDS = (
    'amount',
    'date',
    'memo',
    'payment_reference',
    'transfer_prepared_by_id',
    'transfer_receiver_name',
)
# Fields that can only change while both sides are still in draft.
CASH_TRANSFER_DRAFT_ONLY_FIELDS = ('amount', 'date', 'journal_id', 'currency_id')


class AccountPayment(models.Model):
    _inherit = 'account.payment'

    is_cash_transfer = fields.Boolean(
        string="Cash Internal Transfer",
        tracking=True,
        help="Tick to move money from this journal to another journal of the same currency. "
             "Confirming the payment creates the matching receipt in the other journal.",
    )
    transfer_journal_id = fields.Many2one(
        comodel_name='account.journal',
        string="Transfer Journal",
        check_company=True,
        tracking=True,
        domain="[('id', 'in', available_transfer_journal_ids)]",
        help="On the sending side: the journal that receives the money.\n"
             "On the receiving side: the journal the money comes from.",
    )
    available_transfer_journal_ids = fields.Many2many(
        comodel_name='account.journal',
        compute='_compute_available_transfer_journal_ids',
    )
    transfer_from_journal_id = fields.Many2one(
        comodel_name='account.journal',
        string="From Journal",
        compute='_compute_transfer_direction',
    )
    transfer_to_journal_id = fields.Many2one(
        comodel_name='account.journal',
        string="To Journal",
        compute='_compute_transfer_direction',
    )
    cash_transfer_summary = fields.Char(
        string="Transfer Summary",
        compute='_compute_cash_transfer_summary',
    )
    transfer_prepared_by_id = fields.Many2one(
        comodel_name='res.users',
        string="Prepared By",
        default=lambda self: self.env.user,
        tracking=True,
        copy=False,
    )
    transfer_receiver_name = fields.Char(
        string="Receiver Name",
        tracking=True,
        copy=False,
        help="Name of the person who receives the money. Printed on the transfer voucher.",
    )

    # -------------------------------------------------------------------------
    # COMPUTE / ONCHANGE
    # -------------------------------------------------------------------------

    @api.model
    def _get_cash_transfer_journal_currency(self, journal):
        return journal.currency_id or journal.company_id.currency_id

    @api.depends('journal_id', 'company_id')
    def _compute_available_transfer_journal_ids(self):
        Journal = self.env['account.journal']
        for pay in self:
            if not pay.journal_id or not pay.company_id:
                pay.available_transfer_journal_ids = Journal
                continue
            currency = self._get_cash_transfer_journal_currency(pay.journal_id)
            journals = Journal.search([
                *Journal._check_company_domain(pay.company_id),
                ('type', 'in', ('bank', 'cash')),
                ('id', '!=', pay.journal_id._origin.id),
            ])
            pay.available_transfer_journal_ids = journals.filtered(
                lambda j: self._get_cash_transfer_journal_currency(j) == currency
            )

    @api.depends('is_cash_transfer', 'payment_type', 'journal_id', 'transfer_journal_id')
    def _compute_transfer_direction(self):
        for pay in self:
            if not pay.is_cash_transfer:
                pay.transfer_from_journal_id = False
                pay.transfer_to_journal_id = False
            elif pay.payment_type == 'inbound':
                pay.transfer_from_journal_id = pay.transfer_journal_id
                pay.transfer_to_journal_id = pay.journal_id
            else:
                pay.transfer_from_journal_id = pay.journal_id
                pay.transfer_to_journal_id = pay.transfer_journal_id

    @api.depends('is_cash_transfer', 'amount', 'currency_id', 'transfer_from_journal_id', 'transfer_to_journal_id')
    def _compute_cash_transfer_summary(self):
        for pay in self:
            if not pay.is_cash_transfer:
                pay.cash_transfer_summary = False
                continue
            amount = formatLang(self.env, pay.amount, currency_obj=pay.currency_id)
            pay.cash_transfer_summary = _(
                "Transferring %(amount)s from %(from_journal)s to %(to_journal)s",
                amount=amount,
                from_journal=pay.transfer_from_journal_id.name or "…",
                to_journal=pay.transfer_to_journal_id.name or "…",
            )

    @api.depends('is_cash_transfer', 'journal_id')
    def _compute_outstanding_account_id(self):
        super()._compute_outstanding_account_id()
        # Cash journals usually have no outstanding account on their payment methods:
        # a transfer must still produce a journal entry, so book it directly on the
        # journal's own cash/bank account in that case.
        for pay in self:
            if pay.is_cash_transfer and not pay.outstanding_account_id:
                pay.outstanding_account_id = pay.journal_id.default_account_id

    @api.depends('is_cash_transfer', 'company_id')
    def _compute_destination_account_id(self):
        super()._compute_destination_account_id()
        for pay in self:
            if pay.is_cash_transfer:
                pay.destination_account_id = pay._get_cash_transfer_account()

    @api.depends('is_cash_transfer')
    def _compute_show_require_partner_bank(self):
        super()._compute_show_require_partner_bank()
        for pay in self:
            if pay.is_cash_transfer:
                pay.show_partner_bank_account = False
                pay.require_partner_bank_account = False

    @api.onchange('is_cash_transfer')
    def _onchange_is_cash_transfer(self):
        if self.is_cash_transfer:
            self.payment_type = 'outbound'
            self.partner_id = False
        else:
            self.transfer_journal_id = False

    @api.onchange('journal_id')
    def _onchange_journal_id_cash_transfer(self):
        if self.is_cash_transfer and self.transfer_journal_id not in self.available_transfer_journal_ids:
            self.transfer_journal_id = False

    # -------------------------------------------------------------------------
    # CONSTRAINTS
    # -------------------------------------------------------------------------

    @api.constrains('is_cash_transfer', 'journal_id', 'transfer_journal_id', 'currency_id')
    def _check_cash_transfer_journals(self):
        for pay in self.filtered(lambda p: p.is_cash_transfer and p.transfer_journal_id):
            if pay.transfer_journal_id == pay.journal_id:
                raise ValidationError(_("A cash transfer needs two different journals."))
            source_currency = self._get_cash_transfer_journal_currency(pay.journal_id)
            target_currency = self._get_cash_transfer_journal_currency(pay.transfer_journal_id)
            if source_currency != target_currency or pay.currency_id != source_currency:
                raise ValidationError(_(
                    "A cash internal transfer must use one currency: %(journal)s is in %(currency)s, "
                    "%(other_journal)s is in %(other_currency)s and the payment is in %(payment_currency)s.",
                    journal=pay.journal_id.display_name,
                    currency=source_currency.name,
                    other_journal=pay.transfer_journal_id.display_name,
                    other_currency=target_currency.name,
                    payment_currency=pay.currency_id.name,
                ))

    # -------------------------------------------------------------------------
    # HELPERS
    # -------------------------------------------------------------------------

    def _get_cash_transfer_account(self):
        self.ensure_one()
        company = self.company_id or self.env.company
        return company.transfer_account_id or company.root_id.transfer_account_id

    def _get_aml_default_display_name_list(self):
        values = super()._get_aml_default_display_name_list()
        if not self.is_cash_transfer:
            return values
        label = _(
            "Cash Transfer: %(from_journal)s to %(to_journal)s",
            from_journal=self.transfer_from_journal_id.name or '',
            to_journal=self.transfer_to_journal_id.name or '',
        )
        if self.memo:
            return [('label', label), ('sep', " - "), ('memo', self.memo)]
        return [('label', label)]

    def _check_cash_transfer_before_post(self):
        for pay in self:
            if not pay.transfer_journal_id:
                raise UserError(_(
                    "Select the journal that receives the money before confirming the cash transfer %(payment)s.",
                    payment=pay.display_name,
                ))
            if pay.currency_id.is_zero(pay.amount):
                raise UserError(_("The amount of a cash transfer must be greater than zero."))
            if not pay._get_cash_transfer_account():
                raise UserError(_(
                    "No Internal Transfer account is set for %(company)s. Set it in "
                    "Accounting > Configuration > Settings > Default Accounts > Internal Transfer.",
                    company=pay.company_id.display_name,
                ))
        self._check_cash_transfer_journals()

    def _prepare_cash_transfer_pair_vals(self):
        self.ensure_one()
        return {
            'is_cash_transfer': True,
            'payment_type': 'inbound' if self.payment_type == 'outbound' else 'outbound',
            'partner_type': self.partner_type,
            'partner_id': False,
            'journal_id': self.transfer_journal_id.id,
            'transfer_journal_id': self.journal_id.id,
            'currency_id': self.currency_id.id,
            'amount': self.amount,
            'date': self.date,
            'memo': self.memo,
            'payment_reference': self.payment_reference,
            'transfer_prepared_by_id': self.transfer_prepared_by_id.id,
            'transfer_receiver_name': self.transfer_receiver_name,
            'paired_internal_transfer_payment_id': self.id,
        }

    def _create_cash_transfer_pairs(self):
        Payment = self.env['account.payment'].with_context(cash_transfer_skip_sync=True)
        for pay in self:
            pair = Payment.create(pay._prepare_cash_transfer_pair_vals())
            pay.with_context(cash_transfer_skip_sync=True).paired_internal_transfer_payment_id = pair
            pair.message_post(body=_(
                "This payment was created automatically as the other side of the cash transfer %s.",
                pay._get_html_link(),
            ))

    def _reconcile_cash_transfer_pairs(self):
        done = self.env['account.payment']
        for pay in self:
            pair = pay.paired_internal_transfer_payment_id
            if pay in done or not pair or not pay.move_id or not pair.move_id:
                continue
            done |= pay | pair
            if pay.move_id.state != 'posted' or pair.move_id.state != 'posted':
                continue
            account = pay.destination_account_id
            if not account.reconcile:
                continue
            lines = (pay.move_id.line_ids | pair.move_id.line_ids).filtered(
                lambda line: line.account_id == account and not line.reconciled
            )
            if len(lines) > 1:
                lines.reconcile()

    # -------------------------------------------------------------------------
    # LOW-LEVEL / BUSINESS METHODS
    # -------------------------------------------------------------------------

    def write(self, vals):
        res = super().write(vals)
        if not self.env.context.get('cash_transfer_skip_sync'):
            self._sync_cash_transfer_pairs(vals)
        return res

    def _sync_cash_transfer_pairs(self, vals):
        common_vals = {fname: vals[fname] for fname in CASH_TRANSFER_SYNC_FIELDS if fname in vals}
        journal_changed = 'journal_id' in vals or 'transfer_journal_id' in vals
        if not common_vals and not journal_changed:
            return
        for pay in self.filtered(lambda p: p.is_cash_transfer and p.paired_internal_transfer_payment_id):
            pair = pay.paired_internal_transfer_payment_id
            pair_vals = dict(common_vals)
            if journal_changed:
                pair_vals.update({
                    'journal_id': pay.transfer_journal_id.id,
                    'transfer_journal_id': pay.journal_id.id,
                    'currency_id': pay.currency_id.id,
                })
            # Only write what actually differs, so posted pairs are not touched needlessly.
            pair_vals = {
                fname: value for fname, value in pair_vals.items()
                if pair._fields[fname].convert_to_write(pair[fname], pair) != value
            }
            if not pair_vals:
                continue
            if pair.state != 'draft' and any(f in pair_vals for f in CASH_TRANSFER_DRAFT_ONLY_FIELDS):
                raise UserError(_(
                    "Reset both sides of the cash transfer to draft before changing the amount, date or journals."
                ))
            pair.with_context(cash_transfer_skip_sync=True).write(pair_vals)

    def action_post(self):
        if self.env.context.get('cash_transfer_skip_pair'):
            return super().action_post()

        transfers = self.filtered('is_cash_transfer')
        transfers._check_cash_transfer_before_post()
        transfers.filtered(lambda p: not p.paired_internal_transfer_payment_id)._create_cash_transfer_pairs()

        res = super().action_post()

        pairs_to_post = transfers.paired_internal_transfer_payment_id.filtered(lambda p: p.state == 'draft') - self
        if pairs_to_post:
            pairs_to_post.with_context(cash_transfer_skip_pair=True).action_post()
        transfers._reconcile_cash_transfer_pairs()
        return res

    def action_draft(self):
        res = super().action_draft()
        if not self.env.context.get('cash_transfer_skip_pair'):
            pairs = self.filtered('is_cash_transfer').paired_internal_transfer_payment_id
            pairs = pairs.filtered(lambda p: p.state != 'draft') - self
            if pairs:
                pairs.with_context(cash_transfer_skip_pair=True).action_draft()
        return res

    def action_cancel(self):
        res = super().action_cancel()
        if not self.env.context.get('cash_transfer_skip_pair'):
            pairs = self.filtered('is_cash_transfer').paired_internal_transfer_payment_id
            pairs = pairs.filtered(lambda p: p.state != 'canceled') - self
            if pairs:
                pairs.with_context(cash_transfer_skip_pair=True).action_cancel()
        return res

    def unlink(self):
        pairs = self.env['account.payment']
        if not self.env.context.get('cash_transfer_skip_pair'):
            pairs = self.filtered('is_cash_transfer').paired_internal_transfer_payment_id - self
        res = super().unlink()
        if pairs.exists():
            pairs.exists().with_context(cash_transfer_skip_pair=True).unlink()
        return res

    def action_open_cash_transfer_pair(self):
        self.ensure_one()
        return {
            'name': _("Other Side of the Transfer"),
            'type': 'ir.actions.act_window',
            'res_model': 'account.payment',
            'view_mode': 'form',
            'res_id': self.paired_internal_transfer_payment_id.id,
            'context': {'create': False},
        }

    def action_print_cash_transfer(self):
        return self.env.ref('cash_internal_transfer.action_report_cash_transfer').report_action(self)
