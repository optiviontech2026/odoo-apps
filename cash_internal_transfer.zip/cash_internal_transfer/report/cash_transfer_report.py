from odoo import _, api, models
from odoo.exceptions import UserError


class ReportCashTransfer(models.AbstractModel):
    _name = 'report.cash_internal_transfer.report_cash_transfer'
    _description = "Cash Transfer Voucher"

    @api.model
    def _get_report_values(self, docids, data=None):
        docs = self.env['account.payment'].browse(docids)
        not_transfers = docs.filtered(lambda p: not p.is_cash_transfer)
        if not_transfers:
            raise UserError(_(
                "The Cash Transfer Voucher can only be printed for cash internal transfers. "
                "Not a transfer: %(payments)s",
                payments=", ".join(p.display_name for p in not_transfers),
            ))
        return {
            'doc_ids': docs.ids,
            'doc_model': 'account.payment',
            'docs': docs,
            'data': data,
        }
