# Customer Return Orders (Odoo 19)

Technical name: `customer_return_order` · Version `19.0.1.2.0` · License LGPL-3
Depends on: `sale_management`, `sale_stock` (so Sales, Inventory, Accounting)

Menu: **Sales → Orders → Customer Returns**
Configuration: **Sales → Configuration → Return Reasons**

Workflow: **Draft Return → Confirm Return → Receive Returned Products → Create Credit Note**

---

## 1. Installation

1. Copy the `customer_return_order` folder into an addons path of your Odoo 19 server
   (for Odoo.sh: commit it to your repository).
2. Restart the Odoo service.
3. Activate developer mode, then **Apps → Update Apps List**.
4. Search for **Customer Return Orders** and click **Activate**.

Server requirements (standard Odoo requirements, nothing specific to this module):

* `wkhtmltopdf` 0.12.6 **with patched Qt** for PDF headers and footers.
* `rtlcss` (`npm install -g rtlcss`) so that Arabic and other right-to-left languages get
  mirrored layouts, in the web client and in PDFs.

**Upgrading from an earlier version**: replace the folder, restart, and upgrade the module.
From 19.0.1.0.0 (single original sales order), a migration script moves each existing return's
sales order into the new *Original Sales Orders* field. Existing receipts and credit notes are
not changed; the single receipt and single credit note apply to returns confirmed and credited
after the upgrade.

Run the automated tests (50 tests):

```bash
odoo-bin -c odoo.conf -d <test_db> -i customer_return_order --test-enable \
         --test-tags /customer_return_order --stop-after-init
```

## 2. Configuration

Everything comes from the standard configuration; the module adds no return policy of its own.

* **Return destination**: Inventory → Configuration → Operation Types → *Delivery Orders* →
  **Type of Operation for Returns**, and the default destination location of that return type.
  This is what the standard Return button uses, and so does this module.
* **Return reasons**: Sales → Configuration → Return Reasons (translatable, can be archived).
* **Sequence**: `SRO/<year>/00001`, editable in Settings → Technical → Sequences
  (code `customer.return.order`).
* Product type, invoicing policy, tracking (lots/serials), units of measure, taxes, fiscal
  positions, accounts and valuation are all read from the standard product, category,
  partner and company settings.

## 3. Usage

### 3.1 Create the return (Sales user)
1. Sales → Orders → Customer Returns → **New** (or open the sales order and use the
   **Returns** smart button once a return exists).
2. Select the **Customer** and one or more **Original Sales Orders** of that customer (or pick
   the orders first). The invoice address, return pickup address, salesperson, team and
   currency are filled from the oldest selected order; the warehouse and pricelist are shown
   when all orders share them. **Customer Invoices** lists the invoices of all the selected
   orders.
3. Click **Add Products**. The wizard lists every completed delivery of the selected orders
   with the order, the delivered quantity, the lots/serial numbers and the quantity still
   returnable (previous returns deducted). Enter the quantities, or click **Return All**, then
   **Add to Return**. Lines can also be added directly in the list: choose the original order
   line; when it was delivered in one transfer, the delivered move is proposed automatically.
   Removing an order from the header removes its lines.
4. Prices, discounts, taxes and units come from the original order lines. Set the return
   reason, terms and internal notes, then **Confirm Return**.

### 3.2 Receive the products (Inventory user)
* Confirming creates **one return receipt for all the selected orders and deliveries**, from
  the customer location to the configured return destination. Each delivery goes through the
  standard return wizard, and its returned moves are added to the same receipt with the
  wizard's own line processing (the method Odoo's exchange feature uses). Every returned move
  stays linked to its own delivered move, uses the delivered lots/serial numbers, and decreases
  the delivered quantity of its sales order line (standard *Update quantities on SO* flag).
* One receipt cannot be received into two warehouses: when the orders were delivered from
  different warehouses (different return operation type or destination), one receipt per
  warehouse is created.
* **Receive Products** opens the pending receipt; validate it as usual, partially if needed.
  Backorders stay linked to the return. The **Receipts** smart button lists all receipts and
  backorders.
* Status: Confirmed → Partially Received → Received. Cancelling a receipt backorder moves the
  return to Received with the quantity actually received.

### 3.3 Create the credit note (Accounting user with Invoicing rights)
* **Create Credit Note** appears once a receipt is validated and some received quantity can be
  credited. Each line shows **Credited**, **To Credit** and a **Credit Eligibility** explanation.
* The credit note is created with the standard **Credit Note** (reversal) of the original
  invoice, in **draft**, then reduced to the returned lines and quantities. It keeps the
  invoice prices, discounts, taxes, fiscal position, currency, accounts, analytic distribution
  and sales order links.
* **One credit note covers all the invoices of the selected orders**: the most recent invoice
  is reversed with the standard wizard and the returned lines of the other invoices are added
  with their own prices, discounts, taxes and accounts. Invoices are combined under the same
  rule Odoo uses to put several sales orders on one invoice: same company, invoice address,
  delivery address, currency and fiscal position, plus the same journal. Invoices that differ
  get their own credit note.
* An Odoo credit note can reverse only one invoice, so when several invoices are combined the
  *Reversal of* field stays empty; the reference lists every invoice, each credit note line
  records the invoice line it credits, and each invoice gets a chatter note.
* Review and post it as any credit note. Stock valuation and COGS entries are produced by the
  standard flows when the receipt is validated and the credit note is posted.
* Credit status: Nothing to Credit → To Credit → Partially Credited → Fully Credited.

### 3.4 Cancelling
* A draft or confirmed return can be cancelled while nothing has been received; pending
  receipts are cancelled and logged in the chatter.
* Once products are received, or while a non-cancelled credit note exists, cancellation is
  refused. Validated receipts and posted entries are never cancelled or deleted automatically;
  use the standard Return button on the receipt or the standard credit note reversal instead.
* After confirmation the customer, addresses, original orders, company, currency, pricelist,
  warehouse, date and all line products/quantities/prices are locked (in the view and on the
  server). Salesperson, sales team, return reason, terms and internal notes stay editable.

## 4. Quantity rules (all enforced server-side)

| Quantity | Rule |
|---|---|
| Return quantity | ≤ delivered quantity of the delivered move − all non-cancelled returns of that move (standard returns, other return orders, backorders). Checked when saving and again, under a row lock, at confirmation. |
| Received | Validated return receipts − validated returns of those receipts, in the line unit. |
| Credited | Lines of **draft and posted** credit notes linked to the return line; cancelled credit notes are ignored, so cancelling a draft credit note frees the quantity. |
| To Credit | min(received − credited, creditable quantity of the original order line). |
| Creditable quantity of an order line | Posted invoice quantity − all non-cancelled credit notes of that line (any origin). For products **invoiced on delivered quantities**, only the part invoiced above the delivered quantity, i.e. what the sales order itself would refund (negative quantity to invoice). |

Duplicate credits are prevented by recomputing from the linked documents at every click and by
locking the return order and the original order lines (`FOR UPDATE NOWAIT`): a second
simultaneous click gets a clear message instead of a second credit note.

## 5. Security

| Role | Rights |
|---|---|
| Sales / User: Own Documents | Create, edit and confirm their own returns (record rule on salesperson, like sales orders). Can confirm returns without Inventory rights: the module grants this group access to the standard return wizard, the same way `sale_stock` already lets sales users create transfers. Remove the last two lines of `security/ir.model.access.csv` if confirmation must require Inventory rights. |
| Sales / User: All Documents | All returns of their companies. |
| Sales / Administrator | All returns, can delete draft or cancelled returns, manages return reasons. |
| Inventory / User | Read all returns of their companies; validates receipts with standard rights. |
| Accounting / Invoicing (Billing) and above | Read all returns; only these users can create credit notes. Posting follows standard Accounting rights. |

Multi-company record rules restrict returns and lines to the user's allowed companies, and all
relational fields are company-checked.

## 6. Assumptions and requirements that standard Odoo cannot satisfy as stated

1. **Products invoiced on ordered quantities.** The credit note is the standard reversal of the
   invoice, which keeps the link to the sales order line (exactly like the invoice's own
   *Credit Note* button). Odoo therefore lowers the invoiced quantity, and the sales order shows
   the credited quantity as *to invoice* again. This is standard behaviour for this invoicing
   policy; the module does not change it. If the goods will not be re-delivered, reduce the
   ordered quantity on the sales order. Products invoiced on delivered quantities stay
   consistent (delivered = invoiced).
   For both policies, the standard return lowers the delivered quantity, so the sales order
   shows the returned quantity as not delivered; no new delivery is created automatically.
2. **A delivered move is required.** Every line must reference a completed delivery of the
   original order, because the standard return mechanism works against a delivery. Returns of
   goods that were never delivered through Odoo are not supported.
3. **Not supported, blocked with an explanation:** services (as requested: they need a separate
   credit-only process), kits delivered as components (manufacturing BoM type *Kit*), and
   dropshipped deliveries.
4. **Return destination.** The receipt uses the return operation type of the original delivery
   and its destination; choosing another warehouse on the return is not offered, because the
   standard return mechanism does not support it.
5. **Prices.** The return order shows the original order line prices; the credit note uses the
   original invoice line prices (they are the same unless the invoice was edited).
6. **Several invoices for the same order line** (e.g. delivered quantities invoiced in several
   steps): quantities are credited against the most recent posted invoice first. Only posted
   invoices are credited; if the invoice is still a draft, the line explains that the draft
   should be corrected instead.
7. **Down payments and other invoice lines** are not part of the credit note; only the returned
   product lines are kept.
8. Two draft returns may each request the same remaining quantity; the second one is refused
   when it is confirmed.
9. **Several original sales orders on one return** must share the same customer (commercial
   entity), company and currency, because the return has one customer, one company and its
   totals are in one currency. Orders in another currency need a separate return. Orders from
   different warehouses are allowed but get one receipt per warehouse.
10. **Transfers smart button of the sales orders.** Odoo links a transfer to one sales order, so
    a receipt shared by several orders appears under the first order's *Delivery* button only.
    The quantities of every order are still updated through the returned moves, and the
    receipt is reachable from the return's *Receipts* button and from each order's *Returns*
    button.

## 7. Technical overview

| Area | Implementation |
|---|---|
| Original orders | `customer.return.order.sale_order_ids` (many2many, relation `customer_return_order_sale_order_rel`, inverse `sale.order.customer_return_ids`); each line stores its `sale_order_id` |
| Models | `customer.return.order`, `customer.return.order.line`, `customer.return.reason`, wizard `customer.return.order.add.products` |
| Inventory | `stock.return.picking` (standard wizard) per delivery; first delivery via `action_create_returns`, the others added to the same receipt with `stock.return.picking.line._process_line`; hooks add `customer_return_line_id` to the return moves; backorders keep the link through `_prepare_move_split_vals` |
| Accounting | `account.move.reversal` (standard wizard) on the most recent invoice of each group, other invoices' lines added from their invoice lines; grouping keys from `sale.order._get_invoice_grouping_keys()` + journal |
| Links | `stock.move.customer_return_line_id`, `stock.picking.customer_return_order_id` (stored, computed from moves), `account.move.customer_return_order_id`, `account.move.line.customer_return_line_id`, `account.move.line.customer_return_origin_line_id` (credited invoice line) |
| Statuses | `state` and `credit_status` are stored and computed from the linked moves and credit notes |
| Report | QWeb PDF *Customer Return Order*, same layout as the sales order report, RTL-ready |
| Translations | `i18n/customer_return_order.pot` and a complete Arabic translation `i18n/ar.po` |
| Tests | `tests/`: 50 tests covering the workflow, several original orders with one receipt and one credit note (and the warehouse and invoice-address splits), partial receipts and backorders, multiple deliveries, lots and serials, units of measure, previous returns and credits, uninvoiced and draft invoices, both invoicing policies, fiscal positions, foreign currency, several invoices, cancellation, locking, permissions, multi-company and duplicate prevention |
