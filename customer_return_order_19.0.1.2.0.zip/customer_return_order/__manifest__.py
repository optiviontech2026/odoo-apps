{
    'name': 'Customer Return Orders',
    'version': '19.0.1.2.0',
    'category': 'Sales/Sales',
    'summary': 'Customer returns: standard return receipts against the original '
               'deliveries, then draft credit notes against the original invoices',
    'description': """
Customer Return Orders
======================

Workflow: Draft Return -> Confirm Return -> Receive Returned Products -> Create Credit Note

* A return order references one or more original sales orders of the same customer,
  their delivery moves and their invoices.
* Confirmation creates one receipt for all the selected orders with the standard Inventory
  return mechanism (stock.return.picking) of each original delivery, so returned moves keep
  their link to the delivered moves, lots/serial numbers, routes and the warehouse return type.
* One draft credit note for all the invoices, based on the standard Accounting reversal
  (account.move.reversal), keeping the original prices, discounts, taxes, fiscal position,
  currency and sales order links.
* Quantities are validated server-side against delivered, previously returned,
  received, invoiced and previously credited quantities.
""",
    'author': 'Optivion Tech',
    'license': 'LGPL-3',
    'depends': ['sale_management', 'sale_stock'],
    'data': [
        'security/ir.model.access.csv',
        'security/customer_return_security.xml',
        'data/ir_sequence_data.xml',
        'data/customer_return_reason_data.xml',
        'report/customer_return_order_report.xml',
        'report/customer_return_order_templates.xml',
        'wizard/customer_return_add_products_views.xml',
        'views/customer_return_reason_views.xml',
        'views/customer_return_order_views.xml',
        'views/sale_order_views.xml',
        'views/stock_picking_views.xml',
        'views/account_move_views.xml',
        'views/customer_return_menus.xml',
    ],
    'installable': True,
    'application': False,
}
