from odoo.tools.sql import column_exists


def migrate(cr, version):
    """19.0.1.0.0 had a single 'Original Sales Order' (sale_order_id); copy it into the
    new 'Original Sales Orders' many2many relation."""
    if not version or not column_exists(cr, 'customer_return_order', 'sale_order_id'):
        return
    cr.execute("""
        INSERT INTO customer_return_order_sale_order_rel (return_order_id, sale_order_id)
             SELECT id, sale_order_id
               FROM customer_return_order
              WHERE sale_order_id IS NOT NULL
        ON CONFLICT DO NOTHING
    """)
