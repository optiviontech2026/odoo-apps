from odoo import fields, models


class AccountMove(models.Model):
    _inherit = 'account.move'

    customer_return_order_id = fields.Many2one(
        'customer.return.order', string='Customer Return Order', index='btree_not_null',
        readonly=True, copy=False, check_company=True)

    def action_view_customer_return_order(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'customer.return.order',
            'view_mode': 'form',
            'res_id': self.customer_return_order_id.id,
        }


class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    customer_return_line_id = fields.Many2one(
        'customer.return.order.line', string='Customer Return Line', index='btree_not_null',
        readonly=True, copy=False)
    customer_return_origin_line_id = fields.Many2one(
        'account.move.line', string='Credited Invoice Line', index='btree_not_null',
        readonly=True, copy=False,
        help="Original invoice line credited by this credit note line (customer returns).")
