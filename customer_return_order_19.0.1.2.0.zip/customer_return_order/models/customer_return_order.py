from collections import defaultdict

import psycopg2
from markupsafe import Markup

from odoo import _, api, fields, models
from odoo.exceptions import AccessError, UserError, ValidationError
from odoo.fields import Command
from odoo.tools import SQL, mute_logger

RETURN_STATES = [
    ('draft', 'Draft'),
    ('confirmed', 'Confirmed'),
    ('partial', 'Partially Received'),
    ('received', 'Received'),
    ('cancel', 'Cancelled'),
]

CREDIT_STATES = [
    ('nothing', 'Nothing to Credit'),
    ('to_credit', 'To Credit'),
    ('partial', 'Partially Credited'),
    ('credited', 'Fully Credited'),
]

# Header fields that cannot change once the return is confirmed.
LOCKED_ORDER_FIELDS = {
    'partner_id', 'partner_invoice_id', 'partner_shipping_id', 'sale_order_ids',
    'company_id', 'currency_id', 'pricelist_id', 'warehouse_id', 'date_return',
}


class CustomerReturnOrder(models.Model):
    _name = 'customer.return.order'
    _description = 'Customer Return Order'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'date_return desc, id desc'
    _check_company_auto = True
    _mail_post_access = 'read'

    # ------------------------------------------------------------------
    # Fields
    # ------------------------------------------------------------------
    name = fields.Char(
        string='Return Reference', required=True, copy=False, readonly=True,
        index='trigram', default=lambda self: _('New'))
    company_id = fields.Many2one(
        'res.company', string='Company', required=True, index=True,
        default=lambda self: self.env.company)
    sale_order_ids = fields.Many2many(
        'sale.order', 'customer_return_order_sale_order_rel', 'return_order_id', 'sale_order_id',
        string='Original Sales Orders', required=True, check_company=True, copy=True,
        domain="[('state', '=', 'sale'), ('partner_id.commercial_partner_id', '=', commercial_partner_id)] "
               "if commercial_partner_id else [('state', '=', 'sale')]",
        help="Confirmed sales orders of the customer whose delivered products are returned. "
             "All orders must belong to the same customer, company and currency.")
    sale_order_count = fields.Integer(compute='_compute_sale_order_count')
    partner_id = fields.Many2one(
        'res.partner', string='Customer', required=True, index=True, tracking=True,
        check_company=True, compute='_compute_partner_id', store=True, readonly=False,
        precompute=True)
    commercial_partner_id = fields.Many2one(related='partner_id.commercial_partner_id')
    partner_invoice_id = fields.Many2one(
        'res.partner', string='Invoice Address', required=True, check_company=True,
        compute='_compute_partner_addresses', store=True, readonly=False, precompute=True,
        tracking=True)
    partner_shipping_id = fields.Many2one(
        'res.partner', string='Return Pickup Address', required=True, check_company=True,
        compute='_compute_partner_addresses', store=True, readonly=False, precompute=True,
        tracking=True,
        help="Address where the returned goods are collected. It is set as the partner "
             "of the return receipts.")
    date_return = fields.Date(
        string='Return Date', required=True, copy=False, tracking=True,
        default=fields.Date.context_today)
    user_id = fields.Many2one(
        'res.users', string='Salesperson', index=True, tracking=True,
        compute='_compute_user_id', store=True, readonly=False, precompute=True,
        domain="[('share', '=', False), ('company_ids', 'in', company_id)]")
    team_id = fields.Many2one(
        'crm.team', string='Sales Team', index=True, tracking=True, check_company=True,
        compute='_compute_team_id', store=True, readonly=False, precompute=True)
    warehouse_id = fields.Many2one(
        'stock.warehouse', string='Warehouse', check_company=True,
        compute='_compute_from_sale_order', store=True, precompute=True,
        help="Warehouse of the original sales orders (empty when they come from several "
             "warehouses). Each return receipt uses the return operation type configured on the "
             "operation type of its original delivery.")
    currency_id = fields.Many2one(
        'res.currency', string='Currency', required=True,
        compute='_compute_from_sale_order', store=True, precompute=True)
    pricelist_id = fields.Many2one(
        'product.pricelist', string='Pricelist', check_company=True,
        compute='_compute_from_sale_order', store=True, precompute=True,
        help="Pricelist of the original sales orders (empty when they use different "
             "pricelists). Return prices are copied from the original order lines; they are "
             "not recomputed from the pricelist.")
    invoice_ids = fields.Many2many(
        'account.move', string='Customer Invoices', compute='_compute_invoice_ids',
        help="Customer invoices of all the original sales orders.")
    invoice_count = fields.Integer(compute='_compute_invoice_ids')
    return_reason_id = fields.Many2one(
        'customer.return.reason', string='Return Reason', tracking=True)
    internal_note = fields.Html(string='Internal Notes')
    note = fields.Html(string='Terms and Conditions')

    order_line = fields.One2many(
        'customer.return.order.line', 'order_id', string='Return Lines', copy=True)

    workflow_state = fields.Selection(
        [('draft', 'Draft'), ('confirmed', 'Confirmed'), ('cancel', 'Cancelled')],
        string='Workflow State', required=True, default='draft', copy=False,
        readonly=True, index=True)
    state = fields.Selection(
        RETURN_STATES, string='Status', compute='_compute_state', store=True,
        index=True, tracking=True, copy=False, readonly=True)
    credit_status = fields.Selection(
        CREDIT_STATES, string='Credit Status', compute='_compute_credit_status',
        store=True, index=True, tracking=True, copy=False, readonly=True)

    picking_ids = fields.One2many(
        'stock.picking', 'customer_return_order_id', string='Receipts', readonly=True)
    picking_count = fields.Integer(string='Receipt Count', compute='_compute_picking_count')
    has_pending_receipt = fields.Boolean(compute='_compute_picking_count')
    credit_note_ids = fields.One2many(
        'account.move', 'customer_return_order_id', string='Credit Notes', readonly=True)
    credit_note_count = fields.Integer(compute='_compute_credit_note_count')
    can_create_credit_note = fields.Boolean(compute='_compute_can_create_credit_note')

    amount_untaxed = fields.Monetary(
        string='Untaxed Amount', compute='_compute_amounts', store=True, tracking=True)
    amount_tax = fields.Monetary(string='Taxes', compute='_compute_amounts', store=True)
    amount_total = fields.Monetary(
        string='Total', compute='_compute_amounts', store=True, tracking=True)
    tax_totals = fields.Binary(compute='_compute_tax_totals', exportable=False)
    company_price_include = fields.Selection(related='company_id.account_price_include')

    # ------------------------------------------------------------------
    # Computes
    # ------------------------------------------------------------------
    @api.depends('sale_order_ids')
    def _compute_sale_order_count(self):
        for order in self:
            order.sale_order_count = len(order.sale_order_ids)

    def _cro_main_sale_order(self):
        """First original sales order of the customer: source of the default header values."""
        self.ensure_one()
        orders = self.sale_order_ids.sorted(lambda so: (so.date_order, so._origin.id or 0))
        if self.partner_id:
            same_customer = orders.filtered(
                lambda so: so.partner_id.commercial_partner_id == self.partner_id.commercial_partner_id)
            orders = same_customer or orders
        return orders[:1]

    @staticmethod
    def _cro_common_value(records):
        """The single value shared by all `records`, or an empty recordset."""
        return records if len(records) == 1 else records[:0]

    @api.depends('sale_order_ids')
    def _compute_partner_id(self):
        for order in self:
            main = order._cro_main_sale_order()
            if main and main.partner_id.commercial_partner_id != order.partner_id.commercial_partner_id:
                order.partner_id = main.partner_id

    @api.depends('partner_id', 'sale_order_ids')
    def _compute_partner_addresses(self):
        for order in self:
            sale = order._cro_main_sale_order()
            if sale and sale.partner_id.commercial_partner_id == order.partner_id.commercial_partner_id:
                order.partner_invoice_id = sale.partner_invoice_id
                order.partner_shipping_id = sale.partner_shipping_id
            elif order.partner_id:
                addresses = order.partner_id.address_get(['invoice', 'delivery'])
                order.partner_invoice_id = addresses['invoice']
                order.partner_shipping_id = addresses['delivery']
            else:
                order.partner_invoice_id = False
                order.partner_shipping_id = False

    @api.depends('sale_order_ids')
    def _compute_user_id(self):
        for order in self:
            order.user_id = order._cro_main_sale_order().user_id or order.user_id or self.env.user

    @api.depends('sale_order_ids', 'user_id')
    def _compute_team_id(self):
        for order in self:
            main_team = order._cro_main_sale_order().team_id
            if main_team:
                order.team_id = main_team
            elif not order.team_id:
                order.team_id = self.env['crm.team']._get_default_team_id(
                    user_id=order.user_id.id,
                    domain=self.env['crm.team']._check_company_domain(order.company_id.id),
                )

    @api.depends('sale_order_ids', 'company_id')
    def _compute_from_sale_order(self):
        for order in self:
            sales = order.sale_order_ids
            order.warehouse_id = self._cro_common_value(sales.warehouse_id)
            order.pricelist_id = self._cro_common_value(sales.pricelist_id)
            order.currency_id = order._cro_main_sale_order().currency_id \
                or order.company_id.currency_id or self.env.company.currency_id

    @api.depends('sale_order_ids.invoice_ids.state', 'sale_order_ids.invoice_ids.move_type')
    def _compute_invoice_ids(self):
        for order in self:
            invoices = order.sale_order_ids.invoice_ids.filtered(
                lambda m: m.move_type == 'out_invoice' and m.state != 'cancel')
            order.invoice_ids = invoices
            order.invoice_count = len(invoices)

    @api.depends('picking_ids.state')
    def _compute_picking_count(self):
        for order in self:
            order.picking_count = len(order.picking_ids)
            order.has_pending_receipt = any(
                picking.state not in ('done', 'cancel') and picking.picking_type_code == 'incoming'
                for picking in order.picking_ids)

    @api.depends('credit_note_ids')
    def _compute_credit_note_count(self):
        for order in self:
            order.credit_note_count = len(order.credit_note_ids)

    @api.depends('state', 'order_line.qty_to_credit')
    def _compute_can_create_credit_note(self):
        for order in self:
            order.can_create_credit_note = order.state in ('partial', 'received') and any(
                not line.product_uom_id.is_zero(line.qty_to_credit) and line.qty_to_credit > 0
                for line in order.order_line)

    @api.depends('workflow_state', 'order_line.qty_received', 'order_line.product_uom_qty',
                 'order_line.move_ids.state')
    def _compute_state(self):
        for order in self:
            if order.workflow_state in ('draft', 'cancel'):
                order.state = order.workflow_state
                continue
            lines = order.order_line
            received_any = any(line.qty_received > 0 and not line.product_uom_id.is_zero(line.qty_received)
                               for line in lines)
            all_received = bool(lines) and all(
                line.product_uom_id.compare(line.qty_received, line.product_uom_qty) >= 0 for line in lines)
            pending = any(line._cro_get_pending_receipt_moves() for line in lines)
            if all_received or (received_any and not pending):
                order.state = 'received'
            elif received_any:
                order.state = 'partial'
            else:
                order.state = 'confirmed'

    @api.depends('state', 'order_line.qty_credited', 'order_line.qty_to_credit',
                 'order_line.qty_received', 'order_line.move_ids.state')
    def _compute_credit_status(self):
        for order in self:
            lines = order.order_line
            if order.state in ('draft', 'cancel') or not lines:
                order.credit_status = 'nothing'
                continue
            credited = any(line.qty_credited > 0 and not line.product_uom_id.is_zero(line.qty_credited)
                           for line in lines)
            to_credit = any(line.qty_to_credit > 0 and not line.product_uom_id.is_zero(line.qty_to_credit)
                            for line in lines)
            if not credited:
                order.credit_status = 'to_credit' if to_credit else 'nothing'
            elif to_credit or any(line._cro_expects_more_credit() for line in lines):
                order.credit_status = 'partial'
            else:
                order.credit_status = 'credited'

    def _cro_prepare_base_lines(self):
        self.ensure_one()
        return [line._prepare_base_line_for_taxes_computation() for line in self.order_line]

    @api.depends('order_line.price_subtotal', 'order_line.price_total', 'currency_id', 'company_id')
    def _compute_amounts(self):
        AccountTax = self.env['account.tax']
        for order in self:
            base_lines = order._cro_prepare_base_lines()
            AccountTax._add_tax_details_in_base_lines(base_lines, order.company_id)
            AccountTax._round_base_lines_tax_details(base_lines, order.company_id)
            totals = AccountTax._get_tax_totals_summary(
                base_lines=base_lines,
                currency=order.currency_id or order.company_id.currency_id,
                company=order.company_id,
            )
            order.amount_untaxed = totals['base_amount_currency']
            order.amount_tax = totals['tax_amount_currency']
            order.amount_total = totals['total_amount_currency']

    @api.depends_context('lang')
    @api.depends('order_line.price_subtotal', 'order_line.price_total', 'currency_id', 'company_id')
    def _compute_tax_totals(self):
        AccountTax = self.env['account.tax']
        for order in self:
            base_lines = order._cro_prepare_base_lines()
            AccountTax._add_tax_details_in_base_lines(base_lines, order.company_id)
            AccountTax._round_base_lines_tax_details(base_lines, order.company_id)
            order.tax_totals = AccountTax._get_tax_totals_summary(
                base_lines=base_lines,
                currency=order.currency_id or order.company_id.currency_id,
                company=order.company_id,
            )

    # ------------------------------------------------------------------
    # Constraints
    # ------------------------------------------------------------------
    @api.constrains('sale_order_ids', 'partner_id', 'company_id', 'currency_id')
    def _check_sale_orders(self):
        for order in self:
            if not order.sale_order_ids:
                raise ValidationError(self.env._(
                    "Select at least one original sales order for return %(ret)s.", ret=order.name))
            for sale in order.sale_order_ids:
                if sale.company_id != order.company_id:
                    raise ValidationError(self.env._(
                        "The original sales order %(order)s belongs to another company.",
                        order=sale.display_name))
                if sale.partner_id.commercial_partner_id != order.partner_id.commercial_partner_id:
                    raise ValidationError(self.env._(
                        "All original sales orders of return %(ret)s must belong to its customer "
                        "%(customer)s: %(order)s belongs to %(other)s.",
                        ret=order.name, customer=order.partner_id.commercial_partner_id.display_name,
                        order=sale.display_name, other=sale.partner_id.commercial_partner_id.display_name))
                if sale.currency_id != order.currency_id:
                    raise ValidationError(self.env._(
                        "All original sales orders of return %(ret)s must use the same currency "
                        "(%(currency)s): %(order)s is in %(other)s. Create a separate return for it.",
                        ret=order.name, currency=order.currency_id.name,
                        order=sale.display_name, other=sale.currency_id.name))

    # ------------------------------------------------------------------
    # ORM
    # ------------------------------------------------------------------
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', _('New')) == _('New'):
                company = self.env['res.company'].browse(vals.get('company_id')) or self.env.company
                seq_date = fields.Date.to_date(vals.get('date_return')) or fields.Date.context_today(self)
                vals['name'] = self.env['ir.sequence'].with_company(company).next_by_code(
                    'customer.return.order', sequence_date=seq_date) or _('New')
        return super().create(vals_list)

    def write(self, vals):
        locked = LOCKED_ORDER_FIELDS & set(vals)
        if locked:
            for order in self:
                if order.state == 'draft':
                    continue
                changed = [
                    order._fields[fname].get_description(self.env)['string']
                    for fname in locked
                    if order._fields[fname].type == 'many2many'
                    or order._fields[fname].convert_to_cache(vals[fname], order, validate=False)
                    != order._fields[fname].convert_to_cache(order[fname], order, validate=False)
                ]
                if changed:
                    raise UserError(self.env._(
                        "Return %(ret)s is no longer a draft: the following fields cannot be "
                        "changed anymore: %(fields)s.", ret=order.name, fields=', '.join(changed)))
        return super().write(vals)

    @api.ondelete(at_uninstall=False)
    def _unlink_except_processed(self):
        for order in self:
            if order.state not in ('draft', 'cancel'):
                raise UserError(self.env._(
                    "You can only delete draft or cancelled return orders. Cancel %(ret)s first.",
                    ret=order.name))
            if any(move.state == 'done' for move in order.order_line.move_ids) or order.credit_note_ids:
                raise UserError(self.env._(
                    "Return %(ret)s is linked to validated receipts or credit notes and cannot be deleted.",
                    ret=order.name))

    @api.onchange('sale_order_ids')
    def _onchange_sale_order_ids(self):
        selected = self.sale_order_ids._origin
        orphans = self.order_line.filtered(
            lambda line: line.sale_line_id and line.sale_line_id.order_id._origin not in selected)
        if orphans:
            self.order_line -= orphans
            return {'warning': {
                'title': self.env._("Return lines removed"),
                'message': self.env._(
                    "The return lines of the sales orders you removed have been removed too: %(products)s",
                    products=', '.join(orphans.product_id.mapped('display_name'))),
            }}

    # ------------------------------------------------------------------
    # Actions: confirmation and receipts
    # ------------------------------------------------------------------
    def action_open_add_products(self):
        self.ensure_one()
        if self.state != 'draft':
            raise UserError(self.env._("Products can only be added to draft return orders."))
        if not self.sale_order_ids:
            raise UserError(self.env._("Select the original sales orders first."))
        return {
            'type': 'ir.actions.act_window',
            'name': self.env._("Select Products to Return"),
            'res_model': 'customer.return.order.add.products',
            'view_mode': 'form',
            'target': 'new',
            'context': {'default_order_id': self.id},
        }

    def action_confirm(self):
        for order in self:
            if order.state != 'draft':
                raise UserError(self.env._("Only draft return orders can be confirmed (%(ret)s).", ret=order.name))
            order._cro_check_before_confirm()
        # Serialize concurrent confirmations on the same delivered moves, then re-check
        # the remaining returnable quantities with the lock held.
        self._cro_lock_rows('stock_move', self.order_line.origin_move_id.ids, self.env._(
            "Another return is currently being processed for the same deliveries. Please try again."))
        self.order_line._cro_check_returnable_qty()
        for order in self:
            pickings = order._cro_create_return_pickings()
            order.workflow_state = 'confirmed'
            order.message_post(body=self.env._(
                "Return confirmed. Return receipts created: %(receipts)s",
                receipts=Markup(', ').join(picking._get_html_link() for picking in pickings)))
        return True

    def _cro_check_before_confirm(self):
        self.ensure_one()
        if not self.order_line:
            raise UserError(self.env._("Add at least one product to return before confirming %(ret)s.", ret=self.name))
        not_confirmed = self.sale_order_ids.filtered(lambda so: so.state != 'sale')
        if not_confirmed:
            raise UserError(self.env._(
                "These original sales orders are not confirmed sales orders: %(orders)s",
                orders=', '.join(not_confirmed.mapped('display_name'))))
        zero_lines = self.order_line.filtered(lambda l: l.product_uom_qty <= 0 or l.product_uom_id.is_zero(l.product_uom_qty))
        if zero_lines:
            raise UserError(self.env._(
                "Set a return quantity for every line or remove the lines with no quantity: %(products)s",
                products=', '.join(zero_lines.product_id.mapped('display_name'))))
        self.order_line._cro_check_line_consistency()

    def _cro_create_return_pickings(self):
        """Create the return receipt with the standard return wizard.

        Every original delivery gets its own standard return wizard, so that each returned
        move is linked to its delivered move (origin_returned_move_id / move_orig_ids), reuses
        the delivered lots/serial numbers and decreases the delivered quantity of its sales
        order line. The returned moves of all deliveries are put in ONE receipt with the
        wizard's own ``_process_line`` (the method the standard exchange uses to fill an
        existing transfer). Deliveries can only share a receipt when their returns have the
        same operation type, source and destination locations; otherwise (e.g. orders
        shipped from different warehouses) one receipt per warehouse/destination is created.
        """
        self.ensure_one()
        lines_by_picking = defaultdict(lambda: self.env['customer.return.order.line'])
        for line in self.order_line.sorted(lambda l: (l.origin_move_id.date, l.origin_move_id.id)):
            lines_by_picking[line.origin_move_id.picking_id] |= line
        receipts = {}
        deliveries_by_receipt = defaultdict(lambda: self.env['stock.picking'])
        for delivery, lines in lines_by_picking.items():
            if not delivery:
                raise UserError(self.env._(
                    "The delivered move of %(product)s has no transfer and cannot be returned with the "
                    "standard return mechanism.", product=lines[0].product_id.display_name))
            wizard = self._cro_prepare_return_wizard(delivery, lines)
            picking_vals = wizard._prepare_picking_default_values()
            key = (picking_vals['picking_type_id'], picking_vals['location_id'], picking_vals['location_dest_id'])
            receipt = receipts.get(key)
            if not receipt:
                action = wizard.action_create_returns()
                receipts[key] = self.env['stock.picking'].browse(action['res_id'])
            else:
                for return_move in wizard.product_return_moves.move_id:
                    return_move.move_dest_ids.filtered(
                        lambda m: m.state not in ('done', 'cancel'))._do_unreserve()
                for wizard_line in wizard.product_return_moves:
                    wizard_line._process_line(receipt)
                receipt.action_confirm()
                receipt.action_assign()
                receipt.message_post_with_source(
                    'mail.message_origin_link',
                    render_values={'self': receipt, 'origin': delivery},
                    subtype_xmlid='mail.mt_note',
                )
            deliveries_by_receipt[receipts[key]] |= delivery

        new_pickings = self.env['stock.picking']
        for receipt, deliveries in deliveries_by_receipt.items():
            picking_vals = {
                'origin': self.env._(
                    "%(ret)s - Return of %(deliveries)s",
                    ret=self.name, deliveries=', '.join(deliveries.mapped('name'))),
            }
            if self.partner_shipping_id and receipt.partner_id != self.partner_shipping_id:
                picking_vals['partner_id'] = self.partner_shipping_id.id
            receipt.write(picking_vals)
            new_pickings |= receipt
        return new_pickings

    def _cro_prepare_return_wizard(self, delivery, lines):
        """Standard return wizard of `delivery` with the quantities of `lines`."""
        wizard = self.env['stock.return.picking'].with_context(
            active_model='stock.picking', active_id=delivery.id, active_ids=delivery.ids,
        ).create({
            'picking_id': delivery.id,
            'customer_return_order_id': self.id,
        })
        line_by_move = {line.origin_move_id: line for line in lines}
        missing = set(line_by_move) - set(wizard.product_return_moves.move_id)
        if missing:
            raise UserError(self.env._(
                "The delivery %(delivery)s cannot return %(products)s anymore.",
                delivery=delivery.name,
                products=', '.join(m.product_id.display_name for m in missing)))
        for wizard_line in wizard.product_return_moves:
            line = line_by_move.get(wizard_line.move_id)
            if line:
                wizard_line.write({
                    'quantity': line.product_uom_id._compute_quantity(
                        line.product_uom_qty, wizard_line.move_id.product_uom, rounding_method='HALF-UP'),
                    # Standard flag: decrease the delivered quantity of the sales order line.
                    'to_refund': True,
                    'customer_return_line_id': line.id,
                })
            else:
                wizard_line.quantity = 0.0
        return wizard

    def action_receive_products(self):
        self.ensure_one()
        pickings = self.picking_ids.filtered(
            lambda p: p.state not in ('done', 'cancel') and p.picking_type_code == 'incoming')
        if not pickings:
            raise UserError(self.env._("There is no return receipt waiting to be received."))
        return self._cro_action_view_pickings(pickings)

    def action_view_receipts(self):
        self.ensure_one()
        return self._cro_action_view_pickings(self.picking_ids)

    def _cro_action_view_pickings(self, pickings):
        action = self.env['ir.actions.act_window']._for_xml_id('stock.action_picking_tree_all')
        action['context'] = {'create': False}
        if len(pickings) == 1:
            action.update({
                'views': [(self.env.ref('stock.view_picking_form').id, 'form')],
                'res_id': pickings.id,
            })
        else:
            action['domain'] = [('id', 'in', pickings.ids)]
        return action

    def action_view_credit_notes(self):
        self.ensure_one()
        return self._cro_action_view_moves(self.credit_note_ids, 'account.action_move_out_refund_type')

    def action_view_invoices(self):
        self.ensure_one()
        return self._cro_action_view_moves(self.invoice_ids, 'account.action_move_out_invoice_type')

    def _cro_action_view_moves(self, moves, xmlid):
        action = self.env['ir.actions.act_window']._for_xml_id(xmlid)
        action['context'] = {'create': False}
        if len(moves) == 1:
            action.update({
                'views': [(self.env.ref('account.view_move_form').id, 'form')],
                'res_id': moves.id,
            })
        else:
            action['domain'] = [('id', 'in', moves.ids)]
        return action

    def action_view_sale_orders(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id('sale.action_orders')
        action['context'] = {'create': False}
        if len(self.sale_order_ids) == 1:
            action.update({
                'views': [(self.env.ref('sale.view_order_form').id, 'form')],
                'res_id': self.sale_order_ids.id,
            })
        else:
            action['domain'] = [('id', 'in', self.sale_order_ids.ids)]
        return action

    # ------------------------------------------------------------------
    # Actions: cancellation
    # ------------------------------------------------------------------
    def action_cancel(self):
        for order in self:
            if order.state == 'cancel':
                continue
            if any(move.state == 'done' for move in order.order_line.move_ids):
                raise UserError(self.env._(
                    "Return %(ret)s cannot be cancelled: returned products have already been received. "
                    "Validated receipts are never cancelled automatically; to undo a receipt, return the "
                    "products from the receipt with the standard Return button.", ret=order.name))
            if order.credit_note_ids.filtered(lambda m: m.state != 'cancel'):
                raise UserError(self.env._(
                    "Return %(ret)s cannot be cancelled: it has credit notes. Cancel or reverse them in "
                    "Accounting first.", ret=order.name))
            pending = order.picking_ids.filtered(lambda p: p.state not in ('done', 'cancel'))
            if pending:
                pending.action_cancel()
                order.message_post(body=self.env._(
                    "Pending return receipts cancelled: %(receipts)s",
                    receipts=', '.join(pending.mapped('name'))))
            order.workflow_state = 'cancel'
        return True

    def action_draft(self):
        for order in self:
            if order.state != 'cancel':
                raise UserError(self.env._("Only cancelled return orders can be set back to draft."))
            order.workflow_state = 'draft'
        return True

    # ------------------------------------------------------------------
    # Actions: credit notes
    # ------------------------------------------------------------------
    def action_create_credit_note(self):
        """Create ONE draft customer credit note for the received, invoiced and not yet
        credited quantities of all the original orders.

        The credit note is the standard reversal of an original invoice; the returned lines
        of the other invoices are added to it with their original prices, discounts, taxes,
        accounts and sales order links. Invoices are only combined when Odoo itself would
        combine those sales orders in one invoice (same company, invoice address, delivery
        address, currency and fiscal position) and use the same journal; otherwise one
        credit note per compatible group is created."""
        if not self.env.user.has_group('account.group_account_invoice'):
            raise AccessError(self.env._(
                "Only users with invoicing rights (Accounting / Invoicing) can create credit notes."))
        for order in self:
            if order.state not in ('partial', 'received'):
                raise UserError(self.env._(
                    "Credit notes can only be created once at least one return receipt of %(ret)s "
                    "has been validated.", ret=order.name))
        # Lock the return orders and the original sales order lines so that concurrent clicks
        # (or two returns of the same order line) cannot credit the same quantity twice.
        busy_message = self.env._(
            "A credit note is already being created for this return or for the same sales order "
            "lines. Please wait a moment and reload the page.")
        self._cro_lock_rows('customer_return_order', self.ids, busy_message)
        self._cro_lock_rows('sale_order_line', self.order_line.sale_line_id.ids, busy_message)
        refunds = self.env['account.move']
        for order in self:
            plan = order.order_line._cro_get_credit_plan()
            allocations_by_group = defaultdict(list)
            for line, allocations in plan.items():
                for invoice_line, qty in allocations:
                    key = order._cro_credit_note_grouping_key(invoice_line.move_id)
                    allocations_by_group[key].append((line, invoice_line, qty))
            if not allocations_by_group:
                raise UserError(order._cro_get_nothing_to_credit_message())
            for allocations in allocations_by_group.values():
                refunds |= order._cro_create_refund(allocations)
        if not refunds:
            raise UserError(self.env._("There is nothing left to credit."))
        return self._cro_action_view_moves(refunds, 'account.action_move_out_refund_type')

    @api.model
    def _cro_credit_note_grouping_key(self, invoice):
        """Invoices that may share one credit note: same keys as the standard grouping of
        several sales orders in one invoice, plus the journal."""
        fnames = self.env['sale.order']._get_invoice_grouping_keys() + ['journal_id', 'move_type']
        return tuple(invoice[fname] for fname in fnames if fname in invoice._fields)

    def _cro_get_nothing_to_credit_message(self):
        self.ensure_one()
        details = '\n'.join(
            '- %s: %s' % (line.product_id.display_name, line.credit_info or '')
            for line in self.order_line)
        return self.env._("Nothing can be credited for %(ret)s:\n%(details)s", ret=self.name, details=details)

    def _cro_create_refund(self, allocations):
        """Create one draft credit note for `allocations`.

        The most recent invoice is reversed with the standard wizard (header, journal,
        fiscal position, currency, payment terms, sales order links). Its copied lines are
        reduced to the returned quantities; the returned lines of the other invoices of the
        group are then added from their invoice lines. Each credit note line keeps the
        credited invoice line in ``customer_return_origin_line_id``.

        :param allocations: list of (return_line, invoice_line, qty in sale line UoM) whose
            invoices share the same grouping key.
        """
        self.ensure_one()
        invoices = self.env['account.move']
        for _line, invoice_line, _qty in allocations:
            invoices |= invoice_line.move_id
        invoices = invoices.sorted(lambda m: (m.invoice_date or m.date, m.id), reverse=True)
        invoice = invoices[0].with_company(invoices[0].company_id)
        reason = self.name
        if self.return_reason_id:
            reason = '%s (%s)' % (self.name, self.return_reason_id.name)
        reversal = self.env['account.move.reversal'].with_company(invoice.company_id).with_context(
            active_model='account.move', active_ids=invoice.ids,
        ).create({
            'reason': reason,
            'journal_id': invoice.journal_id.id,
            'date': fields.Date.context_today(self),
        })
        reversal.refund_moves()
        refund = reversal.new_move_ids
        if len(refund) != 1 or refund.state != 'draft' or refund.move_type != 'out_refund':
            raise UserError(self.env._("The standard reversal of %(inv)s did not produce a draft credit note.",
                                       inv=invoice.name))

        allocations_by_invoice_line = defaultdict(list)
        for line, invoice_line, qty in allocations:
            allocations_by_invoice_line[invoice_line].append((line, qty))

        def to_line_qty(return_line, qty, invoice_line):
            return return_line.sale_line_id.product_uom_id._compute_quantity(
                qty, invoice_line.product_uom_id or return_line.product_uom_id, rounding_method='HALF-UP')

        def new_line_vals(template_line, origin_line, return_line, qty):
            vals = template_line.with_context(include_business_fields=True).copy_data({
                'quantity': to_line_qty(return_line, qty, origin_line),
                'customer_return_line_id': return_line.id,
                'customer_return_origin_line_id': origin_line.id,
            })[0]
            for key in ('move_id', 'balance', 'amount_currency', 'debit', 'credit', 'date_maturity'):
                vals.pop(key, None)
            return vals

        # 1. Lines copied by the standard reversal of the main invoice
        source_lines = invoice.invoice_line_ids.filtered(lambda l: l.display_type == 'product').sorted(
            lambda l: (l.sequence, l.id))
        refund_lines = refund.invoice_line_ids.filtered(lambda l: l.display_type == 'product').sorted(
            lambda l: (l.sequence, l.id))
        if len(source_lines) != len(refund_lines) or any(
            src.product_id != dst.product_id or src.sale_line_ids != dst.sale_line_ids
            for src, dst in zip(source_lines, refund_lines)
        ):
            raise UserError(self.env._(
                "The credit note lines of %(inv)s could not be matched with the original invoice lines.",
                inv=invoice.name))
        commands = [
            Command.delete(other.id)
            for other in refund.invoice_line_ids
            if other.display_type != 'product'
        ]
        for src, dst in zip(source_lines, refund_lines):
            line_allocations = allocations_by_invoice_line.get(src)
            if not line_allocations:
                commands.append(Command.delete(dst.id))
                continue
            for index, (return_line, qty) in enumerate(line_allocations):
                if index == 0:
                    commands.append(Command.update(dst.id, {
                        'quantity': to_line_qty(return_line, qty, src),
                        'customer_return_line_id': return_line.id,
                        'customer_return_origin_line_id': src.id,
                    }))
                else:
                    commands.append(Command.create(new_line_vals(dst, src, return_line, qty)))

        # 2. Returned lines of the other invoices of the group
        sequence = max(refund_lines.mapped('sequence') or [10])
        for other_invoice in invoices[1:]:
            other_lines = other_invoice.invoice_line_ids.filtered(
                lambda l: l.display_type == 'product' and l in allocations_by_invoice_line
            ).sorted(lambda l: (l.sequence, l.id))
            for src in other_lines:
                for return_line, qty in allocations_by_invoice_line[src]:
                    sequence += 1
                    vals = new_line_vals(src, src, return_line, qty)
                    vals['sequence'] = sequence
                    commands.append(Command.create(vals))

        refund_vals = {
            'invoice_line_ids': commands,
            'customer_return_order_id': self.id,
        }
        if len(invoices) > 1:
            # A credit note can only reverse one invoice; the credited invoice of each line
            # is kept in customer_return_origin_line_id instead.
            refund_vals.update({
                'reversed_entry_id': False,
                'ref': self.env._("Reversal of: %(invoices)s, %(reason)s",
                                  invoices=', '.join(invoices.mapped('name')), reason=reason),
                'invoice_origin': ', '.join(dict.fromkeys(
                    origin for origin in invoices.mapped('invoice_origin') if origin)),
            })
        refund.write(refund_vals)
        if not refund.invoice_line_ids.filtered(lambda l: l.display_type == 'product'):
            raise UserError(self.env._("The credit note for %(inv)s has no line to credit.", inv=invoice.name))

        invoice_links = Markup(', ').join(inv._get_html_link() for inv in invoices)
        refund.message_post(body=self.env._(
            "Credit note created from customer return %(ret)s for invoices %(invoices)s.",
            ret=self._get_html_link(), invoices=invoice_links))
        for other_invoice in invoices[1:]:
            other_invoice.message_post(body=self.env._(
                "Partially credited by %(refund)s (customer return %(ret)s).",
                refund=refund._get_html_link(), ret=self._get_html_link()))
        self.message_post(body=self.env._(
            "Draft credit note %(refund)s created for invoices %(invoices)s.",
            refund=refund._get_html_link(), invoices=invoice_links))
        return refund

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _cro_lock_rows(self, table, ids, message):
        """Lock rows with NOWAIT; a concurrent transaction gets a clear message."""
        if not ids:
            return
        try:
            with self.env.cr.savepoint(flush=False), mute_logger('odoo.sql_db'):
                self.env.cr.execute(SQL(
                    "SELECT id FROM %s WHERE id IN %s FOR UPDATE NOWAIT",
                    SQL.identifier(table), tuple(ids)))
        except psycopg2.errors.LockNotAvailable:
            raise UserError(message)

    def _get_report_base_filename(self):
        self.ensure_one()
        return 'Return Order - %s' % self.name
