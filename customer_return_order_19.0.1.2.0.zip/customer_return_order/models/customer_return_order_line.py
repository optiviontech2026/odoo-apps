from collections import defaultdict

from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError

# Line fields that cannot change once the return is confirmed.
LOCKED_LINE_FIELDS = {
    'order_id', 'sale_line_id', 'origin_move_id', 'product_uom_qty',
    'price_unit', 'discount', 'tax_ids',
}


class CustomerReturnOrderLine(models.Model):
    _name = 'customer.return.order.line'
    _description = 'Customer Return Order Line'
    _order = 'order_id, sequence, id'
    _check_company_auto = True
    _rec_names_search = ['name', 'order_id.name', 'product_id']

    _origin_move_unique = models.Constraint(
        'UNIQUE(order_id, origin_move_id)',
        'A delivered move can only appear once per return order: change the quantity of '
        'the existing line instead.',
    )

    order_id = fields.Many2one(
        'customer.return.order', string='Return Order', required=True, index=True,
        ondelete='cascade')
    sequence = fields.Integer(default=10)
    company_id = fields.Many2one(related='order_id.company_id', store=True, index=True)
    currency_id = fields.Many2one(related='order_id.currency_id', store=True)
    partner_id = fields.Many2one(related='order_id.partner_id', store=True, string='Customer')
    state = fields.Selection(related='order_id.state', store=True, string='Status')
    sale_order_id = fields.Many2one(
        related='sale_line_id.order_id', store=True, index=True, string='Sales Order')

    sale_line_id = fields.Many2one(
        'sale.order.line', string='Original Order Line', required=True, index=True,
        ondelete='restrict', check_company=True,
        domain="[('display_type', '=', False), ('product_type', '=', 'consu')]")
    origin_move_id = fields.Many2one(
        'stock.move', string='Delivered Move', required=True, index=True, ondelete='restrict',
        check_company=True,
        domain="[('sale_line_id', '=', sale_line_id), ('state', '=', 'done'), "
               "('location_dest_usage', '=', 'customer')]",
        help="Done delivery move of the original sales order line that is returned.")
    delivery_picking_id = fields.Many2one(
        related='origin_move_id.picking_id', store=True, string='Delivery')
    product_id = fields.Many2one(
        'product.product', string='Product', compute='_compute_from_sale_line', store=True,
        precompute=True, index=True)
    product_type = fields.Selection(related='product_id.type')
    product_tracking = fields.Selection(related='product_id.tracking', string='Tracking')
    invoice_policy = fields.Selection(related='product_id.invoice_policy')
    name = fields.Text(
        string='Description', compute='_compute_from_sale_line', store=True, readonly=False,
        precompute=True)
    product_uom_id = fields.Many2one(
        'uom.uom', string='Unit', compute='_compute_from_sale_line', store=True, precompute=True)
    product_uom_qty = fields.Float(
        string='Return Quantity', digits='Product Unit', required=True, default=0.0)
    qty_returnable = fields.Float(
        string='Returnable', digits='Product Unit', compute='_compute_qty_returnable',
        help="Delivered quantity of the delivered move that is not returned yet by other "
             "returns (standard returns and other return orders).")
    qty_received = fields.Float(
        string='Received', digits='Product Unit', compute='_compute_qty_received', store=True)
    qty_credited = fields.Float(
        string='Credited', digits='Product Unit', compute='_compute_qty_credited', store=True,
        help="Quantity on draft and posted credit notes created for this line "
             "(cancelled credit notes are ignored).")
    qty_to_credit = fields.Float(
        string='To Credit', digits='Product Unit', compute='_compute_qty_to_credit', store=True,
        help="Received quantity that can be credited now, limited by the posted invoices of "
             "the original order line and the quantities already credited.")
    credit_info = fields.Char(string='Credit Eligibility', compute='_compute_credit_info')
    lot_names = fields.Char(string='Lots/Serial Numbers', compute='_compute_lot_names')

    price_unit = fields.Float(
        string='Unit Price', digits='Product Price', compute='_compute_from_sale_line',
        store=True, readonly=False, precompute=True)
    discount = fields.Float(
        string='Discount (%)', digits='Discount', compute='_compute_from_sale_line',
        store=True, readonly=False, precompute=True)
    tax_ids = fields.Many2many(
        'account.tax', string='Taxes', compute='_compute_from_sale_line', store=True,
        readonly=False, precompute=True, check_company=True, context={'active_test': False})
    price_subtotal = fields.Monetary(string='Subtotal', compute='_compute_amount', store=True)
    price_tax = fields.Float(string='Total Tax', compute='_compute_amount', store=True)
    price_total = fields.Monetary(string='Total', compute='_compute_amount', store=True)

    return_reason_id = fields.Many2one(
        'customer.return.reason', string='Return Reason', compute='_compute_return_reason_id',
        store=True, readonly=False, precompute=True)

    move_ids = fields.One2many('stock.move', 'customer_return_line_id', string='Return Moves', readonly=True)
    credit_line_ids = fields.One2many(
        'account.move.line', 'customer_return_line_id', string='Credit Note Lines', readonly=True)

    # ------------------------------------------------------------------
    # Computes
    # ------------------------------------------------------------------
    @api.depends('sale_line_id')
    def _compute_from_sale_line(self):
        """Prices, discount, taxes and unit come from the original order line."""
        for line in self:
            sale_line = line.sale_line_id
            line.product_id = sale_line.product_id
            line.name = sale_line.name
            line.product_uom_id = sale_line.product_uom_id
            line.price_unit = sale_line.price_unit
            line.discount = sale_line.discount
            line.tax_ids = sale_line.tax_ids

    @api.depends('order_id.return_reason_id')
    def _compute_return_reason_id(self):
        for line in self:
            if not line.return_reason_id:
                line.return_reason_id = line.order_id.return_reason_id

    @api.depends('origin_move_id', 'product_uom_id', 'origin_move_id.returned_move_ids.state',
                 'origin_move_id.returned_move_ids.quantity', 'origin_move_id.returned_move_ids.product_uom_qty')
    def _compute_qty_returnable(self):
        for line in self:
            line.qty_returnable = line._cro_get_returnable_qty() if line.origin_move_id else 0.0

    @api.depends('move_ids.state', 'move_ids.quantity', 'move_ids.product_uom',
                 'move_ids.returned_move_ids.state', 'move_ids.returned_move_ids.quantity', 'product_uom_id')
    def _compute_qty_received(self):
        for line in self:
            line.qty_received = line._cro_get_received_qty()

    @api.depends('credit_line_ids.parent_state', 'credit_line_ids.quantity',
                 'credit_line_ids.product_uom_id', 'credit_line_ids.move_id.move_type', 'product_uom_id')
    def _compute_qty_credited(self):
        for line in self:
            line.qty_credited = line._cro_get_credited_qty()

    @api.depends('state', 'qty_received', 'qty_credited',
                 'sale_line_id.qty_delivered',
                 'sale_line_id.invoice_lines.parent_state',
                 'sale_line_id.invoice_lines.quantity',
                 'sale_line_id.invoice_lines.move_id.reversed_entry_id',
                 'sale_line_id.invoice_lines.customer_return_origin_line_id',
                 'order_id.order_line.qty_received',
                 'order_id.order_line.qty_credited')
    def _compute_qty_to_credit(self):
        to_credit = {}
        for order in self.order_id:
            plan = order.order_line._cro_get_credit_plan()
            for line, allocations in plan.items():
                to_credit[line] = sum(qty for _invoice_line, qty in allocations)
        for line in self:
            line.qty_to_credit = line.product_uom_id.round(to_credit.get(line, 0.0)) if line.product_uom_id else 0.0

    @api.depends('state', 'qty_received', 'qty_credited', 'qty_to_credit', 'product_uom_qty')
    @api.depends_context('lang')
    def _compute_credit_info(self):
        for line in self:
            line.credit_info = line._cro_get_credit_info()

    @api.depends('move_ids.move_line_ids.lot_id', 'origin_move_id.move_line_ids.lot_id')
    def _compute_lot_names(self):
        for line in self:
            moves = line.move_ids.filtered(lambda m: m.state != 'cancel') or line.origin_move_id
            line.lot_names = ', '.join(moves.move_line_ids.lot_id.mapped('name'))

    @api.depends('product_uom_qty', 'discount', 'price_unit', 'tax_ids')
    def _compute_amount(self):
        AccountTax = self.env['account.tax']
        for line in self:
            company = line.company_id or self.env.company
            base_line = line._prepare_base_line_for_taxes_computation()
            AccountTax._add_tax_details_in_base_line(base_line, company)
            AccountTax._round_base_lines_tax_details([base_line], company)
            line.price_subtotal = base_line['tax_details']['total_excluded_currency']
            line.price_total = base_line['tax_details']['total_included_currency']
            line.price_tax = line.price_total - line.price_subtotal

    def _prepare_base_line_for_taxes_computation(self, **kwargs):
        self.ensure_one()
        order = self.order_id
        company = order.company_id or self.env.company
        return self.env['account.tax']._prepare_base_line_for_taxes_computation(
            self,
            **{
                'tax_ids': self.tax_ids,
                'quantity': self.product_uom_qty,
                'partner_id': order.partner_id,
                'currency_id': order.currency_id or company.currency_id,
                'rate': self.sale_line_id.order_id.currency_rate or 1.0,
                'name': self.name,
                **kwargs,
            },
        )

    # ------------------------------------------------------------------
    # Constraints
    # ------------------------------------------------------------------
    @api.constrains('sale_line_id', 'origin_move_id', 'order_id')
    def _check_line_consistency(self):
        self._cro_check_line_consistency()

    @api.constrains('product_uom_qty', 'origin_move_id')
    def _check_return_quantity(self):
        for line in self:
            if line.product_uom_qty < 0:
                raise ValidationError(self.env._("The return quantity cannot be negative."))
        self._cro_check_returnable_qty()

    def _cro_check_line_consistency(self):
        for line in self:
            sale_line = line.sale_line_id
            product = sale_line.product_id
            if sale_line.order_id not in line.order_id.sale_order_ids:
                raise ValidationError(self.env._(
                    "The order line %(line)s does not belong to the original sales orders of %(ret)s. "
                    "Add %(order)s to the original sales orders first.",
                    line=sale_line.display_name, ret=line.order_id.name, order=sale_line.order_id.display_name))
            if product.type == 'service':
                raise ValidationError(self.env._(
                    "%(product)s is a service: services are not received in stock and cannot be "
                    "processed by a customer return order. Use a separate credit-only process "
                    "(standard credit note on the invoice) for services.", product=product.display_name))
            if product.type != 'consu':
                raise ValidationError(self.env._(
                    "%(product)s cannot be returned: only goods delivered from stock can be returned.",
                    product=product.display_name))
            move = line.origin_move_id
            if move.sale_line_id != sale_line:
                raise ValidationError(self.env._(
                    "The delivered move of %(product)s does not belong to the selected order line.",
                    product=product.display_name))
            if move.product_id != product:
                raise ValidationError(self.env._(
                    "%(product)s was delivered as components (kit). Kits are not supported by customer "
                    "return orders; use the standard return and credit note.", product=product.display_name))
            if move.state != 'done' or move.location_dest_id.usage != 'customer' \
                    or move.location_id.usage == 'customer':
                raise ValidationError(self.env._(
                    "Only completed deliveries to the customer can be returned (%(product)s).",
                    product=product.display_name))

    def _cro_check_returnable_qty(self):
        """Server-side guard: never return more than delivered minus already returned."""
        for line in self:
            if not line.origin_move_id or not line.product_uom_id:
                continue
            if line.order_id.state == 'cancel':
                continue
            returnable = line._cro_get_returnable_qty()
            if line.product_uom_id.compare(line.product_uom_qty, returnable) > 0:
                raise ValidationError(self.env._(
                    "You cannot return %(qty)s %(uom)s of %(product)s from %(delivery)s: only "
                    "%(returnable)s %(uom)s remain returnable (delivered quantity minus previous returns).",
                    qty=line.product_uom_qty, uom=line.product_uom_id.name,
                    product=line.product_id.display_name, delivery=line.origin_move_id.reference,
                    returnable=line.product_uom_id.round(returnable)))

    # ------------------------------------------------------------------
    # ORM
    # ------------------------------------------------------------------
    @api.model_create_multi
    def create(self, vals_list):
        order_ids = {vals.get('order_id') for vals in vals_list if vals.get('order_id')}
        orders = self.env['customer.return.order'].browse(order_ids)
        if any(order.state != 'draft' for order in orders):
            raise UserError(self.env._("Lines can only be added to draft return orders."))
        return super().create(vals_list)

    def write(self, vals):
        locked = LOCKED_LINE_FIELDS & set(vals)
        if locked and any(line.order_id.state != 'draft' for line in self):
            raise UserError(self.env._(
                "The products, quantities and prices of a confirmed return order cannot be changed."))
        return super().write(vals)

    @api.ondelete(at_uninstall=False)
    def _unlink_except_confirmed(self):
        if any(line.order_id.state not in ('draft', 'cancel') for line in self):
            raise UserError(self.env._("Lines of a confirmed return order cannot be deleted."))

    @api.onchange('sale_line_id')
    def _onchange_sale_line_id(self):
        if self.sale_line_id and (not self.origin_move_id or self.origin_move_id.sale_line_id != self.sale_line_id):
            moves = self.sale_line_id.move_ids.filtered(
                lambda m: m.state == 'done' and m.location_dest_id.usage == 'customer'
                and m.location_id.usage != 'customer')
            self.origin_move_id = moves[:1] if len(moves) == 1 else False

    # ------------------------------------------------------------------
    # Quantity helpers (always computed from the linked documents)
    # ------------------------------------------------------------------
    def _cro_get_returnable_qty(self):
        """Delivered quantity of the delivered move minus all non-cancelled returns of it
        (standard returns, backorders and other return orders), excluding the moves of
        this line. Expressed in the line unit."""
        self.ensure_one()
        move = self.origin_move_id
        line_id = self._origin.id
        returned = 0.0
        for returned_move in move.returned_move_ids:
            if returned_move.state == 'cancel':
                continue
            if line_id and returned_move.customer_return_line_id.id == line_id:
                continue
            qty = returned_move.quantity if returned_move.state == 'done' else returned_move.product_uom_qty
            returned += returned_move.product_uom._compute_quantity(qty, move.product_uom, round=False)
        remaining = max(move.quantity - returned, 0.0)
        uom = self.product_uom_id or move.product_uom
        return move.product_uom._compute_quantity(remaining, uom, round=False)

    def _cro_get_received_qty(self):
        """Validated return receipts, minus validated returns of those receipts."""
        self.ensure_one()
        uom = self.product_uom_id
        if not uom:
            return 0.0
        qty = 0.0
        for move in self.move_ids.filtered(lambda m: m.state == 'done' and m.location_id.usage == 'customer'):
            qty += move.product_uom._compute_quantity(move.quantity, uom, rounding_method='HALF-UP')
            for back in move.returned_move_ids.filtered(
                    lambda m: m.state == 'done' and m.location_dest_id.usage == 'customer'):
                qty -= back.product_uom._compute_quantity(back.quantity, uom, rounding_method='HALF-UP')
        return uom.round(qty)

    def _cro_get_pending_receipt_moves(self):
        self.ensure_one()
        return self.move_ids.filtered(
            lambda m: m.state not in ('done', 'cancel') and m.location_id.usage == 'customer')

    def _cro_get_credited_qty(self):
        """Quantity on non-cancelled (draft or posted) credit notes linked to this line."""
        self.ensure_one()
        uom = self.product_uom_id
        if not uom:
            return 0.0
        qty = 0.0
        for aml in self.credit_line_ids:
            if aml.parent_state == 'cancel' or aml.display_type != 'product':
                continue
            line_qty = aml.product_uom_id._compute_quantity(aml.quantity, uom, round=False) \
                if aml.product_uom_id else aml.quantity
            qty += line_qty if aml.move_id.move_type == 'out_refund' else -line_qty
        return uom.round(qty)

    # ------------------------------------------------------------------
    # Credit computation
    # ------------------------------------------------------------------
    @api.model
    def _cro_get_sale_line_credit_capacity(self, sale_line):
        """Return (capacity, invoice_capacities) for an original sales order line.

        * capacity: quantity that can still be credited, in the sale line unit. It is the
          quantity of posted invoices minus all non-cancelled credit notes (draft or posted,
          from any origin). For products invoiced on delivered quantities, only the part
          invoiced above the delivered quantity can be credited, exactly like the standard
          sales order would do (negative quantity to invoice).
        * invoice_capacities: list of [invoice_line, remaining qty] for posted invoices,
          most recent first, the remaining quantity being reduced by the credit notes
          reversing that invoice.
        """
        uom = sale_line.product_uom_id

        def to_sale_uom(aml):
            if aml.product_uom_id:
                return aml.product_uom_id._compute_quantity(aml.quantity, uom, round=False)
            return aml.quantity

        product_lines = sale_line.invoice_lines.filtered(lambda l: l.display_type == 'product')
        invoice_lines = product_lines.filtered(
            lambda l: l.move_id.move_type == 'out_invoice' and l.parent_state == 'posted')
        refund_lines = product_lines.filtered(
            lambda l: l.move_id.move_type == 'out_refund' and l.parent_state != 'cancel')
        # Credit note lines created by return orders are linked to the sale line through the
        # standard reversal; also include them in case that link was removed manually.
        refund_lines |= self.env['account.move.line'].search([
            ('customer_return_line_id.sale_line_id', '=', sale_line.id),
            ('parent_state', '!=', 'cancel'),
            ('move_id.move_type', '=', 'out_refund'),
            ('display_type', '=', 'product'),
        ])
        invoiced = sum(to_sale_uom(l) for l in invoice_lines)
        refunded = sum(to_sale_uom(l) for l in refund_lines)
        net_invoiced = invoiced - refunded
        if sale_line.product_id.invoice_policy == 'delivery':
            capacity = net_invoiced - sale_line.qty_delivered
        else:
            capacity = net_invoiced
        capacity = max(capacity, 0.0)

        refunded_by_invoice = defaultdict(float)
        for refund_line in refund_lines:
            origin = refund_line.customer_return_origin_line_id.move_id or refund_line.move_id.reversed_entry_id
            if origin:
                refunded_by_invoice[origin] += to_sale_uom(refund_line)
        invoice_capacities = []
        for invoice_line in invoice_lines.sorted(
                lambda l: (l.move_id.invoice_date or l.move_id.date, l.move_id.id, l.id), reverse=True):
            qty = to_sale_uom(invoice_line)
            already = refunded_by_invoice[invoice_line.move_id]
            used = min(max(already, 0.0), max(qty, 0.0))
            refunded_by_invoice[invoice_line.move_id] -= used
            remaining = qty - used
            if remaining > 0 and not uom.is_zero(remaining):
                invoice_capacities.append([invoice_line, remaining])
        return capacity, invoice_capacities

    def _cro_get_credit_plan(self):
        """Allocate the creditable quantity of each line to posted invoice lines.

        :return: {return_line: [(invoice_line, qty in sale line unit)]}
        """
        plan = defaultdict(list)
        lines = self.filtered(lambda l: l.order_id.state in ('partial', 'received') and l.sale_line_id)
        lines_by_sale_line = defaultdict(lambda: self.env['customer.return.order.line'])
        for line in lines.sorted(lambda l: (l.order_id.id, l.sequence, l.id)):
            lines_by_sale_line[line.sale_line_id] |= line
        for sale_line, sale_line_lines in lines_by_sale_line.items():
            if sale_line.product_id.type != 'consu':
                continue
            uom = sale_line.product_uom_id
            capacity, invoice_capacities = self._cro_get_sale_line_credit_capacity(sale_line)
            for line in sale_line_lines:
                need = line._cro_get_received_qty() - line._cro_get_credited_qty()
                need = line.product_uom_id._compute_quantity(need, uom, round=False)
                take = min(need, capacity)
                if take <= 0 or uom.is_zero(take):
                    continue
                capacity -= take
                for entry in invoice_capacities:
                    if take <= 0 or uom.is_zero(take):
                        break
                    qty = min(entry[1], take)
                    if qty <= 0 or uom.is_zero(qty):
                        continue
                    plan[line].append((entry[0], qty))
                    entry[1] -= qty
                    take -= qty
        return dict(plan)

    def _cro_expects_more_credit(self):
        """True when quantities still waiting for receipt are expected to be credited."""
        self.ensure_one()
        if not self._cro_get_pending_receipt_moves():
            return False
        capacity, _invoice_capacities = self._cro_get_sale_line_credit_capacity(self.sale_line_id)
        if self.sale_line_id.product_id.invoice_policy == 'delivery':
            pending = sum(
                m.product_uom._compute_quantity(m.product_uom_qty, self.product_uom_id, round=False)
                for m in self._cro_get_pending_receipt_moves())
            capacity += pending
        return capacity > 0 and not self.product_uom_id.is_zero(capacity)

    def _cro_get_credit_info(self):
        self.ensure_one()
        _ = self.env._
        uom = self.product_uom_id
        if not self.sale_line_id or not uom:
            return ''
        if self.product_id.type == 'service':
            return _("Services require a separate credit-only process.")
        if self.state == 'draft':
            return _("Confirm the return first.")
        if self.state == 'cancel':
            return _("Return cancelled.")
        if self.qty_to_credit > 0 and not uom.is_zero(self.qty_to_credit):
            return _("%(qty)s %(uom)s can be credited.", qty=self.qty_to_credit, uom=uom.name)
        if self.qty_received <= 0 or uom.is_zero(self.qty_received):
            return _("Waiting for the return receipt to be validated.")
        if uom.compare(self.qty_credited, self.qty_received) >= 0:
            if self._cro_get_pending_receipt_moves():
                return _("Received quantity credited. Waiting for the remaining receipt.")
            return _("Received quantity fully credited.")
        sale_line = self.sale_line_id
        product_lines = sale_line.invoice_lines.filtered(lambda l: l.display_type == 'product')
        posted = product_lines.filtered(lambda l: l.move_id.move_type == 'out_invoice' and l.parent_state == 'posted')
        if not posted:
            if product_lines.filtered(lambda l: l.move_id.move_type == 'out_invoice' and l.parent_state == 'draft'):
                return _("The original invoice is still a draft: correct the draft invoice instead of "
                         "creating a credit note.")
            if self.invoice_policy == 'delivery':
                return _("Not invoiced (invoiced on delivered quantities): the return reduces the "
                         "quantity to invoice on the sales order, no credit note is needed.")
            return _("Not invoiced: there is no invoice to credit for this product.")
        if self.invoice_policy == 'delivery':
            return _("Invoiced on delivered quantities: the invoiced quantity does not exceed the "
                     "delivered quantity anymore, so there is nothing to credit.")
        return _("The invoiced quantity has already been credited.")
