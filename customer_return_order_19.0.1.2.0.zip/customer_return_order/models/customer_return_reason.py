from odoo import fields, models


class CustomerReturnReason(models.Model):
    _name = 'customer.return.reason'
    _description = 'Customer Return Reason'
    _order = 'sequence, id'

    name = fields.Char(string='Reason', required=True, translate=True)
    sequence = fields.Integer(default=10)
    description = fields.Text(translate=True)
    active = fields.Boolean(default=True)
