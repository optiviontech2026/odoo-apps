from odoo import api, fields, models


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    customer_return_ids = fields.Many2many(
        'customer.return.order', 'customer_return_order_sale_order_rel', 'sale_order_id', 'return_order_id',
        string='Customer Returns', copy=False, readonly=True)
    customer_return_count = fields.Integer(compute='_compute_customer_return_count')

    @api.depends('customer_return_ids')
    def _compute_customer_return_count(self):
        for order in self:
            order.customer_return_count = len(order.customer_return_ids)

    def action_view_customer_returns(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id(
            'customer_return_order.action_customer_return_order')
        action['domain'] = [('sale_order_ids', 'in', self.id)]
        action['context'] = {
            'default_sale_order_ids': [self.id],
            'default_company_id': self.company_id.id,
        }
        if len(self.customer_return_ids) <= 1:
            # No return yet: open a new return for this order; one return: open it.
            action.update({
                'views': [(False, 'form')],
                'res_id': self.customer_return_ids.id,
            })
        return action
