from odoo import fields, models


class StockMove(models.Model):
    _inherit = 'stock.move'

    customer_return_line_id = fields.Many2one(
        'customer.return.order.line', string='Customer Return Line', index='btree_not_null',
        readonly=True, copy=False, check_company=True)

    def _prepare_move_split_vals(self, qty):
        # Backorders of a return receipt keep the link to the return line.
        vals = super()._prepare_move_split_vals(qty)
        if self.customer_return_line_id:
            vals['customer_return_line_id'] = self.customer_return_line_id.id
        return vals

    def _prepare_merge_moves_distinct_fields(self):
        fields_list = super()._prepare_merge_moves_distinct_fields()
        fields_list.append('customer_return_line_id')
        return fields_list
