from odoo import api, fields, models
from odoo.tools.sql import column_exists, create_column


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    customer_return_order_id = fields.Many2one(
        'customer.return.order', string='Customer Return Order', index='btree_not_null',
        compute='_compute_customer_return_order_id', store=True, readonly=True,
        help="Customer return order that created this return receipt (backorders included).")

    def _auto_init(self):
        # Create the column without computing it on every existing transfer: no transfer
        # can be linked to a return order before this module is installed.
        if not column_exists(self.env.cr, 'stock_picking', 'customer_return_order_id'):
            create_column(self.env.cr, 'stock_picking', 'customer_return_order_id', 'int4')
        return super()._auto_init()

    @api.depends('move_ids.customer_return_line_id')
    def _compute_customer_return_order_id(self):
        for picking in self:
            orders = picking.move_ids.customer_return_line_id.order_id
            picking.customer_return_order_id = orders[:1]

    def action_view_customer_return_order(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'customer.return.order',
            'view_mode': 'form',
            'res_id': self.customer_return_order_id.id,
        }
