from odoo.fields import Command
from odoo.tests import new_test_user

from odoo.addons.sale.tests.common import TestSaleCommon


class CustomerReturnCommon(TestSaleCommon):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.company = cls.company_data['company']
        cls.env.user.group_ids |= cls.env.ref('stock.group_production_lot') | cls.env.ref('uom.group_uom')
        cls.warehouse = cls.env['stock.warehouse'].search([('company_id', '=', cls.company.id)], limit=1)
        cls.stock_location = cls.warehouse.lot_stock_id
        cls.customer = cls.partner_a

        def product(name, **vals):
            return cls.env['product.product'].create({
                'name': name,
                'type': 'consu',
                'is_storable': True,
                'invoice_policy': 'order',
                'list_price': 100.0,
                'standard_price': 60.0,
                'categ_id': cls.product_category.id,
                'taxes_id': [Command.set(cls.tax_sale_a.ids)],
                **vals,
            })

        cls.product_order = product('Returnable Order Policy')
        cls.product_delivery = product('Returnable Delivery Policy', invoice_policy='delivery')
        cls.product_lot = product('Lot Product', tracking='lot')
        cls.product_serial = product('Serial Product', tracking='serial')
        cls.product_service = cls.company_data['product_service_order']

        Quant = cls.env['stock.quant']
        for prod in (cls.product_order, cls.product_delivery):
            Quant._update_available_quantity(prod, cls.stock_location, 1000.0)
        cls.lot_1, cls.lot_2 = cls.env['stock.lot'].create([
            {'name': 'LOT-1', 'product_id': cls.product_lot.id, 'company_id': cls.company.id},
            {'name': 'LOT-2', 'product_id': cls.product_lot.id, 'company_id': cls.company.id},
        ])
        Quant._update_available_quantity(cls.product_lot, cls.stock_location, 5.0, lot_id=cls.lot_1)
        Quant._update_available_quantity(cls.product_lot, cls.stock_location, 5.0, lot_id=cls.lot_2)
        cls.serials = cls.env['stock.lot'].create([
            {'name': 'SN-%s' % i, 'product_id': cls.product_serial.id, 'company_id': cls.company.id}
            for i in range(1, 4)
        ])
        for serial in cls.serials:
            Quant._update_available_quantity(cls.product_serial, cls.stock_location, 1.0, lot_id=serial)

        # Users
        company_vals = {'company_id': cls.company.id, 'company_ids': [Command.set(cls.company.ids)]}
        cls.user_salesman = new_test_user(
            cls.env, login='cro_salesman', groups='sales_team.group_sale_salesman', **company_vals)
        cls.user_salesman_2 = new_test_user(
            cls.env, login='cro_salesman_2', groups='sales_team.group_sale_salesman', **company_vals)
        cls.user_stock = new_test_user(
            cls.env, login='cro_stock', groups='stock.group_stock_user', **company_vals)
        cls.user_billing = new_test_user(
            cls.env, login='cro_billing', groups='account.group_account_invoice', **company_vals)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _create_so(self, lines, partner=None, user=None, **vals):
        """lines: list of (product, qty) or (product, qty, extra_line_vals)."""
        order_lines = []
        for line in lines:
            product, qty = line[0], line[1]
            extra = line[2] if len(line) > 2 else {}
            order_lines.append(Command.create({
                'product_id': product.id,
                'product_uom_qty': qty,
                **extra,
            }))
        so = self.env['sale.order'].create({
            'partner_id': (partner or self.customer).id,
            'warehouse_id': self.warehouse.id,
            'user_id': (user or self.env.user).id,
            'order_line': order_lines,
            **vals,
        })
        so.action_confirm()
        return so

    def _validate(self, picking, quantities=None, backorder=True):
        """Validate `picking`; quantities is {product: qty in the move unit}.
        Returns the backorder created, if any."""
        if picking.state == 'draft':
            picking.action_confirm()
        if picking.state not in ('assigned', 'done'):
            picking.action_assign()
        for move in picking.move_ids:
            if quantities is not None and move.product_id in quantities:
                move.quantity = quantities[move.product_id]
            move.picked = True
        picking.with_context(cancel_backorder=not backorder)._action_done()
        return self.env['stock.picking'].search([('backorder_id', '=', picking.id)])

    def _deliver(self, so, quantities=None, backorder=True):
        picking = so.picking_ids.filtered(lambda p: p.state not in ('done', 'cancel'))
        self.assertEqual(len(picking), 1)
        return self._validate(picking, quantities, backorder)

    def _invoice(self, so, post=True):
        invoice = so._create_invoices()
        if post:
            invoice.action_post()
        return invoice

    def _delivered_moves(self, so, product=None):
        moves = so.order_line.move_ids.filtered(
            lambda m: m.state == 'done' and m.location_dest_id.usage == 'customer')
        if product:
            moves = moves.filtered(lambda m: m.product_id == product)
        return moves.sorted('id')

    def _create_return(self, sale_orders, move_qtys, env=None, **vals):
        env = env or self.env
        return env['customer.return.order'].create({
            'sale_order_ids': [Command.set(sale_orders.ids)],
            'order_line': [Command.create({
                'sale_line_id': move.sale_line_id.id,
                'origin_move_id': move.id,
                'product_uom_qty': qty,
            }) for move, qty in move_qtys],
            **vals,
        })

    def _receipts(self, return_order, pending_only=False):
        pickings = return_order.picking_ids
        if pending_only:
            pickings = pickings.filtered(lambda p: p.state not in ('done', 'cancel'))
        return pickings.sorted('id')
