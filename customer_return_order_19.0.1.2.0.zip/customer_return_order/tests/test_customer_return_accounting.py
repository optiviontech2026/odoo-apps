from odoo.exceptions import UserError
from odoo.fields import Command
from odoo.tests import tagged

from .common import CustomerReturnCommon


@tagged('post_install', '-at_install')
class TestCustomerReturnAccounting(CustomerReturnCommon):
    """Credit notes after receipt validation."""

    def _refund_lines(self, refunds):
        return refunds.invoice_line_ids.filtered(lambda l: l.display_type == 'product')

    def test_full_flow_ordered_policy(self):
        so = self._create_so([(self.product_order, 10, {'price_unit': 200.0, 'discount': 10.0})])
        self._deliver(so)
        invoice = self._invoice(so)
        ret = self._create_return(so, [(self._delivered_moves(so), 4)])
        ret.action_confirm()
        # No credit before a receipt is validated
        self.assertFalse(ret.can_create_credit_note)
        self.assertEqual(ret.credit_status, 'nothing')
        with self.assertRaises(UserError):
            ret.action_create_credit_note()

        backorder = self._validate(ret.picking_ids, {self.product_order: 3})
        self.assertEqual(ret.state, 'partial')
        self.assertEqual(ret.order_line.qty_to_credit, 3.0, "Only the received quantity can be credited")
        self.assertTrue(ret.can_create_credit_note)
        self.assertEqual(ret.credit_status, 'to_credit')

        action = ret.action_create_credit_note()
        refund = ret.credit_note_ids
        self.assertEqual(len(refund), 1)
        self.assertEqual(action['res_id'], refund.id)
        self.assertEqual(refund.state, 'draft', "Credit notes are created in draft")
        self.assertEqual(refund.move_type, 'out_refund')
        self.assertEqual(refund.reversed_entry_id, invoice)
        self.assertEqual(refund.customer_return_order_id, ret)
        self.assertEqual(refund.partner_id, invoice.partner_id)
        self.assertEqual(refund.currency_id, invoice.currency_id)
        self.assertEqual(refund.fiscal_position_id, invoice.fiscal_position_id)
        self.assertEqual(refund.journal_id, invoice.journal_id)
        refund_line = self._refund_lines(refund)
        invoice_line = invoice.invoice_line_ids
        self.assertEqual(refund_line.quantity, 3.0)
        self.assertEqual(refund_line.price_unit, invoice_line.price_unit)
        self.assertEqual(refund_line.discount, invoice_line.discount)
        self.assertEqual(refund_line.tax_ids, invoice_line.tax_ids)
        self.assertEqual(refund_line.account_id, invoice_line.account_id)
        self.assertEqual(refund_line.sale_line_ids, so.order_line)
        self.assertEqual(refund_line.customer_return_line_id, ret.order_line)
        self.assertAlmostEqual(refund.amount_untaxed, 3 * 200.0 * 0.9)
        self.assertEqual(ret.order_line.qty_credited, 3.0)
        self.assertEqual(ret.order_line.qty_to_credit, 0.0)
        self.assertEqual(ret.credit_status, 'partial', "1 unit is still expected")

        # Repeated click: nothing left, no duplicate
        with self.assertRaises(UserError):
            ret.action_create_credit_note()
        self.assertEqual(len(ret.credit_note_ids), 1)

        self._validate(backorder)
        self.assertEqual(ret.state, 'received')
        self.assertEqual(ret.order_line.qty_to_credit, 1.0)
        ret.action_create_credit_note()
        self.assertEqual(len(ret.credit_note_ids), 2)
        self.assertEqual(ret.order_line.qty_credited, 4.0)
        self.assertEqual(ret.credit_status, 'credited')
        self.assertEqual(ret.credit_note_count, 2)
        # Posting is left to accounting users, and works with the standard flow
        ret.credit_note_ids.action_post()
        self.assertEqual(ret.order_line.qty_credited, 4.0)
        self.assertEqual(ret.credit_status, 'credited')
        # Standard credit note behaviour on the sales order (same as the invoice "Credit Note" button)
        self.assertEqual(so.order_line.qty_delivered, 6.0)
        self.assertEqual(so.order_line.qty_invoiced, 6.0)

    def test_delivered_policy_keeps_sale_order_consistent(self):
        so = self._create_so([(self.product_delivery, 10)])
        self._deliver(so)
        self._invoice(so)
        ret = self._create_return(so, [(self._delivered_moves(so), 3)])
        ret.action_confirm()
        self._validate(ret.picking_ids)
        sale_line = so.order_line
        self.assertEqual(sale_line.qty_delivered, 7.0)
        self.assertEqual(sale_line.qty_to_invoice, -3.0)
        self.assertEqual(ret.order_line.qty_to_credit, 3.0)
        ret.action_create_credit_note()
        self.assertEqual(sale_line.qty_invoiced, 7.0)
        self.assertEqual(sale_line.qty_to_invoice, 0.0)
        self.assertNotEqual(so.invoice_status, 'to invoice')
        self.assertEqual(ret.credit_status, 'credited')

    def test_delivered_policy_partially_invoiced(self):
        """Only the part invoiced above the delivered quantity is credited."""
        so = self._create_so([(self.product_delivery, 10)])
        backorder = self._deliver(so, {self.product_delivery: 4})
        self._invoice(so)  # 4 invoiced
        self._validate(backorder)  # 10 delivered, 4 invoiced
        move_1, move_2 = self._delivered_moves(so)
        ret = self._create_return(so, [(move_2, 5)])
        ret.action_confirm()
        self._validate(ret.picking_ids)
        # delivered 5, invoiced 4: nothing was over-invoiced
        self.assertEqual(so.order_line.qty_delivered, 5.0)
        self.assertEqual(ret.order_line.qty_to_credit, 0.0)
        self.assertEqual(ret.credit_status, 'nothing')
        self.assertIn('delivered', ret.order_line.credit_info)
        with self.assertRaises(UserError):
            ret.action_create_credit_note()
        self.assertEqual(so.order_line.qty_to_invoice, 1.0)

    def test_uninvoiced_return(self):
        so = self._create_so([(self.product_order, 5)])
        self._deliver(so)
        ret = self._create_return(so, [(self._delivered_moves(so), 2)])
        ret.action_confirm()
        self._validate(ret.picking_ids)
        self.assertEqual(ret.state, 'received', "The inventory return is allowed")
        self.assertEqual(ret.order_line.qty_to_credit, 0.0)
        self.assertEqual(ret.credit_status, 'nothing')
        self.assertIn('Not invoiced', ret.order_line.credit_info)
        self.assertFalse(ret.can_create_credit_note)
        with self.assertRaisesRegex(UserError, 'Not invoiced'):
            ret.action_create_credit_note()
        self.assertFalse(ret.credit_note_ids)

    def test_draft_invoice_is_not_credited(self):
        so = self._create_so([(self.product_order, 5)])
        self._deliver(so)
        self._invoice(so, post=False)
        ret = self._create_return(so, [(self._delivered_moves(so), 2)])
        ret.action_confirm()
        self._validate(ret.picking_ids)
        self.assertEqual(ret.order_line.qty_to_credit, 0.0)
        self.assertIn('draft', ret.order_line.credit_info)

    def test_previously_credited_quantity(self):
        so = self._create_so([(self.product_order, 10)])
        self._deliver(so)
        invoice = self._invoice(so)
        # Standard credit note outside of the module for 8 units
        reversal = self.env['account.move.reversal'].with_context(
            active_model='account.move', active_ids=invoice.ids,
        ).create({'journal_id': invoice.journal_id.id, 'reason': 'commercial gesture'})
        reversal.refund_moves()
        manual_refund = reversal.new_move_ids
        manual_refund.invoice_line_ids.quantity = 8.0
        manual_refund.action_post()

        ret = self._create_return(so, [(self._delivered_moves(so), 5)])
        ret.action_confirm()
        self._validate(ret.picking_ids)
        self.assertEqual(ret.order_line.qty_to_credit, 2.0, "Only 2 invoiced units are left to credit")
        ret.action_create_credit_note()
        self.assertEqual(self._refund_lines(ret.credit_note_ids).quantity, 2.0)
        self.assertEqual(ret.credit_status, 'credited')
        self.assertIn('already been credited', ret.order_line.credit_info)

    def test_two_returns_share_invoice_capacity(self):
        so = self._create_so([(self.product_order, 10)])
        self._deliver(so)
        self._invoice(so)
        move = self._delivered_moves(so)
        ret_1 = self._create_return(so, [(move, 6)])
        ret_1.action_confirm()
        self._validate(ret_1.picking_ids)
        ret_1.action_create_credit_note()
        ret_2 = self._create_return(so, [(move, 4)])
        ret_2.action_confirm()
        self._validate(ret_2.picking_ids)
        self.assertEqual(ret_2.order_line.qty_to_credit, 4.0)
        ret_2.action_create_credit_note()
        self.assertEqual(so.order_line.qty_invoiced, 0.0)
        self.assertEqual(
            sum(self._refund_lines(ret_1.credit_note_ids | ret_2.credit_note_ids).mapped('quantity')), 10.0)

    def test_cancelled_credit_note_frees_quantity(self):
        so = self._create_so([(self.product_order, 5)])
        self._deliver(so)
        self._invoice(so)
        ret = self._create_return(so, [(self._delivered_moves(so), 2)])
        ret.action_confirm()
        self._validate(ret.picking_ids)
        ret.action_create_credit_note()
        refund = ret.credit_note_ids
        self.assertEqual(ret.order_line.qty_credited, 2.0)
        refund.button_cancel()
        self.assertEqual(refund.state, 'cancel')
        self.assertEqual(ret.order_line.qty_credited, 0.0)
        self.assertEqual(ret.order_line.qty_to_credit, 2.0)
        self.assertEqual(ret.credit_status, 'to_credit')
        ret.action_create_credit_note()
        self.assertEqual(len(ret.credit_note_ids.filtered(lambda m: m.state != 'cancel')), 1)
        self.assertEqual(ret.order_line.qty_credited, 2.0)
        # Draft credit notes block the cancellation of the return
        with self.assertRaises(UserError):
            ret.action_cancel()

    def test_multiple_deliveries_single_invoice(self):
        so = self._create_so([(self.product_order, 10)])
        backorder = self._deliver(so, {self.product_order: 6})
        self._validate(backorder)
        invoice = self._invoice(so)
        move_1, move_2 = self._delivered_moves(so)
        ret = self._create_return(so, [(move_1, 2), (move_2, 3)])
        ret.action_confirm()
        for receipt in ret.picking_ids:
            self._validate(receipt)
        ret.action_create_credit_note()
        refund = ret.credit_note_ids
        self.assertEqual(len(refund), 1, "Both lines credit the same invoice")
        self.assertEqual(refund.reversed_entry_id, invoice)
        lines = self._refund_lines(refund)
        self.assertEqual(len(lines), 2, "One credit note line per return line")
        self.assertEqual(lines.customer_return_line_id, ret.order_line)
        self.assertEqual(sorted(lines.mapped('quantity')), [2.0, 3.0])
        self.assertTrue(all(line.sale_line_ids == so.order_line for line in lines))

    def test_one_credit_note_for_several_invoices(self):
        so = self._create_so([(self.product_delivery, 10)])
        backorder = self._deliver(so, {self.product_delivery: 4})
        invoice_a = self._invoice(so)
        self._validate(backorder)
        invoice_b = self._invoice(so)
        self.assertNotEqual(invoice_a, invoice_b)
        move_1, move_2 = self._delivered_moves(so)
        ret = self._create_return(so, [(move_1, 4), (move_2, 4)])
        ret.action_confirm()
        self.assertEqual(len(ret.picking_ids), 1)
        self._validate(ret.picking_ids)
        self.assertEqual(sum(ret.order_line.mapped('qty_to_credit')), 8.0)
        ret.action_create_credit_note()
        refund = ret.credit_note_ids
        self.assertEqual(len(refund), 1, "One credit note for both invoices")
        self.assertFalse(refund.reversed_entry_id, "A credit note can only reverse one invoice")
        self.assertIn(invoice_a.name, refund.ref)
        self.assertIn(invoice_b.name, refund.ref)
        lines = self._refund_lines(refund)
        credited = {}
        for line in lines:
            invoice = line.customer_return_origin_line_id.move_id
            credited[invoice] = credited.get(invoice, 0.0) + line.quantity
            self.assertEqual(line.price_unit, line.customer_return_origin_line_id.price_unit)
            self.assertEqual(line.sale_line_ids, so.order_line)
        self.assertEqual(credited, {invoice_b: 6.0, invoice_a: 2.0}, "Most recent invoice first")
        refund.action_post()
        self.assertEqual(so.order_line.qty_invoiced, so.order_line.qty_delivered)
        self.assertEqual(ret.credit_status, 'credited')

        # A later return only credits what is left on each invoice (2 units of invoice A)
        ret_2 = self._create_return(so, [(move_2, 2)])
        ret_2.action_confirm()
        self._validate(ret_2.picking_ids)
        self.assertEqual(ret_2.order_line.qty_to_credit, 2.0)
        ret_2.action_create_credit_note()
        self.assertEqual(ret_2.credit_note_ids.reversed_entry_id, invoice_a)
        self.assertEqual(self._refund_lines(ret_2.credit_note_ids).quantity, 2.0)
        self.assertEqual(so.order_line.qty_invoiced, 0.0)

    def test_units_of_measure_credit(self):
        so = self._create_so([(self.product_order, 2, {
            'product_uom_id': self.uom_dozen.id, 'price_unit': 1200.0})])
        self._deliver(so)
        invoice = self._invoice(so)
        ret = self._create_return(so, [(self._delivered_moves(so), 0.5)])
        ret.action_confirm()
        self._validate(ret.picking_ids)
        ret.action_create_credit_note()
        line = self._refund_lines(ret.credit_note_ids)
        self.assertEqual(line.product_uom_id, invoice.invoice_line_ids.product_uom_id)
        self.assertEqual(line.quantity, 0.5)
        self.assertAlmostEqual(line.price_subtotal, 600.0)

    def test_fiscal_position_and_taxes_preserved(self):
        so = self._create_so([(self.product_order, 4)], partner=self.partner_b)
        self.assertEqual(so.fiscal_position_id, self.fiscal_pos_a)
        self.assertEqual(so.order_line.tax_ids, self.tax_sale_b)
        self._deliver(so)
        invoice = self._invoice(so)
        ret = self._create_return(so, [(self._delivered_moves(so), 1)])
        self.assertEqual(ret.order_line.tax_ids, self.tax_sale_b)
        ret.action_confirm()
        self._validate(ret.picking_ids)
        ret.action_create_credit_note()
        refund = ret.credit_note_ids
        self.assertEqual(refund.fiscal_position_id, invoice.fiscal_position_id)
        self.assertEqual(self._refund_lines(refund).tax_ids, self.tax_sale_b)
        self.assertEqual(self._refund_lines(refund).account_id, invoice.invoice_line_ids.account_id)

    def test_foreign_currency(self):
        currency = self.setup_other_currency('EUR')
        pricelist = self.env['product.pricelist'].create({
            'name': 'EUR pricelist', 'currency_id': currency.id, 'company_id': self.company.id})
        so = self._create_so([(self.product_order, 3, {'price_unit': 77.0})], pricelist_id=pricelist.id)
        self.assertEqual(so.currency_id, currency)
        self._deliver(so)
        invoice = self._invoice(so)
        ret = self._create_return(so, [(self._delivered_moves(so), 1)])
        self.assertEqual(ret.currency_id, currency)
        ret.action_confirm()
        self._validate(ret.picking_ids)
        ret.action_create_credit_note()
        refund = ret.credit_note_ids
        self.assertEqual(refund.currency_id, currency)
        self.assertEqual(refund.invoice_currency_rate, invoice.invoice_currency_rate)
        self.assertEqual(self._refund_lines(refund).price_unit, 77.0)

    def test_mixed_invoice_lines_keep_only_returned(self):
        so = self._create_so([(self.product_order, 3), (self.product_lot, 2), (self.product_service, 1)])
        self._deliver(so)
        invoice = self._invoice(so)
        self.assertEqual(len(invoice.invoice_line_ids.filtered(lambda l: l.display_type == 'product')), 3)
        ret = self._create_return(so, [(self._delivered_moves(so, self.product_order), 1)])
        ret.action_confirm()
        self._validate(ret.picking_ids)
        ret.action_create_credit_note()
        lines = self._refund_lines(ret.credit_note_ids)
        self.assertEqual(lines.product_id, self.product_order, "Only the returned product is credited")
        self.assertEqual(lines.quantity, 1.0)

    def test_invoice_posted_after_receipt(self):
        """Credit eligibility follows invoices posted after the receipt."""
        so = self._create_so([(self.product_order, 5)])
        self._deliver(so)
        ret = self._create_return(so, [(self._delivered_moves(so), 2)])
        ret.action_confirm()
        self._validate(ret.picking_ids)
        self.assertEqual(ret.credit_status, 'nothing')
        self._invoice(so)
        self.assertEqual(ret.order_line.qty_to_credit, 2.0)
        self.assertEqual(ret.credit_status, 'to_credit')
        ret.action_create_credit_note()
        self.assertEqual(ret.credit_status, 'credited')
