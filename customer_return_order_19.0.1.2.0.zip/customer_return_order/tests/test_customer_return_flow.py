from odoo import fields
from odoo.exceptions import UserError, ValidationError
from odoo.fields import Command
from odoo.tests import Form, tagged

from .common import CustomerReturnCommon


@tagged('post_install', '-at_install')
class TestCustomerReturnFlow(CustomerReturnCommon):
    """Return order, confirmation and inventory receipt."""

    def test_sequence_and_defaults(self):
        so = self._create_so([(self.product_order, 5)])
        self._deliver(so)
        ret = self._create_return(so, [(self._delivered_moves(so), 1)])
        year = fields.Date.context_today(ret).year
        self.assertTrue(ret.name.startswith('SRO/%s/' % year), ret.name)
        self.assertEqual(len(ret.name.split('/')[-1]), 5)
        self.assertEqual(ret.state, 'draft')
        self.assertEqual(ret.credit_status, 'nothing')
        self.assertEqual(ret.partner_id, so.partner_id)
        self.assertEqual(ret.partner_invoice_id, so.partner_invoice_id)
        self.assertEqual(ret.partner_shipping_id, so.partner_shipping_id)
        self.assertEqual(ret.warehouse_id, so.warehouse_id)
        self.assertEqual(ret.currency_id, so.currency_id)
        self.assertEqual(ret.pricelist_id, so.pricelist_id)
        self.assertEqual(ret.user_id, so.user_id)
        self.assertEqual(ret.team_id, so.team_id)

    def test_prices_from_original_order(self):
        so = self._create_so([(self.product_order, 4, {'price_unit': 250.0, 'discount': 10.0})])
        self._deliver(so)
        ret = self._create_return(so, [(self._delivered_moves(so), 2)])
        line = ret.order_line
        sale_line = so.order_line
        self.assertEqual(line.product_id, self.product_order)
        self.assertEqual(line.product_uom_id, sale_line.product_uom_id)
        self.assertEqual(line.price_unit, 250.0)
        self.assertEqual(line.discount, 10.0)
        self.assertEqual(line.tax_ids, sale_line.tax_ids)
        self.assertAlmostEqual(line.price_subtotal, 450.0)
        self.assertAlmostEqual(ret.amount_untaxed, 450.0)
        self.assertAlmostEqual(ret.amount_total, line.price_total)
        self.assertTrue(ret.tax_totals)

    def test_add_products_wizard(self):
        so = self._create_so([(self.product_order, 6), (self.product_lot, 3), (self.product_service, 1)])
        self._deliver(so)
        ret = self.env['customer.return.order'].create({'sale_order_ids': [Command.set(so.ids)]})
        action = ret.action_open_add_products()
        wizard = Form(self.env[action['res_model']].with_context(action['context']))
        self.assertEqual(len(wizard.line_ids), 2, "Only delivered goods are proposed")
        self.assertIn(self.product_service.display_name, wizard.skipped_info)
        with wizard.line_ids.edit(0) as wline:
            self.assertEqual(wline.qty_returnable, 6.0)
            wline.quantity = 2.0
        wizard_record = wizard.save()
        wizard_record.action_add_products()
        self.assertEqual(len(ret.order_line), 1)
        self.assertEqual(ret.order_line.product_uom_qty, 2.0)
        self.assertEqual(ret.order_line.origin_move_id, self._delivered_moves(so, self.product_order))

        # "Return All" proposes the remaining quantity of the other delivered moves only
        wizard_record = self.env['customer.return.order.add.products'].with_context(
            default_order_id=ret.id).create({})
        self.assertEqual(wizard_record.line_ids.product_id, self.product_lot)
        wizard_record.action_return_all()
        self.assertEqual(wizard_record.line_ids.quantity, 3.0)
        wizard_record.action_add_products()
        self.assertEqual(len(ret.order_line), 2)

    def test_confirm_creates_standard_return(self):
        so = self._create_so([(self.product_order, 10)])
        self._deliver(so)
        delivery_move = self._delivered_moves(so)
        ret = self._create_return(so, [(delivery_move, 4)])
        ret.action_confirm()
        self.assertEqual(ret.state, 'confirmed')
        receipt = ret.picking_ids
        self.assertEqual(len(receipt), 1)
        self.assertEqual(receipt.picking_type_code, 'incoming')
        self.assertEqual(receipt.return_id, delivery_move.picking_id)
        self.assertEqual(receipt.picking_type_id, delivery_move.picking_type_id.return_picking_type_id)
        self.assertEqual(receipt.location_id, delivery_move.location_dest_id)
        self.assertEqual(receipt.location_dest_id,
                         delivery_move.picking_type_id.return_picking_type_id.default_location_dest_id)
        self.assertEqual(receipt.partner_id, ret.partner_shipping_id)
        self.assertEqual(receipt.customer_return_order_id, ret)
        self.assertIn(ret.name, receipt.origin)
        move = receipt.move_ids
        self.assertEqual(move.origin_returned_move_id, delivery_move)
        self.assertIn(delivery_move, move.move_orig_ids)
        self.assertEqual(move.sale_line_id, so.order_line)
        self.assertTrue(move.to_refund)
        self.assertEqual(move.product_uom_qty, 4.0)
        self.assertEqual(move.customer_return_line_id, ret.order_line)
        self.assertTrue(ret.has_pending_receipt)
        action = ret.action_receive_products()
        self.assertEqual(action['res_id'], receipt.id)
        self.assertEqual(so.customer_return_count, 1)
        self.assertEqual(so.action_view_customer_returns()['res_id'], ret.id)

    def test_partial_receipt_backorder_and_states(self):
        so = self._create_so([(self.product_order, 10)])
        self._deliver(so)
        ret = self._create_return(so, [(self._delivered_moves(so), 4)])
        ret.action_confirm()
        backorder = self._validate(ret.picking_ids, {self.product_order: 3})
        self.assertTrue(backorder)
        self.assertEqual(ret.state, 'partial')
        self.assertEqual(ret.order_line.qty_received, 3.0)
        self.assertEqual(ret.picking_count, 2, "The receipt backorder is linked to the return")
        self.assertEqual(backorder.customer_return_order_id, ret)
        self.assertEqual(backorder.move_ids.customer_return_line_id, ret.order_line)
        self.assertEqual(so.order_line.qty_delivered, 7.0, "Standard returned quantity behaviour")
        self._validate(backorder)
        self.assertEqual(ret.state, 'received')
        self.assertEqual(ret.order_line.qty_received, 4.0)
        self.assertEqual(so.order_line.qty_delivered, 6.0)

    def test_cancelled_backorder_marks_received(self):
        so = self._create_so([(self.product_order, 10)])
        self._deliver(so)
        ret = self._create_return(so, [(self._delivered_moves(so), 4)])
        ret.action_confirm()
        self._validate(ret.picking_ids, {self.product_order: 3}, backorder=False)
        self.assertEqual(ret.state, 'received')
        self.assertEqual(ret.order_line.qty_received, 3.0)

    def test_multiple_deliveries(self):
        so = self._create_so([(self.product_order, 10)])
        backorder = self._deliver(so, {self.product_order: 6})
        self._validate(backorder)
        move_1, move_2 = self._delivered_moves(so)
        self.assertNotEqual(move_1.picking_id, move_2.picking_id)
        ret = self._create_return(so, [(move_1, 2), (move_2, 3)])
        ret.action_confirm()
        receipt = ret.picking_ids
        self.assertEqual(len(receipt), 1, "One receipt for all the original deliveries")
        self.assertEqual(len(receipt.move_ids), 2)
        for return_move in receipt.move_ids:
            # each returned move stays linked to its own delivered move
            origin = return_move.origin_returned_move_id
            self.assertIn(origin, move_1 | move_2)
            self.assertIn(origin, return_move.move_orig_ids)
            self.assertEqual(return_move.customer_return_line_id.origin_move_id, origin)
            self.assertTrue(return_move.to_refund)
        self.assertIn(move_1.picking_id.name, receipt.origin)
        self.assertIn(move_2.picking_id.name, receipt.origin)
        self._validate(receipt)
        self.assertEqual(ret.state, 'received')
        self.assertEqual(so.order_line.qty_delivered, 5.0)

    def test_deliveries_from_two_warehouses(self):
        """Deliveries from different warehouses cannot be received in one transfer."""
        warehouse_2 = self.env['stock.warehouse'].create({
            'name': 'Second Warehouse', 'code': 'WH2', 'company_id': self.company.id})
        self.env['stock.quant']._update_available_quantity(self.product_order, warehouse_2.lot_stock_id, 10.0)
        so_1 = self._create_so([(self.product_order, 3)])
        so_2 = self._create_so([(self.product_order, 3)], warehouse_id=warehouse_2.id)
        self._deliver(so_1)
        self._deliver(so_2)
        ret = self._create_return(so_1 | so_2, [
            (self._delivered_moves(so_1), 1), (self._delivered_moves(so_2), 2)])
        self.assertFalse(ret.warehouse_id, "No common warehouse")
        ret.action_confirm()
        self.assertEqual(len(ret.picking_ids), 2, "One receipt per warehouse")
        self.assertEqual(ret.picking_ids.picking_type_id.warehouse_id, self.warehouse | warehouse_2)
        for receipt in ret.picking_ids:
            self.assertEqual(receipt.move_ids.origin_returned_move_id.picking_id, receipt.return_id)
            self._validate(receipt)
        self.assertEqual(ret.state, 'received')

    def test_returnable_quantity_is_enforced(self):
        so = self._create_so([(self.product_order, 5)])
        self._deliver(so)
        move = self._delivered_moves(so)
        with self.assertRaises(ValidationError):
            self._create_return(so, [(move, 6)])
        ret = self._create_return(so, [(move, 5)])
        with self.assertRaises(ValidationError):
            ret.order_line.product_uom_qty = 5.5
        self.assertEqual(ret.order_line.qty_returnable, 5.0)

    def test_previous_standard_return_is_deducted(self):
        so = self._create_so([(self.product_order, 10)])
        self._deliver(so)
        move = self._delivered_moves(so)
        # Standard return outside of the module
        wizard = self.env['stock.return.picking'].with_context(
            active_model='stock.picking', active_id=move.picking_id.id, active_ids=move.picking_id.ids,
        ).create({'picking_id': move.picking_id.id})
        wizard.product_return_moves.quantity = 2.0
        std_return = self.env['stock.picking'].browse(wizard.action_create_returns()['res_id'])
        # A pending (not validated) standard return already reserves its quantity
        with self.assertRaises(ValidationError):
            self._create_return(so, [(move, 9)])
        self._validate(std_return)
        ret = self._create_return(so, [(move, 8)])
        self.assertEqual(ret.order_line.qty_returnable, 8.0)

    def test_two_returns_cannot_exceed_delivery(self):
        so = self._create_so([(self.product_order, 5)])
        self._deliver(so)
        move = self._delivered_moves(so)
        ret_1 = self._create_return(so, [(move, 3)])
        ret_2 = self._create_return(so, [(move, 3)])
        ret_1.action_confirm()
        with self.assertRaises(ValidationError):
            ret_2.action_confirm()
        self.assertEqual(ret_2.state, 'draft')
        self.assertFalse(ret_2.picking_ids)

    def test_lot_tracked_product(self):
        so = self._create_so([(self.product_lot, 8)])
        self._deliver(so)
        move = self._delivered_moves(so)
        delivered_lots = move.move_line_ids.lot_id
        self.assertEqual(delivered_lots, self.lot_1 | self.lot_2)
        ret = self._create_return(so, [(move, 4)])
        ret.action_confirm()
        receipt = ret.picking_ids
        self.assertTrue(receipt.move_line_ids.lot_id)
        self.assertLessEqual(receipt.move_line_ids.lot_id, delivered_lots,
                             "The receipt proposes the delivered lots")
        self.assertEqual(sum(receipt.move_line_ids.mapped('quantity')), 4.0)
        self._validate(receipt)
        self.assertEqual(ret.order_line.qty_received, 4.0)
        self.assertEqual(self.product_lot.with_context(location=self.stock_location.id).qty_available, 6.0)

    def test_serial_tracked_product(self):
        so = self._create_so([(self.product_serial, 3)])
        self._deliver(so)
        move = self._delivered_moves(so)
        self.assertEqual(move.move_line_ids.lot_id, self.serials)
        ret = self._create_return(so, [(move, 2)])
        ret.action_confirm()
        receipt = ret.picking_ids
        self.assertEqual(len(receipt.move_line_ids), 2, "One line per serial number")
        self.assertTrue(all(ml.quantity == 1 for ml in receipt.move_line_ids))
        self.assertLessEqual(receipt.move_line_ids.lot_id, self.serials)
        self._validate(receipt)
        self.assertEqual(ret.order_line.qty_received, 2.0)
        returned_serials = receipt.move_line_ids.lot_id
        quants = self.env['stock.quant'].search([
            ('lot_id', 'in', returned_serials.ids), ('location_id', '=', receipt.location_dest_id.id)])
        self.assertEqual(sum(quants.mapped('quantity')), 2.0)
        self.assertIn(returned_serials[0].name, ret.order_line.lot_names)

    def test_units_of_measure(self):
        so = self._create_so([(self.product_order, 2, {
            'product_uom_id': self.uom_dozen.id, 'price_unit': 1200.0})])
        self._deliver(so)
        move = self._delivered_moves(so)
        ret = self._create_return(so, [(move, 0.5)])
        self.assertEqual(ret.order_line.product_uom_id, self.uom_dozen)
        self.assertEqual(ret.order_line.qty_returnable, 2.0)
        ret.action_confirm()
        return_move = ret.picking_ids.move_ids
        self.assertEqual(
            return_move.product_uom._compute_quantity(return_move.product_uom_qty, self.uom_unit), 6.0)
        self._validate(ret.picking_ids)
        self.assertEqual(ret.order_line.qty_received, 0.5)
        self.assertEqual(so.order_line.qty_delivered, 1.5)

    def test_service_lines_are_blocked(self):
        so = self._create_so([(self.product_order, 2), (self.product_service, 1)])
        self._deliver(so)
        goods_move = self._delivered_moves(so)
        service_line = so.order_line.filtered(lambda l: l.product_id == self.product_service)
        with self.assertRaisesRegex(ValidationError, 'service'):
            self.env['customer.return.order'].create({
                'sale_order_ids': [Command.set(so.ids)],
                'order_line': [Command.create({
                    'sale_line_id': service_line.id,
                    'origin_move_id': goods_move.id,
                    'product_uom_qty': 1,
                })],
            })

    def test_line_must_match_sale_order(self):
        so_1 = self._create_so([(self.product_order, 2)])
        so_2 = self._create_so([(self.product_order, 2)])
        self._deliver(so_1)
        self._deliver(so_2)
        with self.assertRaises(ValidationError):
            self.env['customer.return.order'].create({
                'sale_order_ids': [Command.set(so_1.ids)],
                'order_line': [Command.create({
                    'sale_line_id': so_2.order_line.id,
                    'origin_move_id': self._delivered_moves(so_2).id,
                    'product_uom_qty': 1,
                })],
            })

    def test_readonly_after_confirmation(self):
        so = self._create_so([(self.product_order, 5)])
        self._deliver(so)
        ret = self._create_return(so, [(self._delivered_moves(so), 2)])
        ret.action_confirm()
        with self.assertRaises(UserError):
            ret.partner_shipping_id = self.partner_b
        with self.assertRaises(UserError):
            ret.order_line.product_uom_qty = 1.0
        with self.assertRaises(UserError):
            ret.order_line.price_unit = 1.0
        with self.assertRaises(UserError):
            ret.order_line.unlink()
        with self.assertRaises(UserError):
            ret.write({'order_line': [Command.create({
                'sale_line_id': so.order_line.id,
                'origin_move_id': self._delivered_moves(so).id,
                'product_uom_qty': 1,
            })]})
        # Controlled exceptions
        ret.write({
            'internal_note': '<p>Inspected</p>',
            'note': '<p>Terms</p>',
            'return_reason_id': self.env.ref('customer_return_order.return_reason_damaged').id,
            'user_id': self.user_salesman.id,
        })
        self.assertEqual(ret.user_id, self.user_salesman)
        with self.assertRaises(UserError):
            ret.unlink()

    def test_cancel_and_reset(self):
        so = self._create_so([(self.product_order, 5)])
        self._deliver(so)
        ret = self._create_return(so, [(self._delivered_moves(so), 2)])
        ret.action_confirm()
        receipt = ret.picking_ids
        ret.action_cancel()
        self.assertEqual(ret.state, 'cancel')
        self.assertEqual(receipt.state, 'cancel')
        self.assertEqual(ret.order_line.qty_returnable, 5.0, "Cancelled receipts free the quantity")
        ret.action_draft()
        self.assertEqual(ret.state, 'draft')
        ret.action_confirm()
        new_receipt = ret.picking_ids.filtered(lambda p: p.state != 'cancel')
        self.assertEqual(len(new_receipt), 1)
        self._validate(new_receipt)
        with self.assertRaisesRegex(UserError, 'already been received'):
            ret.action_cancel()
        self.assertEqual(new_receipt.state, 'done', "Validated receipts are never cancelled")

    def test_return_of_return_reduces_received(self):
        so = self._create_so([(self.product_order, 5)])
        self._deliver(so)
        ret = self._create_return(so, [(self._delivered_moves(so), 3)])
        ret.action_confirm()
        receipt = ret.picking_ids
        self._validate(receipt)
        self.assertEqual(ret.order_line.qty_received, 3.0)
        wizard = self.env['stock.return.picking'].with_context(
            active_model='stock.picking', active_id=receipt.id, active_ids=receipt.ids,
        ).create({'picking_id': receipt.id})
        wizard.product_return_moves.quantity = 1.0
        back = self.env['stock.picking'].browse(wizard.action_create_returns()['res_id'])
        self._validate(back)
        self.assertEqual(ret.order_line.qty_received, 2.0)

    def test_report_renders(self):
        so = self._create_so([(self.product_order, 5, {'discount': 5.0})])
        self._deliver(so)
        ret = self._create_return(so, [(self._delivered_moves(so), 2)],
                                  return_reason_id=self.env.ref('customer_return_order.return_reason_damaged').id)
        html = self.env['ir.actions.report']._render_qweb_html(
            'customer_return_order.report_customer_return_order', ret.ids)[0]
        self.assertIn(ret.name, html.decode())
        self.assertIn(self.product_order.name, html.decode())

    def test_form_view_flow(self):
        """Create a return through the form view, as the web client does."""
        so = self._create_so([(self.product_order, 5)], partner=self.partner_b)
        self._deliver(so)
        with Form(self.env['customer.return.order']) as form:
            form.partner_id = self.partner_b
            form.sale_order_ids.add(so)
            self.assertEqual(form.partner_invoice_id, so.partner_invoice_id)
            form.return_reason_id = self.env.ref('customer_return_order.return_reason_wrong_product')
            with form.order_line.new() as line:
                line.sale_line_id = so.order_line
                self.assertEqual(line.origin_move_id, self._delivered_moves(so),
                                 "The single delivered move is proposed automatically")
                line.product_uom_qty = 2
        ret = form.record
        self.assertEqual(ret.order_line.product_id, self.product_order)
        self.assertEqual(ret.order_line.return_reason_id, ret.return_reason_id)
        self.assertEqual(ret.order_line.price_unit, so.order_line.price_unit)
        ret.action_confirm()
        with Form(ret) as form:
            form.internal_note = '<p>Checked by QA</p>'
        self.assertEqual(ret.state, 'confirmed')
