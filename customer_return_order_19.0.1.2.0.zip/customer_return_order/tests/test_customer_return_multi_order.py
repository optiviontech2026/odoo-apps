from odoo.exceptions import UserError, ValidationError
from odoo.fields import Command
from odoo.tests import Form, tagged

from .common import CustomerReturnCommon


@tagged('post_install', '-at_install')
class TestCustomerReturnMultiOrder(CustomerReturnCommon):
    """One return order for several original sales orders of the same customer."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.customer_contact = cls.env['res.partner'].create({
            'name': 'Purchasing Contact', 'parent_id': cls.customer.id, 'type': 'contact'})

    def _two_orders(self, invoice=True):
        so_1 = self._create_so([(self.product_order, 5, {'price_unit': 100.0})])
        so_2 = self._create_so([(self.product_delivery, 4, {'price_unit': 80.0}), (self.product_lot, 2)],
                               partner=self.customer_contact)
        self._deliver(so_1)
        self._deliver(so_2)
        invoices = self.env['account.move']
        if invoice:
            invoices = self._invoice(so_1) | self._invoice(so_2)
        return so_1, so_2, invoices

    def test_header_from_several_orders(self):
        so_1, so_2, invoices = self._two_orders()
        ret = self._create_return(
            so_1 | so_2,
            [(self._delivered_moves(so_1), 2), (self._delivered_moves(so_2, self.product_delivery), 1)])
        self.assertEqual(ret.sale_order_count, 2)
        self.assertEqual(ret.partner_id.commercial_partner_id, self.customer)
        self.assertEqual(ret.invoice_ids, invoices, "Invoices of all the original orders")
        self.assertEqual(ret.invoice_count, 2)
        self.assertEqual(ret.warehouse_id, self.warehouse)
        self.assertEqual(ret.currency_id, so_1.currency_id)
        self.assertEqual(ret.order_line.sale_order_id, so_1 | so_2)
        self.assertEqual(so_1.customer_return_ids, ret)
        self.assertEqual(so_2.customer_return_ids, ret)
        self.assertEqual(so_2.customer_return_count, 1)
        action = ret.action_view_sale_orders()
        self.assertEqual(action['domain'], [('id', 'in', (so_1 | so_2).ids)])
        # Grouping the list by original order works on the many2many
        groups = self.env['customer.return.order']._read_group(
            [('id', '=', ret.id)], ['sale_order_ids'], ['__count'])
        self.assertEqual({group[0] for group in groups}, set(so_1 | so_2))

    def test_full_flow_several_orders(self):
        """Several orders of the same customer: one receipt and one credit note."""
        so_1 = self._create_so([(self.product_order, 5, {'price_unit': 100.0, 'discount': 10.0})])
        so_2 = self._create_so([(self.product_delivery, 4, {'price_unit': 80.0}), (self.product_lot, 2)])
        self._deliver(so_1)
        self._deliver(so_2)
        invoice_1 = self._invoice(so_1)
        invoice_2 = self._invoice(so_2)
        ret = self._create_return(so_1 | so_2, [
            (self._delivered_moves(so_1), 2),
            (self._delivered_moves(so_2, self.product_delivery), 3),
            (self._delivered_moves(so_2, self.product_lot), 1),
        ])
        ret.action_confirm()

        receipt = ret.picking_ids
        self.assertEqual(len(receipt), 1, "One receipt for all the original orders")
        self.assertEqual(len(receipt.move_ids), 3)
        deliveries = (self._delivered_moves(so_1) | self._delivered_moves(so_2)).picking_id
        self.assertEqual(receipt.move_ids.origin_returned_move_id.picking_id, deliveries)
        self.assertEqual(receipt.move_ids.sale_line_id.order_id, so_1 | so_2)
        self.assertTrue(all(receipt.move_ids.mapped('to_refund')))
        lot_move = receipt.move_ids.filtered(lambda m: m.product_id == self.product_lot)
        self.assertTrue(lot_move.move_line_ids.lot_id, "Delivered lots are proposed")
        self._validate(receipt)
        self.assertEqual(ret.state, 'received')
        self.assertEqual(so_1.order_line.qty_delivered, 3.0)
        delivery_line = so_2.order_line.filtered(lambda l: l.product_id == self.product_delivery)
        self.assertEqual(delivery_line.qty_delivered, 1.0)

        ret.action_create_credit_note()
        refund = ret.credit_note_ids
        self.assertEqual(len(refund), 1, "One credit note for all the original invoices")
        self.assertEqual(refund.state, 'draft')
        self.assertFalse(refund.reversed_entry_id)
        self.assertIn(invoice_1.name, refund.ref)
        self.assertIn(invoice_2.name, refund.ref)
        self.assertIn(so_1.name, refund.invoice_origin)
        self.assertIn(so_2.name, refund.invoice_origin)
        lines = refund.invoice_line_ids.filtered(lambda l: l.display_type == 'product')
        self.assertEqual(len(lines), 3)
        self.assertEqual(lines.customer_return_line_id, ret.order_line)
        self.assertEqual(lines.customer_return_origin_line_id.move_id, invoice_1 | invoice_2)
        for line in lines:
            origin = line.customer_return_origin_line_id
            self.assertEqual(line.price_unit, origin.price_unit)
            self.assertEqual(line.discount, origin.discount)
            self.assertEqual(line.tax_ids, origin.tax_ids)
            self.assertEqual(line.account_id, origin.account_id)
            self.assertEqual(line.sale_line_ids, origin.sale_line_ids)
            self.assertEqual(line.quantity, line.customer_return_line_id.product_uom_qty)
        self.assertAlmostEqual(refund.amount_untaxed, 2 * 90.0 + 3 * 80.0 + 1 * 100.0)
        refund.action_post()
        self.assertEqual(refund.state, 'posted')
        self.assertEqual(ret.credit_status, 'credited')
        self.assertEqual(so_1.order_line.qty_invoiced, 3.0)
        self.assertEqual(delivery_line.qty_invoiced, delivery_line.qty_delivered)

        html = self.env['ir.actions.report']._render_qweb_html(
            'customer_return_order.report_customer_return_order', ret.ids)[0].decode()
        self.assertIn(so_1.name, html)
        self.assertIn(so_2.name, html)

    def test_incompatible_invoices_get_separate_credit_notes(self):
        """Invoices Odoo would not combine (here: another invoice address) are credited separately."""
        so_1 = self._create_so([(self.product_order, 3)])
        self._deliver(so_1)
        invoice_1 = self._invoice(so_1)
        # The customer gets a dedicated invoice address before the second order
        invoice_address = self.env['res.partner'].create({
            'name': 'Accounts Payable', 'parent_id': self.customer.id, 'type': 'invoice'})
        so_2 = self._create_so([(self.product_order, 3)])
        self.assertEqual(so_2.partner_invoice_id, invoice_address)
        self._deliver(so_2)
        invoice_2 = self._invoice(so_2)
        self.assertNotEqual(invoice_1.partner_id, invoice_2.partner_id)
        ret = self._create_return(so_1 | so_2, [
            (self._delivered_moves(so_1), 1), (self._delivered_moves(so_2), 1)])
        ret.action_confirm()
        self.assertEqual(len(ret.picking_ids), 1, "Still one receipt")
        self._validate(ret.picking_ids)
        ret.action_create_credit_note()
        refunds = ret.credit_note_ids
        self.assertEqual(len(refunds), 2)
        self.assertEqual(refunds.reversed_entry_id, invoice_1 | invoice_2)
        self.assertEqual(refunds.partner_id, invoice_1.partner_id | invoice_2.partner_id)

    def test_one_order_invoiced_the_other_not(self):
        so_1 = self._create_so([(self.product_order, 5)])
        so_2 = self._create_so([(self.product_order, 5)])
        self._deliver(so_1)
        self._deliver(so_2)
        invoice_1 = self._invoice(so_1)
        ret = self._create_return(so_1 | so_2, [
            (self._delivered_moves(so_1), 1), (self._delivered_moves(so_2), 2)])
        ret.action_confirm()
        for receipt in ret.picking_ids:
            self._validate(receipt)
        line_1 = ret.order_line.filtered(lambda l: l.sale_order_id == so_1)
        line_2 = ret.order_line - line_1
        self.assertEqual(line_1.qty_to_credit, 1.0)
        self.assertEqual(line_2.qty_to_credit, 0.0)
        self.assertIn('Not invoiced', line_2.credit_info)
        ret.action_create_credit_note()
        self.assertEqual(ret.credit_note_ids.reversed_entry_id, invoice_1)
        self.assertEqual(ret.credit_status, 'credited')

    def test_add_products_wizard_lists_all_orders(self):
        so_1, so_2, _invoices = self._two_orders(invoice=False)
        ret = self.env['customer.return.order'].create({'sale_order_ids': [Command.set((so_1 | so_2).ids)]})
        wizard = self.env['customer.return.order.add.products'].with_context(default_order_id=ret.id).create({})
        self.assertEqual(wizard.line_ids.sale_order_id, so_1 | so_2)
        self.assertEqual(len(wizard.line_ids), 3)
        wizard.action_return_all()
        wizard.action_add_products()
        self.assertEqual(len(ret.order_line), 3)
        self.assertEqual(ret.order_line.sale_order_id, so_1 | so_2)

    def test_orders_must_share_customer_company_currency(self):
        so_1 = self._create_so([(self.product_order, 2)])
        so_other_customer = self._create_so([(self.product_order, 2)], partner=self.partner_b)
        with self.assertRaisesRegex(ValidationError, 'must belong to its customer'):
            self._create_return(so_1 | so_other_customer, [])

        currency = self.setup_other_currency('EUR')
        pricelist = self.env['product.pricelist'].create({
            'name': 'EUR', 'currency_id': currency.id, 'company_id': self.company.id})
        so_eur = self._create_so([(self.product_order, 2)], pricelist_id=pricelist.id)
        with self.assertRaisesRegex(ValidationError, 'same currency'):
            self._create_return(so_1 | so_eur, [])

        with self.assertRaisesRegex(ValidationError, 'at least one'):
            self.env['customer.return.order'].create({'partner_id': self.customer.id})

    def test_line_order_must_be_selected(self):
        so_1 = self._create_so([(self.product_order, 2)])
        so_2 = self._create_so([(self.product_order, 2)])
        self._deliver(so_1)
        self._deliver(so_2)
        with self.assertRaisesRegex(ValidationError, 'Add %s' % so_2.name):
            self._create_return(so_1, [(self._delivered_moves(so_2), 1)])

    def test_removing_an_order_removes_its_lines(self):
        so_1 = self._create_so([(self.product_order, 3)])
        so_2 = self._create_so([(self.product_order, 3)])
        self._deliver(so_1)
        self._deliver(so_2)
        form = Form(self.env['customer.return.order'])
        form.sale_order_ids.add(so_1)
        form.sale_order_ids.add(so_2)
        self.assertEqual(form.partner_id, self.customer)
        for so in (so_1, so_2):
            with form.order_line.new() as line:
                line.sale_line_id = so.order_line
                line.product_uom_qty = 1
        form.sale_order_ids.remove(id=so_2.id)
        ret = form.save()
        self.assertEqual(ret.sale_order_ids, so_1)
        self.assertEqual(ret.order_line.sale_order_id, so_1)

    def test_orders_locked_after_confirmation(self):
        so_1 = self._create_so([(self.product_order, 3)])
        so_2 = self._create_so([(self.product_order, 3)])
        self._deliver(so_1)
        ret = self._create_return(so_1, [(self._delivered_moves(so_1), 1)])
        ret.action_confirm()
        with self.assertRaises(UserError):
            ret.sale_order_ids = [Command.link(so_2.id)]
        self.assertEqual(ret.sale_order_ids, so_1)
