from odoo.exceptions import AccessError, UserError
from odoo.fields import Command
from odoo.tests import new_test_user, tagged

from .common import CustomerReturnCommon


@tagged('post_install', '-at_install')
class TestCustomerReturnSecurity(CustomerReturnCommon):

    def test_role_based_workflow(self):
        """Sales user creates and confirms, inventory user receives, billing user credits."""
        so = self._create_so([(self.product_order, 5)], user=self.user_salesman)
        self._deliver(so)
        self._invoice(so)

        salesman_env = self.env(user=self.user_salesman)
        ret = self._create_return(so.with_env(salesman_env), [(self._delivered_moves(so).with_env(salesman_env), 2)],
                                  env=salesman_env)
        ret.action_confirm()
        self.assertEqual(ret.state, 'confirmed')

        # Sales users cannot create credit notes
        self.assertFalse(self.user_salesman.has_group('account.group_account_invoice'))
        receipt = ret.picking_ids
        self._validate(receipt.with_user(self.user_stock))
        self.assertEqual(ret.state, 'received')
        with self.assertRaises(AccessError):
            ret.action_create_credit_note()

        # Inventory users can read but not modify returns
        ret_as_stock = ret.with_user(self.user_stock)
        self.assertEqual(ret_as_stock.name, ret.name)
        with self.assertRaises(AccessError):
            ret_as_stock.write({'internal_note': 'x'})

        # Billing users create the draft credit note
        ret_as_billing = ret.with_user(self.user_billing)
        ret_as_billing.action_create_credit_note()
        refund = ret.credit_note_ids
        self.assertEqual(refund.state, 'draft')
        self.assertEqual(refund.create_uid, self.user_billing)
        with self.assertRaises(AccessError):
            ret_as_billing.write({'internal_note': 'x'})

    def test_salesman_own_documents(self):
        so = self._create_so([(self.product_order, 5)], user=self.user_salesman)
        self._deliver(so)
        ret = self._create_return(so, [(self._delivered_moves(so), 1)])
        self.assertEqual(ret.user_id, self.user_salesman)
        Return = self.env['customer.return.order']
        self.assertIn(ret, Return.with_user(self.user_salesman).search([]))
        self.assertNotIn(ret, Return.with_user(self.user_salesman_2).search([]))
        with self.assertRaises(AccessError):
            ret.with_user(self.user_salesman_2).read(['name'])
        manager = new_test_user(self.env, login='cro_sales_manager', groups='sales_team.group_sale_manager',
                                company_id=self.company.id, company_ids=[Command.set(self.company.ids)])
        self.assertIn(ret, Return.with_user(manager).search([]))

    def test_salesman_cannot_delete(self):
        so = self._create_so([(self.product_order, 5)], user=self.user_salesman)
        self._deliver(so)
        ret = self._create_return(so, [(self._delivered_moves(so), 1)])
        with self.assertRaises(AccessError):
            ret.with_user(self.user_salesman).unlink()
        ret.unlink()  # sales manager (test user) can delete drafts

    def test_multi_company_isolation(self):
        company_2 = self.setup_other_company()['company']
        warehouse_2 = self.env['stock.warehouse'].search([('company_id', '=', company_2.id)], limit=1)
        product = self.product_order
        self.env['stock.quant'].with_company(company_2)._update_available_quantity(
            product, warehouse_2.lot_stock_id, 10.0)
        so_2 = self.env['sale.order'].with_company(company_2).create({
            'partner_id': self.customer.id,
            'company_id': company_2.id,
            'warehouse_id': warehouse_2.id,
            'order_line': [Command.create({'product_id': product.id, 'product_uom_qty': 3})],
        })
        so_2.action_confirm()
        picking = so_2.picking_ids
        picking.move_ids.picked = True
        picking._action_done()
        move_2 = self._delivered_moves(so_2)

        ret_2 = self.env['customer.return.order'].with_company(company_2).create({
            'sale_order_ids': [Command.set(so_2.ids)],
            'company_id': company_2.id,
            'order_line': [Command.create({
                'sale_line_id': so_2.order_line.id, 'origin_move_id': move_2.id, 'product_uom_qty': 1})],
        })
        self.assertEqual(ret_2.company_id, company_2)
        ret_2.with_company(company_2).action_confirm()
        self.assertEqual(ret_2.picking_ids.company_id, company_2)
        self.assertEqual(ret_2.picking_ids.picking_type_id.warehouse_id, warehouse_2)

        # A company-1 user does not see company-2 returns
        self.assertNotIn(ret_2, self.env['customer.return.order'].with_user(self.user_billing).search([]))
        with self.assertRaises(AccessError):
            ret_2.with_user(self.user_billing).read(['name'])

        # A company-1 return cannot use a company-2 sales order
        with self.assertRaises(UserError):  # ValidationError is a UserError
            self.env['customer.return.order'].create({
                'sale_order_ids': [Command.set(so_2.ids)],
                'company_id': self.company.id,
            })

    def test_concurrent_credit_lock(self):
        """A row locked by another transaction gives a clear message instead of waiting."""
        from odoo.sql_db import db_connect
        # A committed row that this test transaction never writes
        country_id = self.env.ref('base.aq').id
        other_cr = db_connect(self.env.cr.dbname).cursor()
        try:
            other_cr.execute("SET lock_timeout = '5s'")
            other_cr.execute("SELECT id FROM res_country WHERE id = %s FOR UPDATE", [country_id])
            with self.assertRaisesRegex(UserError, 'busy'):
                self.env['customer.return.order']._cro_lock_rows('res_country', [country_id], 'busy')
        finally:
            other_cr.rollback()
            other_cr.close()
