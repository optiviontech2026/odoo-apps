from odoo import api, fields, models
from odoo.exceptions import UserError
from odoo.fields import Command


class CustomerReturnAddProducts(models.TransientModel):
    _name = 'customer.return.order.add.products'
    _description = 'Select Products to Return'

    order_id = fields.Many2one('customer.return.order', string='Return Order', required=True, readonly=True)
    sale_order_ids = fields.Many2many(related='order_id.sale_order_ids')
    line_ids = fields.One2many('customer.return.order.add.products.line', 'wizard_id', string='Delivered Products')
    skipped_info = fields.Text(readonly=True)

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        order = self.env['customer.return.order'].browse(
            res.get('order_id') or self.env.context.get('default_order_id'))
        if not order:
            return res
        if order.state != 'draft':
            raise UserError(self.env._("Products can only be added to draft return orders."))
        lines, skipped = self._prepare_lines(order)
        if 'line_ids' in fields_list:
            res['line_ids'] = [Command.create(vals) for vals in lines]
        if 'skipped_info' in fields_list and skipped:
            res['skipped_info'] = '\n'.join(skipped)
        return res

    @api.model
    def _prepare_lines(self, order):
        """One line per completed delivery move of the original orders with a remaining
        returnable quantity. Moves already on the return are skipped."""
        existing_moves = order.order_line.origin_move_id
        lines, skipped = [], []
        sale_lines = order.sale_order_ids.sorted(lambda so: (so.date_order, so.id)).order_line
        for sale_line in sale_lines.filtered(lambda l: not l.display_type):
            product = sale_line.product_id
            if product.type == 'service':
                skipped.append(self.env._(
                    "%(order)s - %(product)s: services require a separate credit-only process.",
                    order=sale_line.order_id.name, product=product.display_name))
                continue
            if product.type != 'consu':
                continue
            moves = sale_line.move_ids.filtered(
                lambda m: m.state == 'done' and m.location_dest_id.usage == 'customer'
                and m.location_id.usage != 'customer' and m not in existing_moves)
            kit_moves = moves.filtered(lambda m: m.product_id != product)
            if kit_moves:
                skipped.append(self.env._(
                    "%(order)s - %(product)s: delivered as kit components, not supported.",
                    order=sale_line.order_id.name, product=product.display_name))
            for move in (moves - kit_moves).sorted(lambda m: (m.date, m.id)):
                uom = sale_line.product_uom_id
                returned = 0.0
                for returned_move in move.returned_move_ids.filtered(lambda m: m.state != 'cancel'):
                    qty = returned_move.quantity if returned_move.state == 'done' else returned_move.product_uom_qty
                    returned += returned_move.product_uom._compute_quantity(qty, move.product_uom, round=False)
                remaining = move.product_uom._compute_quantity(max(move.quantity - returned, 0.0), uom, round=False)
                if remaining <= 0 or uom.is_zero(remaining):
                    continue
                lines.append({
                    'sale_line_id': sale_line.id,
                    'origin_move_id': move.id,
                    'qty_delivered': move.product_uom._compute_quantity(move.quantity, uom, round=False),
                    'qty_returnable': uom.round(remaining),
                    'quantity': 0.0,
                })
        return lines, skipped

    def action_return_all(self):
        self.ensure_one()
        for line in self.line_ids:
            line.quantity = line.qty_returnable
        return {
            'type': 'ir.actions.act_window',
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
            'name': self.env._("Select Products to Return"),
        }

    def action_add_products(self):
        self.ensure_one()
        order = self.order_id
        if order.state != 'draft':
            raise UserError(self.env._("Products can only be added to draft return orders."))
        selected = self.line_ids.filtered(lambda l: l.quantity > 0 and not l.product_uom_id.is_zero(l.quantity))
        if not selected:
            raise UserError(self.env._("Set a quantity to return on at least one line."))
        for line in selected:
            if line.product_uom_id.compare(line.quantity, line.qty_returnable) > 0:
                raise UserError(self.env._(
                    "You cannot return more than %(qty)s %(uom)s of %(product)s from %(delivery)s.",
                    qty=line.qty_returnable, uom=line.product_uom_id.name,
                    product=line.product_id.display_name, delivery=line.delivery_picking_id.name))
        order.write({'order_line': [Command.create({
            'sale_line_id': line.sale_line_id.id,
            'origin_move_id': line.origin_move_id.id,
            'product_uom_qty': line.quantity,
            'return_reason_id': order.return_reason_id.id,
        }) for line in selected]})
        return {'type': 'ir.actions.act_window_close'}


class CustomerReturnAddProductsLine(models.TransientModel):
    _name = 'customer.return.order.add.products.line'
    _description = 'Select Products to Return - Line'

    wizard_id = fields.Many2one('customer.return.order.add.products', required=True, ondelete='cascade')
    sale_line_id = fields.Many2one('sale.order.line', string='Order Line', required=True, readonly=True)
    sale_order_id = fields.Many2one(related='sale_line_id.order_id', string='Sales Order')
    origin_move_id = fields.Many2one('stock.move', string='Delivered Move', required=True, readonly=True)
    product_id = fields.Many2one(related='sale_line_id.product_id')
    delivery_picking_id = fields.Many2one(related='origin_move_id.picking_id', string='Delivery')
    delivery_date = fields.Datetime(related='origin_move_id.date', string='Delivered On')
    lot_names = fields.Char(string='Lots/Serial Numbers', compute='_compute_lot_names')
    product_uom_id = fields.Many2one(related='sale_line_id.product_uom_id')
    price_unit = fields.Float(related='sale_line_id.price_unit')
    discount = fields.Float(related='sale_line_id.discount')
    qty_delivered = fields.Float(string='Delivered', digits='Product Unit', readonly=True)
    qty_returnable = fields.Float(string='Returnable', digits='Product Unit', readonly=True)
    quantity = fields.Float(string='To Return', digits='Product Unit')

    @api.depends('origin_move_id')
    def _compute_lot_names(self):
        for line in self:
            line.lot_names = ', '.join(line.origin_move_id.move_line_ids.lot_id.mapped('name'))
