from odoo import fields, models


class StockReturnPickingLine(models.TransientModel):
    _inherit = 'stock.return.picking.line'

    customer_return_line_id = fields.Many2one('customer.return.order.line', string='Customer Return Line')

    def _prepare_move_default_values(self, new_picking):
        vals = super()._prepare_move_default_values(new_picking)
        if self.customer_return_line_id:
            vals['customer_return_line_id'] = self.customer_return_line_id.id
        return vals


class StockReturnPicking(models.TransientModel):
    _inherit = 'stock.return.picking'

    customer_return_order_id = fields.Many2one('customer.return.order', string='Customer Return Order')
