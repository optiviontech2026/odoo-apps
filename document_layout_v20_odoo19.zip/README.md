# Document Layout – Odoo 20 Edition (for Odoo 19)

Two modules that replace the Odoo 19 **Configure your document layout** window with the Odoo 20 version.
They were ported from the Odoo 20.0 source code and tested on Odoo 19.0 (Community + Accounting).

| Module | What it does | Install |
|---|---|---|
| `document_layout_v20` | Odoo 20 layouts, table designs, fonts, preview and PDF rendering | Install it |
| `document_layout_v20_account` | Odoo 20 Accounting behaviour of the configurator | Installs automatically with Accounting |

## What the configurator offers (exactly the Odoo 20 options)

| Setting | Odoo 19 | Odoo 20 (this module) |
|---|---|---|
| **Layout** | Light, Boxed, Bold, Striped, Bubble, Wave, Folder | **Light, Bubble, Wave, Folder, Center, Dual, Lines, Compact** (redesigned Odoo 20 versions) |
| **Tables** | – | **Light, Boxed, Bold, Striped, Bubble, Column, Compact** (new, independent of the layout) |
| **Text** | … Tajawal, Fira Mono | … Tajawal, **Noto Sans Mono** (font files included) |
| **Background** | Blank / Demo logo / Custom | **Removed** (as in Odoo 20) |
| Logo, Colors, Address, Tagline, Footer, Paper format | yes | yes |
| Preview | 2-line sample | Odoo 20 4-line sample, "Page 1 / 1" footer |

Accounting (`document_layout_v20_account`):
* Users with basic Accounting rights, not only administrators, configure the layout when they print their first invoice. The preview shows that invoice.
* **Configure Later** button: print now, and configure on the next print.
* Accounting users can only change the layout fields of companies they are allowed in. Those fields (logo, header, footer, address, paper format, font, colors, tables, QR code, tax ID) are written with elevated rights, as in Odoo 20.

## Installation

1. Copy both folders into your custom addons path.
2. Restart Odoo, then go to **Apps → Update Apps List**.
3. Install **Document Layout - Odoo 20 Edition**. The Accounting module installs with it automatically.
4. Go to **Settings → Companies → Configure Document Layout**.

### What happens to existing companies

On installation each company moves to the Odoo 20 equivalent of its current setup, as the Odoo 20 upgrade does:

| Odoo 19 layout | Becomes |
|---|---|
| Light | Light layout + Light tables |
| Boxed / Bold / Striped | Light layout + Boxed / Bold / Striped tables |
| Bubble | Bubble layout + Bubble tables |
| Wave / Folder | Wave / Folder layout + Striped tables |
| Fira Mono font | Noto Sans Mono |

A company with no layout prints with the Odoo 20 Light layout.

### Uninstalling

Each company gets back the closest Odoo 19 layout (for example, Light + Bold tables becomes Bold; Center/Dual/Lines/Compact become Light). Noto Sans Mono goes back to Fira Mono.

## Notes

* **Business document content is unchanged.** The invoice, quotation and other document bodies are still the Odoo 19 templates. The page layout around them, the table styling and the configurator follow Odoo 20.
* The Odoo 20 layouts are separate templates (`document_layout_v20.external_layout_*`). Localization modules that customize the *Odoo 19* layouts (e.g. `l10n_sa`, `l10n_cz`, `l10n_ph`) do not change these templates. Other layouts such as DIN 5008 stay available.
* Odoo 20 uses new badge widgets built on a newer web framework. Here the Layout and Tables choices use the Odoo 19 badge widget: same choices, slightly different look.
* As with standard Odoo, PDF headers and footers need **wkhtmltopdf 0.12.6.x "with patched qt"**. An unpatched build prints documents without their header and footer.

License: LGPL-3 (contains code ported from Odoo Community). Noto Sans Mono: SIL Open Font License 1.1.
