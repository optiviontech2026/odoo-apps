{
    'name': 'Document Layout - Odoo 20 Edition',
    'version': '19.0.1.0.0',
    'summary': 'The Odoo 20 "Configure your document layout" in Odoo 19: '
               'Odoo 20 layouts, table designs and fonts only',
    'description': """
Brings the Odoo 20 document layout configuration to Odoo 19
==============================================================

The *Configure your document layout* window offers exactly what Odoo 20 offers:

* **Layout**: Light, Bubble, Wave, Folder, Center, Dual, Lines, Compact
  (the Odoo 20 versions; the Odoo 19 Boxed / Bold / Striped page layouts are gone)
* **Tables**: new, independent table design - Light, Boxed, Bold, Striped,
  Bubble, Column, Compact
* **Text**: the Odoo 20 fonts (Noto Sans Mono replaces Fira Mono)
* Logo, Colors, Address, Tagline, Footer, Paper format
* No more Background option (removed in Odoo 20)
* Odoo 20 preview (4-line sample invoice, page counter)

On installation each company is moved to the Odoo 20 equivalent of its current
layout (e.g. Odoo 19 "Boxed" becomes Light layout + Boxed tables), as the
Odoo 20 upgrade does. Uninstalling restores the closest Odoo 19 layout.
""",
    'category': 'Productivity',
    'author': 'Optivion Tech',
    'license': 'LGPL-3',
    'depends': ['web'],
    'data': [
        'views/report_templates.xml',
        'views/base_document_layout_views.xml',
        'data/report_layout_data.xml',
    ],
    'assets': {
        'web.report_assets_common': [
            ('after',
             'web/static/src/webclient/actions/reports/report_tables.scss',
             'document_layout_v20/static/src/report/*.scss'),
        ],
        'web.assets_backend': [
            'document_layout_v20/static/src/scss/base_document_layout_v20.scss',
        ],
    },
    'post_init_hook': 'post_init_hook',
    'uninstall_hook': 'uninstall_hook',
    'installable': True,
    'application': False,
}
