import logging

from .models.const import (
    LEGACY_FONT_MAP,
    LEGACY_LAYOUT_MAP,
    REVERSE_LAYOUT_MAP,
    REVERSE_LIGHT_BY_TABLES,
)

_logger = logging.getLogger(__name__)


def post_init_hook(env):
    """Move every company to the Odoo 20 equivalent of its current setup.

    Boxed / Bold / Striped become the Light layout with the matching table
    design; Bubble, Wave and Folder become their Odoo 20 versions; Fira Mono
    becomes Noto Sans Mono.
    """
    companies = env['res.company'].sudo().with_context(active_test=False).search([])
    for company in companies:
        vals = {}
        legacy_key = company.external_report_layout_id.key
        if legacy_key in LEGACY_LAYOUT_MAP:
            xmlid, tables = LEGACY_LAYOUT_MAP[legacy_key]
            vals['external_report_layout_id'] = env.ref(xmlid).view_id.id
            vals['report_tables_id'] = tables
        if company.font in LEGACY_FONT_MAP:
            vals['font'] = LEGACY_FONT_MAP[company.font]
        if vals:
            _logger.info("Odoo 20 document layout: company %s -> %s", company.name, vals)
            company.write(vals)
    companies._update_asset_style()


def uninstall_hook(env):
    """Give every company back the closest Odoo 19 layout and font."""
    companies = env['res.company'].sudo().with_context(active_test=False).search([])
    for company in companies:
        vals = {}
        key = company.external_report_layout_id.key or ''
        if key.startswith('document_layout_v20.'):
            if key == 'document_layout_v20.external_layout_light':
                target = REVERSE_LIGHT_BY_TABLES.get(company.report_tables_id, 'web.external_layout_standard')
            else:
                target = REVERSE_LAYOUT_MAP.get(key, 'web.external_layout_standard')
            vals['external_report_layout_id'] = env.ref(target).id
        if company.font == 'Noto_Sans_Mono':
            vals['font'] = 'Fira_Mono'
        if vals:
            company.write(vals)

    # Rebuild the company stylesheet without the Odoo 20 rules.
    style_view = env.ref('document_layout_v20.styles_company_report', raise_if_not_found=False)
    if style_view:
        style_view.sudo().active = False
    companies._update_asset_style()
    env.registry.clear_cache('assets')
