from odoo import api, fields, models

from .const import FONT_KEYS, FONTS, LEGACY_FONT_MAP, LEGACY_LAYOUT_MAP


class BaseDocumentLayout(models.TransientModel):
    _inherit = 'base.document.layout'

    # Odoo 20: only the Odoo 20 layouts are offered.
    report_layout_id = fields.Many2one('report.layout', domain=[('v20_hidden', '=', False)])

    # Odoo 20: "Tables" design, independent from the page layout.
    report_tables_id = fields.Selection(
        related='company_id.report_tables_id', readonly=False, required=True)

    # Odoo 20 "Text" choices. A related selection always exposes all the
    # values of res.company.font (Fira Mono included), so the configurator
    # edits this field, which is kept in sync with `font`.
    font_v20 = fields.Selection(
        FONTS, string='Text',
        compute='_compute_font_v20', inverse='_inverse_font_v20', readonly=False)

    @api.depends('font')
    def _compute_font_v20(self):
        for wizard in self:
            font = LEGACY_FONT_MAP.get(wizard.font, wizard.font)
            wizard.font_v20 = font if font in FONT_KEYS else 'Lato'

    def _inverse_font_v20(self):
        for wizard in self:
            if wizard.font_v20 and wizard.font != wizard.font_v20:
                wizard.font = wizard.font_v20

    @api.onchange('font_v20')
    def _onchange_font_v20(self):
        for wizard in self:
            if wizard.font_v20 and wizard.font != wizard.font_v20:
                wizard.font = wizard.font_v20

    @api.onchange('company_id')
    def _onchange_company_id(self):
        super()._onchange_company_id()
        for wizard in self:
            company = wizard.company_id
            wizard.report_tables_id = company.report_tables_id or 'light'
            if wizard.font in LEGACY_FONT_MAP:
                wizard.font = LEGACY_FONT_MAP[wizard.font]

            if wizard.report_layout_id and not wizard.report_layout_id.v20_hidden:
                continue
            # The company still uses an Odoo 19 layout (or none): propose its
            # Odoo 20 equivalent, as the Odoo 20 upgrade does.
            legacy_key = company.external_report_layout_id.key
            layout, tables = self.env['report.layout'], None
            if legacy_key in LEGACY_LAYOUT_MAP:
                xmlid, tables = LEGACY_LAYOUT_MAP[legacy_key]
                layout = self.env.ref(xmlid, raise_if_not_found=False) or layout
            if not layout:
                layout = layout.search([('v20_hidden', '=', False)], limit=1)
            wizard.report_layout_id = layout
            wizard.external_report_layout_id = layout.view_id
            if tables:
                wizard.report_tables_id = tables

    @api.depends('report_tables_id')
    def _compute_preview(self):
        # EXTENDS web: the table design changes the preview.
        return super()._compute_preview()

    def _get_render_information(self, styles):
        res = super()._get_render_information(styles)
        # Odoo 20 shows "Page 1 / 1" in the footer of the preview.
        res['is_preview'] = True
        return res
