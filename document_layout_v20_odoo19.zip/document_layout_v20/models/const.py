# Values of the Odoo 20 "Configure your document layout" screen.

# Tables (res.company.report_tables_id)
TABLE_DESIGNS = [
    ('light', 'Light'),
    ('boxed', 'Boxed'),
    ('bold', 'Bold'),
    ('striped', 'Striped'),
    ('bubble', 'Bubble'),
    ('column', 'Column'),
    ('compact', 'Compact'),
]

# Text (res.company.font): Odoo 20 replaced Fira Mono with Noto Sans Mono.
FONTS = [
    ('Lato', 'Lato'),
    ('Roboto', 'Roboto'),
    ('Open_Sans', 'Open Sans'),
    ('Montserrat', 'Montserrat'),
    ('Oswald', 'Oswald'),
    ('Raleway', 'Raleway'),
    ('Tajawal', 'Tajawal'),
    ('Noto_Sans_Mono', 'Noto Sans Mono'),
]
FONT_KEYS = {key for key, _label in FONTS}
LEGACY_FONT_MAP = {'Fira_Mono': 'Noto_Sans_Mono'}

# Odoo 19 layout (view key) -> Odoo 20 layout (report.layout xmlid) + table design.
# Odoo 20 turned Boxed, Bold and Striped into table designs of the Light layout.
LEGACY_LAYOUT_MAP = {
    'web.external_layout_standard': ('document_layout_v20.report_layout_light', 'light'),
    'web.external_layout_boxed': ('document_layout_v20.report_layout_light', 'boxed'),
    'web.external_layout_bold': ('document_layout_v20.report_layout_light', 'bold'),
    'web.external_layout_striped': ('document_layout_v20.report_layout_light', 'striped'),
    'web.external_layout_bubble': ('document_layout_v20.report_layout_bubble', 'bubble'),
    'web.external_layout_wave': ('document_layout_v20.report_layout_wave', 'striped'),
    'web.external_layout_folder': ('document_layout_v20.report_layout_folder', 'striped'),
}

# Used on uninstall: Odoo 20 layout (view key) -> closest Odoo 19 layout (view xmlid).
REVERSE_LAYOUT_MAP = {
    'document_layout_v20.external_layout_wave': 'web.external_layout_wave',
    'document_layout_v20.external_layout_bubble': 'web.external_layout_bubble',
    'document_layout_v20.external_layout_folder': 'web.external_layout_folder',
}
REVERSE_LIGHT_BY_TABLES = {
    'boxed': 'web.external_layout_boxed',
    'bold': 'web.external_layout_bold',
    'striped': 'web.external_layout_striped',
}
