from odoo import fields, models


class ReportLayout(models.Model):
    _inherit = 'report.layout'

    v20_hidden = fields.Boolean(
        string='Hidden (replaced by Odoo 20)',
        help="Odoo 19 layout replaced by an Odoo 20 layout or table design: "
             "it is no longer offered in the document layout configurator.",
    )
