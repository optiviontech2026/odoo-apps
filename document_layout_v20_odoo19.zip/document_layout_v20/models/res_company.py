from odoo import api, fields, models

from .const import TABLE_DESIGNS


class ResCompany(models.Model):
    _inherit = 'res.company'

    report_tables_id = fields.Selection(
        TABLE_DESIGNS,
        string='Table Design',
        default='light',
        help="Look of the line tables of the printed documents (Odoo 20 document layout).",
    )
    font = fields.Selection(
        selection_add=[('Noto_Sans_Mono', 'Noto Sans Mono')],
        ondelete={'Noto_Sans_Mono': 'set default'},
    )

    @api.model_create_multi
    def create(self, vals_list):
        companies = super().create(vals_list)
        if any('report_tables_id' in vals for vals in vals_list):
            self._update_asset_style()
        return companies

    def write(self, vals):
        res = super().write(vals)
        # The table design is rendered into the company stylesheet asset.
        # (web already regenerates it for font, colors and layout changes.)
        if 'report_tables_id' in vals and not {
            'external_report_layout_id', 'font', 'primary_color', 'secondary_color',
        }.intersection(vals):
            self._update_asset_style()
            self.env.registry.clear_cache('assets')
        return res
