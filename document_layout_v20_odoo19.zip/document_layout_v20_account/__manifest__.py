{
    'name': 'Document Layout - Odoo 20 Edition (Accounting)',
    'version': '19.0.1.0.0',
    'summary': 'Odoo 20 behaviour of the document layout configurator in Accounting',
    'description': """
Odoo 20 document layout configurator, Accounting part
=====================================================

* Accounting users (not only administrators) are asked to configure the
  document layout when they print their first invoice, with a live preview
  of that invoice.
* "Configure Later" button: print now, configure next time.
* Accounting users can only change the layout settings of their allowed
  companies; the company is written with elevated rights for those fields only.

Installed automatically with *Document Layout - Odoo 20 Edition* when
Accounting is installed.
""",
    'category': 'Accounting',
    'author': 'Optivion Tech',
    'license': 'LGPL-3',
    'depends': ['document_layout_v20', 'account'],
    'data': [
        'security/ir.model.access.csv',
        'views/base_document_layout_views.xml',
    ],
    'auto_install': True,
    'installable': True,
}
