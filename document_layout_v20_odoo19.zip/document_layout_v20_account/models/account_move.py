from odoo import models


class AccountMove(models.Model):
    _inherit = 'account.move'

    def _get_action_with_base_document_layout_configurator(self, report_action):
        # EXTENDS account (Odoo 20 behaviour): accounting users, not only
        # administrators, configure the layout when printing their first
        # invoice, and they can postpone it ("Configure Later").
        action = super()._get_action_with_base_document_layout_configurator(report_action)
        is_configurator = action.get('res_model') == 'base.document.layout'
        if (
            not is_configurator
            and not self.env.is_admin()
            and self.env.user.has_group('account.group_account_basic')
            and not self.env.company.external_report_layout_id
            and not self.env.context.get('discard_logo_check')
        ):
            action = self.env['ir.actions.report']._action_configure_external_report_layout(
                report_action,
                "account.action_base_document_layout_configurator",
            )
            action['context']['default_from_invoice'] = self[:1].move_type == 'out_invoice'
            is_configurator = True
        if is_configurator:
            action['context']['can_configure_later'] = True
            action['context']['account_document_layout_configurator'] = True
        return action
