# Ported from Odoo 20 (addons/account/wizard/base_document_layout.py).
from odoo import api, fields, models
from odoo.exceptions import AccessError

# Company fields an accounting user may change through the configurator.
ACCOUNT_DOCUMENT_LAYOUT_COMPANY_FIELDS = {
    'logo',
    'report_header',
    'report_footer',
    'company_details',
    'paperformat_id',
    'font',
    'primary_color',
    'secondary_color',
    'report_tables_id',
    'qr_code',
    'vat',
}

# Odoo 19 fields that do not exist in the Odoo 20 configurator.
IGNORED_COMPANY_FIELDS = {'layout_background', 'layout_background_image'}


class BaseDocumentLayout(models.TransientModel):
    _inherit = 'base.document.layout'

    can_configure_later = fields.Boolean(compute='_compute_can_configure_later')

    @api.depends_context('can_configure_later')
    def _compute_can_configure_later(self):
        can_configure_later = bool(self.env.context.get('can_configure_later'))
        for wizard in self:
            wizard.can_configure_later = can_configure_later

    def _is_account_layout_configurator(self):
        return bool(
            self.env.context.get('account_document_layout_configurator')
            and self.env.user.has_group('account.group_account_basic')
        )

    def _check_company_access(self, companies):
        allowed_company_ids = self.env.companies.ids
        if not companies or any(company.id not in allowed_company_ids for company in companies):
            raise AccessError(self.env._("You cannot configure the document layout for this company."))

    def _get_accessible_preview_move(self):
        self.ensure_one()
        if (
            self.env.context.get('active_model') != 'account.move'
            or not self.env.context.get('active_id')
        ):
            return self.env['account.move']

        move = self.env['account.move'].browse(self.env.context['active_id']).exists()
        if not move:
            raise AccessError(self.env._("You cannot preview this invoice."))
        move.check_access('read')
        if move.company_id != self.company_id:
            raise AccessError(self.env._("You cannot preview this invoice."))
        return move

    # -------------------------------------------------------------------------
    # Preview
    # -------------------------------------------------------------------------

    @api.depends('qr_code', 'account_number')
    def _compute_preview(self):
        # Non-accounting wizards: standard behaviour.
        non_account_wizards = self.filtered(lambda w: not w._is_account_layout_configurator())
        super(BaseDocumentLayout, non_account_wizards)._compute_preview()

        account_wizards = self - non_account_wizards
        if not account_wizards:
            return

        styles = account_wizards._get_asset_style()
        for wizard in account_wizards:
            wizard._check_company_access(wizard.company_id)
            if not wizard.report_layout_id:
                wizard.preview = False
                continue

            render_information = wizard._get_render_information(styles)
            render_information['o'] = wizard._get_accessible_preview_move() or render_information.get('o')
            wizard.preview = self.env['ir.ui.view']._render_template(
                wizard._get_preview_template(),
                render_information,
            )

    def _get_asset_style(self):
        if not self._is_account_layout_configurator():
            return super()._get_asset_style()
        # Accounting users cannot read the views involved in the stylesheet.
        return self.env['ir.qweb'].sudo()._render('web.styles_company_report', {
            'company_ids': self.sudo(),
        }, raise_if_not_found=False)

    # -------------------------------------------------------------------------
    # Onchange / CRUD: company fields are written with sudo, whitelist only
    # -------------------------------------------------------------------------

    @api.onchange('company_id')
    def _onchange_company_id(self):
        account_wizards = self.filtered(lambda w: w._is_account_layout_configurator())
        super(BaseDocumentLayout, self - account_wizards)._onchange_company_id()
        if account_wizards:
            for wizard in account_wizards:
                wizard._check_company_access(wizard.company_id)
            # Accounting users cannot read the ir.ui.view of external_report_layout_id.
            super(BaseDocumentLayout, account_wizards.sudo())._onchange_company_id()

    @api.model
    def _extract_company_layout_vals(self, vals):
        vals.pop('external_report_layout_id', None)
        company_vals = {}
        for field_name in ACCOUNT_DOCUMENT_LAYOUT_COMPANY_FIELDS:
            if field_name in vals:
                company_vals[field_name] = vals.pop(field_name)
        # Any other company field is not editable here.
        for field_name in list(vals):
            field = self._fields.get(field_name)
            if field_name in IGNORED_COMPANY_FIELDS or (
                field and field.related and field.related.startswith('company_id.') and not field.readonly
            ):
                vals.pop(field_name)

        if 'report_layout_id' in vals:
            report_layout = self.env['report.layout'].browse(vals['report_layout_id'])
            company_vals['external_report_layout_id'] = report_layout.view_id.id if report_layout else False
        return company_vals

    @api.model_create_multi
    def create(self, vals_list):
        if not self._is_account_layout_configurator():
            return super().create(vals_list)

        self.check_access('create')
        vals_list = [dict(vals) for vals in vals_list]
        companies = []
        company_vals_list = []
        for vals in vals_list:
            company = self.env['res.company'].browse(vals.get('company_id') or self.env.company.id)
            self._check_company_access(company)
            vals['company_id'] = company.id
            companies.append(company)
            company_vals_list.append(self._extract_company_layout_vals(vals))

        records = super(BaseDocumentLayout, self.sudo()).create(vals_list).with_env(self.env)
        for company, company_vals in zip(companies, company_vals_list):
            if company_vals:
                company.sudo().write(company_vals)
        return records

    def write(self, vals):
        if not self._is_account_layout_configurator():
            return super().write(vals)

        vals = dict(vals)
        companies = (
            self.env['res.company'].browse(vals['company_id'])
            if 'company_id' in vals
            else self.company_id
        )
        self._check_company_access(companies)
        company_vals = self._extract_company_layout_vals(vals)
        res = super().write(vals)
        if company_vals:
            companies.sudo().write(company_vals)
        return res

    # -------------------------------------------------------------------------
    # Buttons
    # -------------------------------------------------------------------------

    def document_layout_save(self):
        if self._is_account_layout_configurator():
            # Accounting users cannot write the onboarding progress records.
            self._check_company_access(self.company_id)
            return super(BaseDocumentLayout, self.sudo()).document_layout_save()
        return super().document_layout_save()

    def action_configure_later(self):
        self.ensure_one()
        report_action = self.env.context.get('report_action')
        if not report_action:
            return {'type': 'ir.actions.act_window_close'}

        self.check_access('write')
        self._check_company_access(self.company_id)
        self.company_id.sudo().external_report_layout_id = False
        return report_action
