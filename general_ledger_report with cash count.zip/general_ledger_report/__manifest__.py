{
    'name': 'General Ledger Report',
    'author': 'Optivion Tech',
    'version': '19.0.2.1.0',
    'category': 'Accounting/Accounting',
    'summary': 'General ledger report by period, account type and account (PDF and Excel)',
    'description': """
General Ledger Report
=====================
Adds Accounting > Reporting > Account Report balance.
A wizard lets you choose the period (defaults to today), account type and accounts,
then shows the report on screen, prints a PDF or exports an Excel file: partner receipt/payment
charts per currency, per-account ledgers with running balance and reconciliation, source ledger.
""",
    'depends': ['account'],
    'data': [
        'security/ir.model.access.csv',
        'data/general_ledger_denominations.xml',
        'report/general_ledger_paperformat.xml',
        'report/general_ledger_templates.xml',
        'wizard/general_ledger_wizard_views.xml',
        'wizard/general_ledger_screen_views.xml',
        'wizard/general_ledger_cash_count_views.xml',
    ],
    'installable': True,
    'application': False,
    'license': 'LGPL-3',
}
