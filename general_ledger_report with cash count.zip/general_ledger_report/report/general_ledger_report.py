from odoo import api, models


class ReportGeneralLedger(models.AbstractModel):
    _name = 'report.general_ledger_report.report_general_ledger'
    _description = 'General Ledger QWeb Report'

    @api.model
    def _get_report_values(self, docids, data=None):
        docs = self.env['general.ledger.wizard'].browse(docids)
        return {
            'doc_ids': docids,
            'doc_model': 'general.ledger.wizard',
            'docs': docs,
            'gl_by_doc': {doc.id: doc._get_report_data() for doc in docs},
        }
