"""Pure-python helpers (no Odoo imports): description cleaning, partner summary, chart paging, Excel builder."""
import io
import math
import re

REF_RE = re.compile(r'^\s*([A-Z]{2,}\d*/\d{4}/\d+)\s*')
WILD = re.compile(r'[*?~]')

# Base colours: the first four are blue, green, purple, amber/brown; the rest follow so that
# every account gets a different colour.
BASE = ['#1F4E79', '#2E6B34', '#5B2C83', '#7F5A00', '#0F6B6B', '#8B1E3F', '#455A64', '#A0522D',
        '#6B7A1F', '#8E2A7A', '#2F5D8A', '#B3541E', '#3F7D58', '#6A4C93', '#8C6D1F', '#1F7A8C']


def _mix(hex_color, ratio):
    h = hex_color.lstrip('#')
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return '#%02X%02X%02X' % tuple(int(c + (255 - c) * ratio) for c in (r, g, b))


def account_colors(i):
    """(dark, mid, light) for the i-th account; never repeats."""
    if i < len(BASE):
        dark = BASE[i]
    else:  # beyond the fixed list: spread hues around the colour wheel
        import colorsys
        hue = ((i - len(BASE)) * 0.381966) % 1.0
        r, g, b = colorsys.hls_to_rgb(hue, 0.30, 0.55)
        dark = '#%02X%02X%02X' % (int(r * 255), int(g * 255), int(b * 255))
    return dark, _mix(dark, 0.85), _mix(dark, 0.94)


PALETTE = [account_colors(i) for i in range(4)]
GREEN, ORANGE = '#2E9E4F', '#F28C28'
NUM = '#,##0.00;[Red]-#,##0.00'
NUMZ = '#,##0.00;-#,##0.00;;@'      # zero shows as blank


def split_reference(text):
    m = REF_RE.match(text or '')
    return (m.group(1), (text or '')[m.end():]) if m else ('', text or '')


def clean_description(text):
    """Remove 'Manual'/'Manual:' and duplicated text; keep distinct parts once."""
    _ref, rest = split_reference(text)
    parts = re.split(r'\s*\bManual:?\s*', rest, maxsplit=1)

    def unwrap(s):
        s = s.strip()
        return s[1:-1].strip() if s.startswith('(') and s.endswith(')') else s
    a = unwrap(parts[0])
    b = parts[1].strip() if len(parts) > 1 else ''
    if not b or a == b:
        out = a or b
    elif b.endswith('[...]') and a.startswith(b[:-5].strip()):
        out = a
    elif a.endswith('[...]') and b.startswith(a[:-5].strip()):
        out = b
    elif b in a:
        out = a
    elif a in b:
        out = b
    else:
        out = a + ' | ' + b
    return out.strip()


def finalize(data):
    """Add partner summary and chart pages to the report data dict."""
    acc_tot = {}
    for acc in data['accounts']:
        for r in acc['rows']:
            k = (acc['cur'], r['partner'] or '(No partner)')
            d = acc_tot.setdefault(k, [0.0, 0.0])
            if r['amt'] > 0:
                d[0] += r['amt']
            elif r['amt'] < 0:
                d[1] -= r['amt']
    summary = {}
    for (cur, p), (rec, pay) in acc_tot.items():
        rec, pay = round(rec, 2), round(pay, 2)
        if rec or pay:
            summary.setdefault(cur, []).append({'p': p, 'r': rec, 'pay': pay})
    charts = {}
    for cur, rows in summary.items():
        rows.sort(key=lambda x: (-(x['r'] + x['pay']), x['p']))
        mx = max(max(x['r'], x['pay']) for x in rows)
        step = 10 ** math.floor(math.log10(mx))
        for m in (1, 2, 5, 10):
            if mx / (step * m) <= 5:
                step *= m
                break
        ticks, v = [], 0
        while v <= mx * 1.0001:
            ticks.append(v)
            v += step
        pages = []
        for i in range(0, len(rows), 14):
            pages.append({'cont': i > 0, 'ticks': ticks, 'rows': [
                dict(x, wr=round(80 * x['r'] / mx, 2), wp=round(80 * x['pay'] / mx, 2)) for x in rows[i:i + 14]]})
        charts[cur] = pages
    for rows in summary.values():
        for x in rows:
            x['net'] = round(x['r'] - x['pay'], 2)
    data['totals'] = {cur: (round(sum(x['r'] for x in rows), 2), round(sum(x['pay'] for x in rows), 2))
                      for cur, rows in summary.items()}
    data['summary'], data['charts'] = summary, charts
    return data


def build_xlsx(data):
    import xlsxwriter
    out = io.BytesIO()
    wb = xlsxwriter.Workbook(out, {'in_memory': True})
    F = lambda **k: wb.add_format({'font_name': 'Arial', 'font_size': 10, **k})
    brand = data['color']
    rtl = data.get('dir') == 'rtl'
    inc = data['include_charts']
    pc = wb.add_worksheet('Partner Charts') if inc else None
    ar = wb.add_worksheet('Account Report')
    sl = wb.add_worksheet('Source Ledger')
    cd = wb.add_worksheet('Chart Data') if inc else None
    for ws in (pc, ar, sl, cd):
        if ws is None:
            continue
        ws.hide_gridlines(2)
        if rtl:
            ws.right_to_left()
    title, sub, note = F(bold=True, font_size=16, font_color='#1F2937'), F(font_size=11, font_color='#4B5563'), F(italic=True, font_size=9, font_color='#6B7280')
    txt = F(border=1, text_wrap=True, valign='top', border_color='#BFBFBF')
    for ws, t in ((pc, 'Partner Receipts & Payments'), (ar, 'Account Ledger Report'), (sl, 'Source Ledger')):
        if ws is None:
            continue
        ws.write(0, 0, data['company'], title)
        ws.write(1, 0, '%s  |  Period: %s' % (t, data['period']), sub)
        ws.set_landscape(); ws.set_paper(9); ws.fit_to_pages(1, 0)
        ws.set_margins(0.4, 0.4, 0.6, 0.6)
        ws.set_footer('&CPage &P of &N')
        ws.set_header('&C%s - %s - %s' % (data['company'].replace('&', '&&'), t.replace('&', '&&'), data['period']))

    # ---------------- Source Ledger ----------------
    sh = F(bold=True, font_color='#FFFFFF', bg_color='#374151', border=1)
    sl.write_row(3, 0, ['Account Code', 'Account / Description', 'Date', 'Journal Entry', 'Journal', 'Partner',
                        'Currency', 'Debit', 'Credit', 'Balance', 'Amount (account currency)'], sh)
    for i, w in enumerate([13, 60, 13, 22, 9, 30, 10, 16, 16, 16, 22]):
        sl.set_column(i, i, w)
    sl.freeze_panes(4, 0)
    n_ = F(num_format=NUM, border=1, border_color='#BFBFBF')
    d_ = F(num_format='dd-mmm-yyyy', border=1, border_color='#BFBFBF', align='left')
    b_ = F(bold=True, border=1, border_color='#BFBFBF', bg_color='#F2F2F2')
    bn_ = F(bold=True, num_format=NUM, border=1, border_color='#BFBFBF', bg_color='#F2F2F2')
    r = 4
    for acc in data['accounts']:
        sl.write(r, 0, acc['code'], b_); sl.write(r, 1, acc['name'], b_)
        for c in range(2, 11):
            sl.write_blank(r, c, None, b_)
        r += 1
        acc['_so'] = r
        sl.write(r, 0, acc['code'], txt); sl.write(r, 1, 'Initial Balance', txt)
        sl.write(r, 6, acc['cur'], txt); sl.write(r, 9, acc['opening_company'], n_); sl.write(r, 10, acc['opening'], n_)
        r += 1
        for row in acc['rows']:
            row['_sr'] = r
            sl.write(r, 0, acc['code'], txt); sl.write(r, 1, row['raw'], txt)
            sl.write_datetime(r, 2, row['raw_date'], d_)
            sl.write(r, 3, row['ref'], txt); sl.write(r, 4, row['journal'], txt); sl.write(r, 5, row['partner'], txt)
            sl.write(r, 6, acc['cur'], txt)
            sl.write(r, 7, row['debit'], n_); sl.write(r, 8, row['credit'], n_)
            sl.write(r, 9, row['balance_company'], n_); sl.write(r, 10, row['amt'], n_)
            r += 1
        acc['_st'] = r
        sl.write(r, 0, acc['code'], b_); sl.write(r, 1, 'Total %s (closing balance per ledger)' % acc['name'], b_)
        for c in range(2, 9):
            sl.write_blank(r, c, None, b_)
        sl.write(r, 9, acc['closing_src_company'], bn_); sl.write(r, 10, acc['closing_src'], bn_)
        r += 2
    SL = "'Source Ledger'!"

    # ---------------- Account Report ----------------
    for i, w in enumerate([8, 14, 24, 34, 62, 22, 22]):
        ar.set_column(i, i, w)
    ar.write(2, 0, "Amounts are shown in each account's own currency. Company-currency accounts: Debit - Credit "
                   "(payments negative). Currencies are never combined.", note)
    ar.freeze_panes(3, 0)
    ar.repeat_rows(0, 2)
    sections = {}
    r = 4
    for acc in data['accounts']:
        dark, mid, light = acc['col']; cur = acc['cur']
        band = F(bold=True, font_size=13, font_color='#FFFFFF', bg_color=dark, valign='vcenter', indent=1)
        info = F(bold=True, font_color=dark, bg_color=mid, indent=1)
        ar.set_row(r, 24)
        ar.merge_range(r, 0, r, 6, '%s  —  %s' % (acc['code'], acc['name']), band); r += 1
        ar.merge_range(r, 0, r, 6, 'Account Code: %s      Account Name: %s      Currency: %s' % (acc['code'], acc['name'], cur), info); r += 1
        lab = F(bold=True, align='right', bg_color=light, border=1, border_color='#BFBFBF')
        val = F(bold=True, num_format=NUM, bg_color=light, border=1, border_color='#BFBFBF')
        ar.merge_range(r, 0, r, 5, 'Opening Balance (Initial Balance) — %s' % cur, lab)
        ar.write_formula(r, 6, '=%sK%d' % (SL, acc['_so'] + 1), val, acc['opening'])
        orow = r; r += 1
        hdr = F(bold=True, font_color='#FFFFFF', bg_color=dark, border=1, border_color='#BFBFBF', text_wrap=True, valign='vcenter')
        hdrr = F(bold=True, font_color='#FFFFFF', bg_color=dark, border=1, border_color='#BFBFBF', align='right', valign='vcenter')
        ar.set_row(r, 22)
        for j, h in enumerate(['Line', 'Date', 'Transaction Reference', 'Partner', 'Description',
                               'Amount (%s)' % cur, 'Balance (%s)' % cur]):
            ar.write(r, j, h, hdrr if j > 4 else hdr)
        r += 1
        first = r
        for i, row in enumerate(acc['rows'], 1):
            bg = {'bg_color': light} if i % 2 == 0 else {}
            t_ = F(border=1, border_color='#BFBFBF', text_wrap=True, valign='top', **bg)
            tc = F(border=1, border_color='#BFBFBF', valign='top', align='center', **bg)
            td = F(border=1, border_color='#BFBFBF', valign='top', align='left', num_format='dd-mmm-yyyy', **bg)
            tn = F(border=1, border_color='#BFBFBF', valign='top', num_format=NUM, **bg)
            ar.set_row(r, max(15, 13.5 * max(math.ceil(len(row['desc']) / 52), math.ceil(len(row['partner']) / 27)) + 3))
            ar.write(r, 0, i, tc)
            ar.write_datetime(r, 1, row['raw_date'], td)
            ar.write(r, 2, row['ref'], t_); ar.write(r, 3, row['partner'], t_); ar.write(r, 4, row['desc'], t_)
            sr = row['_sr'] + 1
            f = '=%sH%d-%sI%d' % (SL, sr, SL, sr) if not acc['foreign'] else '=%sK%d' % (SL, sr)
            ar.write_formula(r, 5, f, tn, row['amt'])
            ar.write_formula(r, 6, '=G%d+F%d' % ((orow if i == 1 else r - 1) + 1, r + 1), tn, row['bal'])
            r += 1
        last = r - 1
        if not acc['rows']:
            ar.merge_range(r, 0, r, 6, 'No transactions in this period.', F(italic=True, font_color='#6B7280', align='center', border=1, border_color='#BFBFBF'))
            r += 1

        def trow(label, formula, value, bold, fmt=NUM, color=None):
            nonlocal r
            bg = {'bg_color': mid} if bold else {}
            lf = F(bold=bold, align='right', border=1, border_color='#BFBFBF', **bg)
            vf = F(bold=bold, num_format=fmt, align='right', border=1, border_color='#BFBFBF', **bg, **({'font_color': color} if color else {}))
            ar.merge_range(r, 0, r, 5, label, lf)
            if isinstance(formula, str):
                ar.write_formula(r, 6, formula, vf, value)
            else:
                ar.write_number(r, 6, formula, vf)
            r += 1
            return r  # 1-based row of the one just written
        net = trow('Net Activity (%s)' % cur, '=SUM(F%d:F%d)' % (first + 1, last + 1) if acc['rows'] else 0, acc['net'], True)
        clo = trow('Closing Balance (%s)' % cur, '=G%d+G%d' % (orow + 1, net), acc['closing'], True)
        src = trow('Closing Balance per Source Ledger (%s)' % cur, '=%sK%d' % (SL, acc['_st'] + 1), acc['closing_src'], False)
        dif = trow('Reconciliation Difference', '=ROUND(G%d-G%d,2)' % (clo, src), acc['diff'], False)
        trow('Reconciliation Status', '=IF(G%d=0,"RECONCILED","DIFFERENCE")' % dif,
             'RECONCILED' if not acc['diff'] else 'DIFFERENCE', True, 'General', '#2E6B34')
        cnt = acc.get('count')
        if cnt:
            r += 1
            ar.set_row(r, 22)
            ar.merge_range(r, 0, r, 6, 'Physical Cash Count — %s' % cur,
                           F(bold=True, font_size=12, font_color='#FFFFFF', bg_color=dark, valign='vcenter', indent=1))
            r += 1
            ar.merge_range(r, 0, r, 4, 'Denomination (%s)' % cur, hdrr)
            ar.write(r, 5, 'Count', hdrr)
            ar.write(r, 6, 'Amount (%s)' % cur, hdrr)
            r += 1
            cfirst = r + 1
            for i, x in enumerate(cnt['lines'], 1):
                bg = {'bg_color': light} if i % 2 == 0 else {}
                dn = F(border=1, border_color='#BFBFBF', num_format='#,##0.00', align='right', **bg)
                qn = F(border=1, border_color='#BFBFBF', num_format='#,##0', align='right', **bg)
                an = F(border=1, border_color='#BFBFBF', num_format=NUMZ, align='right', **bg)
                ar.merge_range(r, 0, r, 4, x['den'], dn)
                ar.write_number(r, 5, x['qty'], qn)
                ar.write_formula(r, 6, '=A%d*F%d' % (r + 1, r + 1), an, x['amt'])
                r += 1
            clast = r
            tot = trow('Total Counted (%s)' % cur, '=SUM(G%d:G%d)' % (cfirst, clast), cnt['total'], True)
            bk = trow('Book Balance — Closing (%s)' % cur, '=G%d' % clo, cnt['book'], False)
            df = trow('Difference (Counted − Book)', '=ROUND(G%d-G%d,2)' % (tot, bk), cnt['diff'], True)
            st = trow('Count Status', '=IF(G%d=0,"MATCHED",IF(G%d<0,"SHORTAGE","EXCESS"))' % (df, df),
                      cnt['status'], True, 'General', '#2E6B34')
            for word, color in (('SHORTAGE', '#C00000'), ('EXCESS', '#B45F06')):
                ar.conditional_format(st - 1, 6, st - 1, 6, {
                    'type': 'text', 'criteria': 'containing', 'value': word,
                    'format': wb.add_format({'font_color': color, 'bold': True})})
        sections[acc['code']] = dict(first=first + 1, last=last + 1, cur=cur, has=bool(acc['rows']), net=net)
        r += 2

    # ---------------- Chart Data + Partner Charts ----------------
    if not inc:
        wb.close()
        return out.getvalue()
    pc.set_column(0, 0, 46); pc.set_column(1, 1, 11); pc.set_column(2, 4, 22)
    pc.freeze_panes(3, 0)
    pc.write(2, 0, 'Receipts = positive amounts, Payments = negative amounts (shown as positive). '
                   'Each currency has its own chart; currencies are never combined.', note)
    cd.write(0, 0, 'Chart source data (zero amounts left blank so no bar or label is drawn).', note)
    col = 0
    chart_pos = {}
    hd = F(bold=True, font_color='#FFFFFF', bg_color='#374151')
    for cur, rows in data['summary'].items():
        cd.write_row(2, col, ['Partner (%s)' % cur, 'Receipts (%s)' % cur, 'Payments (%s)' % cur], hd)
        cd.set_column(col, col, 40); cd.set_column(col + 1, col + 2, 18)
        for i, x in enumerate(rows, 3):
            cd.write(i, col, x['p'])
            if x['r']:
                cd.write_number(i, col + 1, x['r'], F(num_format='#,##0.00'))
            if x['pay']:
                cd.write_number(i, col + 2, x['pay'], F(num_format='#,##0.00'))
        chart_pos[cur] = (col, 3, 2 + len(rows))
        col += 4
    r = 4
    if True:
        for cur, rows in data['summary'].items():
            c0, r1, r2 = chart_pos[cur]
            ch = wb.add_chart({'type': 'bar'})
            for k, (color, nm) in enumerate(((GREEN, 'Receipts'), (ORANGE, 'Payments')), 1):
                ch.add_series({
                    'name': ['Chart Data', 2, c0 + k],
                    'categories': ['Chart Data', r1, c0, r2, c0],
                    'values': ['Chart Data', r1, c0 + k, r2, c0 + k],
                    'fill': {'color': color}, 'border': {'color': color}, 'gap': 50,
                    'data_labels': {'value': True, 'num_format': '#,##0.00;-#,##0.00;;', 'position': 'outside_end',
                                    'font': {'size': 8}},
                })
            ch.set_title({'name': 'Receipts vs Payments by Partner — %s' % cur, 'name_font': {'size': 13}})
            ch.set_y_axis({'name': 'Partner (%s activity)' % cur, 'reverse': True, 'crossing': 'max', 'num_font': {'size': 8}})
            ch.set_x_axis({'name': 'Amount (%s)' % cur, 'num_format': '#,##0', 'major_gridlines': {'visible': False}})
            ch.set_legend({'position': 'bottom'})
            height = max(300, 40 * len(rows) + 140)
            ch.set_size({'width': 1000, 'height': height})
            pc.insert_chart(r, 0, ch)
            r += math.ceil(height / 20) + 2
    pc.write(r, 0, 'Partner Summary (zero amounts hidden)', F(bold=True, font_size=13, font_color='#1F2937')); r += 1
    sh_ = F(bold=True, font_color='#FFFFFF', bg_color=brand, border=1, border_color='#BFBFBF')
    for j, h in enumerate(['Partner', 'Currency', 'Receipt Amount', 'Payment Amount', 'Net Amount']):
        pc.write(r, j, h, sh_ if j < 2 else F(bold=True, font_color='#FFFFFF', bg_color=brand, border=1, border_color='#BFBFBF', align='right'))
    pc.set_row(r, 22); r += 1
    AR = "'Account Report'!"
    for cur, rows in data['summary'].items():
        secs = [s for s in sections.values() if s['cur'] == cur and s['has']]
        r0 = r
        for x in rows:
            pc.write(r, 0, x['p'], txt); pc.write(r, 1, cur, F(border=1, border_color='#BFBFBF', align='center', valign='top'))
            nf = F(border=1, border_color='#BFBFBF', valign='top', num_format=NUMZ)
            nn = F(border=1, border_color='#BFBFBF', valign='top', num_format=NUM)
            if WILD.search(x['p']):
                pc.write_number(r, 2, x['r'], nf); pc.write_number(r, 3, x['pay'], nf)
            else:
                rf = '+'.join('SUMIFS(%s$F$%d:$F$%d,%s$D$%d:$D$%d,$A%d,%s$F$%d:$F$%d,">0")' % (AR, s['first'], s['last'], AR, s['first'], s['last'], r + 1, AR, s['first'], s['last']) for s in secs)
                pf = '-(' + '+'.join('SUMIFS(%s$F$%d:$F$%d,%s$D$%d:$D$%d,$A%d,%s$F$%d:$F$%d,"<0")' % (AR, s['first'], s['last'], AR, s['first'], s['last'], r + 1, AR, s['first'], s['last']) for s in secs) + ')'
                pc.write_formula(r, 2, '=' + rf, nf, x['r']); pc.write_formula(r, 3, '=' + pf, nf, x['pay'])
            pc.write_formula(r, 4, '=C%d-D%d' % (r + 1, r + 1), nn, round(x['r'] - x['pay'], 2))
            r += 1
        tf = F(bold=True, bg_color='#E5E7EB', border=1, border_color='#BFBFBF')
        tn = F(bold=True, bg_color='#E5E7EB', border=1, border_color='#BFBFBF', num_format=NUMZ)
        tn2 = F(bold=True, bg_color='#E5E7EB', border=1, border_color='#BFBFBF', num_format=NUM)
        pc.write(r, 0, 'Total %s' % cur, tf); pc.write(r, 1, cur, tf)
        tr_, tp_ = round(sum(x['r'] for x in rows), 2), round(sum(x['pay'] for x in rows), 2)
        pc.write_formula(r, 2, '=SUM(C%d:C%d)' % (r0 + 1, r), tn, tr_)
        pc.write_formula(r, 3, '=SUM(D%d:D%d)' % (r0 + 1, r), tn, tp_)
        pc.write_formula(r, 4, '=SUM(E%d:E%d)' % (r0 + 1, r), tn2, round(tr_ - tp_, 2))
        r += 2
    pc.activate(); pc.set_first_sheet()
    wb.close()
    return out.getvalue()
