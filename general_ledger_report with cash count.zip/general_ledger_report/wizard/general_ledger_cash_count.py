from odoo import _, api, fields, models
from odoo.exceptions import ValidationError


class GeneralLedgerDenomination(models.Model):
    """Banknote / coin values of a currency, used to prepare the physical cash count sheet."""
    _name = 'general.ledger.denomination'
    _description = 'Cash Denomination'
    _order = 'currency_id, value desc'

    currency_id = fields.Many2one(
        'res.currency', string='Currency', required=True, ondelete='cascade',
        context={'active_test': False})
    value = fields.Float(string='Denomination', required=True, digits=(16, 3))
    active = fields.Boolean(default=True)

    @api.constrains('currency_id', 'value')
    def _check_unique_value(self):
        for rec in self:
            if rec.value <= 0:
                raise ValidationError(_("The denomination must be greater than zero."))
            if self.search_count([('currency_id', '=', rec.currency_id.id), ('value', '=', rec.value),
                                  ('id', '!=', rec.id)]):
                raise ValidationError(_("The denomination %(v)s already exists for %(c)s.",
                                        v=rec.value, c=rec.currency_id.name))

    @api.depends('currency_id', 'value')
    def _compute_display_name(self):
        for rec in self:
            rec.display_name = '%s %s' % (rec.currency_id.name or '', '{:,.2f}'.format(rec.value))


class GeneralLedgerCountLine(models.TransientModel):
    """One counted denomination of one account in the report window."""
    _name = 'general.ledger.count.line'
    _description = 'Physical Cash Count Line'
    _order = 'account_id, denomination desc, id'

    wizard_id = fields.Many2one('general.ledger.wizard', ondelete='cascade')
    account_id = fields.Many2one('account.account', string='Account', required=True)
    currency_id = fields.Many2one(
        'res.currency', string='Currency', required=True, context={'active_test': False})
    denomination = fields.Float(string='Denomination', digits=(16, 3))
    quantity = fields.Integer(string='Count')
    amount = fields.Monetary(compute='_compute_amount', store=True, currency_field='currency_id')

    @api.depends('denomination', 'quantity')
    def _compute_amount(self):
        for line in self:
            line.amount = line.denomination * line.quantity
