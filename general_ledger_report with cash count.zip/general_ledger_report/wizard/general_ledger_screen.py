from odoo import fields, models


class GeneralLedgerAccount(models.TransientModel):
    _name = 'general.ledger.account'
    _description = 'General Ledger Account (on-screen)'
    _order = 'code, id'

    wizard_id = fields.Many2one('general.ledger.wizard', ondelete='cascade', required=True)
    account_id = fields.Many2one('account.account', string='Account', readonly=True)
    code = fields.Char(related='account_id.code', store=True)
    currency_id = fields.Many2one('res.currency', string='Currency')
    opening = fields.Monetary(string='Opening Balance')
    net = fields.Monetary(string='Net Activity')
    closing = fields.Monetary(string='Closing Balance')
    has_count = fields.Boolean()
    counted = fields.Monetary(string='Counted Cash')
    count_difference = fields.Monetary(string='Count Difference')
    line_ids = fields.One2many('general.ledger.line', 'ledger_account_id', string='Lines')
    date_from = fields.Date(related='wizard_id.date_from')
    date_to = fields.Date(related='wizard_id.date_to')


class GeneralLedgerLine(models.TransientModel):
    _name = 'general.ledger.line'
    _description = 'General Ledger Line (on-screen)'
    _order = 'id'

    ledger_account_id = fields.Many2one('general.ledger.account', ondelete='cascade', required=True)
    currency_id = fields.Many2one('res.currency', related='ledger_account_id.currency_id')
    line_no = fields.Integer(string='Line')
    date = fields.Date()
    move_id = fields.Many2one('account.move', string='Transaction Reference')
    partner_id = fields.Many2one('res.partner', string='Partner')
    description = fields.Char()
    amount = fields.Monetary()
    balance = fields.Monetary()
