import base64
from datetime import timedelta

from odoo import Command, _, api, fields, models
from odoo.exceptions import ValidationError

from ..report.report_utils import account_colors, build_xlsx, clean_description, finalize


class GeneralLedgerWizard(models.TransientModel):
    _name = 'general.ledger.wizard'
    _description = 'General Ledger Report Wizard'

    company_id = fields.Many2one(
        'res.company', string='Company', required=True,
        default=lambda self: self.env.company)
    date_from = fields.Date(string='From', required=True, default=fields.Date.context_today)
    date_to = fields.Date(string='To', required=True, default=fields.Date.context_today)
    target_move = fields.Selection(
        [('posted', 'Posted Entries'), ('all', 'All Entries (draft + posted)')],
        string='Target Moves', required=True, default='posted')
    account_type = fields.Selection(
        selection='_get_account_types', string='Account Type',
        help="Leave empty to include every account type.")
    account_ids = fields.Many2many(
        'account.account', string='Accounts',
        help="Leave empty to include every account (of the selected type).")
    hide_empty = fields.Boolean(
        string='Hide accounts without balance or movement', default=True,
        help="An account is hidden only when it has no transactions and a zero opening and closing balance.")
    include_charts = fields.Boolean(
        string='Include partner charts and summary', default=True,
        help="Receipts vs payments by partner, one chart per currency, placed before the account details.")
    include_cash_count = fields.Boolean(
        string='Include physical cash count',
        help="Enter the counted notes per denomination for each account. The denominations come from the "
             "currency of each account. The report compares the counted total with the book balance.")
    count_line_ids = fields.One2many('general.ledger.count.line', 'wizard_id', string='Cash Count')
    xlsx_file = fields.Binary(string='Excel File', readonly=True)
    xlsx_filename = fields.Char(readonly=True)
    period_label = fields.Char(compute='_compute_period_label')

    @api.model
    def _get_account_types(self):
        return self.env['account.account']._fields['account_type']._description_selection(self.env)

    @api.depends('date_from', 'date_to')
    def _compute_period_label(self):
        for wiz in self:
            d1, d2 = wiz.date_from, wiz.date_to
            if not d1 or not d2:
                wiz.period_label = ''
            elif d1.day == 1 and (d2 + timedelta(days=1)).day == 1 and d1.year == d2.year and d1.month == d2.month:
                wiz.period_label = d2.strftime('%b %Y')      # a full calendar month, e.g. "Oct 2026"
            elif d1 == d2:
                wiz.period_label = str(d1)
            else:
                wiz.period_label = '%s to %s' % (d1, d2)

    @api.constrains('date_from', 'date_to')
    def _check_dates(self):
        for wiz in self:
            if wiz.date_from > wiz.date_to:
                raise ValidationError(_("The start date must not be after the end date."))

    @api.onchange('account_type', 'company_id')
    def _onchange_account_type(self):
        accounts = self.account_ids
        if self.account_type:
            accounts = accounts.filtered(lambda a: a.account_type == self.account_type)
        self.account_ids = accounts.filtered(lambda a: self.company_id.id in a.company_ids.ids)

    @api.onchange('include_cash_count', 'account_ids', 'account_type', 'company_id')
    def _onchange_cash_count(self):
        """Prepare one count line per denomination of each selected account's currency."""
        if not self.include_cash_count:
            self.count_line_ids = [Command.clear()]
            return
        accounts = self._get_accounts(default_cash_only=True)
        cmap = self._account_currency_map(accounts)
        keep = {(l.account_id.id, l.denomination): l.quantity for l in self.count_line_ids}
        Denomination = self.env['general.ledger.denomination']
        commands = [Command.clear()]
        for acc in accounts:
            cur = cmap[acc.id]
            for den in Denomination.search([('currency_id', '=', cur.id)], order='value desc'):
                commands.append(Command.create({
                    'account_id': acc.id, 'currency_id': cur.id, 'denomination': den.value,
                    'quantity': keep.get((acc.id, den.value), 0),
                }))
        self.count_line_ids = commands

    # ------------------------------------------------------------------
    # Data
    # ------------------------------------------------------------------
    def _get_accounts(self, default_cash_only=False):
        """Accounts selected in the window. With default_cash_only and nothing selected,
        use all cash/bank accounts so the count sheet is not generated for the whole chart."""
        self.ensure_one()
        company = self.company_id
        domain = [('company_ids', 'in', company.ids)]
        if self.account_ids:
            domain.append(('id', 'in', self.account_ids.ids))
        elif self.account_type:
            domain.append(('account_type', '=', self.account_type))
        elif default_cash_only:
            domain.append(('account_type', '=', 'asset_cash'))
        return self.env['account.account'].with_company(company).search(domain).sorted(
            lambda a: (a.code or '', a.id))

    def _account_currency_map(self, accounts):
        """account id -> currency: the account's own currency, else the single currency used by its
        lines up to the end date, else the company currency."""
        company = self.company_id
        ccur = company.currency_id
        Line = self.env['account.move.line'].with_company(company)
        used = {}
        if accounts:
            for acc, cur, _count in Line._read_group(
                    [('company_id', '=', company.id), ('account_id', 'in', accounts.ids),
                     ('date', '<=', self.date_to)],
                    ['account_id', 'currency_id'], ['__count']):
                used.setdefault(acc.id, set()).add(cur.id)
        Currency = self.env['res.currency'].with_context(active_test=False)
        result = {}
        for acc in accounts:
            cur = acc.currency_id if 'currency_id' in acc._fields and acc.currency_id else False
            if not cur:
                ids = used.get(acc.id, set())
                cur = Currency.browse(next(iter(ids))) if len(ids) == 1 else ccur
            result[acc.id] = cur
        return result

    def _get_report_data(self):
        """One dict used by the PDF template, the Excel export and the on-screen view."""
        self.ensure_one()
        company = self.company_id
        ccur = company.currency_id
        Line = self.env['account.move.line'].with_company(company)

        accounts = self._get_accounts()
        currency_map = self._account_currency_map(accounts)

        states = ['posted'] if self.target_move == 'posted' else ['draft', 'posted']
        base = [('company_id', '=', company.id), ('parent_state', 'in', states),
                ('account_id', 'in', accounts.ids)]

        def sums(extra):
            return {acc.id: (bal, fc) for acc, bal, fc in Line._read_group(
                base + extra, ['account_id'], ['balance:sum', 'amount_currency:sum'])}
        opening_map = sums([('date', '<', self.date_from)])
        closing_map = sums([('date', '<=', self.date_to)])

        by_account = {}
        for line in Line.search(
                base + [('date', '>=', self.date_from), ('date', '<=', self.date_to)],
                order='date, move_id, id'):
            by_account.setdefault(line.account_id.id, []).append(line)

        count_by_account = {}
        if self.include_cash_count:
            for cl in self.count_line_ids.sorted(lambda l: -l.denomination):
                count_by_account.setdefault(cl.account_id.id, []).append(cl)

        result = []
        for acc in accounts:
            lines = by_account.get(acc.id, [])
            cur = currency_map[acc.id]
            foreign = cur != ccur
            idx = 1 if foreign else 0
            opening = opening_map.get(acc.id, (0.0, 0.0))[idx]
            closing_src = closing_map.get(acc.id, (0.0, 0.0))[idx]
            if self.hide_empty and not lines and cur.is_zero(opening) and cur.is_zero(closing_src):
                continue
            running, rows = opening, []
            for n, line in enumerate(lines, 1):
                amt = line.amount_currency if foreign else line.balance
                running = cur.round(running + amt)
                move = line.move_id
                rows.append({
                    'n': n,
                    'raw_date': line.date,
                    'date': line.date.strftime('%d-%b-%Y'),
                    'move_id': move.id,
                    'partner_id': line.partner_id.id,
                    'ref': move.name or '',
                    'partner': line.partner_id.name or '',
                    'desc': clean_description(line.name) or clean_description(move.ref) or '',
                    'raw': line.name or '',
                    'journal': line.journal_id.code or '',
                    'debit': line.debit, 'credit': line.credit,
                    'balance_company': line.balance,
                    'amt': amt, 'bal': running,
                })
            net = cur.round(sum(r['amt'] for r in rows))
            closing = cur.round(opening + net)
            count = False
            if count_by_account.get(acc.id):
                clines = [{'den': cl.denomination, 'qty': cl.quantity,
                           'amt': cur.round(cl.denomination * cl.quantity)} for cl in count_by_account[acc.id]]
                counted = cur.round(sum(x['amt'] for x in clines))
                diff = cur.round(counted - closing)
                count = {'lines': clines, 'total': counted, 'book': closing, 'diff': diff,
                         'status': 'MATCHED' if cur.is_zero(diff) else ('SHORTAGE' if diff < 0 else 'EXCESS')}
            result.append({
                'id': acc.id, 'code': acc.code or '', 'name': acc.name or '',
                'cur': cur.name, 'currency_id': cur.id, 'foreign': foreign,
                'opening': opening, 'opening_company': opening_map.get(acc.id, (0.0, 0.0))[0],
                'rows': rows, 'net': net, 'closing': closing,
                'closing_src': closing_src, 'closing_src_company': closing_map.get(acc.id, (0.0, 0.0))[0],
                'diff': cur.round(closing - closing_src),
                'count': count,
            })
        for i, acc in enumerate(result):
            acc['col'] = account_colors(i)

        color = company.primary_color or '#714B67'   # Odoo brand colour (company setting)
        h = color.lstrip('#')
        tint = '#%02X%02X%02X' % tuple(int(c + (255 - c) * 0.88) for c in (int(h[i:i + 2], 16) for i in (0, 2, 4)))
        lang = self.env['res.lang']._lang_get(self.env.lang or 'en_US')
        type_label = dict(self._get_account_types()).get(self.account_type, '') if self.account_type else _('All')
        data = {
            'company': company.name,
            'period': self.period_label,
            'date_from': self.date_from.strftime('%d-%b-%Y'),
            'date_to': self.date_to.strftime('%d-%b-%Y'),
            'target_move': dict(self._fields['target_move'].selection)[self.target_move],
            'account_type': type_label,
            'color': color, 'tint': tint,
            'dir': (lang.direction if lang else 'ltr') or 'ltr',
            'include_charts': self.include_charts,
            'accounts': result,
        }
        return finalize(data)

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------
    def action_view_screen(self):
        """Show the ledger on screen: one row per account; opening a row shows all its lines."""
        self.ensure_one()
        Account = self.env['general.ledger.account']
        Account.search([('wizard_id', '=', self.id)]).unlink()
        for acc in self._get_report_data()['accounts']:
            Account.create({
                'wizard_id': self.id,
                'account_id': acc['id'],
                'currency_id': acc['currency_id'],
                'opening': acc['opening'], 'net': acc['net'], 'closing': acc['closing'],
                'has_count': bool(acc['count']),
                'counted': acc['count']['total'] if acc['count'] else 0.0,
                'count_difference': acc['count']['diff'] if acc['count'] else 0.0,
                'line_ids': [Command.create({
                    'line_no': r['n'], 'date': r['raw_date'], 'move_id': r['move_id'],
                    'partner_id': r['partner_id'] or False, 'description': r['desc'],
                    'amount': r['amt'], 'balance': r['bal'],
                }) for r in acc['rows']],
            })
        return {
            'type': 'ir.actions.act_window',
            'name': _('Account Report balance  %(p)s', p=self.period_label),
            'res_model': 'general.ledger.account',
            'view_mode': 'list,form',
            'domain': [('wizard_id', '=', self.id)],
            'target': 'current',
        }

    def action_print_pdf(self):
        self.ensure_one()
        return self.env.ref('general_ledger_report.action_report_general_ledger').report_action(self)

    def action_export_xlsx(self):
        self.ensure_one()
        data = self._get_report_data()
        name = 'Account_Ledger_Report_%s.xlsx' % (self.period_label or '').replace(' ', '_')
        self.write({'xlsx_file': base64.b64encode(build_xlsx(data)), 'xlsx_filename': name})
        return {
            'type': 'ir.actions.act_url',
            'url': "/web/content/?model=%s&id=%s&field=xlsx_file&filename_field=xlsx_filename&download=true"
                   % (self._name, self.id),
            'target': 'self',
        }

