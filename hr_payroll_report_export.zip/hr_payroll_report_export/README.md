# Payroll Report Export (Payslip Lines) – Odoo 19

Adds **Export Payroll Report** to the Payslip Lines list
(*Payroll ▸ Reporting ▸ Payslip Lines* ▸ select lines ▸ **Actions ▸ Export Payroll Report**)
and a menu entry *Payroll ▸ Reporting ▸ Payroll Report (Excel / PDF)* (all lines, optional filters).

## How it works in Odoo
1. **Payroll ▸ Reporting ▸ Payroll Report** (or select lines in *Payslip Lines* ▸ **Actions ▸ Payroll Report**).
2. In the window choose the **period** (from / to) and the **departments** (empty = all; sub-departments included),
   plus language (English / Arabic) and company.
3. Tick or untick **Include control checks** (Excel sheet, PDF page and on-screen section).
4. **Show Report** (on screen), **Download Excel** or **Download PDF**.

On screen, the report is linked to Odoo: click an **employee name** to open the employee profile, and click **any amount**
(employee, department subtotal, grand total, top figures) to open the **payslip lines** behind it.

## What you get
* **Excel** (`Payroll-<Month-Year>-<Company>.xlsx`): Dashboard (bar chart first), Employee Register,
  Pay Components, Adjustment Details, Analysis, Source Data, Control Checks – live formulas.
* **PDF** (A4 landscape, header/footer, page numbers, signature blocks for Finance and Administration).
* One table per main department (Finance first), employees by position seniority,
  subtotal per department and a grand total, "Not provided" positions last.
* **English or Arabic (RTL)** – chosen in the wizard, independent of the user's Odoo language.

## Install
1. Copy the `hr_payroll_report_export` folder into your addons path (Odoo 19 Enterprise with `hr_payroll`).
2. `pip install xlsxwriter` (already bundled with standard Odoo installs).
3. Apps ▸ Update Apps List ▸ install **Payroll Report Export**.

## Mapping (how the lines are read)
| Report item | Source |
|---|---|
| Basic salary | line code `BASIC` |
| Allowances | lines whose category code is `ALW` |
| Deductions | lines whose category code is `DED` (shown positive) |
| GROSS / NET lines | used **only** as control totals (never added) |
| Department | employee department (full path, sub-departments grouped under the main one) |
| Position | employee job position |
| Period / currency | payslip `date_from` / `date_to` and currency |

Override codes with the system parameter `hr_payroll_report_export.settings` (JSON), e.g.
`{"basic_code": "BASIC", "gross_code": "GROSS", "net_code": "NET", "allow_cats": ["ALW"], "ded_cats": ["DED"]}`.

## Notes
* PDF in Arabic needs an Arabic-capable font on the server (e.g. `fonts-noto-core`, `fonts-dejavu`).
  Latin words inside Arabic text are isolated automatically for wkhtmltopdf.
* If the company has no document layout configured, Odoo first shows its standard
  "Configure your document layout" dialog before printing any PDF.
* Tested on Odoo 19 Community with a minimal `hr_payroll` stand-in model (same field names);
  `hr_payroll` itself is Enterprise-only.

## Report designs (layout, font and colours)
Payroll ▸ Reporting ▸ **Report Designs** (also selectable in the window, field *Report design*).
Each design sets: the layout (**own header/footer** = the original report look, or the **company document layout**),
the font, and the colours of the title / column headers, department headline, sub-department line, subtotal rows,
grand total rows, text and accent. Text on coloured rows turns light or dark automatically.
Four designs are installed (Slate & Sage = the original, Orange & Light Gray, Classic Blue, Company document layout);
create or edit your own. The design is applied to the Excel, the PDF and the on-screen report.
With the company layout, the headers and headlines follow the company's primary / secondary colours.

## Departments
Each main department is a table; employees of that department come first, then every sub-department under its own name
(with its own subtotal), then the department total.
