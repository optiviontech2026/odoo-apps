# -*- coding: utf-8 -*-
{
    'name': 'Payroll Report Export (Payslip Lines)',
    'summary': 'Export the Payslip Lines as a professional payroll report - Excel (with formulas) and PDF, English / Arabic',
    'description': """
Payroll Report (Payslip Lines)
==============================

How it works in Odoo
--------------------
1. Open *Payroll > Reporting > Payroll Report* (or *Payroll > Reporting > Payslip Lines*, tick lines and use
   *Actions > Payroll Report*).
2. In the window choose the **payroll period** (from / to), the **departments** to include (empty = all, sub-departments
   are included automatically), the report language (English / Arabic RTL) and, if needed, the company.
3. Click **Show Report** to see the report on screen, or **Download Excel** / **Download PDF**.

On-screen report (linked to Odoo data)
--------------------------------------
* One table per main department (Finance first), employees ordered by position, subtotal per department and grand total.
* Click an **employee name** to open the employee profile.
* Click **any amount** (basic, allowances, gross, deductions, net, a department subtotal, the grand total or a top
  figure) to open the **payslip lines** behind it.

Exports
-------
* Excel with live formulas: Dashboard, Employee Register, Pay Components, Adjustment Details, Analysis, Source Data,
  Control Checks.
* A4 landscape PDF with Finance / Administration signature blocks.
""",
    'version': '19.0.1.1.1',
    'category': 'Human Resources/Payroll',
    'author': 'Custom',
    'license': 'LGPL-3',
    'depends': ['hr_payroll'],
    'external_dependencies': {'python': ['xlsxwriter']},
    'data': [
        'security/ir.model.access.csv',
        'data/design_data.xml',
        'report/report_paperformat.xml',
        'report/report_actions.xml',
        'report/report_templates.xml',
        'views/design_views.xml',
        'views/wizard_views.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'hr_payroll_report_export/static/src/payroll_report/payroll_report.js',
            'hr_payroll_report_export/static/src/payroll_report/payroll_report.xml',
            'hr_payroll_report_export/static/src/payroll_report/payroll_report.scss',
        ],
    },
    'post_init_hook': 'post_init_hook',
    'uninstall_hook': 'uninstall_hook',
    'installable': True,
    'application': True,
}
