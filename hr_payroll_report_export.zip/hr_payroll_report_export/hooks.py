# -*- coding: utf-8 -*-
import logging

_logger = logging.getLogger(__name__)
MODULE = 'hr_payroll_report_export'
MENU_XMLID = 'payroll_report_export_menu'
DESIGN_MENU_XMLID = MENU_XMLID + '_design'


def _find_parent_menu(env):
    """Locate Payroll > Reporting without hard-coding an xmlid that may change."""
    for xmlid in ('hr_payroll.menu_hr_payroll_report', 'hr_payroll.menu_hr_payroll_reporting',
                  'hr_payroll.payroll_menu_report'):
        menu = env.ref(xmlid, raise_if_not_found=False)
        if menu:
            return menu
    root = env.ref('hr_payroll.menu_hr_payroll_root', raise_if_not_found=False)
    domain = [('name', 'in', ['Reporting', 'التقارير'])]
    if root:
        domain.append(('parent_id', 'child_of', root.id))
    return env['ir.ui.menu'].search(domain, limit=1)


def create_menus(env):
    """Create the Reporting menu entries once (safe to call again, e.g. from a migration)."""
    parent = _find_parent_menu(env)
    if not parent:
        _logger.warning('Payroll report export: reporting menu not found; use the Actions menu on Payslip Lines.')
        return
    for xmlid, name, action_xmlid, seq in (
            (MENU_XMLID, 'Payroll Report', MODULE + '.action_payroll_report_wizard_menu', 90),
            (DESIGN_MENU_XMLID, 'Report Designs', MODULE + '.action_payroll_report_design', 91)):
        if env.ref('%s.%s' % (MODULE, xmlid), raise_if_not_found=False):
            continue
        action = env.ref(action_xmlid, raise_if_not_found=False)
        if not action:
            continue
        menu = env['ir.ui.menu'].create({
            'name': name, 'parent_id': parent.id, 'sequence': seq,
            'action': '%s,%d' % (action._name, action.id)})
        env['ir.model.data'].create({
            'name': xmlid, 'module': MODULE, 'model': 'ir.ui.menu', 'res_id': menu.id, 'noupdate': True})


def post_init_hook(env):
    create_menus(env)


def uninstall_hook(env):
    data = env['ir.model.data'].search([('module', '=', MODULE), ('name', 'in', [MENU_XMLID, DESIGN_MENU_XMLID])])
    env['ir.ui.menu'].browse(data.mapped('res_id')).exists().unlink()
