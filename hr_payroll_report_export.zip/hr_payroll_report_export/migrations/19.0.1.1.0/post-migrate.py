# -*- coding: utf-8 -*-
from odoo import SUPERUSER_ID, api

from odoo.addons.hr_payroll_report_export.hooks import create_menus


def migrate(cr, version):
    create_menus(api.Environment(cr, SUPERUSER_ID, {}))
