# -*- coding: utf-8 -*-
# report_engine, labels, styles and xlsx_builder are plain Python helpers.
from . import payroll_report_design
