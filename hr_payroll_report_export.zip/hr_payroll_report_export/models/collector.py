# -*- coding: utf-8 -*-
"""Reads hr.payslip.line records and turns them into the engine's neutral rows."""
import json
import re
from datetime import date

from . import labels
from .report_engine import build_report

PARAM = 'hr_payroll_report_export.settings'


def get_settings(env):
    raw = env['ir.config_parameter'].sudo().get_param(PARAM)
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except ValueError:
        return {}


def rows_from_lines(lines):
    rows = []
    lines = lines.sorted(lambda l: (l.slip_id.id, l.sequence, l.id))
    for i, l in enumerate(lines):
        slip = l.slip_id
        emp = slip.employee_id
        dept = emp.department_id.complete_name or emp.department_id.name or ''
        job = emp.job_id.name or emp.job_title or ''
        cat = l.category_id
        cur = slip.currency_id or slip.company_id.currency_id
        rows.append(dict(
            row=i + 2, date_from=slip.date_from, date_to=slip.date_to, emp_id=emp.id,
            employee=emp.name or '', dept=dept or None, job=job or None, name=l.name or '',
            code=l.code or '', cat_code=(cat.code or '').upper(), cat_name=cat.name or '',
            qty=l.quantity or 0.0, currency=cur.name or '', rate=l.rate or 0.0,
            amount=l.amount or 0.0, total=l.total or 0.0, company=slip.company_id.name or '',
            slip_id=slip.id, line_id=l.id))
    return rows


def build(env, lines, lang='en', include_checks=True, design=None):
    """Return (data, rows, translator, meta)."""
    rows = rows_from_lines(lines)
    if not rows:
        return None, rows, labels.Translator(lang), {}
    tr = labels.Translator(lang)
    canon = lambda x: labels.AR_TO_EN.get(x, x)
    company = rows[0]['company'] or env.company.name
    data = build_report(rows, get_settings(env), company=company, prepared=date.today(), canon=canon)
    d1, d2 = data['date_from'], data['date_to']
    if d1 and d2:
        if d1.year == d2.year and d1.month == d2.month and d1.day == 1:
            period = tr.month_year(d1.month, d1.year)
        else:
            period = '%s - %s' % (tr.date(d1), tr.date(d2))
    else:
        period = tr('not_provided')
    meta = dict(company=company, prepared_txt=tr.date(data['prepared']), period_txt=period,
                currency_txt=data['currency'] or tr('not_provided'), d1=d1, d2=d2,
                include_checks=include_checks)
    company_rec = lines[:1].slip_id.company_id or env.company
    meta['style'] = (design if design else env['payroll.report.design']).get_style(company_rec.sudo())
    return data, rows, tr, meta


def file_stem(tr, meta):
    """Payroll-Month-Company"""
    d1 = meta.get('d1')
    month = ('%s-%s' % (labels.MONTHS_EN[d1.month - 1], d1.year)) if d1 else 'Period'
    comp = re.sub(r'[^\w\-]+', '-', meta['company'], flags=re.U).strip('-') or 'Company'
    return 'Payroll-%s-%s' % (month, comp)
