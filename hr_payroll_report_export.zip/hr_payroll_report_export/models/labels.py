# -*- coding: utf-8 -*-
"""English / Arabic labels used by the XLSX and PDF outputs.

The report language is chosen in the wizard, independently of the user's
interface language, so these labels do not depend on installed Odoo languages.
Each value is (English, Arabic). Messages use str.format() placeholders.
"""

LABELS = {
    # generic
    'report': ('Payroll Report', 'تقرير الرواتب'),
    'prepared': ('Prepared', 'تاريخ الإعداد'),
    'period': ('Payroll period', 'فترة الرواتب'),
    'currency': ('Currency', 'العملة'),
    'not_specified': ('Not specified', 'غير محدد'),
    'not_provided': ('Not provided', 'غير متوفر'),
    'to': ('to', 'إلى'),
    'employees': ('Employees', 'الموظفون'),
    'employees_n': ('{n} employees', '{n} موظف'),
    'includes': ('includes', 'تشمل'),
    'page': ('Page', 'صفحة'),
    'of': ('of', 'من'),
    'confidential': ('CONFIDENTIAL - Payroll data for authorised personnel only',
                     'سري - بيانات الرواتب للأشخاص المخوّلين فقط'),
    'total': ('TOTAL', 'الإجمالي'),
    'subtotal': ('SUBTOTAL - {dept}', 'المجموع الفرعي - {dept}'),
    'dept_total': ('TOTAL - {dept}', 'المجموع الكلي - {dept}'),
    'grand_total': ('GRAND TOTAL - ALL DEPARTMENTS', 'الإجمالي العام - جميع الأقسام'),
    # dashboard
    'dashboard': ('Dashboard', 'لوحة المعلومات'),
    'dashboard_title': ('Payroll Report - Dashboard', 'تقرير الرواتب - لوحة المعلومات'),
    'key_figures': ('KEY FIGURES', 'الأرقام الرئيسية'),
    'net_by_dept': ('NET PAYROLL BY MAIN DEPARTMENT', 'صافي الرواتب حسب القسم الرئيسي'),
    'dept_summary': ('MAIN DEPARTMENT SUMMARY', 'ملخص الأقسام الرئيسية'),
    'k_employees': ('EMPLOYEES', 'الموظفون'),
    'k_basic': ('BASIC SALARY', 'الراتب الأساسي'),
    'k_allow': ('ALLOWANCES', 'البدلات'),
    'k_gross': ('GROSS PAY', 'إجمالي الراتب'),
    'k_ded': ('DEDUCTIONS', 'الاستقطاعات'),
    'k_net': ('NET PAY', 'صافي الراتب'),
    'payroll_totals': ('Payroll totals', 'إجماليات الرواتب'),
    'all_departments': ('All departments', 'جميع الأقسام'),
    'net_pay_cur': ('Net pay ({cur})', 'صافي الراتب ({cur})'),
    # columns
    'main_dept': ('Main Department', 'القسم الرئيسي'),
    'source_dept': ('Source Department', 'القسم في المصدر'),
    'c_no': ('#', '#'),
    'c_employee': ('Employee Name', 'اسم الموظف'),
    'c_employee_id': ('Employee ID', 'رقم الموظف'),
    'c_position': ('Position', 'المنصب'),
    'c_basic': ('Basic Salary', 'الراتب الأساسي'),
    'c_allow': ('Total Allowances', 'إجمالي البدلات'),
    'c_gross': ('Gross Pay', 'إجمالي الراتب'),
    'c_ded': ('Deductions', 'الاستقطاعات'),
    'c_net': ('Net Pay', 'صافي الراتب'),
    'c_allowances': ('Allowances', 'البدلات'),
    'c_basic_short': ('Basic Salary', 'الراتب الأساسي'),
    # sheets
    'sh_register': ('Employee Register', 'سجل الموظفين'),
    'sh_components': ('Pay Components', 'مكونات الراتب'),
    'sh_adjust': ('Adjustment Details', 'تفاصيل التعديلات'),
    'sh_analysis': ('Analysis', 'التحليل'),
    'sh_source': ('Source Data', 'بيانات المصدر'),
    'sh_checks': ('Control Checks', 'فحوصات التحكم'),
    'register_title': ('Employee Register - payroll by main department',
                       'سجل الموظفين - الرواتب حسب القسم الرئيسي'),
    'components_title': ('Pay Components - each allowance type shown separately',
                         'مكونات الراتب - كل نوع بدل بشكل منفصل'),
    'adjust_title': ('Adjustment Details - allowance and deduction lines, original wording and signed amounts',
                     'تفاصيل التعديلات - بنود البدلات والاستقطاعات بنصها الأصلي ومبالغها بإشاراتها'),
    'analysis_title': ('Payroll Analysis - department share, allowance mix, positions and top earners',
                       'تحليل الرواتب - حصة الأقسام وتوزيع البدلات والمناصب وأعلى الرواتب'),
    'checks_title': ('Control Checks Report - reconciliation of the report to the source data',
                     'تقرير فحوصات التحكم - مطابقة التقرير مع بيانات المصدر'),
    # pay components
    'pay_code_row': ('Pay code ->', 'رمز الدفع ->'),
    'c_gross_calc': ('Gross Pay (calculated)', 'إجمالي الراتب (محسوب)'),
    'c_gross_src': ('Gross per Source', 'الإجمالي حسب المصدر'),
    'c_net_calc': ('Net Pay (calculated)', 'صافي الراتب (محسوب)'),
    'c_net_src': ('Net per Source', 'الصافي حسب المصدر'),
    'c_gross_diff': ('Gross Difference', 'فرق الإجمالي'),
    'c_net_diff': ('Net Difference', 'فرق الصافي'),
    'c_check': ('Check', 'الفحص'),
    'total_visible': ('TOTAL (visible rows)', 'الإجمالي (الصفوف الظاهرة)'),
    'ok': ('OK', 'سليم'), 'check_flag': ('CHECK', 'تحقق'), 'all_ok': ('ALL OK', 'الكل سليم'),
    'n_to_check': ('{n} to check', '{n} للتحقق'),
    # adjustments
    'a_row': ('Source Row', 'صف المصدر'),
    'a_category': ('Category', 'الفئة'),
    'a_code': ('Pay Code', 'رمز الدفع'),
    'a_desc': ('Original Description', 'الوصف الأصلي'),
    'a_signed': ('Signed Amount (as in source)', 'المبلغ بإشارته (كما في المصدر)'),
    'a_treat': ('Treatment in Report', 'المعالجة في التقرير'),
    'a_amount': ('Amount in Report', 'المبلغ في التقرير'),
    'a_allow_added': ('Allowance - added', 'بدل - يُضاف'),
    'a_ded_sub': ('Deduction - shown positive, subtracted', 'استقطاع - يُعرض موجباً ويُطرح'),
    'cat_allowance': ('Allowance', 'بدل'),
    'cat_deduction': ('Deduction', 'استقطاع'),
    'a_note': ('Signed Amount is copied exactly from the source (deductions are negative). '
               'BASIC, GROSS and NET lines are excluded here by design.',
               'المبلغ بإشارته منسوخ كما هو من المصدر (الاستقطاعات سالبة). '
               'بنود الأساسي والإجمالي والصافي مستبعدة هنا عمداً.'),
    # analysis
    'an_dept': ('1. DEPARTMENT SHARE AND AVERAGES', '1. حصة الأقسام والمتوسطات'),
    'an_allow': ('2. ALLOWANCE MIX BY TYPE', '2. توزيع البدلات حسب النوع'),
    'an_pos': ('3. POSITION SUMMARY', '3. ملخص المناصب'),
    'an_top': ('4. HIGHEST NET PAY (TOP 5)', '4. أعلى صافي رواتب (أعلى 5)'),
    'an_dept_pdf': ('Department share and averages', 'حصة الأقسام والمتوسطات'),
    'an_allow_pdf': ('Allowance mix by type', 'توزيع البدلات حسب النوع'),
    'an_pos_pdf': ('Position summary', 'ملخص المناصب'),
    'an_top_pdf': ('Highest net pay', 'أعلى صافي راتب'),
    'pct_net': ('% of Net Payroll', '٪ من صافي الرواتب'),
    'avg_gross': ('Average Gross', 'متوسط الإجمالي'),
    'avg_net': ('Average Net', 'متوسط الصافي'),
    'avg_basic': ('Average Basic', 'متوسط الأساسي'),
    'allow_type': ('Allowance type', 'نوع البدل'),
    'recipients': ('Employees receiving', 'عدد المستلمين'),
    'pct_allow': ('% of Allowances', '٪ من البدلات'),
    'avg_recipient': ('Average per recipient', 'المتوسط لكل مستلم'),
    'total_net': ('Total Net', 'إجمالي الصافي'),
    'pay_code': ('Pay code', 'رمز الدفع'),
    'payroll_analysis': ('PAYROLL ANALYSIS', 'تحليل الرواتب'),
    # checks
    'chk_result': ('Result', 'النتيجة'),
    'chk_detail': ('Detail', 'التفاصيل'),
    'chk_check': ('Check', 'الفحص'),
    'chk_report': ('CONTROL CHECKS REPORT', 'تقرير فحوصات التحكم'),
    'flags_title': ('DATA-QUALITY FLAGS', 'ملاحظات جودة البيانات'),
    'recon_title': ('DEPARTMENT RECONCILIATION TO SOURCE GROSS / NET LINES',
                    'مطابقة الأقسام مع بنود GROSS / NET في المصدر'),
    'calc_gross': ('Calculated Gross', 'الإجمالي المحسوب'),
    'src_gross': ('Source GROSS', 'GROSS في المصدر'),
    'calc_net': ('Calculated Net', 'الصافي المحسوب'),
    'src_net': ('Source NET', 'NET في المصدر'),
    'difference': ('Difference', 'الفرق'),
    'status': ('Status', 'الحالة'),
    'PASS': ('PASS', 'ناجح'), 'FAIL': ('FAIL', 'فاشل'), 'FLAG': ('FLAG', 'تنبيه'),
    'REVIEW': ('REVIEW', 'مراجعة'), 'INFO': ('INFO', 'معلومة'),
    'chk_1': ('Basic + allowances = gross', 'الأساسي + البدلات = الإجمالي'),
    'chk_2': ('Gross - deductions = net', 'الإجمالي - الاستقطاعات = الصافي'),
    'chk_3': ('Calculated gross total = source GROSS lines', 'إجمالي المحسوب = بنود GROSS في المصدر'),
    'chk_4': ('Calculated net total = source NET lines', 'صافي المحسوب = بنود NET في المصدر'),
    'chk_5': ('Employees in source = employees reported', 'الموظفون في المصدر = الموظفون في التقرير'),
    'chk_6': ('Department subtotals add to the grand total', 'المجاميع الفرعية للأقسام تساوي الإجمالي العام'),
    'chk_7': ('Deductions displayed as positive amounts', 'الاستقطاعات معروضة كمبالغ موجبة'),
    'chk_8': ('GROSS / NET lines treated as summary values', 'بنود GROSS / NET تُعامل كقيم ملخصة'),
    'chk_9': ('Missing positions', 'مناصب مفقودة'),
    'chk_10': ('Possible duplicate records', 'سجلات مكررة محتملة'),
    'chk_11': ('Payroll period and currency', 'فترة الرواتب والعملة'),
    'chk_12': ('Employees with several payslips in the period', 'موظفون لديهم أكثر من قسيمة في الفترة'),
    'd_agree_gross': ('{a} of {b} employees agree with the source GROSS line',
                      '{a} من {b} موظفاً متوافقون مع بند GROSS في المصدر'),
    'd_agree_net': ('{a} of {b} employees agree with the source NET line',
                    '{a} من {b} موظفاً متوافقون مع بند NET في المصدر'),
    'd_calc_vs_src': ('Calculated {a} vs source {b}', 'المحسوب {a} مقابل المصدر {b}'),
    'd_unique': ('{a} unique employees in source; {b} in the report',
                 '{a} موظفاً فريداً في المصدر؛ {b} في التقرير'),
    'd_sub_sum': ('Grand total is the sum of department subtotals only (no double counting)',
                  'الإجمالي العام هو مجموع المجاميع الفرعية للأقسام فقط (دون احتساب مزدوج)'),
    'd_ded_pos': ('Total deductions {a} shown positive and subtracted from gross',
                  'إجمالي الاستقطاعات {a} معروض كمبلغ موجب ويُطرح من الإجمالي'),
    'd_summary_lines': ('{a} of {b} source lines are GROSS/NET control lines; not added as earnings',
                        '{a} من {b} بنداً في المصدر هي بنود رقابية GROSS/NET؛ ولا تُضاف كمستحقات'),
    'd_missing_pos': ('{a} employee(s) shown as "Not provided"', '{a} موظف معروض بعبارة "غير متوفر"'),
    'd_none': ('None', 'لا يوجد'),
    'd_dups': ('{a} repeated line(s); {b} pair(s) of similar names kept as separate employees (to be confirmed)',
               '{a} بند مكرر؛ {b} زوج من الأسماء المتشابهة أُبقي كموظفين منفصلين (بانتظار التأكيد)'),
    'd_period_cur': ('Payroll period: {a}; currency: {b}', 'فترة الرواتب: {a}؛ العملة: {b}'),
    'd_multi_slips': ('{a} employee(s) have more than one payslip in the period; their lines are added together',
                      '{a} موظف لديهم أكثر من قسيمة في الفترة؛ تُجمع بنودهم معاً'),
    # flags
    'fl_missing_pos': ('Missing position', 'منصب مفقود'),
    'fl_missing_dept': ('Missing department', 'قسم مفقود'),
    'fl_ded': ('Deduction present', 'يوجد استقطاع'),
    'fl_disc': ('DISCREPANCY', 'فرق'),
    'fl_dup': ('Possible duplicate', 'تكرار محتمل'),
    'fl_similar': ('Similar names (review only)', 'أسماء متشابهة (للمراجعة فقط)'),
    'fl_multi': ('Multiple payslips', 'قسائم متعددة'),
    'm_missing_pos': ('Job title is blank on all {n} lines ({d}). Shown as "Not provided", sorted last.',
                      'المسمى الوظيفي فارغ في جميع البنود ({n}) ({d}). يُعرض "غير متوفر" ويُرتّب أخيراً.'),
    'm_missing_dept': ('Department is blank. Grouped under "Not provided".',
                       'القسم فارغ. يُجمّع تحت "غير متوفر".'),
    'm_ded': ('Source line is signed -{a}; shown positive and subtracted.',
              'المبلغ في المصدر بإشارة سالبة -{a}؛ يُعرض موجباً ويُطرح.'),
    'm_disc': ('Gross diff {a}, net diff {b} vs source GROSS/NET{c}.',
               'فرق الإجمالي {a}، فرق الصافي {b} مقابل GROSS/NET في المصدر{c}.'),
    'm_summary_missing': (' (summary line missing)', ' (بند الملخص مفقود)'),
    'm_dup_basic': ('More than one BASIC line.', 'أكثر من بند أساسي واحد.'),
    'm_dup_line': ('Repeated line "{a}" {b} (source row {c}).', 'بند مكرر "{a}" {b} (صف المصدر {c}).'),
    'm_similar': ('{a}% similar; kept as separate employees.', 'تشابه {a}٪؛ أُبقي كموظفين منفصلين.'),
    'm_multi': ('{a} payslips in the period; lines added together.', '{a} قسائم في الفترة؛ جُمعت بنودها.'),
    'm_names_skipped': ('Similar-name check skipped: more than {n} employees.',
                        'تم تخطي فحص الأسماء المتشابهة: عدد الموظفين أكبر من {n}.'),
    # signatures
    'sign_title': ('APPROVAL AND SIGNATURES', 'الاعتماد والتواقيع'),
    'sign_finance': ('FINANCE DEPARTMENT', 'قسم المالية'),
    'sign_admin': ('ADMINISTRATION DEPARTMENT', 'قسم الإدارة'),
    'sign_name': ('Name:', 'الاسم:'),
    'sign_signature': ('Signature:', 'التوقيع:'),
    'sign_date': ('Date:', 'التاريخ:'),
    'foot_note': ('Deductions are shown as positive amounts and subtracted to reach Net Pay. '
                  'Gross pay = basic salary + total allowances. Source GROSS/NET lines are control totals only.',
                  'تُعرض الاستقطاعات كمبالغ موجبة وتُطرح للوصول إلى صافي الراتب. '
                  'إجمالي الراتب = الراتب الأساسي + إجمالي البدلات. بنود GROSS/NET في المصدر مجاميع رقابية فقط.'),
    'department_report': ('EMPLOYEE PAYROLL BY MAIN DEPARTMENT', 'رواتب الموظفين حسب القسم الرئيسي'),
}

MONTHS_EN = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
             'August', 'September', 'October', 'November', 'December']
MONTHS_AR = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو',
             'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر']

# Known department / position names (English -> Arabic). Names that are not in
# this table (for example names already entered in Arabic) are left untouched.
AR_NAMES = {
    'Finance': 'المالية', 'Administration': 'الإدارة', 'Sales': 'المبيعات',
    'Security': 'الأمن', 'Service': 'الخدمات', 'Warehouse': 'المستودع',
    'Financial Controller': 'المراقب المالي', 'Internal Auditor': 'المدقق الداخلي',
    'Accountant': 'محاسب', 'Cashier': 'أمين الصندوق',
    'Warehouse Manager': 'مدير المستودع', 'Designer': 'مصمم',
    'Warehouse Assistant': 'مساعد مستودع', 'Sales Team Manager': 'مدير فريق المبيعات',
    'Supervisor': 'مشرف', 'IT & Monitor': 'تقنية المعلومات والمتابعة',
    'Delegate': 'مندوب', 'Driver': 'سائق', 'Gard': 'حارس', 'Housekeeper': 'عامل نظافة',
}
AR_TO_EN = {v: k for k, v in AR_NAMES.items()}


class Translator:
    """Small helper bound to one language ('en' or 'ar')."""

    def __init__(self, lang='en'):
        self.lang = 'ar' if lang == 'ar' else 'en'
        self.idx = 1 if self.lang == 'ar' else 0

    @property
    def is_rtl(self):
        return self.lang == 'ar'

    def __call__(self, key, **kw):
        txt = LABELS[key][self.idx]
        return txt.format(**kw) if kw else txt

    def name(self, text):
        """Translate a department / position name (joins on ' / ')."""
        if not text:
            return text
        if self.lang != 'ar':
            return text
        return ' / '.join(AR_NAMES.get(p.strip(), p.strip()) for p in text.split(' / '))

    def month_year(self, month, year):
        names = MONTHS_AR if self.lang == 'ar' else MONTHS_EN
        return '%s %s' % (names[month - 1], year)

    def date(self, d):
        if not d:
            return ''
        if self.lang == 'ar':
            return '%02d %s %s' % (d.day, MONTHS_AR[d.month - 1], d.year)
        return d.strftime('%d %b %Y')
