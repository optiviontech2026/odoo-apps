# -*- coding: utf-8 -*-
from odoo import _, api, fields, models
from odoo.exceptions import ValidationError

from . import styles


class PayrollReportDesign(models.Model):
    _name = 'payroll.report.design'
    _description = 'Payroll Report Design'
    _order = 'sequence, id'

    name = fields.Char(required=True, translate=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    company_id = fields.Many2one('res.company', string='Company',
                                 help='Leave empty to make the design available for every company.')
    use_company_layout = fields.Boolean(
        string='Use the company document layout in the PDF', default=False,
        help='Ticked: the PDF uses the company layout (Settings > Configure Document Layout: header, footer, logo, '
             'font) and its primary / secondary colours for the table headers and headlines. '
             'Unticked: the report prints its own header and footer.')
    font = fields.Selection([(f, f) for f in styles.FONTS], default='Arial', required=True)
    header_color = fields.Char(string='Title / column headers', default=styles.DEFAULT['header_color'], required=True)
    headline_color = fields.Char(string='Department headline', default=styles.DEFAULT['headline_color'], required=True)
    subline_color = fields.Char(string='Sub-department line', default=styles.DEFAULT['subline_color'], required=True)
    subtotal_color = fields.Char(string='Subtotal rows', default=styles.DEFAULT['subtotal_color'], required=True)
    total_color = fields.Char(string='Grand total rows', default=styles.DEFAULT['total_color'], required=True)
    text_color = fields.Char(string='Text', default=styles.DEFAULT['text_color'], required=True)
    accent_color = fields.Char(string='Accent (lines, chart bars)', default=styles.DEFAULT['accent_color'], required=True)

    @api.constrains('header_color', 'headline_color', 'subline_color', 'subtotal_color', 'total_color',
                    'text_color', 'accent_color')
    def _check_colors(self):
        for rec in self:
            for f in ('header_color', 'headline_color', 'subline_color', 'subtotal_color', 'total_color',
                      'text_color', 'accent_color'):
                if not styles.valid(rec[f]):
                    raise ValidationError(_('"%s" must be a colour like #3F5B73.', rec._fields[f].string))

    def get_style(self, company=None):
        """Complete style dict for the Excel / PDF / on-screen report."""
        self.ensure_one() if self else None
        raw = {k: self[k] for k in ('header_color', 'headline_color', 'subline_color', 'subtotal_color',
                                    'total_color', 'text_color', 'accent_color', 'font',
                                    'use_company_layout')} if self else {}
        return styles.resolve(raw, company and company.primary_color, company and company.secondary_color)
