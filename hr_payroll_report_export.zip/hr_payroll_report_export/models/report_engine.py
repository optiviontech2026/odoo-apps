# -*- coding: utf-8 -*-
"""Payroll report engine: turns payslip-line rows into the report data set.

Pure Python (no Odoo imports) so it can be unit-tested on its own.

Each input row is a dict with the keys:
    row, date_from, date_to, emp_id, employee, dept, job, name, code,
    cat_code, cat_name, qty, currency, rate, amount, total, company, slip_id
"""
import difflib
import itertools
from collections import OrderedDict

NP = 'Not provided'          # canonical (English) marker; translated on output
TOL = 0.005

DEFAULT_SETTINGS = {
    'basic_code': 'BASIC',
    'gross_code': 'GROSS',
    'net_code': 'NET',
    'allow_cats': ['ALW', 'ALLOWANCE'],      # category code or name, upper-case
    'ded_cats': ['DED', 'DEDUCTION'],
    'first_departments': ['FINANCE', 'المالية'],
    'position_order': {
        'Finance': ['Financial Controller', 'Internal Auditor', 'Accountant', 'Cashier'],
        'Administration': ['Warehouse Manager', 'Designer', 'Warehouse Assistant'],
        'Sales': ['Sales Team Manager', 'Supervisor', 'IT & Monitor', 'Delegate', 'Driver'],
    },
    'similar_threshold': 0.8,
    'similar_max_employees': 500,
}


def r2(v):
    return round(v + 0.0, 2) + 0.0


def sub_name(main, sdept):
    """Name of a sub-department without its parent ('Administration / Warehouse' -> 'Warehouse')."""
    parts = [x.strip() for x in (sdept or '').split(' / ')]
    return ' / '.join(parts[1:]) if len(parts) > 1 and sdept != main else ''


def main_dept(dept):
    return (dept or '').split(' / ')[0].strip() or NP


def classify(r, s):
    code = r['code']
    if code == s['basic_code']:
        return 'basic'
    if code == s['gross_code']:
        return 'gross'
    if code == s['net_code']:
        return 'net'
    cats = {(r.get('cat_code') or '').strip().upper(), (r.get('cat_name') or '').strip().upper()}
    if cats & set(s['allow_cats']):
        return 'allow'
    if cats & set(s['ded_cats']):
        return 'ded'
    return 'other'


def build_report(rows, settings=None, company='', prepared=None, canon=None):
    """Return the report data dict.

    :param canon: optional callable mapping a (possibly Arabic) department /
                  position name to its canonical English name, used only for
                  ordering rules.
    """
    s = dict(DEFAULT_SETTINGS)
    s.update(settings or {})
    canon = canon or (lambda x: x)
    pos_order = {k.lower(): [canon(p).lower() for p in v] for k, v in s['position_order'].items()}
    first_aliases = {a.lower() for a in s['first_departments']}

    # ---- group rows per employee ------------------------------------------------
    emps = OrderedDict()
    flags = []            # (type_key, scope, msg_key, params)
    seen_lines = set()
    allow_codes = OrderedDict()
    for r in rows:
        k = classify(r, s)
        r['kind'] = k
        e = emps.get(r['emp_id'])
        if e is None:
            e = emps[r['emp_id']] = dict(
                emp_id=r['emp_id'], name=r['employee'], sdept=r['dept'] or NP,
                main=main_dept(r['dept']), pos=(r['job'] or '').strip() or NP,
                basic=0.0, allow=0.0, ded_raw=0.0, gs=0.0, ns=0.0, al={},
                n_lines=0, n_basic=0, has_g=False, has_n=False, slips=set())
        e['n_lines'] += 1
        e['slips'].add(r['slip_id'])
        if (r['job'] or '').strip() and e['pos'] == NP:
            e['pos'] = r['job'].strip()
        t = r['total']
        if k == 'basic':
            e['basic'] += t
            e['n_basic'] += 1
        elif k == 'allow':
            e['allow'] += t
            e['al'][r['code']] = e['al'].get(r['code'], 0.0) + t
            allow_codes.setdefault(r['code'], (r.get('rule_name') or r['name'] or r['code']).strip())
        elif k == 'ded':
            e['ded_raw'] += t
        elif k == 'gross':
            e['gs'] += t
            e['has_g'] = True
        elif k == 'net':
            e['ns'] += t
            e['has_n'] = True
        if k in ('allow', 'ded'):
            key = (r['emp_id'], r['code'], r['name'], round(r['total'], 2), r['slip_id'])
            if key in seen_lines:
                flags.append(('fl_dup', r['employee'], 'm_dup_line',
                              dict(a=r['name'], b='{:,.2f}'.format(r['total']), c=r['row'])))
            seen_lines.add(key)

    emps = list(emps.values())
    for e in emps:
        for k in ('basic', 'allow', 'gs', 'ns'):
            e[k] = r2(e[k])
        e['al'] = {c: r2(v) for c, v in e['al'].items()}
        e['ded'] = abs(r2(e['ded_raw']))
        e['gross'] = r2(e['basic'] + e['allow'])
        e['net'] = r2(e['gross'] - e['ded'])
        e['dg'] = r2(e['gross'] - e['gs'])
        e['dn'] = r2(e['net'] - e['ns'])
        e['ok'] = e['has_g'] and e['has_n'] and abs(e['dg']) < TOL and abs(e['dn']) < TOL
        e['n_slips'] = len(e['slips'])

    # ---- departments and ordering ----------------------------------------------
    firsts = [m for m in dict.fromkeys(e['main'] for e in emps) if m.lower() in first_aliases]
    rest = sorted((m for m in dict.fromkeys(e['main'] for e in emps) if m not in firsts),
                  key=lambda x: x.casefold())
    order = firsts + rest

    def key(e):
        ranks = pos_order.get(canon(e['main']).lower(), [])
        p = canon(e['pos']).lower()
        if e['pos'] == NP:
            pr = (2, 0, '')
        elif p in ranks:
            pr = (0, ranks.index(p), '')
        else:
            pr = (1, 0, p)
        return (order.index(e['main']),) + pr + (e['name'].casefold(),)

    emps.sort(key=key)
    by = OrderedDict((m, [e for e in emps if e['main'] == m]) for m in order)

    def agg(es):
        return dict(n=len(es), basic=r2(sum(e['basic'] for e in es)), allow=r2(sum(e['allow'] for e in es)),
                    gross=r2(sum(e['gross'] for e in es)), ded=r2(sum(e['ded'] for e in es)),
                    net=r2(sum(e['net'] for e in es)),
                    gs=r2(sum(e['gs'] for e in es)), ns=r2(sum(e['ns'] for e in es)))

    ds = OrderedDict((m, agg(es)) for m, es in by.items())
    tot = agg(emps)
    for m, es in by.items():
        ds[m]['subs'] = sorted({e['sdept'] for e in es} - {m})
        # sub-department groups: employees of the main department itself first, then each
        # sub-department by name; position order is kept inside every group
        keys = sorted({e['sdept'] for e in es}, key=lambda x: (x != m, x.casefold()))
        groups = [dict(sdept=k, sub=(k != m), emps=[e for e in es if e['sdept'] == k]) for k in keys]
        for g in groups:
            g['totals'] = agg(g['emps'])
        by[m] = [e for g in groups for e in g['emps']]
        ds[m]['groups'] = groups
        ds[m]['has_subs'] = any(g['sub'] for g in groups)

    # ---- flags -------------------------------------------------------------------
    for e in emps:
        if e['pos'] == NP:
            flags.append(('fl_missing_pos', e['name'], 'm_missing_pos', dict(n=e['n_lines'], d=e['sdept'])))
        if e['main'] == NP:
            flags.append(('fl_missing_dept', e['name'], 'm_missing_dept', {}))
        if e['ded']:
            flags.append(('fl_ded', e['name'], 'm_ded', dict(a='{:,.2f}'.format(e['ded']))))
        if not e['ok']:
            flags.append(('fl_disc', e['name'], 'm_disc', dict(
                a='{:,.2f}'.format(e['dg']), b='{:,.2f}'.format(e['dn']),
                c='' if (e['has_g'] and e['has_n']) else 'SUMMARY_MISSING')))
        if e['n_slips'] > 1:
            flags.append(('fl_multi', e['name'], 'm_multi', dict(a=e['n_slips'])))
        elif e['n_basic'] > 1:
            flags.append(('fl_dup', e['name'], 'm_dup_basic', {}))
    n_similar = 0
    if len(emps) <= s['similar_max_employees']:
        for a, b in itertools.combinations(emps, 2):
            ratio = difflib.SequenceMatcher(None, a['name'].lower(), b['name'].lower()).ratio()
            if ratio >= s['similar_threshold']:
                n_similar += 1
                flags.append(('fl_similar', '%s  /  %s' % (a['name'], b['name']), 'm_similar',
                              dict(a=round(ratio * 100))))
    else:
        flags.append(('fl_similar', '', 'm_names_skipped', dict(n=s['similar_max_employees'])))
    n_dup_lines = sum(1 for f in flags if f[0] == 'fl_dup')

    # ---- period / currency ---------------------------------------------------------
    dfrom = [r['date_from'] for r in rows if r.get('date_from')]
    dto = [r['date_to'] for r in rows if r.get('date_to')]
    d1, d2 = (min(dfrom), max(dto)) if dfrom and dto else (None, None)
    curs = sorted({r['currency'] for r in rows if r.get('currency')})
    currency = curs[0] if len(curs) == 1 else ''
    companies = sorted({r['company'] for r in rows if r.get('company')})
    company_name = company or ', '.join(companies)

    # ---- checks ---------------------------------------------------------------------
    nE = len(emps)
    nG = sum(1 for e in emps if e['has_g'] and abs(e['dg']) < TOL)
    nN = sum(1 for e in emps if e['has_n'] and abs(e['dn']) < TOL)
    sg, sn = r2(sum(e['gs'] for e in emps)), r2(sum(e['ns'] for e in emps))
    n_src = len({r['emp_id'] for r in rows})
    n_sum_lines = sum(1 for r in rows if r['kind'] in ('gross', 'net'))
    n_np = sum(1 for e in emps if e['pos'] == NP)
    n_multi = sum(1 for e in emps if e['n_slips'] > 1)
    sub_total = r2(sum(v['net'] for v in ds.values()))
    f2 = '{:,.2f}'.format
    checks = [
        ('chk_1', 'PASS' if nG == nE else 'FAIL', 'd_agree_gross', dict(a=nG, b=nE)),
        ('chk_2', 'PASS' if nN == nE else 'FAIL', 'd_agree_net', dict(a=nN, b=nE)),
        ('chk_3', 'PASS' if abs(tot['gross'] - sg) < TOL else 'FAIL', 'd_calc_vs_src', dict(a=f2(tot['gross']), b=f2(sg))),
        ('chk_4', 'PASS' if abs(tot['net'] - sn) < TOL else 'FAIL', 'd_calc_vs_src', dict(a=f2(tot['net']), b=f2(sn))),
        ('chk_5', 'PASS' if n_src == nE else 'FAIL', 'd_unique', dict(a=n_src, b=nE)),
        ('chk_6', 'PASS' if abs(sub_total - tot['net']) < TOL else 'FAIL', 'd_sub_sum', {}),
        ('chk_7', 'PASS' if all(e['ded'] >= 0 for e in emps) else 'FAIL', 'd_ded_pos', dict(a=f2(tot['ded']))),
        ('chk_8', 'PASS', 'd_summary_lines', dict(a=n_sum_lines, b=len(rows))),
        ('chk_9', 'FLAG' if n_np else 'PASS', 'd_missing_pos' if n_np else 'd_none', dict(a=n_np)),
        ('chk_10', 'REVIEW' if (n_dup_lines or n_similar) else 'PASS', 'd_dups', dict(a=n_dup_lines, b=n_similar)),
        ('chk_11', 'INFO', 'd_period_cur', dict(a='PERIOD', b='CURRENCY')),
    ]
    if n_multi:
        checks.insert(10, ('chk_12', 'FLAG', 'd_multi_slips', dict(a=n_multi)))

    recon = []
    for m, v in ds.items():
        dg, dn = r2(v['gross'] - v['gs']), r2(v['net'] - v['ns'])
        recon.append(dict(dept=m, n=v['n'], cg=v['gross'], sg=v['gs'], dg=dg, cn=v['net'], sn=v['ns'], dn=dn,
                          ok=abs(dg) < TOL and abs(dn) < TOL))
    recon.append(dict(dept=None, n=nE, cg=tot['gross'], sg=sg, dg=r2(tot['gross'] - sg), cn=tot['net'], sn=sn,
                      dn=r2(tot['net'] - sn), ok=abs(tot['gross'] - sg) < TOL and abs(tot['net'] - sn) < TOL))

    # ---- analysis ---------------------------------------------------------------------
    T = tot['net'] or 1.0
    A = tot['allow'] or 1.0
    an_dept = [dict(dept=m, n=v['n'], net=v['net'], pct=v['net'] / T * 100.0,
                    avg_gross=v['gross'] / v['n'], avg_net=v['net'] / v['n']) for m, v in ds.items()]
    an_allow = []
    for code, label in allow_codes.items():
        vals = [e['al'][code] for e in emps if e['al'].get(code)]
        v = r2(sum(e['al'].get(code, 0.0) for e in emps))
        an_allow.append(dict(code=code, label=label, n=len(vals), total=v, pct=v / A * 100.0,
                             avg=(v / len(vals)) if vals else 0.0))
    groups = OrderedDict()
    for e in emps:
        groups.setdefault((e['main'], e['pos']), []).append(e)
    an_pos = [dict(dept=m, pos=p, n=len(g), basic=sum(x['basic'] for x in g) / len(g),
                   gross=sum(x['gross'] for x in g) / len(g), net=sum(x['net'] for x in g) / len(g),
                   total=r2(sum(x['net'] for x in g))) for (m, p), g in groups.items()]
    an_top = [dict(name=e['name'], dept=e['main'], pos=e['pos'], net=e['net'])
              for e in sorted(emps, key=lambda x: -x['net'])[:5]]

    return dict(
        company=company_name, prepared=prepared, date_from=d1, date_to=d2, currency=currency,
        emps=emps, order=order, by=by, ds=ds, tot=tot, codes=list(allow_codes.items()),
        flags=flags, checks=checks, recon=recon, settings=s,
        analysis=dict(dept=an_dept, allow=an_allow, pos=an_pos, top=an_top),
        n_rows=len(rows),
    )
