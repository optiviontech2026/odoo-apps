# -*- coding: utf-8 -*-
"""Colour helpers shared by the Excel, PDF and on-screen report (pure Python)."""
import re

DEFAULT = dict(
    header_color='#3F5B73', headline_color='#5E8C7E', subline_color='#CFE0DA', subtotal_color='#E6EFEC',
    total_color='#3F5B73', text_color='#2B2F33', accent_color='#E0BE8A', font='Arial', use_company_layout=False)
FONTS = {'Arial': "Arial,'Liberation Sans','DejaVu Sans',sans-serif",
         'Tahoma': "Tahoma,'DejaVu Sans',Verdana,sans-serif",
         'Georgia': "Georgia,'DejaVu Serif','Times New Roman',serif",
         'Times New Roman': "'Times New Roman','Liberation Serif','DejaVu Serif',serif",
         'Calibri': "Calibri,Carlito,'DejaVu Sans',Arial,sans-serif"}
_HEX = re.compile(r'^#([0-9A-Fa-f]{6})$')


def valid(color):
    return bool(color and _HEX.match(color))


def _rgb(c):
    c = c.lstrip('#')
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


def mix(color, other='#FFFFFF', ratio=0.5):
    """`ratio` of `other` mixed into `color`."""
    a, b = _rgb(color), _rgb(other)
    return '#%02X%02X%02X' % tuple(round(a[i] * (1 - ratio) + b[i] * ratio) for i in range(3))


def contrast(bg, dark='#2B2F33', light='#FFFFFF'):
    """Readable text colour on a background."""
    r, g, b = (v / 255.0 for v in _rgb(bg))
    lin = lambda v: v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    lum = 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)
    return dark if lum > 0.42 else light


def resolve(raw=None, company_primary=None, company_secondary=None):
    """Complete style dict (all colours valid) from a partial one."""
    st = dict(DEFAULT)
    for k, v in (raw or {}).items():
        if k.endswith('_color'):
            if valid(v):
                st[k] = v
        elif v not in (None, False, ''):
            st[k] = v
        elif k == 'use_company_layout':
            st[k] = bool(v)
    if st.get('use_company_layout'):          # company document layout: its two colours drive headers / headlines
        if valid(company_primary):
            st['header_color'] = st['total_color'] = company_primary
        if valid(company_secondary):
            st['headline_color'] = company_secondary
    if st['font'] not in FONTS:
        st['font'] = 'Arial'
    hdr, head, subl, subt, tot = (st[k] for k in ('header_color', 'headline_color', 'subline_color',
                                                  'subtotal_color', 'total_color'))
    st.update(
        header_text=contrast(hdr), headline_text=contrast(head), subline_text=contrast(subl),
        subtotal_text=contrast(subt), total_text=contrast(tot),
        header2=mix(hdr, '#FFFFFF', 0.22),            # KPI tiles
        subline_light=mix(subl, '#FFFFFF', 0.55),     # sub-department subtotal rows
        stripe=mix(hdr, '#FFFFFF', 0.96), line=mix(hdr, '#FFFFFF', 0.85),
        muted=mix(st['text_color'], '#FFFFFF', 0.45), font_css=FONTS[st['font']])
    return st
