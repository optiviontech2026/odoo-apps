# -*- coding: utf-8 -*-
"""Builds the payroll report workbook with xlsxwriter (bundled with Odoo)."""
import io

import xlsxwriter
from xlsxwriter.utility import xl_col_to_name as CN

from . import styles
from .report_engine import NP

SOURCE_COLS = ['From', 'To', 'Employee', 'Department', 'Job Title', 'Name', 'Code', 'Category',
               'Quantity', 'Currency', 'Rate (%)', 'Amount', 'Total', 'Company']
EXTRA_COL = 'Employee ID'          # helper column used by the formulas

SLATE, SLATE2, SAGE, SAND = '#3F5B73', '#5A7A94', '#5E8C7E', '#E0BE8A'
LSAGE, ALT, LINE, TXT, MUTED = '#E6EFEC', '#F5F7F6', '#D9E0DD', '#2B2F33', '#6B7785'
NUM = '#,##0.00'
SNUM = '#,##0.00;-#,##0.00'
STATUS_COLORS = {'PASS': ('#137333', '#DDF3E4'), 'FAIL': ('#9B1C1C', '#F8C9C9'),
                 'FLAG': ('#8A5A00', '#FFF1CC'), 'REVIEW': ('#8A5A00', '#FFF1CC'),
                 'INFO': ('#3F5B73', '#E6EFEC')}


def _q(name):
    return "'%s'" % name.replace("'", "''")


def _crit(text):
    return '"%s"' % str(text).replace('"', '""')


class _Fmt:
    def __init__(self, wb, rtl, font='Arial', txt='#2B2F33'):
        self.wb, self.cache, self.rtl, self.font, self.txt = wb, {}, rtl, font, txt

    def __call__(self, **kw):
        base = {'font_name': self.font, 'font_size': 10, 'font_color': self.txt, 'valign': 'vcenter'}
        base.update(kw)
        key = tuple(sorted(base.items()))
        if key not in self.cache:
            self.cache[key] = self.wb.add_format(base)
        return self.cache[key]


def build_xlsx(data, rows, tr, meta):
    """Return the workbook as bytes.

    :param data: dict from report_engine.build_report
    :param rows: the source rows (list of dicts), in source order
    :param tr: labels.Translator
    :param meta: dict(company, prepared_txt, period_txt, currency_txt, period_title)
    """
    out = io.BytesIO()
    wb = xlsxwriter.Workbook(out, {'in_memory': True, 'strings_to_formulas': False,
                                   'strings_to_urls': False, 'strings_to_numbers': False})
    rtl = tr.is_rtl
    st = meta.get('style') or styles.resolve()
    SLATE, SLATE2, SAGE, SAND, LSAGE = (st['header_color'], st['header2'], st['headline_color'],
                                        st['accent_color'], st['subtotal_color'])
    ALT, LINE, TXT, MUTED, FONT = st['stripe'], st['line'], st['text_color'], st['muted'], st['font']
    SUBL, SUBL_L, TOT = st['subline_color'], st['subline_light'], st['total_color']
    HDR_T, HEAD_T, SUBL_T, SUBT_T, TOT_T = (st['header_text'], st['headline_text'], st['subline_text'],
                                           st['subtotal_text'], st['total_text'])
    SLATE2_T = styles.contrast(SLATE2)
    HTXT = SLATE if styles.contrast(SLATE) == '#FFFFFF' else TXT      # coloured titles stay readable
    F = _Fmt(wb, rtl, FONT, TXT)
    company = meta['company'] or ''
    sub_text = '%s: %s   |   %s: %s   |   %s: %s' % (
        tr('prepared'), meta['prepared_txt'], tr('period'), meta['period_txt'],
        tr('currency'), meta['currency_txt'])

    names = dict(dash=tr('dashboard'), reg=tr('sh_register'), pc=tr('sh_components'),
                 adj=tr('sh_adjust'), an=tr('sh_analysis'), src=tr('sh_source'), chk=tr('sh_checks'))
    inc_checks = meta.get('include_checks', True)
    if not inc_checks:
        names.pop('chk')
    ws = {k: wb.add_worksheet(v[:31]) for k, v in names.items()}
    order_sheets = ['dash', 'reg', 'pc', 'adj', 'an', 'src']
    # xlsxwriter keeps creation order: re-create in the wanted order is not needed
    # because `names` was built in that order already.
    dash, reg, pc, adj, an, src = (ws[k] for k in order_sheets)
    chk = ws.get('chk')
    ws_names = {k: _q(names[k][:31]) for k in names}

    emps, order, by, ds, tot = data['emps'], data['order'], data['by'], data['ds'], data['tot']
    codes = data['codes']
    nA = len(codes)
    st = data['settings']

    def page(sheet, landscape=True, fit_h=0, repeat=None):
        sheet.set_paper(9)
        sheet.set_landscape() if landscape else sheet.set_portrait()
        sheet.fit_to_pages(1, fit_h)
        sheet.set_margins(left=0.4, right=0.4, top=0.75, bottom=0.7)
        sheet.center_horizontally()
        sheet.set_header('&L&8%s&R&8%s' % (company.replace('&', '&&'), tr('report')))
        sheet.set_footer('&L&8%s&C&8%s: %s&R&8%s &P %s &N' % (
            tr('confidential'), tr('prepared'), meta['prepared_txt'], tr('page'), tr('of')))
        if repeat is not None:
            sheet.repeat_rows(*repeat)
        sheet.hide_gridlines(2)
        if rtl:
            sheet.right_to_left()

    def banner(sheet, ncols, title):
        sheet.set_row(0, 26)
        sheet.set_row(1, 18)
        sheet.set_row(2, 16)
        for c in range(ncols):
            sheet.write_blank(0, c, None, F(bg_color=SLATE))
            sheet.write_blank(1, c, None, F(bg_color=SLATE))
            sheet.write_blank(2, c, None, F(bg_color=SAGE))
        sheet.write_string(0, 0, company, F(bg_color=SLATE, font_color=HDR_T, bold=True, font_size=15))
        sheet.write_string(1, 0, title, F(bg_color=SLATE, font_color=HDR_T, font_size=11))
        sheet.write_string(2, 0, sub_text, F(bg_color=SAGE, font_color=HEAD_T, font_size=9))

    def header(sheet, row, labels, col0=0, height=30):
        sheet.set_row(row, height)
        f = F(bold=True, font_color=HDR_T, bg_color=SLATE, align='center', text_wrap=True,
              bottom=2, bottom_color=SAND)
        for i, lab in enumerate(labels):
            sheet.write_string(row, col0 + i, lab, f)

    def cell(i, **kw):
        kw.setdefault('bottom', 1)
        kw.setdefault('bottom_color', LINE)
        if i % 2:
            kw.setdefault('bg_color', ALT)
        return F(**kw)

    # ============================================================== Source Data
    nsrc = len(rows)
    last_src = nsrc + 1
    scol = {n: i for i, n in enumerate(SOURCE_COLS + [EXTRA_COL])}

    def srng(name):
        c = CN(scol[name])
        return "%s!$%s$2:$%s$%d" % (ws_names['src'], c, c, last_src)

    hf = F(bold=True, font_color=HDR_T, bg_color=SLATE, align='center', text_wrap=True)
    for i, n in enumerate(SOURCE_COLS + [EXTRA_COL]):
        src.write_string(0, i, n, hf)
    dfmt = lambda i: cell(i, font_size=9, num_format='yyyy-mm-dd', align='center')
    for i, r in enumerate(rows):
        x = i + 1
        cf = cell(i, font_size=9)
        nf = cell(i, font_size=9, num_format=SNUM)
        if r.get('date_from'):
            src.write_datetime(x, 0, _dt(r['date_from']), dfmt(i))
        else:
            src.write_blank(x, 0, None, cf)
        if r.get('date_to'):
            src.write_datetime(x, 1, _dt(r['date_to']), dfmt(i))
        else:
            src.write_blank(x, 1, None, cf)
        for c, k in ((2, 'employee'), (3, 'dept'), (4, 'job'), (5, 'name'), (6, 'code'), (7, 'cat_name'),
                     (9, 'currency'), (13, 'company')):
            v = r.get(k)
            src.write_string(x, c, v, cf) if v else src.write_blank(x, c, None, cf)
        src.write_number(x, 8, r.get('qty') or 0, cell(i, font_size=9, num_format='0.00'))
        src.write_number(x, 10, r.get('rate') or 0, cell(i, font_size=9, num_format='0.00'))
        src.write_number(x, 11, r.get('amount') or 0, nf)
        src.write_number(x, 12, r.get('total') or 0, nf)
        src.write_number(x, 14, r['emp_id'], cell(i, font_size=9, num_format='0', align='center'))
    for i, w in enumerate([12, 12, 30, 26, 22, 48, 20, 16, 10, 10, 10, 12, 12, 20, 12]):
        src.set_column(i, i, w)
    src.freeze_panes(1, 0)
    src.autofilter(0, 0, nsrc, len(SOURCE_COLS))
    page(src, True, 0, (0, 0))
    src.hide_gridlines(0)

    # ================================================== Pay Components (formulas)
    banner(pc, 12 + nA, tr('components_title'))
    cB, cA0 = 6, 7
    cTA, cG, cGS, cD, cN, cNS, cDG, cDN, cCK = (cA0 + nA + i for i in range(9))
    ncols_pc = cCK + 1
    for c in range(ncols_pc):
        pc.write_blank(0, c, None, F(bg_color=SLATE)); pc.write_blank(1, c, None, F(bg_color=SLATE))
        pc.write_blank(2, c, None, F(bg_color=SAGE))
    banner(pc, ncols_pc, tr('components_title'))
    hint = F(font_size=8, italic=True, font_color=MUTED, align='center')
    pc.write_string(3, 0, tr('pay_code_row'), F(font_size=8, italic=True, font_color=MUTED))
    pc.write_string(3, cB, st['basic_code'], hint)
    for i, (code, _l) in enumerate(codes):
        pc.write_string(3, cA0 + i, code, hint)
    pc.write_string(3, cGS, st['gross_code'], hint)
    pc.write_string(3, cNS, st['net_code'], hint)
    header(pc, 4, [tr('c_no'), tr('c_employee'), tr('c_employee_id'), tr('main_dept'), tr('source_dept'),
                   tr('c_position'), tr('c_basic')] + [l for _c, l in codes] +
           [tr('c_allow'), tr('c_gross_calc'), tr('c_gross_src'), tr('c_ded'), tr('c_net_calc'),
            tr('c_net_src'), tr('c_gross_diff'), tr('c_net_diff'), tr('c_check')], height=44)
    ded_cats = sorted({r['cat_name'] for r in rows if r.get('kind') == 'ded' and r.get('cat_name')})
    PC0 = 5
    PCROW = {}
    for i, e in enumerate(emps):
        r = PC0 + i
        x = r + 1                       # excel row number
        PCROW[e['emp_id']] = r
        emp_c = "$C%d" % x
        base = "%s,%s" % (srng('Employee ID'), emp_c)
        tdisp = lambda v: tr.name(v) if v else v
        pc.write_number(r, 0, i + 1, cell(i, align='center', font_size=9))
        pc.write_string(r, 1, e['name'], cell(i, font_size=9))
        pc.write_number(r, 2, e['emp_id'], cell(i, font_size=9, align='center', num_format='0'))
        pc.write_string(r, 3, tdisp(e['main']) if e['main'] != NP else tr('not_provided'), cell(i, font_size=9))
        pc.write_string(r, 4, tdisp(e['sdept']) if e['sdept'] != NP else tr('not_provided'), cell(i, font_size=9))
        pc.write_string(r, 5, tdisp(e['pos']) if e['pos'] != NP else tr('not_provided'), cell(i, font_size=9))
        nf = cell(i, font_size=9, num_format=NUM)
        pc.write_formula(r, cB, "=SUMIFS(%s,%s,%s,%s$4)" % (srng('Total'), base, srng('Code'), CN(cB)), nf, e['basic'])
        for k, (code, _l) in enumerate(codes):
            pc.write_formula(r, cA0 + k, "=SUMIFS(%s,%s,%s,%s$4)" % (srng('Total'), base, srng('Code'), CN(cA0 + k)),
                             nf, e['al'].get(code, 0.0))
        pc.write_formula(r, cTA, "=SUM(%s%d:%s%d)" % (CN(cA0), x, CN(cTA - 1), x), nf, e['allow'])
        pc.write_formula(r, cG, "=%s%d+%s%d" % (CN(cB), x, CN(cTA), x), nf, e['gross'])
        pc.write_formula(r, cGS, "=SUMIFS(%s,%s,%s,%s$4)" % (srng('Total'), base, srng('Code'), CN(cGS)), nf, e['gs'])
        terms = '+'.join("SUMIFS(%s,%s,%s,%s)" % (srng('Total'), base, srng('Category'), _crit(c)) for c in ded_cats) or '0'
        pc.write_formula(r, cD, "=ABS(%s)" % terms, nf, e['ded'])
        pc.write_formula(r, cN, "=%s%d-%s%d" % (CN(cG), x, CN(cD), x), nf, e['net'])
        pc.write_formula(r, cNS, "=SUMIFS(%s,%s,%s,%s$4)" % (srng('Total'), base, srng('Code'), CN(cNS)), nf, e['ns'])
        pc.write_formula(r, cDG, "=ROUND(%s%d-%s%d,2)" % (CN(cG), x, CN(cGS), x), nf, e['dg'])
        pc.write_formula(r, cDN, "=ROUND(%s%d-%s%d,2)" % (CN(cN), x, CN(cNS), x), nf, e['dn'])
        pc.write_formula(r, cCK, '=IF(AND(%s%d=0,%s%d=0),"%s","%s")' % (CN(cDG), x, CN(cDN), x, tr('ok'), tr('check_flag')),
                         cell(i, font_size=9, align='center'), tr('ok') if e['ok'] else tr('check_flag'))
    PCL = PC0 + len(emps) - 1
    PCT = PCL + 1
    pc.write_string(PCT, 1, tr('total_visible'), F(bold=True, font_color=TOT_T, bg_color=TOT))
    for c in range(ncols_pc):
        if c in (1,):
            continue
        if cB <= c <= cDN:
            vals = {cB: tot['basic'], cTA: tot['allow'], cG: tot['gross'], cGS: tot['gs'], cD: tot['ded'],
                    cN: tot['net'], cNS: tot['ns'], cDG: 0, cDN: 0}
            for k, (code, _l) in enumerate(codes):
                vals[cA0 + k] = round(sum(e['al'].get(code, 0.0) for e in emps), 2)
            pc.write_formula(PCT, c, "=SUBTOTAL(109,%s%d:%s%d)" % (CN(c), PC0 + 1, CN(c), PCL + 1),
                             F(bold=True, font_color=TOT_T, bg_color=TOT, num_format=NUM), vals.get(c, 0))
        elif c == cCK:
            pc.write_formula(PCT, c, '=IF(COUNTIF(%s%d:%s%d,"%s")=0,"%s",COUNTIF(%s%d:%s%d,"%s")&" ")' % (
                CN(cCK), PC0 + 1, CN(cCK), PCL + 1, tr('check_flag'), tr('all_ok'),
                CN(cCK), PC0 + 1, CN(cCK), PCL + 1, tr('check_flag')),
                F(bold=True, font_color=TOT_T, bg_color=TOT, align='center'),
                tr('all_ok') if all(e['ok'] for e in emps) else '')
        else:
            pc.write_blank(PCT, c, None, F(bg_color=SLATE))
    for i, w in enumerate([5, 30, 10, 18, 24, 22, 13] + [14] * nA + [14, 15, 16, 13, 15, 16, 13, 13, 11]):
        pc.set_column(i, i, w)
    pc.freeze_panes(PC0, 2)
    pc.autofilter(PC0 - 1, 0, PCL, ncols_pc - 1)
    pc.conditional_format(PC0, cCK, PCL, cCK, {'type': 'cell', 'criteria': '==', 'value': '"%s"' % tr('check_flag'),
                                              'format': wb.add_format({'bg_color': '#F8C9C9', 'font_color': '#9B1C1C', 'bold': True})})
    page(pc, True, 0, (4, 4))

    # ===================================================== Employee Register
    banner(reg, 8, tr('register_title'))
    header(reg, 4, [tr('c_no'), tr('c_employee'), tr('c_position'), tr('c_basic'), tr('c_allow'),
                    tr('c_gross'), tr('c_ded'), tr('c_net')], height=30)
    r = 5
    SUBROW, RNG, breaks, used = {}, {}, [], 0
    pcs = ws_names['pc']
    from .report_engine import sub_name
    cols5 = list(zip(range(3, 8), ('basic', 'allow', 'gross', 'ded', 'net')))
    for m in order:
        es = by[m]
        groups = ds[m]['groups']
        has_subs = ds[m]['has_subs']
        extra = 2 * len(groups) if has_subs else 0
        need = len(es) + 3 + extra
        if used and used + need > 36:
            breaks.append(r)
            used = 0
        a, b = r + 1, r + len(es) + extra            # 0-based first / last row under the band
        band = tr.name(m) if m != NP else tr('not_provided')
        band_f = F(bg_color=SAGE, font_color=HEAD_T, bold=True, font_size=10.5)
        for c in range(8):
            reg.write_blank(r, c, None, band_f)
        reg.write_formula(r, 0, '="%s   |   "&COUNT(A%d:A%d)&" %s"' % (
            band.replace('"', '""'), a + 1, b + 1, tr('employees_n', n='').strip()),
            band_f, '%s   |   %d %s' % (band, len(es), tr('employees_n', n='').strip()))
        reg.set_row(r, 20)
        r += 1
        i = 0
        group_sub_rows = []
        for g in groups:
            if has_subs:      # sub-department band: the department's own staff first, then each sub-department
                gname = tr.name(sub_name(m, g['sdept'])) if g['sub'] else band
                gf = F(bg_color=SUBL, bold=True, font_color=SUBL_T, font_size=10)
                for c in range(8):
                    reg.write_blank(r, c, None, gf)
                reg.write_string(r, 1, gname, gf)
                reg.set_row(r, 18)
                r += 1
            g0 = r
            for e in g['emps']:
                p = PCROW[e['emp_id']] + 1
                x = r + 1
                reg.write_number(r, 0, i + 1, cell(i, align='center'))
                reg.write_string(r, 1, e['name'], cell(i))
                reg.write_string(r, 2, tr.name(e['pos']) if e['pos'] != NP else tr('not_provided'),
                                 cell(i, italic=(e['pos'] == NP), font_color=('#9B1C1C' if e['pos'] == NP else TXT)))
                nf = cell(i, num_format=NUM)
                reg.write_formula(r, 3, "=%s!%s%d" % (pcs, CN(cB), p), nf, e['basic'])
                reg.write_formula(r, 4, "=%s!%s%d" % (pcs, CN(cTA), p), nf, e['allow'])
                reg.write_formula(r, 5, "=D%d+E%d" % (x, x), nf, e['gross'])
                reg.write_formula(r, 6, "=%s!%s%d" % (pcs, CN(cD), p), nf, e['ded'])
                reg.write_formula(r, 7, "=F%d-G%d" % (x, x), nf, e['net'])
                r += 1
                i += 1
            if has_subs:      # sub-department subtotal
                gsf = F(bg_color=SUBL_L, bold=True, italic=True, font_color=TXT, top=1, bottom=1,
                        top_color=SAGE, bottom_color=SAGE)
                gsn = F(bg_color=SUBL_L, bold=True, italic=True, font_color=TXT, top=1, bottom=1,
                        top_color=SAGE, bottom_color=SAGE, num_format=NUM)
                for c in range(8):
                    reg.write_blank(r, c, None, gsf)
                reg.write_string(r, 1, tr('subtotal', dept=gname), gsf)
                for c, key in cols5:
                    reg.write_formula(r, c, "=SUM(%s%d:%s%d)" % (CN(c), g0 + 1, CN(c), r), gsn, g['totals'][key])
                group_sub_rows.append(r)
                r += 1
        sub_f = F(bg_color=LSAGE, bold=True, font_color=SUBT_T, font_size=10.5, top=2, bottom=2,
                  top_color=SAGE, bottom_color=SAGE)
        subn = F(bg_color=LSAGE, bold=True, font_color=SUBT_T, font_size=10.5, top=2, bottom=2,
                 top_color=SAGE, bottom_color=SAGE, num_format=NUM)
        for c in range(8):
            reg.write_blank(r, c, None, sub_f)
        reg.write_string(r, 1, tr('dept_total' if has_subs else 'subtotal', dept=band), sub_f)
        v = ds[m]
        for c, key in cols5:
            if has_subs:
                f = '=' + '+'.join('%s%d' % (CN(c), x + 1) for x in group_sub_rows)
            else:
                f = "=SUM(%s%d:%s%d)" % (CN(c), a + 1, CN(c), b + 1)
            reg.write_formula(r, c, f, subn, v[key])
        reg.set_row(r, 19)
        SUBROW[m], RNG[m] = r, (a, b)
        r += 2
        used += need + 1
    GT = r - 1
    gtf = F(bg_color=TOT, bold=True, font_color=TOT_T, font_size=11)
    gtn = F(bg_color=TOT, bold=True, font_color=TOT_T, font_size=11, num_format=NUM)
    for c in range(8):
        reg.write_blank(GT, c, None, gtf)
    reg.write_string(GT, 1, tr('grand_total'), gtf)
    reg.write_formula(GT, 2, '=' + '+'.join('COUNT(A%d:A%d)' % (RNG[m][0] + 1, RNG[m][1] + 1) for m in order),
                      F(bg_color=TOT, bold=True, font_color=TOT_T, font_size=11, num_format='0', align='left'),
                      tot['n'])
    for c, key in zip(range(3, 8), ('basic', 'allow', 'gross', 'ded', 'net')):
        reg.write_formula(GT, c, '=' + '+'.join('%s%d' % (CN(c), SUBROW[m] + 1) for m in order), gtn, tot[key])
    reg.set_row(GT, 22)
    # signature block
    sr = GT + 3
    sig_h = F(bg_color=SLATE, bold=True, font_color=HDR_T)
    for c in range(8):
        reg.write_blank(sr, c, None, sig_h)
    reg.write_string(sr, 0, tr('sign_title'), sig_h)
    line = F(bottom=1, bottom_color='#000000')
    for title, c0, c1 in ((tr('sign_finance'), 1, 2), (tr('sign_admin'), 4, 7)):
        reg.write_string(sr + 1, c0, title, F(bold=True, font_color=HTXT))
        for k, lab in enumerate((tr('sign_name'), tr('sign_signature'), tr('sign_date'))):
            rr = sr + 3 + k * 2
            reg.set_row(rr, 24)
            for c in range(c0, c1 + 1):
                reg.write_blank(rr, c, None, line)
            reg.write_string(rr, c0, lab, F(bottom=1, bottom_color='#000000', valign='bottom'))
    reg.write_string(GT + 1, 1, tr('foot_note'), F(font_size=8, italic=True, font_color=MUTED))
    for i, w in enumerate([6, 36, 26, 16, 17, 16, 16, 16]):
        reg.set_column(i, i, w)
    reg.freeze_panes(5, 0)
    page(reg, True, 0, (4, 4))
    reg.set_h_pagebreaks(breaks)

    # ===================================================== Adjustment Details
    banner(adj, 10, tr('adjust_title'))
    header(adj, 4, [tr('a_row'), tr('c_employee'), tr('main_dept'), tr('c_position'), tr('a_category'),
                    tr('a_code'), tr('a_desc'), tr('a_signed'), tr('a_treat'), tr('a_amount')], height=40)
    idx = {e['emp_id']: i for i, e in enumerate(emps)}
    emap = {e['emp_id']: e for e in emps}
    arows = sorted((r_ for r_ in rows if r_['kind'] in ('allow', 'ded')), key=lambda r_: (idx[r_['emp_id']], r_['row']))
    ar = 5
    for i, x in enumerate(arows):
        e = emap[x['emp_id']]
        isd = x['kind'] == 'ded'
        xr = ar + 1
        adj.write_number(ar, 0, x['row'], cell(i, font_size=9, align='center'))
        adj.write_string(ar, 1, x['employee'], cell(i, font_size=9))
        adj.write_string(ar, 2, tr.name(e['main']) if e['main'] != NP else tr('not_provided'), cell(i, font_size=9))
        adj.write_string(ar, 3, tr.name(e['pos']) if e['pos'] != NP else tr('not_provided'), cell(i, font_size=9))
        red = dict(bold=True, font_color='#9B1C1C') if isd else {}
        adj.write_string(ar, 4, tr('cat_deduction') if isd else tr('cat_allowance'), cell(i, font_size=9, **red))
        adj.write_string(ar, 5, x['code'], cell(i, font_size=9))
        adj.write_string(ar, 6, x['name'] or '', cell(i, font_size=9))
        adj.write_number(ar, 7, x['total'], cell(i, font_size=9, num_format=SNUM, **red))
        adj.write_formula(ar, 8, '=IF(E%d="%s","%s","%s")' % (xr, tr('cat_deduction'), tr('a_ded_sub'), tr('a_allow_added')),
                          cell(i, font_size=9, **red), tr('a_ded_sub') if isd else tr('a_allow_added'))
        adj.write_formula(ar, 9, '=IF(E%d="%s",-H%d,H%d)' % (xr, tr('cat_deduction'), xr, xr),
                          cell(i, font_size=9, num_format=SNUM), -x['total'] if isd else x['total'])
        ar += 1
    AL = ar - 1
    tf = F(bold=True, font_color=TOT_T, bg_color=TOT)
    tn = F(bold=True, font_color=TOT_T, bg_color=TOT, num_format=SNUM)
    for c in range(10):
        adj.write_blank(ar, c, None, tf)
    adj.write_string(ar, 1, tr('total_visible'), tf)
    s_signed = round(sum(x['total'] for x in arows), 2)
    s_rep = round(sum(-x['total'] if x['kind'] == 'ded' else x['total'] for x in arows), 2)
    if arows:
        adj.write_formula(ar, 7, '=SUBTOTAL(109,H6:H%d)' % (AL + 1), tn, s_signed)
        adj.write_formula(ar, 9, '=SUBTOTAL(109,J6:J%d)' % (AL + 1), tn, s_rep)
    adj.write_string(ar + 2, 1, tr('a_note'), F(font_size=8, italic=True, font_color=MUTED))
    for i, w in enumerate([10, 30, 16, 22, 12, 22, 52, 18, 36, 16]):
        adj.set_column(i, i, w)
    adj.freeze_panes(5, 2)
    if arows:
        adj.autofilter(4, 0, AL, 9)
    page(adj, True, 0, (4, 4))

    # ============================================================== Dashboard
    banner(dash, 8, tr('dashboard_title'))
    dash.set_column(0, 0, 2)
    for c, w in zip(range(1, 8), [40, 13, 17, 17, 17, 17, 17]):
        dash.set_column(c, c, w)
    K = 24
    dash.write_string(3, 1, tr('net_by_dept'), F(bold=True, font_color=HTXT, font_size=11))
    dash.write_string(K, 1, tr('key_figures'), F(bold=True, font_color=HTXT, font_size=11))
    hdr_f = F(font_size=8, bold=True, font_color=HDR_T, bg_color=SLATE, align='center')
    dash.write_string(K + 1, 1, tr('payroll_totals'), hdr_f)
    dash.write_string(K + 2, 1, tr('all_departments'), F(bold=True, font_color=SLATE2_T, bg_color=SLATE2))
    regs = ws_names['reg']
    kp = [('k_employees', 2, tot['n'], '0'), ('k_basic', 3, tot['basic'], NUM), ('k_allow', 4, tot['allow'], NUM),
          ('k_gross', 5, tot['gross'], NUM), ('k_ded', 6, tot['ded'], NUM), ('k_net', 7, tot['net'], NUM)]
    for key, c, v, nf in kp:
        dash.write_string(K + 1, c, tr(key), hdr_f)
        last = c == 7
        dash.write_formula(K + 2, c, "=%s!%s%d" % (regs, CN(c), GT + 1),
                           F(bold=True, font_size=13, font_color=(HEAD_T if last else SLATE2_T), bg_color=(SAGE if last else SLATE2),
                             align='center', num_format=nf), v)
    dash.set_row(K + 2, 32)
    dash.write_string(K + 4, 1, tr('dept_summary'), F(bold=True, font_color=HTXT, font_size=11))
    header(dash, K + 5, [tr('main_dept'), tr('employees'), tr('c_basic'), tr('k_allow').title() if not rtl else tr('k_allow'),
                         tr('c_gross'), tr('c_ded'), tr('c_net')], col0=1, height=26)
    D0 = K + 6
    for i, m in enumerate(order):
        rr = D0 + i
        a, b = RNG[m]
        dash.write_string(rr, 1, tr.name(m) if m != NP else tr('not_provided'), cell(i))
        dash.write_formula(rr, 2, "=COUNT(%s!A%d:A%d)" % (regs, a + 1, b + 1), cell(i, align='center', num_format='0'), ds[m]['n'])
        for k, (key, col) in enumerate(zip(('basic', 'allow', 'gross', 'ded', 'net'), range(3, 8))):
            dash.write_formula(rr, 3 + k, "=%s!%s%d" % (regs, CN(col), SUBROW[m] + 1), cell(i, num_format=NUM), ds[m][key])
    DT = D0 + len(order)
    tf2 = F(bold=True, font_color=TOT_T, bg_color=TOT)
    tn2 = F(bold=True, font_color=TOT_T, bg_color=TOT, num_format=NUM)
    dash.write_string(DT, 1, tr('total'), tf2)
    dash.write_formula(DT, 2, "=SUM(C%d:C%d)" % (D0 + 1, DT), F(bold=True, font_color=TOT_T, bg_color=TOT, align='center', num_format='0'), tot['n'])
    for k, key in enumerate(('basic', 'allow', 'gross', 'ded', 'net')):
        dash.write_formula(DT, 3 + k, "=SUM(%s%d:%s%d)" % (CN(3 + k), D0 + 1, CN(3 + k), DT), tn2, tot[key])
    chart = wb.add_chart({'type': 'bar'})
    chart.add_series({'name': tr('c_net'),
                      'categories': [names['dash'][:31], D0, 1, DT - 1, 1],
                      'values': [names['dash'][:31], D0, 7, DT - 1, 7],
                      'fill': {'color': SAND}, 'border': {'color': SLATE},
                      'data_labels': {'value': True, 'num_format': '#,##0.00', 'font': {'name': FONT, 'size': 9, 'color': TXT}},
                      'gap': 45})
    chart.set_legend({'none': True})
    chart.set_title({'none': True})
    # xlsxwriter bar charts: y_axis = category axis (vertical), x_axis = value axis
    chart.set_y_axis({'reverse': True, 'crossing': 'max', 'num_font': {'name': FONT, 'size': 9}})
    chart.set_x_axis({'reverse': rtl, 'num_format': '#,##0',
                      'major_gridlines': {'visible': True, 'line': {'color': LINE}},
                      'num_font': {'name': FONT, 'size': 9}})
    chart.set_chartarea({'border': {'color': LINE}})
    chart.set_size({'width': 880, 'height': 340})
    dash.insert_chart(4, 1, chart, {'x_offset': 4, 'y_offset': 4})
    # control checks mini-table (links to the full report)
    page(dash, False, 1)

    # ================================================================ Analysis
    banner(an, 7, tr('analysis_title'))
    for c, w in zip(range(7), [30, 26, 16, 18, 18, 18, 16]):
        an.set_column(c, c, w)
    A = data['analysis']
    ar_ = 4
    dsn = names['dash'][:31]
    an.write_string(ar_, 0, tr('an_dept'), F(bold=True, font_color=HTXT, font_size=11)); ar_ += 1
    header(an, ar_, [tr('main_dept'), tr('employees'), tr('c_net'), tr('pct_net'), tr('avg_gross'), tr('avg_net')], height=28); ar_ += 1
    first_dept_row = ar_
    for i, d in enumerate(A['dept']):
        dr = D0 + i + 1
        an.write_string(ar_, 0, tr.name(d['dept']) if d['dept'] != NP else tr('not_provided'), cell(i))
        an.write_formula(ar_, 1, "=%s!C%d" % (ws_names['dash'], dr), cell(i, align='center', num_format='0'), d['n'])
        an.write_formula(ar_, 2, "=%s!H%d" % (ws_names['dash'], dr), cell(i, num_format=NUM), d['net'])
        an.write_formula(ar_, 3, "=%s!H%d/%s!H%d" % (ws_names['dash'], dr, ws_names['dash'], DT + 1), cell(i, num_format='0.0%'), d['pct'] / 100)
        an.write_formula(ar_, 4, "=%s!F%d/%s!C%d" % (ws_names['dash'], dr, ws_names['dash'], dr), cell(i, num_format=NUM), d['avg_gross'])
        an.write_formula(ar_, 5, "=%s!H%d/%s!C%d" % (ws_names['dash'], dr, ws_names['dash'], dr), cell(i, num_format=NUM), d['avg_net'])
        ar_ += 1
    ar_ += 2
    an.write_string(ar_, 0, tr('an_allow'), F(bold=True, font_color=HTXT, font_size=11)); ar_ += 1
    header(an, ar_, [tr('allow_type'), tr('pay_code'), tr('recipients'), tr('c_net').replace(tr('c_net'), tr('total_net')) if False else tr('total').title() if not rtl else tr('total'),
                     tr('pct_allow'), tr('avg_recipient')], height=28); ar_ += 1
    a0 = ar_
    pcn = ws_names['pc']
    for i, al in enumerate(A['allow']):
        col = CN(cA0 + [c for c, _l in codes].index(al['code']))
        rg_ = "%s!%s%d:%s%d" % (pcn, col, PC0 + 1, col, PCL + 1)
        an.write_string(ar_, 0, al['label'], cell(i)); an.write_string(ar_, 1, al['code'], cell(i))
        an.write_formula(ar_, 2, '=COUNTIF(%s,">0")' % rg_, cell(i, align='center', num_format='0'), al['n'])
        an.write_formula(ar_, 3, '=SUM(%s)' % rg_, cell(i, num_format=NUM), al['total'])
        an.write_formula(ar_, 4, '=IF(SUM($D$%d:$D$%d)=0,0,D%d/SUM($D$%d:$D$%d))' % (a0 + 1, a0 + len(A['allow']), ar_ + 1, a0 + 1, a0 + len(A['allow'])),
                         cell(i, num_format='0.0%'), al['pct'] / 100)
        an.write_formula(ar_, 5, '=IF(C%d=0,0,D%d/C%d)' % (ar_ + 1, ar_ + 1, ar_ + 1), cell(i, num_format=NUM), al['avg'])
        ar_ += 1
    ar_ += 2
    an.write_string(ar_, 0, tr('an_pos'), F(bold=True, font_color=HTXT, font_size=11)); ar_ += 1
    header(an, ar_, [tr('main_dept'), tr('c_position'), tr('employees'), tr('avg_basic'), tr('avg_gross'), tr('avg_net'), tr('total_net')], height=28); ar_ += 1
    for i, p in enumerate(A['pos']):
        x = ar_ + 1
        an.write_string(ar_, 0, tr.name(p['dept']) if p['dept'] != NP else tr('not_provided'), cell(i))
        an.write_string(ar_, 1, tr.name(p['pos']) if p['pos'] != NP else tr('not_provided'), cell(i))
        crit = "%s!$D$%d:$D$%d,$A%d,%s!$F$%d:$F$%d,$B%d" % (pcn, PC0 + 1, PCL + 1, x, pcn, PC0 + 1, PCL + 1, x)
        an.write_formula(ar_, 2, "=COUNTIFS(%s)" % crit, cell(i, align='center', num_format='0'), p['n'])
        for k, (col, key) in enumerate(((cB, 'basic'), (cG, 'gross'), (cN, 'net'))):
            an.write_formula(ar_, 3 + k, "=AVERAGEIFS(%s!$%s$%d:$%s$%d,%s)" % (pcn, CN(col), PC0 + 1, CN(col), PCL + 1, crit),
                             cell(i, num_format=NUM), p[key])
        an.write_formula(ar_, 6, "=SUMIFS(%s!$%s$%d:$%s$%d,%s)" % (pcn, CN(cN), PC0 + 1, CN(cN), PCL + 1, crit), cell(i, num_format=NUM), p['total'])
        ar_ += 1
    ar_ += 2
    an.write_string(ar_, 0, tr('an_top'), F(bold=True, font_color=HTXT, font_size=11)); ar_ += 1
    header(an, ar_, [tr('c_employee'), tr('main_dept'), tr('c_position'), tr('c_net')], height=24); ar_ += 1
    for i, t in enumerate(A['top']):
        an.write_string(ar_, 0, t['name'], cell(i))
        an.write_string(ar_, 1, tr.name(t['dept']) if t['dept'] != NP else tr('not_provided'), cell(i))
        an.write_string(ar_, 2, tr.name(t['pos']) if t['pos'] != NP else tr('not_provided'), cell(i))
        an.write_number(ar_, 3, t['net'], cell(i, num_format=NUM))
        ar_ += 1
    an.freeze_panes(3, 0)
    page(an, True, 0)

    # ========================================================== Control checks
    if chk is not None:
        banner(chk, 9, tr('checks_title'))
        for c, w in zip(range(9), [44, 14, 16, 16, 14, 16, 16, 14, 12]):
            chk.set_column(c, c, w)
        header(chk, 4, [tr('chk_check'), tr('chk_result'), tr('chk_detail')], height=22)
        chk.merge_range(4, 2, 4, 8, tr('chk_detail'), F(bold=True, font_color=HDR_T, bg_color=SLATE, align='center', bottom=2, bottom_color=SAND))
        period_cur = dict(a=meta['period_txt'], b=meta['currency_txt'])
        for i, (key, status, dkey, params) in enumerate(data['checks']):
            r_ = 5 + i
            p = dict(params)
            if key == 'chk_11':
                p = period_cur
            detail = tr(dkey, **p)
            col = STATUS_COLORS.get(status, STATUS_COLORS['INFO'])
            chk.write_string(r_, 0, tr(key), cell(i, font_size=9))
            chk.write_string(r_, 1, tr(status), cell(i, font_size=9, bold=True, font_color=col[0], bg_color=col[1], align='center'))
            chk.merge_range(r_, 2, r_, 8, detail, cell(i, font_size=9))
        r0 = 5 + len(data['checks']) + 2
        chk.write_string(r0 - 1, 0, tr('recon_title'), F(bold=True, font_color=HTXT, font_size=11))
        header(chk, r0, [tr('main_dept'), tr('employees'), tr('calc_gross'), tr('src_gross'), tr('difference'),
                         tr('calc_net'), tr('src_net'), tr('difference'), tr('status')], height=30)
        pcm = "%s!$D$%d:$D$%d" % (pcn, PC0 + 1, PCL + 1)
        n_rec = len(data['recon'])
        for i, rc in enumerate(data['recon']):
            r_ = r0 + 1 + i
            x = r_ + 1
            last = rc['dept'] is None
            base = dict(bold=True, font_color=TOT_T, bg_color=TOT) if last else {}
            nf = (lambda **k: F(**{**base, **k})) if last else (lambda **k: cell(i, **k))
            if last:
                chk.write_string(r_, 0, tr('total'), nf())
                chk.write_formula(r_, 1, "=SUM(B%d:B%d)" % (r0 + 2, r_), nf(align='center', num_format='0'), rc['n'])
                for c, key in zip((2, 3, 5, 6), ('cg', 'sg', 'cn', 'sn')):
                    chk.write_formula(r_, c, "=SUM(%s%d:%s%d)" % (CN(c), r0 + 2, CN(c), r_), nf(num_format=NUM), rc[key])
            else:
                m = rc['dept']
                chk.write_string(r_, 0, tr.name(m) if m != NP else tr('not_provided'), nf())
                a, b = RNG[m]
                chk.write_formula(r_, 1, "=COUNT(%s!A%d:A%d)" % (regs, a + 1, b + 1), nf(align='center', num_format='0'), rc['n'])
                chk.write_formula(r_, 2, "=%s!F%d" % (regs, SUBROW[m] + 1), nf(num_format=NUM), rc['cg'])
                chk.write_formula(r_, 3, "=SUMIFS(%s!$%s$%d:$%s$%d,%s,%s)" % (pcn, CN(cGS), PC0 + 1, CN(cGS), PCL + 1, pcm, '"%s"' % ((tr.name(m) if m != NP else tr('not_provided')).replace('"', '""'))), nf(num_format=NUM), rc['sg'])
                chk.write_formula(r_, 5, "=%s!H%d" % (regs, SUBROW[m] + 1), nf(num_format=NUM), rc['cn'])
                chk.write_formula(r_, 6, "=SUMIFS(%s!$%s$%d:$%s$%d,%s,%s)" % (pcn, CN(cNS), PC0 + 1, CN(cNS), PCL + 1, pcm, '"%s"' % ((tr.name(m) if m != NP else tr('not_provided')).replace('"', '""'))), nf(num_format=NUM), rc['sn'])
            chk.write_formula(r_, 4, "=ROUND(C%d-D%d,2)" % (x, x), nf(num_format=NUM), rc['dg'])
            chk.write_formula(r_, 7, "=ROUND(F%d-G%d,2)" % (x, x), nf(num_format=NUM), rc['dn'])
            chk.write_formula(r_, 8, '=IF(AND(E%d=0,H%d=0),"%s","%s")' % (x, x, tr('ok'), tr('check_flag')),
                              nf(align='center'), tr('ok') if rc['ok'] else tr('check_flag'))
        chk.conditional_format(r0 + 1, 8, r0 + n_rec, 8, {'type': 'cell', 'criteria': '==', 'value': '"%s"' % tr('check_flag'),
                                                           'format': wb.add_format({'bg_color': '#F8C9C9', 'font_color': '#9B1C1C', 'bold': True})})
        # flags list
        r1 = r0 + n_rec + 3
        chk.write_string(r1 - 1, 0, tr('flags_title'), F(bold=True, font_color=HTXT, font_size=11))
        header(chk, r1, [tr('chk_check'), tr('c_employee'), tr('chk_detail')], height=22)
        chk.merge_range(r1, 2, r1, 8, tr('chk_detail'), F(bold=True, font_color=HDR_T, bg_color=SLATE, align='center', bottom=2, bottom_color=SAND))
        for i, (fkey, scope, mkey, params) in enumerate(data['flags']):
            r_ = r1 + 1 + i
            p = dict(params)
            if p.get('c') == 'SUMMARY_MISSING':
                p['c'] = tr('m_summary_missing')
            if 'd' in p and mkey == 'm_missing_pos':
                p['d'] = tr.name(p['d'])
            chk.write_string(r_, 0, tr(fkey), cell(i, font_size=9, bold=True))
            chk.write_string(r_, 1, scope or '', cell(i, font_size=9))
            chk.merge_range(r_, 2, r_, 8, tr(mkey, **p), cell(i, font_size=9, text_wrap=True))
        chk.freeze_panes(5, 0)
        page(chk, True, 0)

    wb.close()
    return out.getvalue()


def _dt(d):
    import datetime
    if isinstance(d, datetime.datetime):
        return d
    return datetime.datetime(d.year, d.month, d.day)
