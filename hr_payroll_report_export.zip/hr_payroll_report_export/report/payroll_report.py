# -*- coding: utf-8 -*-
import re

from markupsafe import Markup, escape

from odoo import api, models

from ..models import collector, styles
from ..models.report_engine import NP, sub_name

SLATE, SAGE, SAND = '#3F5B73', '#5E8C7E', '#E0BE8A'


_LATIN = re.compile(r'((?:[-+(]?[A-Za-z0-9][A-Za-z0-9_/.\-%,+:]*[)]?)(?: [-+(]?[A-Za-z0-9][A-Za-z0-9_/.\-%,+:]*[)]?)*)')


def bidi(text):
    """Isolate Latin runs inside Arabic text.

    wkhtmltopdf (old WebKit) overlaps glyphs when a Latin word sits in the
    middle of a right-to-left line; wrapping it in <bdi> avoids that.
    """
    if not text:
        return text
    parts = _LATIN.split(str(text))
    return Markup(''.join(('<bdi>%s</bdi>' % escape(p)) if i % 2 else str(escape(p))
                          for i, p in enumerate(parts)))


CSS = '''
.pr{color:@TXT@;}
.pr h2{font-size:13px;color:@HTXT@;margin:8px 0 4px 0;}
.pr h2.brk{page-break-before:always;}
.pr table.t{width:100%;border-collapse:collapse;margin-bottom:6px;}
.pr table.t th{background:@HDR@;color:@HDR_T@;padding:5px 6px;font-size:9px;border-bottom:2px solid @ACC@;text-align:center;}
.pr table.t td{padding:3px 6px;border-bottom:1px solid @LINE@;}
.pr table.t tr:nth-child(even) td{background:@STRIPE@;}
.pr .num{text-align:right;white-space:nowrap;}
.pr[dir=rtl] .num{text-align:left;}
.pr .band td{background:@HEAD@ !important;color:@HEAD_T@;font-weight:bold;font-size:11px;padding:5px 8px;border:0;}
.pr .subband td{background:@SUBL@ !important;color:@SUBL_T@;font-weight:bold;border:0;}
.pr .gsub td{background:@SUBL_L@ !important;color:@TXT@;font-weight:bold;font-style:italic;border-top:1px solid @HEAD@;}
.pr .sub td{background:@SUBT@ !important;color:@SUBT_T@;font-weight:bold;border-top:2px solid @HEAD@;border-bottom:2px solid @HEAD@;}
.pr .gt td{background:@TOT@ !important;color:@TOT_T@;font-weight:bold;font-size:11px;}
.pr .kpi td{text-align:center;color:@KPI_T@;background:@KPI@;padding:6px;font-size:14px;font-weight:bold;}
.pr .kpi td.last{background:@HEAD@;color:@HEAD_T@;}
.pr .kpil td{text-align:center;background:@HDR@;color:@HDR_T@;font-size:8px;padding:3px;}
.pr .c1txt{color:@HTXT@;}
.pr .brk{page-break-before:always;}
.pr .nobrk{page-break-inside:avoid;}
.pr .PASS{color:#137333;background:#DDF3E4;font-weight:bold;text-align:center;}
.pr .FAIL{color:#9B1C1C;background:#F8C9C9;font-weight:bold;text-align:center;}
.pr .FLAG,.pr .REVIEW{color:#8A5A00;background:#FFF1CC;font-weight:bold;text-align:center;}
.pr .INFO{color:@HTXT@;background:#E6EFEC;font-weight:bold;text-align:center;}
.pr .miss{color:#9B1C1C;font-style:italic;}
'''


def _color(value, default):
    return value if value and re.match(r'^#[0-9A-Fa-f]{3,8}$', value) else default


def fmt(v):
    return '{:,.2f}'.format(v or 0.0)


def chart_svg(tr, ds, order, c1=SLATE, bar=SAND, txt='#2B2F33'):
    """Horizontal bar chart (net pay by main department), first department on top."""
    vals = [(tr.name(m) if m != NP else tr('not_provided'), ds[m]['net']) for m in order]
    width, left, right, row_h, top = 1000, 190, 120, 34, 10
    height = top + row_h * len(vals) + 30
    mx = max([v for _n, v in vals] + [1.0])
    plot = width - left - right
    rtl = tr.is_rtl
    parts = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="100%%" height="%d">' % (width, height, height * 0.62)]
    for k in range(5):
        x = left + plot * k / 4.0
        if rtl:
            x = width - x
        parts.append('<line x1="%.1f" y1="%d" x2="%.1f" y2="%d" stroke="#D9E0DD"/>' % (x, top, x, height - 22))
        parts.append('<text x="%.1f" y="%d" font-size="11" fill="#6B7785" text-anchor="middle">%s</text>' % (
            x, height - 8, '{:,.0f}'.format(mx * k / 4.0)))
    for i, (name, v) in enumerate(vals):
        y = top + i * row_h
        w = plot * v / mx
        if rtl:
            x0, tx, anchor = width - left - w, width - 10, 'end'
            lx = x0 - 6
            la = 'end'
        else:
            x0, tx, anchor = left, 10, 'start'
            lx = left + w + 6
            la = 'start'
        parts.append('<text x="%.1f" y="%.1f" font-size="12" fill="#2B2F33" text-anchor="%s">%s</text>' % (
            tx, y + 21, anchor, escape(name)))
        parts.append('<rect x="%.1f" y="%.1f" width="%.1f" height="22" fill="%s" stroke="%s"/>' % (
            x0, y + 6, max(w, 1), bar, c1))
        parts.append('<text x="%.1f" y="%.1f" font-size="11" fill="#2B2F33" text-anchor="%s">%s</text>' % (
            lx, y + 21, la, fmt(v)))
    parts.append('</svg>')
    return Markup(''.join(parts))


class PayrollReport(models.AbstractModel):
    _name = 'report.hr_payroll_report_export.report_payroll'
    _description = 'Payroll Report (PDF)'

    def _company(self, lines):
        return (lines[:1].slip_id.company_id or self.env.company).sudo()

    @api.model
    def _get_report_values(self, docids, data=None):
        data = data or {}
        lang = data.get('lang_choice') or 'en'
        lines = self.env['hr.payslip.line'].browse(data.get('line_ids') or []).exists()
        include_checks = data.get('include_checks', True)
        design = self.env['payroll.report.design'].browse(data.get('design_id') or []).exists()
        rep, rows, tr, meta = collector.build(self.env, lines, lang, include_checks, design)
        vals = {'doc_ids': docids, 'doc_model': 'payroll.report.wizard', 'docs': self.env['payroll.report.wizard'].browse(docids),
                'has_data': bool(rep)}
        if not rep:
            return vals
        B = bidi if tr.is_rtl else (lambda x: x)
        T = lambda x: tr.name(x) if x != NP else tr('not_provided')
        depts = []
        for m in rep['order']:
            d = rep['ds'][m]
            groups, no = [], 0
            for g in d['groups']:
                emps = []
                for e in g['emps']:
                    no += 1
                    emps.append(dict(no=no, name=e['name'], pos=T(e['pos']), missing=e['pos'] == NP, basic=e['basic'],
                                     allow=e['allow'], gross=e['gross'], ded=e['ded'], net=e['net']))
                groups.append(dict(name=tr.name(sub_name(m, g['sdept'])) if g['sub'] else T(m), totals=g['totals'], emps=emps))
            depts.append(dict(name=T(m), has_subs=d['has_subs'], n=len(rep['by'][m]), totals=d, groups=groups))
        checks = []
        for key, status, dkey, params in rep['checks']:
            p = dict(params)
            if key == 'chk_11':
                p = dict(a=meta['period_txt'], b=meta['currency_txt'])
            checks.append(dict(name=B(tr(key)), status=status, label=B(tr(status)), detail=B(tr(dkey, **p))))
        flags = []
        for fkey, scope, mkey, params in rep['flags']:
            p = dict(params)
            if p.get('c') == 'SUMMARY_MISSING':
                p['c'] = tr('m_summary_missing')
            if mkey == 'm_missing_pos' and 'd' in p:
                p['d'] = tr.name(p['d'])
            flags.append(dict(type=B(tr(fkey)), scope=B(scope or ''), msg=B(tr(mkey, **p))))
        recon = [dict(name=(T(r['dept']) if r['dept'] else tr('total')), total=r['dept'] is None, **{
            k: r[k] for k in ('n', 'cg', 'sg', 'dg', 'cn', 'sn', 'dn', 'ok')}) for r in rep['recon']]
        an = rep['analysis']
        comp = self._company(lines)
        st = meta['style']
        c1 = st['header_color']
        htxt = c1 if styles.contrast(c1) == '#FFFFFF' else st['text_color']
        rep_map = {'@HDR_T@': st['header_text'], '@HDR@': c1, '@HEAD_T@': st['headline_text'], '@HEAD@': st['headline_color'],
                   '@SUBL_T@': st['subline_text'], '@SUBL_L@': st['subline_light'], '@SUBL@': st['subline_color'],
                   '@SUBT_T@': st['subtotal_text'], '@SUBT@': st['subtotal_color'], '@TOT_T@': st['total_text'],
                   '@TOT@': st['total_color'], '@KPI_T@': styles.contrast(st['header2']), '@KPI@': st['header2'],
                   '@TXT@': st['text_color'], '@ACC@': st['accent_color'], '@HTXT@': htxt,
                   '@STRIPE@': st['stripe'], '@LINE@': st['line']}
        css_txt = CSS
        for k in sorted(rep_map, key=len, reverse=True):
            css_txt = css_txt.replace(k, rep_map[k])
        css = Markup(css_txt)
        use_company = st['use_company_layout']
        vals.update(css=css,
            ff=("font-family:'Noto Naskh Arabic','Noto Sans Arabic','DejaVu Sans',Arial,sans-serif" if tr.is_rtl else ('' if use_company else 'font-family:' + st['font_css'])),
            t=lambda key, **kw: B(tr(key, **kw)), fmt=fmt, pct=lambda v: '%.1f%%' % v, rtl=tr.is_rtl, lang=tr.lang, meta=meta, rep=rep, include_checks=include_checks, company=comp, use_company_layout=use_company, st=st, tot=rep['tot'], depts=depts,
            chart=chart_svg(tr, rep['ds'], rep['order'], st['header_color'], st['accent_color'], st['text_color']), checks=checks, flags=flags, recon=recon,
            an_dept=[dict(d, name=T(d['dept'])) for d in an['dept']], an_allow=an['allow'],
            an_pos=[dict(p, dname=T(p['dept']), pname=T(p['pos'])) for p in an['pos']],
            an_top=[dict(t, dname=T(t['dept']), pname=T(t['pos'])) for t in an['top']],
            foot=B(tr('confidential')))
        return vals
