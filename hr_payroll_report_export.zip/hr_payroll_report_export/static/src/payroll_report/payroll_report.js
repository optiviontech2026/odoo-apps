/** @odoo-module **/
import { Component, onWillStart, useState } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { standardActionServiceProps } from "@web/webclient/actions/action_service";

const COLS = ["basic", "allow", "gross", "ded", "net"];

export class PayrollReportView extends Component {
    static template = "hr_payroll_report_export.PayrollReportView";
    static props = { ...standardActionServiceProps };

    setup() {
        this.orm = useService("orm");
        this.action = useService("action");
        this.state = useState({ data: null, showChecks: false });
        this.wizardId = this.props.action.context.wizard_id;
        this.cols = COLS;
        onWillStart(async () => {
            this.state.data = await this.orm.call("payroll.report.wizard", "get_report_json", [[this.wizardId]]);
        });
    }

    fmt(v) {
        return (v || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
    label(key) {
        return this.state.data.labels["c_" + (key === "allow" ? "allow" : key)];
    }
    fill(template, vars) {
        return Object.entries(vars).reduce((t, [k, v]) => t.replace("{" + k + "}", v), template);
    }

    openEmployee(empId) {
        this.action.doAction({
            type: "ir.actions.act_window",
            res_model: "hr.employee",
            res_id: empId,
            views: [[false, "form"]],
            target: "current",
        });
    }

    /** Payslip lines behind an amount (employee cell, department subtotal or grand total). */
    openLines(title, ids) {
        if (!ids || !ids.length) {
            return;
        }
        this.action.doAction({
            type: "ir.actions.act_window",
            name: title,
            res_model: "hr.payslip.line",
            views: [[false, "list"], [false, "form"]],
            domain: [["id", "in", ids]],
            target: "current",
        });
    }

    async exportXlsx() {
        const act = await this.orm.call("payroll.report.wizard", "action_export_xlsx", [[this.wizardId]]);
        this.action.doAction(act);
    }
    async exportPdf() {
        const act = await this.orm.call("payroll.report.wizard", "action_export_pdf", [[this.wizardId]]);
        this.action.doAction(act);
    }
    back() {
        this.action.doAction({
            type: "ir.actions.act_window",
            res_model: "payroll.report.wizard",
            res_id: this.wizardId,
            views: [[false, "form"]],
            target: "new",
        });
    }
}

registry.category("actions").add("payroll_report_view", PayrollReportView);
