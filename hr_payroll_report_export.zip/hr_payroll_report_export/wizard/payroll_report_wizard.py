# -*- coding: utf-8 -*-
import base64
from datetime import date

from dateutil.relativedelta import relativedelta

from odoo import _, api, fields, models
from odoo.exceptions import UserError

from ..models import collector
from ..models.report_engine import NP, sub_name
from ..models.xlsx_builder import build_xlsx

KINDS = ('basic', 'allow', 'ded')


class PayrollReportWizard(models.TransientModel):
    _name = 'payroll.report.wizard'
    _description = 'Payroll Report'

    lang_choice = fields.Selection(
        [('en', 'English'), ('ar', 'العربية (Arabic, right-to-left)')],
        string='Report language', default='en', required=True)
    company_id = fields.Many2one('res.company', string='Company', required=True,
                                 default=lambda s: s.env.company)
    date_from = fields.Date(string='Period from', required=True)
    date_to = fields.Date(string='Period to', required=True)
    department_ids = fields.Many2many(
        'hr.department', string='Departments',
        help='Departments (and their sub-departments) included in the report. Leave empty for all departments.')
    design_id = fields.Many2one(
        'payroll.report.design', string='Report design', required=True,
        default=lambda s: s._default_design(),
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]",
        help='Layout, font and colours (headline, sub-lines, subtotals, totals). Manage them in Payroll > Reporting > Report Designs.')
    include_checks = fields.Boolean(
        string='Include control checks', default=True,
        help='Add the control checks (reconciliation with the GROSS / NET lines, data-quality flags) to the report.')
    line_count = fields.Integer(string='Payslip lines found', compute='_compute_line_count')

    # ------------------------------------------------------------------ defaults
    @api.model
    def _default_design(self):
        return self.env['payroll.report.design'].search(
            ['|', ('company_id', '=', False), ('company_id', '=', self.env.company.id)], limit=1)

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        ctx = self.env.context
        lines = self.env['hr.payslip.line']
        if ctx.get('active_model') == 'hr.payslip.line' and ctx.get('active_ids'):
            lines = lines.browse(ctx['active_ids']).exists()
        if lines:        # opened from the list: start from the period / departments of the selection
            slips = lines.mapped('slip_id')
            res['date_from'] = min(slips.mapped('date_from'))
            res['date_to'] = max(slips.mapped('date_to'))
            depts = lines.mapped('slip_id.employee_id.department_id')
            res['department_ids'] = [fields.Command.set(depts.ids)]
        else:            # otherwise: the most recent payroll period
            last = self.env['hr.payslip'].search([('date_to', '!=', False)], order='date_to desc', limit=1)
            if last:
                res['date_from'], res['date_to'] = last.date_from, last.date_to
            else:
                today = date.today().replace(day=1)
                res['date_from'], res['date_to'] = today, today + relativedelta(months=1, days=-1)
        return res

    # ------------------------------------------------------------------ data
    def _domain(self):
        self.ensure_one()
        dom = [('slip_id.date_from', '>=', self.date_from), ('slip_id.date_to', '<=', self.date_to)]
        if self.company_id:
            dom.append(('slip_id.company_id', '=', self.company_id.id))
        if self.department_ids:
            dom.append(('slip_id.employee_id.department_id', 'child_of', self.department_ids.ids))
        return dom

    def _lines(self):
        self.ensure_one()
        return self.env['hr.payslip.line'].search(self._domain())

    @api.depends('date_from', 'date_to', 'company_id', 'department_ids')
    def _compute_line_count(self):
        for w in self:
            w.line_count = self.env['hr.payslip.line'].search_count(w._domain()) if w.date_from and w.date_to else 0

    @api.constrains('date_from', 'date_to')
    def _check_dates(self):
        for w in self:
            if w.date_from and w.date_to and w.date_from > w.date_to:
                raise UserError(_('"Period from" must be before "Period to".'))

    # ------------------------------------------------------------------ interactive report
    def action_show_report(self):
        self.ensure_one()
        if not self.line_count:
            raise UserError(_('There are no payslip lines for this period / departments.'))
        return {'type': 'ir.actions.client', 'tag': 'payroll_report_view', 'name': _('Payroll Report'),
                'context': {'wizard_id': self.id}, 'target': 'current'}

    def get_report_json(self):
        """Payload for the interactive report; every amount carries the ids of the lines behind it."""
        self.ensure_one()
        data, rows, tr, meta = collector.build(self.env, self._lines(), self.lang_choice, self.include_checks, self.design_id)
        if not data:
            return {}
        by_emp = {}
        for r in rows:
            by_emp.setdefault(r['emp_id'], []).append(r)

        def ids_for(emp_ids):
            """line ids behind each column for a set of employees"""
            out = {k: [] for k in ('basic', 'allow', 'gross', 'ded', 'net')}
            for eid in emp_ids:
                for r in by_emp.get(eid, []):
                    k = r['kind']
                    if k in KINDS:
                        out[k].append(r['line_id'])
                    out['net'].append(r['line_id'])
                    if k in ('basic', 'allow'):
                        out['gross'].append(r['line_id'])
            return out

        T = lambda x: tr.name(x) if x != NP else tr('not_provided')
        depts = []
        for m in data['order']:
            d = data['ds'][m]
            groups = []
            no = 0
            for g in d['groups']:
                emps = []
                for e in g['emps']:
                    no += 1
                    emps.append(dict(emp_id=e['emp_id'], no=no, name=e['name'], pos=T(e['pos']), missing=e['pos'] == NP,
                                     basic=e['basic'], allow=e['allow'], gross=e['gross'], ded=e['ded'], net=e['net'],
                                     ids=ids_for([e['emp_id']])))
                groups.append(dict(
                    name=tr.name(sub_name(m, g['sdept'])) if g['sub'] else T(m), sub=g['sub'], n=len(emps),
                    totals=g['totals'], ids=ids_for([e['emp_id'] for e in g['emps']]), emps=emps))
            depts.append(dict(name=T(m), has_subs=d['has_subs'], n=len(data['by'][m]), totals=d,
                              ids=ids_for([e['emp_id'] for e in data['by'][m]]), groups=groups))
        checks = []
        for key, status, dkey, params in data['checks']:
            p = dict(params)
            if key == 'chk_11':
                p = dict(a=meta['period_txt'], b=meta['currency_txt'])
            checks.append(dict(name=tr(key), status=status, label=tr(status), detail=tr(dkey, **p)))
        L = {k: tr(k) for k in (
            'report', 'prepared', 'period', 'currency', 'dashboard_title', 'k_employees', 'k_basic', 'k_allow',
            'k_gross', 'k_ded', 'k_net', 'c_no', 'c_employee', 'c_position', 'c_basic', 'c_allow', 'c_gross', 'c_ded',
            'c_net', 'grand_total', 'checks_title', 'chk_check', 'chk_result', 'chk_detail', 'employees')}
        L['subtotal'] = tr('subtotal', dept='{dept}')
        L['dept_total'] = tr('dept_total', dept='{dept}')
        L['employees_n'] = tr('employees_n', n='{n}')
        L['hint'] = _('Click an employee name to open the profile, or any amount to see the payslip lines behind it.')
        return dict(
            rtl=tr.is_rtl, labels=L, company=meta['company'], prepared=meta['prepared_txt'], period=meta['period_txt'],
            currency=meta['currency_txt'], tot=data['tot'], tot_ids=ids_for(list(by_emp)), depts=depts, checks=checks,
            include_checks=self.include_checks,
            departments_filter=', '.join(self.department_ids.mapped('name')) or tr('all_departments'))

    # ------------------------------------------------------------------ exports
    def action_export_xlsx(self):
        self.ensure_one()
        data, rows, tr, meta = collector.build(self.env, self._lines(), self.lang_choice, self.include_checks, self.design_id)
        if not data:
            raise UserError(_('There are no payslip lines to export.'))
        content = build_xlsx(data, rows, tr, meta)
        name = collector.file_stem(tr, meta) + '.xlsx'
        att = self.env['ir.attachment'].create({
            'name': name, 'datas': base64.b64encode(content), 'res_model': self._name, 'res_id': self.id,
            'mimetype': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'})
        return {'type': 'ir.actions.act_url', 'target': 'self',
                'url': '/web/content/%d?download=true' % att.id}

    def action_export_pdf(self):
        self.ensure_one()
        lines = self._lines()
        if not lines:
            raise UserError(_('There are no payslip lines to export.'))
        return self.env.ref('hr_payroll_report_export.action_report_payroll').report_action(
            self, data={'line_ids': lines.ids, 'lang_choice': self.lang_choice,
                        'include_checks': self.include_checks, 'design_id': self.design_id.id})

    def _report_filename(self):
        self.ensure_one()
        data, rows, tr, meta = collector.build(self.env, self._lines(), self.lang_choice, self.include_checks, self.design_id)
        return collector.file_stem(tr, meta) if data else 'Payroll-Report'
