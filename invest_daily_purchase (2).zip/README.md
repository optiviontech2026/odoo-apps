# Invest and Daily Purchases (Odoo 19)

Technical name: `invest_daily_purchase` · Version 19.0.1.2.1 · License LGPL-3

> **Upload checklist (Odoo.sh / GitHub).** This package keeps every file in **one folder**
> (only the app icon sits in `static/description`), so it can't break when files are uploaded
> without their sub-folders. The only rule: in your repository, `__manifest__.py` must be
> directly inside a folder named `invest_daily_purchase` at the top level of the repo:
> `invest_daily_purchase/__manifest__.py` ✔ — `invest_daily_purchase/invest_daily_purchase/__manifest__.py` ✘.
> Delete any older copy of the folder first.

Purchase requests for goods and services with configurable sequential approvals, mandatory
supplier offers above a configurable limit, side-by-side quotation comparison, split awards,
supplier purchases, Goods Received Notes (GRN), Certificates of Completion (COC), service
acceptances and controlled vendor billing through standard Odoo Accounting.

**New in 1.2.1:** the *Numbering Sequences* block and menu were removed from the module
configuration; numbering is now set per project. Each project has a **Request Code** and, directly
under it, a **Supplier Order Code** that drives the supplier order numbers (`CODE/<year>/0001`).
Projects created with older versions get their order code and sequence automatically on upgrade.

**New in 1.2:** GRN backorders (or close the remaining quantity), digital signatures on every
approval and document with prints *with* or *without* signatures, project receiving location, site
address and supplier-order numbering, one-click **Purchase File** (order, request, quotations and
their attachments, GRN/COC, vendor bills and their attachments in one PDF), requesters limited to
their own requests (no supplier offers), second-level **Fix & Approve**, and a mandatory third
(final) approval level with its own role.

**New in 1.1:** projects with their own request numbering, project and date chosen on each
request, prints based on the company Document Layout with approval names and signature lines,
and a Purchase Report section with Excel export by project, vendor and other filters.

Depends on the standard Odoo 19 modules: `mail`, `account`, `stock`, `hr`, `analytic`.

---

## 1. Installation

1. Right-click `invest_daily_purchase.zip` → **Extract All** (keep the suggested folder name). You
   get one folder `invest_daily_purchase` with `__manifest__.py` directly inside. Copy that folder
   into one of your custom addons directories (or the top level of your Odoo.sh repository), e.g.
   `/opt/odoo/custom-addons/invest_daily_purchase`.
2. Make sure that directory is in the `addons_path` of your Odoo configuration file:
   ```ini
   addons_path = /opt/odoo/odoo/addons,/opt/odoo/custom-addons
   ```
3. Restart the Odoo service (`sudo systemctl restart odoo`, or however your server is run).
4. In Odoo, activate **developer mode** (Settings → Activate the developer mode).
5. Go to **Apps → Update Apps List**, search for **Invest and Daily Purchases** and click **Activate**.
   Accounting, Inventory and Employees are installed automatically if they are not already.

Command-line alternative:
```bash
odoo-bin -c /etc/odoo/odoo.conf -d <your_database> -i invest_daily_purchase --stop-after-init
```
Upgrade after replacing the files with a newer version (e.g. from 1.0 to 1.1 — no data is lost;
Apps → Invest and Daily Purchases → Upgrade does the same):
```bash
odoo-bin -c /etc/odoo/odoo.conf -d <your_database> -u invest_daily_purchase --stop-after-init
```

Printing PDF documents needs `wkhtmltopdf` on the server — the same requirement as standard Odoo
reports. Use the build **with patched Qt** (0.12.6.1, from github.com/wkhtmltopdf/packaging);
the plain distribution package prints the pages but leaves the company header/footer empty.

## 2. First configuration

### 2.1 Settings — *Invest & Daily Purchases → Configuration → Settings*
| Setting | Meaning |
|---|---|
| Approval Levels | Opens the level list (see 2.2). At least **three** active levels are required; the last one is the final approval. |
| Require Digital Signatures | Submitting, approving and confirming GRN / COC / acceptances need the user's signature (on by default). |
| Allow Second-Level 'Fix & Approve' | Lets second-level approvers approve with an exception when requirements are missing (on by default). |
| Partial GRNs | *Ask* (default), *Always create a backorder*, or *Never* (close the remaining quantity). |
| Projects | Opens the project list (see 2.4). |
| Project Required on Requests | Every request must have a project before it can be submitted. |
| Document Layout | Opens Odoo's Document Layout configurator (logo, colours, font, layout style) used by all prints. |
| Limit | Amount above which supplier offers are mandatory before second-level approval. A total **equal** to the limit does not trigger the requirement. |
| Limit Currency | Company currency used for the limit. Amounts in other currencies are converted with the system rate of the approval date; the rate is stored on the approval step. |
| Taxes | Whether the selected supplier total is compared with or without taxes. |
| Minimum Offers | Number of valid, attached offers (distinct suppliers) required per awarded line above the limit. Default 1. |
| Purchase Journal | Journal used for vendor bills. **Bill numbers always follow this journal's own numbering**; the module never numbers bills itself. |
| Post Accepted Goods to Inventory | Confirmed GRNs receive accepted goods quantities into the GRN receiving location (validated inventory receipt; returned automatically if the GRN is cancelled). |
| COC Approver Must Differ From Verifier | Optional segregation of duties on Certificates of Completion. |

### 2.2 Approval levels — *Configuration → Approval Levels*
Three levels exist after installation ("First-Level", "Second-Level" and "Third-Level (Final)
Approval"), authorized for the roles *First-Level*, *Second-Level* and *Third-Level (Final)
Approver*. When upgrading, a company that has fewer than three levels gets the third level added
automatically; companies already configured with three or more levels are left as they are. For each level you
can set authorized **users** and/or **roles** (groups). Levels are completed in sequence order:

* **Level 1** – approves the need on estimated prices.
* **Level 2** – supplier-offer gate: supplier selection and agreed prices are always required;
  above the limit the required number of attached offers is also enforced.
* **Level 3** – final approval (required). If you add more levels, the last one is the final approval.

### 2.3 Users — *Settings → Users*, section *Invest and Daily Purchases*
| Role | Can do |
|---|---|
| Requester | Create and submit own requests; sees **only** own requests and their approvals — no supplier offers, quotations, comparison, supplier purchases or receipts |
| Approver / First-Level / Second-Level / Third-Level (Final) Approver | See all requests and offers; approve levels they are authorized for |
| Procurement Officer | Record quotations, award suppliers, amend requests after submission |
| Goods Receiver | Create and confirm GRNs |
| Service Completion Verifier | Create, verify and approve COCs and service acceptances |
| Accountant | Create draft vendor bills from accepted quantities (also gets Accounting *Billing* rights) |
| Module Administrator | Everything above + configuration |

Approver roles only give visibility — the right to approve a given level comes from the level
configuration. Every role except *Requester* includes the technical *Purchase Staff* role, which is
what grants access to offers, supplier purchases and receiving documents.

**Signatures:** each user draws their signature once in *My Profile → Preferences → Purchase
Signature* (or the first time they sign). It is applied automatically afterwards; approvers can
redraw it in the approval window.

### 2.4 Projects — *Configuration → Projects* (or Settings → Configure Projects)
All numbering is configured per project (the module settings no longer contain sequences).
Create a project with a name and two codes:

| Field | Example | Numbers produced |
|---|---|---|
| **Request Code** | `HOR` | Purchase requests `HOR/2026/0001`, `HOR/2026/0002`, … |
| **Supplier Order Code** (right under the request code) | `HOR/PO` (default) or e.g. `HOR-ORD` | Supplier orders `HOR/PO/2026/0001`, … |

Both sequences are gap-free, 4 digits, restart every year and take the year from the document
date. Leave the order code empty to use the default *Request Code*`/PO`; while it is the default it
follows changes of the request code. Changing a code changes the prefix of the next numbers only —
numbers already issued are kept. Order codes must be unique per company. The *Request Numbering*
and *Supplier Order Numbering* tabs let you adjust digits, next number and yearly restart and show
a preview of the next number (also visible in the project list).

Each project also has a **Receiving Location** (default location of the GRNs of its orders) and a
**Project Site / Address** printed on requests and as *Deliver To* on purchase orders. An optional
analytic account is copied to the request lines (and then to supplier purchases and vendor bills).

Requests without a project, and their orders, keep the general `PR/` and `SPO/` numbering; GRNs
(`GRN/`), COCs (`COC/`) and service acceptances (`SA/`) keep their own numbering. These general
sequences can still be adjusted, if ever needed, in *Settings → Technical → Sequences* (developer
mode).

## 3. Process

1. **Request** (Requester): choose the **project** and **request date** first (the number comes
   from the project's sequence and its year from the request date; changing the project while in
   draft renumbers the request; both are locked after submission), then purpose, department,
   currency, attachments and lines. Each line is
   *Consumable Goods* (received by GRN) or *Service* (with "Requires Certificate of Completion"
   → COC, otherwise → service acceptance). Mixed requests are supported. **Submit**.
2. **First-level approval** on estimated prices. The request is evaluated against the limit.
3. **Supplier offers / selection** (Procurement): *Manage Supplier Quotations* — one quotation per
   supplier document (one attachment can cover several lines). On the request's *Supplier Offers*
   tab, award quantities (a line can be split between suppliers). The *Comparison* tab shows
   prices side by side, converted to the request currency, lowest highlighted — it is never
   selected automatically; a higher-priced award needs a justification.
4. **Second-level approval**: blocked until awarded quantities equal requested quantities and
   prices are recorded. If the higher of the estimate and the selected supplier total is
   **strictly greater** than the limit, it is also blocked until the required attached offers exist
   (red banner and *Requests → Blocked by Missing Offers*).
5. **Additional approvals**, then **Approved for Purchase**: one supplier purchase per supplier /
   company / currency is created with only that supplier's quantities and prices. No bill is
   created at this point.
6. **Receiving**: GRN for goods (received / accepted / rejected, partial deliveries), COC for
   services (quantity or completion %, cumulative max 100 %, verified then approved), service
   acceptance for other services. Only confirmed, accepted quantities become billable.
7. **Billing** (Accountant): *Create Vendor Bill* appears only when billable quantities exist. A
   draft bill per supplier / company / currency is created in the configured journal; enter the
   supplier's invoice number as *Supplier Invoice Reference*. Quantities on draft bills are
   reserved; cancelling a draft releases them; posted bills are corrected by credit note.

**Amendments**: after approval, a procurement officer can change quantities, prices, suppliers,
currencies or quotation attachments. Affected approvals are invalidated (line changes → from
level 1, offer changes → from level 2), supplier purchases go *On Hold* (no receipts or bills), the
previous values are kept in a revision snapshot and re-approval updates the supplier purchases.

### 3.1 Partial deliveries (GRN backorders)
When a GRN receives less than the open quantity, Odoo asks (setting *Partial GRNs*):
**Create Backorder** prepares a new draft GRN for the rest; **No Backorder (Close Remaining)**
closes the missing quantity — the order counts as fully received and only accepted quantities are
billed. Closed quantities can be reopened from the supplier purchase (*Reopen Closed Quantities*).

### 3.2 Second-level "Fix & Approve"
If offers, attachments or supplier selection are missing at second-level approval, the approval
window lists the missing requirements and offers **Fix requirements and approve (exception)**.
With a mandatory reason, it awards unallocated quantities to the lowest valid offers and waives
missing offers, attachments and higher-price justifications. The reason and the list of fixed
requirements are stored on the approval, shown in the chatter and printed as *Approved with
exception*. Lines with no priced offer at all still have to be completed manually.

## 4. Controls enforced on the server
* Only authorized users can act on the pending level; levels are strictly sequential.
* Workflow fields (status, approvals, supplier purchases) cannot be written through the API;
  approval steps and supplier purchases are read-only for every user.
* Receipts beyond approved quantities are blocked; accepted quantities can only be billed once
  (posted + draft bills ≤ accepted); bill lines must keep the approved price, discount, supplier,
  currency and unit — checked again when the bill is posted.
* Confirmed documents cannot be deleted; cancellation requires a reason and is refused while
  bills reference the document.
* Multi-company record rules on every model; requesters only see their own requests.

## 5. Printing
All prints use `web.external_layout`, i.e. the company's **Document Layout**
(Settings → Companies → Configure Document Layout): layout style, logo, colours, font, header,
footer and paper format — the same as Odoo's own purchase orders and invoices.

Every document has two print entries: **(with signatures)** prints the stored digital signatures,
**(without signatures)** leaves the signature boxes blank for signing by hand.

* **Purchase File** (button *Print Purchase File* on the supplier purchase, or Print menu): one PDF
  with a contents page, the purchase order, the purchase request, the quotation comparison, every
  quotation attachment (PDFs and images), the GRNs / COCs / acceptances, the vendor bills and the
  bills' attachments — with or without signatures. Bills are included for users with accounting
  access; files that are not PDF or image are listed as not included.
* **Quotation Comparison** (request Print menu, purchase staff only).
* **Purchase Request** (Print menu on the request): project, date, requester, lines with selected
  vendors, totals and an **Approvals & Signatures** table: *Requested by* plus every configured
  approval level by name. Approved levels show the approver's name and date; pending levels are
  blank so the paper copy can be signed by hand. Before submission the configured levels are listed.
* **Purchase Order** (Print menu on the supplier purchase): vendor address block, lines, taxes,
  totals and the same signature table.
* **Goods Received Note**, **Certificate of Completion** and **Service Acceptance**: with their own
  signature rows.

## 6. Reporting and Excel export
*Reporting → Purchase Report* — one row per selected vendor and request line (lines without a
selected vendor appear once), with project, vendor, department, requester, product, quantities
(requested, ordered, received, billed), estimated / ordered / received / billed amounts in company
currency, approval status and progress. Pivot (project × vendor by default), list and graph views,
filters and group-by for project, vendor, department, requester, status and month.

Three ways to get Excel:
1. **Reporting → Export to Excel**: choose dates, projects, vendors, departments, requesters,
   status and grouping (e.g. Project > Vendor), then *Export to Excel*. The file uses Odoo's own
   export layout (bold header row, grey group rows "Name (count)" with totals, same number and date
   formats) and adds approvers, GRN/COC numbers and vendor bill numbers, plus a *Filters* sheet.
   *Print PDF* gives the same data in the company document layout; *Open Analysis* opens the pivot.
2. **Pivot view** download button (Odoo standard xlsx).
3. **List view → select lines → Export**, choose the saved export template
   **"Purchase Report by Project & Vendor"** (Odoo's standard export dialog).

## 7. Menus and reports
Requests (My / All / Pending My Approval / Blocked by Missing Offers), Supplier Offers
(Quotations, Quotation Comparison), Supplier Purchases, Receiving (GRN, COC, Service
Acceptances, Outstanding), Billing (Awaiting Billing, Vendor Bills), Reporting (Purchase Report,
Export to Excel, Supplier Purchase Lines Analysis, Estimated vs Selected Cost, Outstanding,
Awaiting Billing), Configuration (Settings, Projects, Approval Levels).

## 8. Automated tests
The automated tests are kept out of this deployment package (Odoo only runs tests from a `tests`
sub-folder, which is the kind of sub-folder that broke the upload). This exact code passed all 53 of
them. Ask for the developer package to run them yourself. They cover the 13 required acceptance scenarios plus workflow, permission and web-form
paths. Run them on a **test** database:
```bash
odoo-bin -c /etc/odoo/odoo.conf -d <test_database> -u invest_daily_purchase \
         --test-tags /invest_daily_purchase --stop-after-init
```

| # | Scenario | Test |
|---|---|---|
| 1 | Below limit: attachments optional, selection & prices required | `test_01_*`, `test_01b_*` |
| 2 | Above limit without offers: L1 ok, L2 blocked | `test_02_*` |
| 3 | Above limit with valid offers: L2 available | `test_03_*`, `test_03b_*` |
| 4 | Equal to limit: offers not mandatory | `test_04_*` |
| 5 | Selected total above limit, estimate below | `test_05_*`, `test_05b_*` (foreign currency) |
| 6 | Lines to different suppliers → separate purchases and bills | `test_06_*` |
| 7 | One line split between suppliers | `test_07_*` |
| 8 | Partial goods receipt | `test_08_*` |
| 9 | Partial service completion | `test_09_*`, `test_09b_*` |
| 10 | Draft bill reservation / no duplicates | `test_10_*`, `test_10b_*` |
| 11 | Price / quantity / supplier / attachment change → re-approval | `test_11_*`, `test_11b/c/d_*` |
| 12 | Independent GRN/COC numbering, journal bill numbering | `test_12_*` |
| 13 | Unauthorized users and direct API calls blocked | `test_13_*` (both files), `test_sequential_*` |
| — | Projects, sequences, prints with signatures, report and Excel export | `test_idp_projects_reports.py` |
| — | 1.2: backorders, signatures, project location / order sequence, purchase file, requester restrictions, Fix & Approve, third level; 1.2.1: supplier order code, repair of older projects, numbering removed from settings | `test_idp_v12.py` |

## 9. Design notes
* Supplier purchases are module records (`idp.supplier.purchase`), not standard Purchase
  Orders, so that Odoo's own purchase receipt/billing rules cannot bypass the GRN/COC and
  approval controls. Suppliers, taxes, currencies, journals, analytic distribution, inventory
  locations and vendor bills are standard Odoo objects.
* A request in the middle of an amendment cannot be rejected (that would orphan the existing
  supplier purchases); use *Return for Correction* instead.
* Offer validity: an offer counts as valid if its quotation is not withdrawn, has a positive
  price and quantity, and is not past its *Valid Until* date on the approval date.
