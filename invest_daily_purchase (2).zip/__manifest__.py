{
    'name': 'Invest and Daily Purchases',
    'version': '19.0.1.2.1',
    'category': 'Supply Chain/Purchase',
    'summary': 'Purchase requests with multi-level approvals, supplier offer comparison, '
               'GRN / Certificate of Completion receiving and controlled vendor billing',
    'description': """
Invest and Daily Purchases
==========================
* Purchase requests for goods and services (mixed requests supported)
* Configurable, sequential approval levels (minimum two)
* Amount limit above which supplier offers are mandatory before second-level approval
* Multiple supplier quotations per request line, side-by-side comparison,
  split awards between suppliers
* Supplier purchases grouped by supplier / company / currency after final approval
* Goods Received Notes (GRN), Certificates of Completion (COC) and service acceptances
  with their own numbering sequences
* Vendor bills created in draft only from accepted, unbilled quantities, numbered by the
  selected accounting journal
* Re-approval on amendments, audit trail, revision snapshots
* Projects with their own request numbering sequences
* Purchase report by project / vendor with Excel export in Odoo's export layout
* Prints based on the company document layout with approval signature lines
""",
    'author': 'Jabal Al Zmroud',
    'license': 'LGPL-3',
    'depends': ['mail', 'account', 'stock', 'hr', 'analytic'],
    'data': [
        'idp_security.xml',
        'ir.model.access.csv',
        'idp_sequence_data.xml',
        'idp_approval_level_data.xml',
        'idp_approval_level_function.xml',
        'idp_project_function.xml',
        'idp_request_action_wizard_views.xml',
        'idp_cancel_wizard_views.xml',
        'idp_bill_wizard_views.xml',
        'idp_sign_wizard_views.xml',
        'idp_grn_backorder_wizard_views.xml',
        'idp_purchase_file_wizard_views.xml',
        'idp_approval_level_views.xml',
        'idp_project_views.xml',
        'idp_purchase_request_views.xml',
        'idp_quotation_views.xml',
        'idp_supplier_purchase_views.xml',
        'idp_receipt_views.xml',
        'idp_analysis_views.xml',
        'idp_purchase_report_views.xml',
        'idp_report_export_wizard_views.xml',
        'account_move_views.xml',
        'res_config_settings_views.xml',
        'res_users_views.xml',
        'idp_menus.xml',
        'idp_report_templates.xml',
        'idp_reports.xml',
    ],
    'post_init_hook': '_idp_post_init',
    'installable': True,
    'application': True,
}
