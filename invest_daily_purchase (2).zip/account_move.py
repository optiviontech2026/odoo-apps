from odoo import _, api, fields, models
from odoo.exceptions import ValidationError

from .idp_common import qty_compare


class AccountMove(models.Model):
    _inherit = 'account.move'

    idp_purchase_ids = fields.Many2many(
        'idp.supplier.purchase', compute='_compute_idp_links', string="Supplier Purchases")
    idp_request_ids = fields.Many2many(
        'idp.purchase.request', compute='_compute_idp_links', string="Purchase Requests")
    idp_receipt_ids = fields.Many2many(
        'idp.receipt', compute='_compute_idp_links', string="GRN / COC / Acceptances")
    idp_is_purchase_bill = fields.Boolean(compute='_compute_idp_links')

    @api.depends('invoice_line_ids.idp_receipt_line_id')
    def _compute_idp_links(self):
        for move in self:
            receipt_lines = move.invoice_line_ids.idp_receipt_line_id
            move.idp_receipt_ids = receipt_lines.receipt_id
            move.idp_purchase_ids = receipt_lines.purchase_id
            move.idp_request_ids = receipt_lines.purchase_id.request_id
            move.idp_is_purchase_bill = bool(receipt_lines)

    @api.constrains('partner_id', 'currency_id', 'company_id', 'move_type')
    def _check_idp_bill_header(self):
        self.invoice_line_ids._check_idp_billing()

    def _post(self, soft=True):
        # Final gate before posting: re-check every purchase-linked line.
        self.invoice_line_ids.filtered('idp_receipt_line_id')._check_idp_billing(strict=True)
        return super()._post(soft=soft)

    def action_view_idp_requests(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id(
            'invest_daily_purchase.action_idp_purchase_request')
        action['domain'] = [('id', 'in', self.idp_request_ids.ids)]
        return action

    def action_view_idp_receipts(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'idp.receipt',
            'name': _("Receiving Documents"),
            'view_mode': 'list,form',
            'domain': [('id', 'in', self.idp_receipt_ids.ids)],
            'context': {'create': False},
        }


class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    idp_receipt_line_id = fields.Many2one(
        'idp.receipt.line', string="GRN / COC / Acceptance Line", index='btree_not_null',
        ondelete='restrict', copy=True)
    idp_purchase_line_id = fields.Many2one(
        'idp.supplier.purchase.line', string="Supplier Purchase Line",
        related='idp_receipt_line_id.purchase_line_id', store=True, index='btree_not_null')

    @api.constrains('idp_receipt_line_id', 'quantity', 'price_unit', 'discount', 'parent_state',
                    'product_uom_id')
    def _check_idp_billing_constraint(self):
        self._check_idp_billing()

    def _check_idp_billing(self, strict=False):
        """Prevent duplicate billing, over-billing and billing of unaccepted quantities."""
        lines = self.filtered('idp_receipt_line_id')
        if not lines:
            return
        env = self.env
        for line in lines:
            move = line.move_id
            rline = line.idp_receipt_line_id.sudo()
            pline = rline.purchase_line_id
            if move.move_type not in ('in_invoice', 'in_refund'):
                raise ValidationError(_(
                    "Purchase-linked lines can only be used on vendor bills and refunds."))
            if line.parent_state == 'cancel':
                continue
            if rline.state != 'done':
                raise ValidationError(_(
                    "%s is not confirmed: only confirmed, accepted quantities can be billed.",
                    rline.receipt_id.name))
            if move.commercial_partner_id != pline.partner_id.commercial_partner_id:
                raise ValidationError(_(
                    "Bill %(bill)s: lines of supplier purchase %(po)s can only be billed to "
                    "%(supplier)s.", bill=move.display_name, po=pline.purchase_id.name,
                    supplier=pline.partner_id.display_name))
            if move.currency_id != pline.currency_id:
                raise ValidationError(_(
                    "Bill %(bill)s must be in %(currency)s, the currency of supplier purchase "
                    "%(po)s.", bill=move.display_name, currency=pline.currency_id.name,
                    po=pline.purchase_id.name))
            if move.company_id != pline.company_id:
                raise ValidationError(_("The bill and the supplier purchase belong to "
                                        "different companies."))
            if line.product_uom_id and line.product_uom_id != pline.uom_id:
                raise ValidationError(_(
                    "Line '%s' must be billed in the purchase unit of measure.", pline.name))
            if line.quantity < 0:
                raise ValidationError(_("Billed quantities cannot be negative."))
            if move.move_type == 'in_invoice':
                currency = pline.currency_id
                if currency.compare_amounts(line.price_unit, pline.price_unit) != 0 \
                        or abs((line.discount or 0.0) - (pline.discount or 0.0)) > 1e-6:
                    raise ValidationError(_(
                        "Line '%(line)s': the unit price and discount must match the approved "
                        "supplier price (%(price)s, %(discount)s%%).", line=pline.name,
                        price=pline.price_unit, discount=pline.discount))
        for rline in lines.idp_receipt_line_id.sudo():
            billed, reserved = rline._idp_billing_quantities()
            if qty_compare(env, billed + reserved, rline.qty_accepted) > 0:
                raise ValidationError(_(
                    "%(doc)s / '%(line)s': billing %(qty)s would exceed the accepted quantity "
                    "%(accepted)s (already billed: %(billed)s). Quantities already billed or "
                    "reserved on another draft bill cannot be billed again.",
                    doc=rline.receipt_id.name, line=rline.name, qty=billed + reserved,
                    accepted=rline.qty_accepted, billed=billed))
            if qty_compare(env, billed, 0.0) < 0:
                raise ValidationError(_(
                    "%(doc)s / '%(line)s': refunded quantity exceeds the billed quantity.",
                    doc=rline.receipt_id.name, line=rline.name))
