from odoo import Command, _, api, fields, models
from odoo.exceptions import ValidationError


class IdpApprovalLevel(models.Model):
    _name = 'idp.approval.level'
    _description = 'Purchase Approval Level'
    _order = 'company_id, sequence, id'

    name = fields.Char(required=True, translate=True)
    sequence = fields.Integer(default=10, help="Approval levels are completed in this order.")
    active = fields.Boolean(default=True)
    company_id = fields.Many2one(
        'res.company', required=True, default=lambda self: self.env.company, index=True)
    user_ids = fields.Many2many(
        'res.users', 'idp_approval_level_user_rel', 'level_id', 'user_id',
        string="Authorized Users", domain=[('share', '=', False)])
    group_ids = fields.Many2many(
        'res.groups', 'idp_approval_level_group_rel', 'level_id', 'group_id',
        string="Authorized Roles",
        help="Members of any of these groups may approve this level.")
    position = fields.Integer(compute='_compute_position', string="Level #")
    level_role = fields.Char(compute='_compute_position', string="Role in Workflow")
    note = fields.Text()

    @api.depends('sequence', 'active', 'company_id')
    def _compute_position(self):
        for company in self.company_id:
            levels = self.search([('company_id', '=', company.id)], order='sequence, id')
            positions = {level.id: idx for idx, level in enumerate(levels, start=1)}
            last = len(levels)
            for level in self.filtered(lambda lv: lv.company_id == company):
                pos = positions.get(level.id, 0)
                level.position = pos
                if pos == 1:
                    level.level_role = _("First-level approval (estimated prices)")
                elif pos == 2:
                    level.level_role = _("Second-level approval (offers & supplier selection gate)")
                elif pos and pos == last:
                    level.level_role = _("Final approval (required)")
                elif pos:
                    level.level_role = _("Additional approval")
                else:
                    level.level_role = _("Inactive")
        for level in self.filtered(lambda lv: not lv.company_id):
            level.position = 0
            level.level_role = False

    @api.constrains('user_ids', 'group_ids', 'active')
    def _check_approvers(self):
        for level in self:
            if level.active and not level.user_ids and not level.group_ids:
                raise ValidationError(_(
                    "Approval level '%s' must define at least one authorized user or role.",
                    level.name))

    def _idp_user_can_approve(self, user=None):
        self.ensure_one()
        user = user or self.env.user
        if user in self.sudo().user_ids:
            return True
        return bool(self.sudo().group_ids & user.sudo().all_group_ids)

    MIN_LEVELS = 3

    @api.model
    def _idp_ensure_min_levels(self):
        """Add the final approval level(s) to companies with fewer than MIN_LEVELS levels."""
        group = self.env.ref('invest_daily_purchase.group_idp_approver_level3',
                             raise_if_not_found=False)
        main = self.env.ref('base.main_company', raise_if_not_found=False)
        for company in self.env['res.company'].search([]):
            levels = self._idp_get_levels(company)
            if not levels or len(levels) >= self.MIN_LEVELS:
                continue
            sequence = max(levels.mapped('sequence'))
            for _i in range(self.MIN_LEVELS - len(levels)):
                sequence += 10
                level = self.sudo().create({
                    'name': _("Third-Level (Final) Approval"),
                    'sequence': sequence,
                    'company_id': company.id,
                    'group_ids': [Command.set(group.ids)] if group else False,
                    'note': _("Final, mandatory approval before the supplier purchases are "
                              "created."),
                })
                if company == main and not self.env.ref(
                        'invest_daily_purchase.approval_level_third', raise_if_not_found=False):
                    self.env['ir.model.data']._update_xmlids([{
                        'xml_id': 'invest_daily_purchase.approval_level_third',
                        'record': level,
                        'noupdate': True,
                    }])
        return True

    @api.model
    def _idp_get_levels(self, company):
        return self.sudo().search(
            [('company_id', '=', company.id), ('active', '=', True)], order='sequence, id')
