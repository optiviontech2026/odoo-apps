from collections import defaultdict

from odoo import Command, _, api, fields, models
from odoo.exceptions import UserError

from .idp_common import (
    GROUP_ACCOUNTANT, GROUP_MANAGER, check_groups, qty_compare, qty_is_zero,
)


class IdpBillWizard(models.TransientModel):
    _name = 'idp.bill.wizard'
    _description = 'Create Vendor Bills from Accepted Quantities'

    purchase_ids = fields.Many2many('idp.supplier.purchase', string="Supplier Purchases")
    line_ids = fields.One2many('idp.bill.wizard.line', 'wizard_id', string="Billable Lines")
    invoice_date = fields.Date(string="Bill Date", default=fields.Date.context_today,
                               required=True)
    vendor_reference = fields.Char(
        string="Supplier Invoice Reference",
        help="Supplier's own invoice number, stored separately from the system bill number. "
             "Applied when all lines belong to one supplier; otherwise enter it on each bill.")
    supplier_count = fields.Integer(compute='_compute_supplier_count')

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        purchase_ids = res.get('purchase_ids') or self.env.context.get('default_purchase_ids')
        if purchase_ids and 'line_ids' in fields_list:
            ids = purchase_ids
            if ids and isinstance(ids[0], (list, tuple)):
                ids = ids[0][2] if ids[0][0] == 6 else [cmd[1] for cmd in ids]
            purchases = self.env['idp.supplier.purchase'].browse(ids)
            rlines = purchases.filtered(lambda p: p.state == 'confirmed').line_ids \
                .receipt_line_ids.filtered(
                    lambda r: r.state == 'done' and not qty_is_zero(self.env, r.qty_to_bill))
            res['line_ids'] = [Command.create({
                'receipt_line_id': rline.id,
                'quantity': rline.qty_to_bill,
            }) for rline in rlines.sorted(lambda r: (r.partner_id.id, r.receipt_id.id, r.id))]
        return res

    @api.depends('line_ids.partner_id')
    def _compute_supplier_count(self):
        for wizard in self:
            wizard.supplier_count = len(wizard.line_ids.partner_id)

    def action_create_bills(self):
        self.ensure_one()
        check_groups(self.env, _("Only accountants can create vendor bills."),
                     GROUP_ACCOUNTANT, GROUP_MANAGER)
        env = self.env
        lines = self.line_ids.filtered(lambda l: not qty_is_zero(env, l.quantity))
        if not lines:
            raise UserError(_("Enter a quantity to bill on at least one line."))
        groups = defaultdict(list)
        for wline in lines:
            rline = wline.receipt_line_id
            pline = rline.purchase_line_id
            purchase = pline.purchase_id
            if purchase.state != 'confirmed':
                raise UserError(_("Supplier purchase %s is not confirmed.", purchase.name))
            if rline.state != 'done':
                raise UserError(_("%s is not confirmed.", rline.receipt_id.name))
            # Server-side availability check (never trust the wizard values).
            billed, reserved = rline._idp_billing_quantities()
            available = rline.qty_accepted - billed - reserved
            if wline.quantity < 0 or qty_compare(env, wline.quantity, available) > 0:
                raise UserError(_(
                    "%(doc)s / '%(line)s': only %(qty)s accepted and unbilled quantity is "
                    "available (other quantities are billed or reserved on draft bills).",
                    doc=rline.receipt_id.name, line=pline.name, qty=max(available, 0.0)))
            key = (purchase.partner_id.commercial_partner_id, purchase.company_id,
                   purchase.currency_id)
            groups[key].append((wline, rline, pline))

        Move = env['account.move']
        bills = Move
        for (partner, company, currency), items in groups.items():
            journal = company._idp_get_purchase_journal()
            if not journal:
                raise UserError(_("Configure a purchase journal for %s.", company.name))
            invoice_lines = []
            for wline, rline, pline in items:
                vals = {
                    'idp_receipt_line_id': rline.id,
                    'name': "%s - %s: %s" % (pline.purchase_id.name, rline.receipt_id.name,
                                             pline.name),
                    'quantity': wline.quantity,
                    'product_uom_id': pline.uom_id.id,
                    'price_unit': pline.price_unit,
                    'discount': pline.discount,
                    'tax_ids': [Command.set(pline.tax_ids.ids)],
                }
                if pline.product_id:
                    vals['product_id'] = pline.product_id.id
                if pline.account_id:
                    vals['account_id'] = pline.account_id.id
                if pline.analytic_distribution:
                    vals['analytic_distribution'] = pline.analytic_distribution
                invoice_lines.append(Command.create(vals))
            purchases = {item[2].purchase_id for item in items}
            bill_vals = {
                'move_type': 'in_invoice',
                'partner_id': partner.id,
                'company_id': company.id,
                'currency_id': currency.id,
                'journal_id': journal.id,
                'invoice_date': self.invoice_date,
                'invoice_origin': ", ".join(sorted(p.name for p in purchases)),
                'invoice_line_ids': invoice_lines,
            }
            if self.vendor_reference and len(groups) == 1:
                bill_vals['ref'] = self.vendor_reference
            bill = Move.with_company(company).with_context(
                default_move_type='in_invoice').create(bill_vals)
            bills |= bill
            for purchase in purchases:
                purchase.sudo().message_post(body=_("Draft vendor bill created: %s",
                                                    bill._get_html_link()))
        action = self.env['ir.actions.act_window']._for_xml_id(
            'account.action_move_in_invoice_type')
        action['domain'] = [('id', 'in', bills.ids)]
        if len(bills) == 1:
            action['views'] = [(False, 'form')]
            action['res_id'] = bills.id
        return action


class IdpBillWizardLine(models.TransientModel):
    _name = 'idp.bill.wizard.line'
    _description = 'Vendor Bill Wizard Line'

    wizard_id = fields.Many2one('idp.bill.wizard', required=True, ondelete='cascade')
    receipt_line_id = fields.Many2one('idp.receipt.line', required=True)
    receipt_id = fields.Many2one(related='receipt_line_id.receipt_id', string="GRN / COC")
    purchase_id = fields.Many2one(related='receipt_line_id.purchase_id')
    partner_id = fields.Many2one(related='receipt_line_id.partner_id', string="Supplier")
    currency_id = fields.Many2one(related='receipt_line_id.purchase_line_id.currency_id')
    name = fields.Char(related='receipt_line_id.name')
    uom_id = fields.Many2one(related='receipt_line_id.uom_id')
    price_unit = fields.Float(related='receipt_line_id.purchase_line_id.price_unit')
    qty_available = fields.Float(related='receipt_line_id.qty_to_bill', string="Available")
    quantity = fields.Float(string="Qty to Bill", digits='Product Unit')
