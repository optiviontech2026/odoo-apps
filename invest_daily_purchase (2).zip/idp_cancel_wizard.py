from odoo import _, fields, models
from odoo.exceptions import UserError

ALLOWED_MODELS = ('idp.purchase.request', 'idp.receipt')


class IdpCancelWizard(models.TransientModel):
    _name = 'idp.cancel.wizard'
    _description = 'Controlled Cancellation'

    res_model = fields.Char(required=True)
    res_id = fields.Integer(required=True)
    reason = fields.Text(required=True)

    def action_confirm(self):
        self.ensure_one()
        if self.res_model not in ALLOWED_MODELS:
            raise UserError(_("This document cannot be cancelled here."))
        if not (self.reason or '').strip():
            raise UserError(_("A cancellation reason is mandatory."))
        record = self.env[self.res_model].browse(self.res_id).exists()
        if not record:
            raise UserError(_("The document no longer exists."))
        record._idp_action_cancel(self.reason.strip())
        return {'type': 'ir.actions.act_window_close'}
