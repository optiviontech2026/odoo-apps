"""Shared constants and helpers for the Invest and Daily Purchases module."""
from odoo.exceptions import AccessError
from odoo.tools import float_compare, float_is_zero

GROUP_REQUESTER = 'invest_daily_purchase.group_idp_requester'
GROUP_APPROVER = 'invest_daily_purchase.group_idp_approver'
GROUP_PROCUREMENT = 'invest_daily_purchase.group_idp_procurement'
GROUP_RECEIVER = 'invest_daily_purchase.group_idp_receiver'
GROUP_VERIFIER = 'invest_daily_purchase.group_idp_verifier'
GROUP_ACCOUNTANT = 'invest_daily_purchase.group_idp_accountant'
GROUP_MANAGER = 'invest_daily_purchase.group_idp_manager'

LINE_TYPES = [
    ('goods', 'Consumable Goods'),
    ('service', 'Service'),
]

RECEIPT_METHODS = [
    ('grn', 'Goods Received Note'),
    ('coc', 'Certificate of Completion'),
    ('acceptance', 'Service Acceptance'),
]

RECEIPT_STATUS = [
    ('no', 'Nothing Received'),
    ('partial', 'Partially Received / Completed'),
    ('full', 'Fully Received / Completed'),
]

BILLING_STATUS = [
    ('no', 'Nothing Billed'),
    ('partial', 'Partially Billed'),
    ('full', 'Fully Billed'),
]


def qty_digits(env):
    return env['decimal.precision'].precision_get('Product Unit')


def qty_compare(env, a, b):
    return float_compare(a or 0.0, b or 0.0, precision_digits=qty_digits(env))


def qty_is_zero(env, a):
    return float_is_zero(a or 0.0, precision_digits=qty_digits(env))


def user_has_any(env, *xmlids):
    user = env.user
    return any(user.has_group(xmlid) for xmlid in xmlids)


def check_groups(env, message, *xmlids):
    """Server-side permission check (raises AccessError)."""
    if env.su:
        return
    if not user_has_any(env, *xmlids):
        raise AccessError(message)


def is_default_value(value, default_states=('draft',)):
    """True when a value sent on create is only a default (web client sends those)."""
    if value in (False, None, 0, '', [], ()):
        return True
    if isinstance(value, str):
        return value in default_states
    if isinstance(value, (list, tuple)):
        # x2many commands that do not link anything: CLEAR (5) or SET with no ids (6)
        for command in value:
            if not isinstance(command, (list, tuple)) or not command:
                return False
            if command[0] == 5:
                continue
            if command[0] == 6 and not (command[2] if len(command) > 2 else None):
                continue
            return False
        return True
    return False


def strip_default_protected(vals, protected):
    """Drop protected keys holding only default values; return the remaining offenders."""
    offenders = set()
    for key in list(protected.intersection(vals)):
        if is_default_value(vals[key]):
            vals.pop(key)
        else:
            offenders.add(key)
    return offenders
