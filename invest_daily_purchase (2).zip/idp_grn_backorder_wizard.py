from markupsafe import Markup

from odoo import _, api, fields, models


class IdpGrnBackorderWizard(models.TransientModel):
    _name = 'idp.grn.backorder.wizard'
    _description = 'Partial GRN: Backorder or Close'

    receipt_id = fields.Many2one('idp.receipt', required=True)
    summary_html = fields.Html(compute='_compute_summary_html', sanitize=False)

    @api.depends('receipt_id')
    def _compute_summary_html(self):
        for wizard in self:
            rows = Markup('').join(
                Markup('<tr><td>%s</td><td class="text-end">%s %s</td></tr>') % (
                    pline.name, qty, pline.uom_id.name)
                for pline, qty in wizard.receipt_id._idp_shortages().items())
            wizard.summary_html = Markup(
                '<table class="table table-sm"><thead><tr><th>%s</th>'
                '<th class="text-end">%s</th></tr></thead><tbody>%s</tbody></table>') % (
                _("Product / Description"), _("Not received yet"), rows)

    def _process(self, decision):
        self.ensure_one()
        result = self.receipt_id.with_context(idp_backorder=decision).action_confirm()
        if isinstance(result, dict):
            return result
        return {'type': 'ir.actions.act_window_close'}

    def action_backorder(self):
        return self._process('backorder')

    def action_no_backorder(self):
        return self._process('close')
