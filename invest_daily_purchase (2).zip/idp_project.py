from odoo import _, api, fields, models
from odoo.exceptions import UserError


class IdpProject(models.Model):
    """Purchase project. Each project owns a numbering sequence for its purchase requests."""
    _name = 'idp.project'
    _description = 'Purchase Project'
    _inherit = ['mail.thread']
    _order = 'code, id'
    _check_company_auto = True

    name = fields.Char(required=True, tracking=True, translate=True)
    code = fields.Char(
        string="Request Code", required=True, tracking=True,
        help="Short code used as the prefix of the project's purchase request numbers, "
             "e.g. HOR gives HOR/2026/0001.")
    purchase_code = fields.Char(
        string="Supplier Order Code", tracking=True,
        help="Prefix of the project's supplier order (supplier purchase) numbers, e.g. HOR/PO "
             "gives HOR/PO/2026/0001. Defaults to the request code followed by /PO.")
    active = fields.Boolean(default=True, tracking=True)
    company_id = fields.Many2one(
        'res.company', required=True, default=lambda self: self.env.company, index=True)
    company_currency_id = fields.Many2one(related='company_id.currency_id', string="Company Currency")
    manager_id = fields.Many2one('res.users', string="Project Manager", tracking=True,
                                 domain=[('share', '=', False)])
    analytic_account_id = fields.Many2one(
        'account.analytic.account', string="Analytic Account", check_company=True,
        help="Default analytic distribution of the project's request lines (carried to "
             "supplier purchases and vendor bills).")
    location_id = fields.Many2one(
        'stock.location', string="Receiving Location", check_company=True,
        domain="[('usage', '=', 'internal')]",
        help="Default inventory location of the GRNs of this project's purchases.")
    site_address = fields.Text(
        string="Project Site / Address",
        help="Shown on purchase requests and purchase orders as the delivery site.")
    date_start = fields.Date(string="Start Date")
    date_end = fields.Date(string="End Date")
    description = fields.Text()

    sequence_id = fields.Many2one(
        'ir.sequence', string="Request Sequence", readonly=True, copy=False,
        help="Separate numbering sequence of this project's purchase requests.")
    sequence_prefix = fields.Char(
        related='sequence_id.prefix', readonly=False, string="Number Prefix")
    sequence_padding = fields.Integer(
        related='sequence_id.padding', readonly=False, string="Number Digits")
    sequence_number_next = fields.Integer(
        related='sequence_id.number_next_actual', readonly=False, string="Next Number")
    sequence_use_date_range = fields.Boolean(
        related='sequence_id.use_date_range', readonly=False, string="Restart Every Year")
    next_number_preview = fields.Char(compute='_compute_next_number_preview',
                                      string="Next Request Number")
    purchase_sequence_id = fields.Many2one(
        'ir.sequence', string="Supplier Order Sequence", readonly=True, copy=False,
        help="Separate numbering of this project's supplier purchases (orders).")
    purchase_sequence_prefix = fields.Char(
        related='purchase_sequence_id.prefix', string="Order Number Prefix")
    purchase_sequence_padding = fields.Integer(
        related='purchase_sequence_id.padding', readonly=False, string="Order Number Digits")
    purchase_sequence_number_next = fields.Integer(
        related='purchase_sequence_id.number_next_actual', readonly=False,
        string="Next Order Number")
    purchase_sequence_use_date_range = fields.Boolean(
        related='purchase_sequence_id.use_date_range', readonly=False,
        string="Restart Order Numbers Every Year")
    next_purchase_number_preview = fields.Char(
        compute='_compute_next_number_preview', string="Next Order Number Preview")

    request_ids = fields.One2many('idp.purchase.request', 'project_id', string="Requests")
    request_count = fields.Integer(compute='_compute_stats')
    purchase_count = fields.Integer(compute='_compute_stats')
    amount_estimated = fields.Monetary(
        compute='_compute_stats', currency_field='company_currency_id',
        string="Estimated (Active Requests)")
    amount_ordered = fields.Monetary(
        compute='_compute_stats', currency_field='company_currency_id',
        string="Ordered (Untaxed)")

    _code_company_uniq = models.Constraint(
        'UNIQUE(code, company_id)', 'The project request code must be unique per company.')
    _purchase_code_company_uniq = models.Constraint(
        'UNIQUE(purchase_code, company_id)',
        'The supplier order code must be unique per company.')

    @api.depends('code', 'name')
    def _compute_display_name(self):
        for project in self:
            project.display_name = f"[{project.code}] {project.name}" if project.code \
                else (project.name or '')

    @api.depends('sequence_id.prefix', 'sequence_id.padding', 'sequence_id.number_next_actual',
                 'purchase_sequence_id.prefix', 'purchase_sequence_id.padding',
                 'purchase_sequence_id.number_next_actual')
    def _compute_next_number_preview(self):
        for project in self:
            sequence = project.sequence_id.sudo()
            project.next_number_preview = sequence.get_next_char(
                sequence.number_next_actual) if sequence else False
            psequence = project.purchase_sequence_id.sudo()
            project.next_purchase_number_preview = psequence.get_next_char(
                psequence.number_next_actual) if psequence else False

    def _compute_stats(self):
        Line = self.env['idp.supplier.purchase.line'].sudo()
        for project in self:
            requests = project.request_ids.filtered(
                lambda r: r.state not in ('rejected', 'cancel'))
            project.request_count = len(project.request_ids)
            project.amount_estimated = sum(requests.line_ids.filtered(
                lambda l: not l.cancelled).mapped('est_subtotal_company'))
            lines = Line.search([('project_id', '=', project.id), ('cancelled', '=', False),
                                 ('state', '!=', 'cancel')])
            project.purchase_count = len(lines.purchase_id)
            project.amount_ordered = sum(lines.mapped('price_subtotal_company'))

    @api.model
    def _idp_clean_code(self, code):
        return (code or '').strip().upper().rstrip('/')

    @api.model
    def _idp_prefix(self, code):
        return '%s/%%(year)s/' % self._idp_clean_code(code)

    @api.model
    def _idp_sequence_vals(self, code, company_id, name, kind='request'):
        """Sequence values; ``code`` is the request code, or the supplier order code when
        ``kind`` is 'purchase'."""
        if kind == 'purchase':
            return {
                'name': _("Supplier Orders - %s", name or code),
                'implementation': 'no_gap',
                'prefix': self._idp_prefix(code),
                'padding': 4,
                'number_next': 1,
                'number_increment': 1,
                'company_id': company_id,
            }
        return {
            'name': _("Purchase Requests - %s", name or code),
            'implementation': 'no_gap',
            'prefix': self._idp_prefix(code),
            'padding': 4,
            'number_next': 1,
            'number_increment': 1,
            'company_id': company_id,
        }

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('code'):
                vals['code'] = self._idp_clean_code(vals['code'])
            if vals.get('purchase_code'):
                vals['purchase_code'] = self._idp_clean_code(vals['purchase_code'])
            elif vals.get('code'):
                vals['purchase_code'] = '%s/PO' % vals['code']
        projects = super().create(vals_list)
        projects._idp_ensure_sequences()
        return projects

    def write(self, vals):
        if vals.get('code'):
            vals['code'] = self._idp_clean_code(vals['code'])
            for project in self:
                sequence = project.sequence_id.sudo()
                if sequence and sequence.prefix == self._idp_prefix(project.code):
                    sequence.prefix = self._idp_prefix(vals['code'])
                # an order code still following the default "<request code>/PO" follows it
                if 'purchase_code' not in vals and \
                        project.purchase_code == '%s/PO' % (project.code or ''):
                    vals = dict(vals, purchase_code='%s/PO' % vals['code'])
        if 'purchase_code' in vals:
            vals['purchase_code'] = self._idp_clean_code(vals['purchase_code']) or False
        res = super().write(vals)
        if 'purchase_code' in vals:
            for project in self:
                if not project.purchase_code:
                    project.purchase_code = '%s/PO' % project.code
                if project.purchase_sequence_id:
                    project.purchase_sequence_id.sudo().prefix = self._idp_prefix(
                        project.purchase_code)
        if 'name' in vals:
            for project in self:
                if project.sequence_id:
                    project.sequence_id.sudo().name = _("Purchase Requests - %s", project.name)
                if project.purchase_sequence_id:
                    project.purchase_sequence_id.sudo().name = _("Supplier Orders - %s",
                                                                 project.name)
        self._idp_ensure_sequences()
        return res

    def _idp_ensure_sequences(self):
        """Make sure every project has its supplier order code and both sequences."""
        Sequence = self.env['ir.sequence'].sudo()
        for project in self.sudo():
            vals = {}
            if not project.purchase_code and project.code:
                vals['purchase_code'] = '%s/PO' % project.code
            if not project.sequence_id:
                vals['sequence_id'] = Sequence.create(self._idp_sequence_vals(
                    project.code, project.company_id.id, project.name)).id
            if not project.purchase_sequence_id:
                vals['purchase_sequence_id'] = Sequence.create(self._idp_sequence_vals(
                    vals.get('purchase_code') or project.purchase_code, project.company_id.id,
                    project.name, kind='purchase')).id
            if vals:
                super(IdpProject, project).write(vals)
        return True

    @api.model
    def _idp_ensure_all_sequences(self):
        """Upgrade helper: projects created before 1.2.1 get their missing sequences."""
        return self.sudo().with_context(active_test=False).search([])._idp_ensure_sequences()

    @api.ondelete(at_uninstall=False)
    def _unlink_except_used(self):
        for project in self:
            if project.request_ids:
                raise UserError(_(
                    "Project %s has purchase requests and cannot be deleted; archive it instead.",
                    project.display_name))

    def _idp_next_request_number(self, date=None):
        self.ensure_one()
        self._idp_ensure_sequences()
        sequence = self.sequence_id.sudo()
        if date:
            sequence = sequence.with_context(ir_sequence_date=fields.Date.to_string(date))
        return sequence.next_by_id(sequence_date=date)

    def _idp_next_purchase_number(self, date=None):
        self.ensure_one()
        self._idp_ensure_sequences()
        sequence = self.purchase_sequence_id.sudo()
        if date:
            sequence = sequence.with_context(ir_sequence_date=fields.Date.to_string(date))
        return sequence.next_by_id(sequence_date=date)

    def action_view_requests(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id(
            'invest_daily_purchase.action_idp_purchase_request')
        action['domain'] = [('project_id', '=', self.id)]
        action['context'] = {'default_project_id': self.id}
        return action

    def action_view_report(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id(
            'invest_daily_purchase.action_idp_purchase_report')
        action['domain'] = [('project_id', '=', self.id)]
        return action
