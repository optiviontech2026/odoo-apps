import base64
import json
import logging

from odoo import _, api, fields, models
from odoo.exceptions import UserError
from odoo.tools.pdf import PdfFileReader, merge_pdf, to_pdf_stream

_logger = logging.getLogger(__name__)

RECEIPT_REPORTS = {
    'grn': 'invest_daily_purchase.action_report_idp_grn',
    'coc': 'invest_daily_purchase.action_report_idp_coc',
    'acceptance': 'invest_daily_purchase.action_report_idp_acceptance',
}


class IdpPurchaseFileWizard(models.TransientModel):
    """Print the complete file of a supplier purchase as one PDF."""
    _name = 'idp.purchase.file.wizard'
    _description = 'Print Purchase File'

    purchase_id = fields.Many2one('idp.supplier.purchase', required=True)
    company_id = fields.Many2one(related='purchase_id.company_id')
    with_signatures = fields.Boolean(
        string="With Digital Signatures", default=True,
        help="Print the documents with the stored digital signatures. Without it, signature "
             "boxes stay blank for handwritten signatures.")
    include_order = fields.Boolean(string="Supplier Purchase (Order)", default=True)
    include_request = fields.Boolean(string="Purchase Request", default=True)
    include_quotations = fields.Boolean(string="Quotation Comparison", default=True)
    include_quotation_attachments = fields.Boolean(string="Quotation Attachments", default=True)
    include_receipts = fields.Boolean(string="GRN / COC / Acceptance", default=True)
    include_bills = fields.Boolean(string="Vendor Bills", default=True)
    include_bill_attachments = fields.Boolean(string="Vendor Bill Attachments", default=True)
    can_print_bills = fields.Boolean(compute='_compute_can_print_bills')
    contents_json = fields.Text(readonly=True)
    file = fields.Binary(readonly=True, attachment=False)
    filename = fields.Char(readonly=True)

    @api.depends_context('uid')
    def _compute_can_print_bills(self):
        allowed = self._idp_user_can_print_bills()
        for wizard in self:
            wizard.can_print_bills = allowed

    @api.model
    def _idp_user_can_print_bills(self):
        user = self.env.user
        return self.env.su or user.has_group('account.group_account_invoice') \
            or user.has_group('account.group_account_readonly')

    # ---- collection ------------------------------------------------------------------------
    def _idp_report(self, xmlid):
        """Report action xmlid, switched to its 'without signatures' variant when needed."""
        if not self.with_signatures:
            xmlid += '_nosign'
        return xmlid

    def _idp_collect(self):
        """Return ([(section, label, kind, payload)], [skipped notes]).

        kind 'report': payload = (report xmlid, ids); kind 'attachment': payload = attachment.
        """
        self.ensure_one()
        purchase = self.purchase_id
        request = purchase.request_id
        parts, skipped = [], []
        if self.include_order:
            parts.append((_("Supplier Purchase"), purchase.name, 'report', (
                self._idp_report('invest_daily_purchase.action_report_idp_supplier_purchase'),
                purchase.ids)))
        if self.include_request:
            parts.append((_("Purchase Request"), request.name, 'report', (
                self._idp_report('invest_daily_purchase.action_report_idp_purchase_request'),
                request.ids)))
        quotations = request.quotation_ids.filtered(lambda q: q.state == 'active').sorted(
            lambda q: (q.partner_id.name or '', q.id))
        if self.include_quotations and quotations:
            parts.append((_("Quotation Comparison"), request.name, 'report', (
                'invest_daily_purchase.action_report_idp_quotation_comparison', request.ids)))
        if self.include_quotation_attachments:
            for quotation in quotations:
                for attachment in quotation.sudo().attachment_ids:
                    parts.append((_("Quotation Attachment"), "%s - %s" % (
                        quotation.display_name, attachment.name), 'attachment', attachment))
        if self.include_receipts:
            receipts = purchase.receipt_ids.filtered(lambda r: r.state == 'done').sorted(
                lambda r: (r.date, r.id))
            for receipt in receipts:
                parts.append((dict(receipt._fields['receipt_type'].selection)[receipt.receipt_type],
                              receipt.name, 'report', (
                                  self._idp_report(RECEIPT_REPORTS[receipt.receipt_type]),
                                  receipt.ids)))
        if self.include_bills or self.include_bill_attachments:
            bills = purchase.sudo().bill_ids.filtered(lambda m: m.state != 'cancel').sorted('id')
            if bills and not self._idp_user_can_print_bills():
                skipped.append(_("Vendor bills: you need accounting access to print them."))
                bills = bills.browse()
            for bill in bills:
                bill = bill.sudo(False)
                label = bill.name if bill.name and bill.name != '/' else bill.display_name
                if self.include_bills:
                    parts.append((_("Vendor Bill"), label, 'report', (
                        'account.account_invoices', bill.ids)))
                if self.include_bill_attachments:
                    attachments = self.env['ir.attachment'].sudo().search([
                        ('res_model', '=', 'account.move'), ('res_id', '=', bill.id),
                        ('res_field', '=', False)], order='id')
                    for attachment in attachments:
                        parts.append((_("Vendor Bill Attachment"), "%s - %s" % (
                            label, attachment.name), 'attachment', attachment))
        return parts, skipped

    # ---- rendering -------------------------------------------------------------------------
    def _idp_render_part(self, kind, payload):
        """Return PDF bytes or None when the item cannot be converted."""
        if kind == 'report':
            xmlid, ids = payload
            report = self.env.ref(xmlid)
            content, _fmt = self.env['ir.actions.report']._render_qweb_pdf(report, ids)
            return content
        mimetype = payload.mimetype or ''
        if mimetype != 'application/pdf' and not mimetype.startswith('image/'):
            return None
        stream = to_pdf_stream(payload)
        return stream.getvalue() if stream else None

    @api.model
    def _idp_is_valid_pdf(self, content):
        if not content or not content.startswith(b'%PDF'):
            return False
        try:
            import io  # noqa: PLC0415
            return len(PdfFileReader(io.BytesIO(content), strict=False).pages) > 0
        except Exception:  # noqa: BLE001 - any unreadable file is skipped and listed
            return False

    def action_print(self):
        self.ensure_one()
        if self.purchase_id.state == 'cancel':
            raise UserError(_("Supplier purchase %s is cancelled.", self.purchase_id.name))
        parts, skipped = self._idp_collect()
        if not parts:
            raise UserError(_("Select at least one section to print."))
        pdfs, contents = [], []
        for section, label, kind, payload in parts:
            try:
                content = self._idp_render_part(kind, payload)
            except Exception as exc:  # noqa: BLE001 - keep printing the other documents
                _logger.warning("Purchase file: could not render %s %s: %s", section, label, exc)
                content = None
            if not self._idp_is_valid_pdf(content):
                skipped.append(_("%(section)s %(label)s: not a PDF or image, or unreadable - "
                                 "not included.", section=section, label=label))
                continue
            pdfs.append(content)
            contents.append({'section': section, 'label': label})
        if not pdfs:
            raise UserError(_("None of the selected documents could be printed."))
        self.contents_json = json.dumps({'contents': contents, 'skipped': skipped})
        cover, _fmt = self.env['ir.actions.report']._render_qweb_pdf(
            'invest_daily_purchase.action_report_idp_purchase_file_cover', self.ids)
        merged = merge_pdf(([cover] if self._idp_is_valid_pdf(cover) else []) + pdfs)
        filename = "%s - %s%s.pdf" % (
            _("Purchase File"), self.purchase_id.name.replace('/', '-'),
            '' if self.with_signatures else ' (' + _("unsigned") + ')')
        self.write({'file': base64.b64encode(merged), 'filename': filename})
        self.purchase_id.sudo().message_post(body=_("Purchase file printed (%(count)s documents%(sig)s).",
                                             count=len(pdfs),
                                             sig='' if self.with_signatures
                                             else ', ' + _("without signatures")))
        return {
            'type': 'ir.actions.act_url',
            'url': '/web/content/%s/%s/file/%s?download=true' % (self._name, self.id, filename),
            'target': 'self',
        }

    def _idp_cover_data(self):
        self.ensure_one()
        return json.loads(self.contents_json or '{}')
