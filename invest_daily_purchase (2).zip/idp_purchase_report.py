from odoo import fields, models
from odoo.tools.sql import SQL

from .idp_common import BILLING_STATUS, LINE_TYPES, RECEIPT_METHODS, RECEIPT_STATUS
from .idp_purchase_request import PROGRESS_STATES, REQUEST_STATES


class IdpPurchaseReport(models.Model):
    """Purchase analysis by project, vendor, department and status.

    One row per awarded supplier offer (proposed or confirmed); request lines without any
    award yet appear once without a vendor. Amounts are in the company currency, except
    ``amount_currency`` which is in the vendor's quotation currency."""
    _name = 'idp.purchase.report'
    _description = 'Invest and Daily Purchases Report'
    _auto = False
    _rec_name = 'request_name'
    _order = 'date_request desc, request_name desc, id'

    request_id = fields.Many2one('idp.purchase.request', string="Purchase Request", readonly=True)
    request_name = fields.Char(string="Request Number", readonly=True)
    date_request = fields.Date(string="Request Date", readonly=True)
    project_id = fields.Many2one('idp.project', string="Project", readonly=True)
    department_id = fields.Many2one('hr.department', string="Department", readonly=True)
    requester_id = fields.Many2one('res.users', string="Requester", readonly=True)
    company_id = fields.Many2one('res.company', readonly=True)
    company_currency_id = fields.Many2one('res.currency', string="Company Currency",
                                          readonly=True)
    request_state = fields.Selection(REQUEST_STATES, string="Approval Status", readonly=True)
    progress_status = fields.Selection(PROGRESS_STATES, string="Progress", readonly=True)
    receipt_status = fields.Selection(RECEIPT_STATUS, string="Receipt Status", readonly=True)
    billing_status = fields.Selection(BILLING_STATUS, string="Billing Status", readonly=True)
    current_level_id = fields.Many2one('idp.approval.level', string="Pending Level",
                                       readonly=True)
    request_line_id = fields.Many2one('idp.purchase.request.line', string="Request Line",
                                      readonly=True)
    product_id = fields.Many2one('product.product', string="Product", readonly=True)
    description = fields.Char(readonly=True)
    line_type = fields.Selection(LINE_TYPES, string="Type", readonly=True)
    receipt_method = fields.Selection(RECEIPT_METHODS, string="Receiving Document",
                                      readonly=True)
    uom_id = fields.Many2one('uom.uom', string="Unit", readonly=True)
    partner_id = fields.Many2one('res.partner', string="Vendor", readonly=True)
    quotation_line_id = fields.Many2one('idp.quotation.line', string="Supplier Offer",
                                        readonly=True)
    quotation_ref = fields.Char(string="Quotation Ref.", readonly=True)
    purchase_line_id = fields.Many2one('idp.supplier.purchase.line', readonly=True)
    supplier_purchase_id = fields.Many2one('idp.supplier.purchase', string="Supplier Purchase",
                                           readonly=True)
    purchase_state = fields.Selection(
        [('confirmed', 'Confirmed'), ('on_hold', 'On Hold'), ('cancel', 'Cancelled')],
        string="Purchase Status", readonly=True)
    date_confirmed = fields.Date(string="Confirmation Date", readonly=True)
    currency_id = fields.Many2one('res.currency', string="Vendor Currency", readonly=True)
    is_awarded = fields.Boolean(string="Supplier Selected", readonly=True)

    qty_requested = fields.Float(string="Requested Qty", digits='Product Unit', readonly=True,
                                 aggregator='sum')
    qty_ordered = fields.Float(string="Awarded / Ordered Qty", digits='Product Unit',
                               readonly=True, aggregator='sum')
    qty_received = fields.Float(string="Received / Certified Qty", digits='Product Unit',
                                readonly=True, aggregator='sum')
    qty_to_receive = fields.Float(string="Outstanding Qty", digits='Product Unit',
                                  readonly=True, aggregator='sum')
    qty_billed = fields.Float(string="Billed Qty", digits='Product Unit', readonly=True,
                              aggregator='sum')
    qty_to_bill = fields.Float(string="Qty to Bill", digits='Product Unit', readonly=True,
                               aggregator='sum')
    price_unit = fields.Float(string="Unit Price", digits='Product Price', readonly=True,
                              aggregator='avg')
    discount = fields.Float(string="Discount (%)", digits='Discount', readonly=True,
                            aggregator='avg')
    amount_currency = fields.Monetary(string="Untaxed (Vendor Currency)",
                                      currency_field='currency_id', readonly=True,
                                      aggregator=None)
    amount_estimated = fields.Monetary(string="Estimated", currency_field='company_currency_id',
                                       readonly=True, aggregator='sum')
    amount_untaxed = fields.Monetary(string="Untaxed Amount", currency_field='company_currency_id',
                                     readonly=True, aggregator='sum')
    amount_total = fields.Monetary(string="Total Incl. Taxes",
                                   currency_field='company_currency_id', readonly=True,
                                   aggregator='sum')
    amount_variance = fields.Monetary(string="Variance vs Estimate",
                                      currency_field='company_currency_id', readonly=True,
                                      aggregator='sum')
    amount_received = fields.Monetary(string="Received Value",
                                      currency_field='company_currency_id', readonly=True,
                                      aggregator='sum')
    amount_billed = fields.Monetary(string="Billed Amount", currency_field='company_currency_id',
                                    readonly=True, aggregator='sum')
    amount_to_bill = fields.Monetary(string="Amount to Bill",
                                     currency_field='company_currency_id', readonly=True,
                                     aggregator='sum')

    def _search(self, domain, offset=0, limit=None, order=None, **kwargs):
        # The report reads several tables directly in SQL: make pending ORM writes visible.
        self.env.flush_all()
        return super()._search(domain, offset=offset, limit=limit, order=order, **kwargs)

    @property
    def _table_query(self):
        estimated = SQL(
            "CASE WHEN ql.id IS NULL OR COALESCE(rl.quantity, 0) = 0 "
            "THEN COALESCE(rl.est_subtotal_company, 0) "
            "ELSE COALESCE(rl.est_subtotal_company, 0) * ql.awarded_qty / rl.quantity END")
        return SQL("""
            SELECT
                CASE WHEN ql.id IS NULL THEN rl.id * 2 + 1 ELSE ql.id * 2 END AS id,
                r.id AS request_id,
                r.name AS request_name,
                r.date_request AS date_request,
                r.project_id AS project_id,
                r.department_id AS department_id,
                r.requester_id AS requester_id,
                r.company_id AS company_id,
                rc.currency_id AS company_currency_id,
                r.state AS request_state,
                r.progress_status AS progress_status,
                r.receipt_status AS receipt_status,
                r.billing_status AS billing_status,
                r.current_level_id AS current_level_id,
                rl.id AS request_line_id,
                rl.product_id AS product_id,
                rl.name AS description,
                rl.line_type AS line_type,
                rl.receipt_method AS receipt_method,
                rl.uom_id AS uom_id,
                q.partner_id AS partner_id,
                ql.id AS quotation_line_id,
                q.reference AS quotation_ref,
                spl.id AS purchase_line_id,
                sp.id AS supplier_purchase_id,
                sp.state AS purchase_state,
                sp.date_confirmed AS date_confirmed,
                COALESCE(q.currency_id, r.currency_id) AS currency_id,
                (ql.id IS NOT NULL) AS is_awarded,
                CASE WHEN ql.id IS NULL THEN rl.quantity ELSE ql.awarded_qty END AS qty_requested,
                COALESCE(ql.awarded_qty, 0) AS qty_ordered,
                COALESCE(spl.qty_received, 0) AS qty_received,
                COALESCE(spl.qty_to_receive, 0) AS qty_to_receive,
                COALESCE(spl.qty_billed, 0) AS qty_billed,
                COALESCE(spl.qty_to_bill, 0) AS qty_to_bill,
                COALESCE(ql.price_unit, 0) AS price_unit,
                COALESCE(ql.discount, 0) AS discount,
                COALESCE(ql.awarded_subtotal, 0) AS amount_currency,
                %(estimated)s AS amount_estimated,
                COALESCE(ql.awarded_subtotal_company, 0) AS amount_untaxed,
                COALESCE(ql.awarded_total_company, 0) AS amount_total,
                CASE WHEN ql.id IS NULL THEN 0
                     ELSE COALESCE(ql.awarded_subtotal_company, 0) - %(estimated)s END
                    AS amount_variance,
                COALESCE(spl.qty_received * spl.price_net_company, 0) AS amount_received,
                COALESCE(spl.qty_billed * spl.price_net_company, 0) AS amount_billed,
                COALESCE(spl.qty_to_bill * spl.price_net_company, 0) AS amount_to_bill
            FROM idp_purchase_request_line rl
            JOIN idp_purchase_request r ON r.id = rl.request_id
            JOIN res_company rc ON rc.id = r.company_id
            LEFT JOIN idp_quotation_line ql
                   ON ql.request_line_id = rl.id
                  AND ql.awarded_qty > 0
                  AND ql.quotation_state = 'active'
            LEFT JOIN idp_quotation q ON q.id = ql.quotation_id
            LEFT JOIN idp_supplier_purchase_line spl
                   ON spl.quotation_line_id = ql.id AND spl.cancelled IS NOT TRUE
            LEFT JOIN idp_supplier_purchase sp ON sp.id = spl.purchase_id
            WHERE rl.cancelled IS NOT TRUE
        """, estimated=estimated)

    # ---- details used by the Excel / PDF exports (not stored in the view) --------------
    def _idp_export_details(self):
        """Return {report_id: {'approvals', 'documents', 'bills'}} for the export."""
        result = {}
        for row in self:
            request = row.request_id.sudo()
            approvals = request.current_round_approval_ids.filtered(
                lambda a: a.state == 'approved').sorted('position')
            pline = row.purchase_line_id.sudo()
            receipts = pline.receipt_line_ids.filtered(lambda r: r.state == 'done').receipt_id
            bills = pline.receipt_line_ids.invoice_line_ids.move_id.filtered(
                lambda m: m.state != 'cancel')
            result[row.id] = {
                'approvals': ", ".join(
                    "%s: %s (%s)" % (a.name, a.user_id.name or '',
                                     fields.Date.to_string(a.date.date()) if a.date else '')
                    for a in approvals),
                'documents': ", ".join(receipts.mapped('name')),
                'bills': ", ".join(b.name for b in bills if b.name and b.name != '/') or (
                    ", ".join(bills.mapped('display_name'))),
                'purpose': request.purpose or '',
            }
        return result
