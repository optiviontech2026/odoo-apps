from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError

from .idp_common import (
    GROUP_MANAGER, GROUP_PROCUREMENT, LINE_TYPES, RECEIPT_METHODS, check_groups, qty_compare,
    qty_is_zero,
)

# Line fields whose change after approval invalidates every approval level.
LINE_RELEVANT_FIELDS = {
    'product_id', 'line_type', 'requires_coc', 'uom_id', 'quantity', 'est_price_unit',
    'cancelled',
}
# Changes that are impossible once receiving / completion documents exist.
LINE_EXECUTION_FIELDS = {'product_id', 'line_type', 'requires_coc', 'uom_id'}


def _value_differs(record, fname, value):
    field = record._fields[fname]
    current = record[fname]
    if field.type == 'many2one':
        return current.id != (value or False)
    if field.type == 'float':
        return qty_compare(record.env, current, value) != 0
    if field.type in ('many2many', 'one2many'):
        return True
    return (current or False) != (value or False)


class IdpPurchaseRequestLine(models.Model):
    _name = 'idp.purchase.request.line'
    _description = 'Purchase Request Line'
    _inherit = ['analytic.mixin']
    _order = 'request_id, sequence, id'
    _check_company_auto = True

    request_id = fields.Many2one(
        'idp.purchase.request', required=True, ondelete='cascade', index=True)
    sequence = fields.Integer(default=10)
    company_id = fields.Many2one(related='request_id.company_id', store=True, index=True)
    currency_id = fields.Many2one(related='request_id.currency_id', store=True)
    state = fields.Selection(related='request_id.state', string="Request Status")
    department_id = fields.Many2one(related='request_id.department_id', store=True)
    project_id = fields.Many2one(related='request_id.project_id', store=True, index=True)
    company_currency_id = fields.Many2one(related='company_id.currency_id', string="Company Currency")
    requester_id = fields.Many2one(related='request_id.requester_id', store=True)
    name = fields.Char(string="Label / Description", required=True)
    product_id = fields.Many2one(
        'product.product', string="Product / Service", check_company=True,
        domain=[('purchase_ok', '=', True)])
    line_type = fields.Selection(LINE_TYPES, string="Type", required=True, default='goods')
    requires_coc = fields.Boolean(
        string="Requires Certificate of Completion",
        compute='_compute_requires_coc', store=True, readonly=False,
        help="Service lines with this option are accepted through a Certificate of Completion; "
             "other service lines need an authorized service acceptance record.")
    receipt_method = fields.Selection(
        RECEIPT_METHODS, compute='_compute_receipt_method', store=True,
        string="Receiving Document")
    uom_id = fields.Many2one(
        'uom.uom', string="Unit of Measure", required=True,
        default=lambda self: self.env.ref('uom.product_uom_unit', raise_if_not_found=False))
    quantity = fields.Float(string="Requested Qty", digits='Product Unit', default=1.0,
                            required=True)
    est_price_unit = fields.Float(string="Estimated Unit Price", digits='Product Price')
    est_subtotal = fields.Monetary(
        string="Estimated Total", compute='_compute_est_subtotal', store=True)
    est_subtotal_company = fields.Monetary(
        string="Estimated Total (Company Currency)", compute='_compute_est_subtotal',
        store=True, currency_field='company_currency_id')
    account_id = fields.Many2one(
        'account.account', string="Expense Account", check_company=True,
        help="Optional account mapping used on vendor bills. Defaults to the product's "
             "expense account.")
    cancelled = fields.Boolean(
        help="Cancelled lines are kept for history but excluded from totals and awards.")

    quotation_line_ids = fields.One2many(
        'idp.quotation.line', 'request_line_id', string="Supplier Offers")
    offer_count = fields.Integer(compute='_compute_awards', store=True, string="# Offers")
    awarded_qty = fields.Float(
        compute='_compute_awards', store=True, digits='Product Unit', string="Awarded Qty")
    award_status = fields.Selection(
        [('none', 'Not Awarded'), ('partial', 'Partially Awarded'), ('full', 'Fully Awarded'),
         ('over', 'Over-Allocated')], compute='_compute_awards', store=True)
    selected_amount = fields.Monetary(
        string="Selected Supplier Cost", compute='_compute_awards', store=True,
        help="Untaxed awarded amount in the request currency (converted at the quotation date).")
    variance_amount = fields.Monetary(
        string="Variance", compute='_compute_awards', store=True)
    lowest_price = fields.Monetary(
        string="Lowest Comparable Price", compute='_compute_awards', store=True)
    selected_supplier_ids = fields.Many2many(
        'res.partner', compute='_compute_selected_suppliers', string="Selected Suppliers",
        compute_sudo=True)

    purchase_line_ids = fields.One2many(
        'idp.supplier.purchase.line', 'request_line_id', string="Supplier Purchase Lines")
    qty_received = fields.Float(
        compute='_compute_execution', store=True, digits='Product Unit',
        string="Accepted / Certified Qty")
    qty_billed = fields.Float(compute='_compute_execution', store=True, digits='Product Unit')

    @api.depends('line_type')
    def _compute_requires_coc(self):
        for line in self:
            line.requires_coc = line.requires_coc if line.line_type == 'service' else False

    @api.depends('line_type', 'requires_coc')
    def _compute_receipt_method(self):
        for line in self:
            if line.line_type == 'goods':
                line.receipt_method = 'grn'
            elif line.requires_coc:
                line.receipt_method = 'coc'
            else:
                line.receipt_method = 'acceptance'

    @api.depends('quantity', 'est_price_unit', 'currency_id', 'request_id.date_request',
                 'company_id')
    def _compute_est_subtotal(self):
        for line in self:
            amount = line.quantity * line.est_price_unit
            line.est_subtotal = line.currency_id.round(amount) if line.currency_id else amount
            company = line.company_id or self.env.company
            if line.currency_id and line.currency_id != company.currency_id:
                line.est_subtotal_company = line.currency_id._convert(
                    line.est_subtotal, company.currency_id, company,
                    line.request_id.date_request or fields.Date.context_today(line))
            else:
                line.est_subtotal_company = line.est_subtotal

    @api.depends('request_id.project_id')
    def _compute_analytic_distribution(self):
        for line in self:
            account = line.request_id.project_id.analytic_account_id
            if account and not line.analytic_distribution:
                line.analytic_distribution = {str(account.id): 100}

    @api.depends('quotation_line_ids.awarded_qty', 'quotation_line_ids.quotation_state',
                 'quotation_line_ids.comparable_price_unit', 'quotation_line_ids.is_valid',
                 'quotation_line_ids.awarded_amount_request_cur', 'quantity', 'est_subtotal',
                 'cancelled')
    def _compute_awards(self):
        for line in self:
            offers = line.quotation_line_ids.filtered(lambda q: q.quotation_state != 'cancel')
            awarded = offers.filtered(lambda q: not qty_is_zero(self.env, q.awarded_qty))
            line.offer_count = len(offers)
            line.awarded_qty = sum(awarded.mapped('awarded_qty'))
            line.selected_amount = 0.0 if line.cancelled else sum(
                awarded.mapped('awarded_amount_request_cur'))
            line.variance_amount = line.selected_amount - (
                0.0 if line.cancelled else line.est_subtotal)
            valid_prices = offers.filtered('is_valid').mapped('comparable_price_unit')
            line.lowest_price = min(valid_prices) if valid_prices else 0.0
            cmp = qty_compare(self.env, line.awarded_qty, line.quantity)
            if qty_is_zero(self.env, line.awarded_qty):
                line.award_status = 'none'
            elif cmp < 0:
                line.award_status = 'partial'
            elif cmp == 0:
                line.award_status = 'full'
            else:
                line.award_status = 'over'

    @api.depends('quotation_line_ids.awarded_qty', 'quotation_line_ids.quotation_state')
    def _compute_selected_suppliers(self):
        for line in self:
            line.selected_supplier_ids = line.quotation_line_ids.filtered(
                lambda q: q.quotation_state != 'cancel'
                and not qty_is_zero(self.env, q.awarded_qty)).partner_id

    @api.depends('purchase_line_ids.qty_received', 'purchase_line_ids.qty_billed')
    def _compute_execution(self):
        for line in self:
            line.qty_received = sum(line.purchase_line_ids.mapped('qty_received'))
            line.qty_billed = sum(line.purchase_line_ids.mapped('qty_billed'))

    @api.onchange('product_id')
    def _onchange_product_id(self):
        product = self.product_id
        if not product:
            return
        self.name = product.display_name
        self.uom_id = product.uom_id
        self.line_type = 'service' if product.type == 'service' else 'goods'
        if not self.est_price_unit:
            self.est_price_unit = product.uom_id._compute_price(
                product.standard_price, self.uom_id) if self.uom_id else product.standard_price

    @api.constrains('quantity', 'est_price_unit')
    def _check_values(self):
        for line in self:
            if line.quantity < 0:
                raise ValidationError(_("Requested quantity cannot be negative."))
            if line.est_price_unit < 0:
                raise ValidationError(_("Estimated unit price cannot be negative."))

    @api.constrains('awarded_qty', 'quantity', 'cancelled')
    def _check_over_allocation(self):
        for line in self:
            if line.cancelled:
                if not qty_is_zero(self.env, line.awarded_qty):
                    raise ValidationError(_(
                        "Line '%s' is cancelled: remove its awarded quantities first.", line.name))
                continue
            if qty_compare(self.env, line.awarded_qty, line.quantity) > 0:
                raise ValidationError(_(
                    "Line '%(line)s': awarded quantity %(awarded)s exceeds the requested quantity "
                    "%(requested)s.", line=line.name, awarded=line.awarded_qty,
                    requested=line.quantity))

    # -------------------------------------------------------------------------------------
    # ORM: amendment control
    # -------------------------------------------------------------------------------------
    def _idp_check_execution_constraints(self, vals):
        for line in self:
            active_plines = line.purchase_line_ids.filtered(lambda p: not p.cancelled)
            received = sum(active_plines.mapped('qty_received'))
            has_docs = bool(active_plines.receipt_line_ids.filtered(
                lambda r: r.state != 'cancel'))
            if has_docs and LINE_EXECUTION_FIELDS & set(vals) and any(
                    _value_differs(line, f, vals[f]) for f in LINE_EXECUTION_FIELDS & set(vals)):
                raise UserError(_(
                    "Line '%s' already has receiving or completion documents: its product, type, "
                    "unit of measure and certificate requirement can no longer change.", line.name))
            if 'quantity' in vals and qty_compare(self.env, vals['quantity'], received) < 0:
                raise UserError(_(
                    "Line '%(line)s': quantity cannot be reduced below the %(qty)s already "
                    "accepted.", line=line.name, qty=received))
            if vals.get('cancelled') and (has_docs or not qty_is_zero(self.env, received)):
                raise UserError(_(
                    "Line '%s' has receiving or completion documents and cannot be cancelled.",
                    line.name))

    @api.model_create_multi
    def create(self, vals_list):
        to_invalidate = self.env['idp.purchase.request']
        if not self.env.su:
            requests = self.env['idp.purchase.request'].browse(
                [vals['request_id'] for vals in vals_list if vals.get('request_id')])
            requests._idp_check_edit_rights('lines')
            to_invalidate = requests._idp_prepare_invalidation(
                1, _("Request line added after approval"))
        lines = super().create(vals_list)
        if to_invalidate:
            to_invalidate._idp_invalidate_approvals(1, _("Request line added after approval"))
        return lines

    def write(self, vals):
        if self.env.su:
            return super().write(vals)
        if 'request_id' in vals and any(line.request_id.id != vals['request_id'] for line in self):
            raise UserError(_("Request lines cannot be moved to another request."))
        self.request_id._idp_check_edit_rights('lines')
        relevant = LINE_RELEVANT_FIELDS & set(vals)
        to_invalidate = self.env['idp.purchase.request']
        reason = False
        if relevant:
            changed = self.filtered(lambda line: any(
                _value_differs(line, fname, vals[fname]) for fname in relevant))
            if changed:
                changed._idp_check_execution_constraints(vals)
                reason = _("Request line changed after approval (%s)",
                           ", ".join(sorted(changed._fields[f].string for f in relevant)))
                to_invalidate = changed.request_id._idp_prepare_invalidation(1, reason)
        res = super().write(vals)
        if to_invalidate:
            to_invalidate._idp_invalidate_approvals(1, reason)
        return res

    @api.ondelete(at_uninstall=False)
    def _unlink_except_used(self):
        for line in self:
            if line.request_id.state == 'draft':
                continue
            check_groups(self.env, _("Only procurement officers can remove lines from a "
                                     "submitted request."), GROUP_PROCUREMENT, GROUP_MANAGER)
            if line.purchase_line_ids or line.quotation_line_ids.filtered(
                    lambda q: not qty_is_zero(self.env, q.awarded_qty)):
                raise UserError(_(
                    "Line '%s' has awarded offers or supplier purchases. Mark it as cancelled "
                    "instead of deleting it.", line.name))

    def unlink(self):
        to_invalidate = self.env['idp.purchase.request']
        if not self.env.su:
            self.request_id._idp_check_edit_rights('lines')
            to_invalidate = self.request_id._idp_prepare_invalidation(
                1, _("Request line removed after approval"))
        res = super().unlink()
        if to_invalidate:
            to_invalidate._idp_invalidate_approvals(1, _("Request line removed after approval"))
        return res
