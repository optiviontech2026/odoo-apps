from odoo import Command, _, api, fields, models
from odoo.exceptions import UserError, ValidationError

from .idp_common import qty_compare, qty_is_zero

# Offer fields whose change after second-level approval requires re-approval.
OFFER_LINE_RELEVANT = {
    'request_line_id', 'product_qty', 'price_unit', 'discount', 'tax_ids', 'awarded_qty',
    'justification',
}
QUOTATION_RELEVANT = {
    'partner_id', 'currency_id', 'attachment_ids', 'state', 'date', 'validity_date',
}


def _differs(record, fname, value):
    field = record._fields[fname]
    current = record[fname]
    if field.type == 'many2one':
        return current.id != (value or False)
    if field.type == 'float':
        return abs((current or 0.0) - (value or 0.0)) > 1e-9
    if field.type in ('many2many', 'one2many'):
        return True
    return (current or False) != (value or False)


class IdpQuotation(models.Model):
    """Supplier quotation document. One quotation (and its attachment) can cover several
    request lines through its offer lines."""
    _name = 'idp.quotation'
    _description = 'Supplier Quotation'
    _inherit = ['mail.thread']
    _order = 'request_id, date desc, id desc'
    _rec_name = 'reference'
    _check_company_auto = True

    request_id = fields.Many2one(
        'idp.purchase.request', required=True, ondelete='cascade', index=True, tracking=True)
    company_id = fields.Many2one(related='request_id.company_id', store=True, index=True)
    project_id = fields.Many2one(related='request_id.project_id', store=True, index=True)
    request_state = fields.Selection(related='request_id.state', string="Request Status")
    partner_id = fields.Many2one(
        'res.partner', string="Supplier", required=True, tracking=True, check_company=True)
    reference = fields.Char(string="Supplier Quotation Ref.", required=True, tracking=True)
    date = fields.Date(string="Quotation Date", required=True,
                       default=fields.Date.context_today, tracking=True)
    validity_date = fields.Date(
        string="Valid Until", tracking=True,
        help="Offers past their validity date do not count as valid offers.")
    currency_id = fields.Many2one(
        'res.currency', required=True, tracking=True,
        default=lambda self: self._default_currency())
    attachment_ids = fields.Many2many(
        'ir.attachment', 'idp_quotation_attachment_rel', 'quotation_id', 'attachment_id',
        string="Quotation Attachments")
    attachment_count = fields.Integer(
        string="# Quotation Attachments", compute='_compute_attachment_count', store=True)
    line_ids = fields.One2many('idp.quotation.line', 'quotation_id', string="Offer Lines")
    state = fields.Selection(
        [('active', 'Valid'), ('cancel', 'Withdrawn')], default='active', required=True,
        tracking=True)
    notes = fields.Text()
    amount_untaxed = fields.Monetary(compute='_compute_amounts', store=True)
    amount_total = fields.Monetary(compute='_compute_amounts', store=True)

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        request = self.env['idp.purchase.request'].browse(
            res.get('request_id') or self.env.context.get('default_request_id'))
        if request and 'line_ids' in fields_list and not res.get('line_ids'):
            res['line_ids'] = [Command.create({
                'request_line_id': line.id,
                'product_qty': line.quantity,
            }) for line in request.line_ids.filtered(lambda l: not l.cancelled)]
        return res

    def _default_currency(self):
        request = self.env['idp.purchase.request'].browse(
            self.env.context.get('default_request_id'))
        return request.currency_id or self.env.company.currency_id

    @api.depends('partner_id', 'reference')
    def _compute_display_name(self):
        for quotation in self:
            quotation.display_name = " / ".join(
                filter(None, [quotation.partner_id.display_name, quotation.reference]))

    @api.depends('attachment_ids')
    def _compute_attachment_count(self):
        for quotation in self:
            quotation.attachment_count = len(quotation.attachment_ids)

    @api.depends('line_ids.price_subtotal', 'line_ids.price_total')
    def _compute_amounts(self):
        for quotation in self:
            quotation.amount_untaxed = sum(quotation.line_ids.mapped('price_subtotal'))
            quotation.amount_total = sum(quotation.line_ids.mapped('price_total'))

    def action_add_request_lines(self):
        """Add an offer line for every active request line not yet quoted."""
        for quotation in self:
            quoted = quotation.line_ids.request_line_id
            missing = quotation.request_id.line_ids.filtered(
                lambda line: not line.cancelled and line not in quoted)
            quotation.write({'line_ids': [Command.create({
                'request_line_id': line.id,
                'product_qty': line.quantity,
                'price_unit': 0.0,
                'tax_ids': [Command.set(line.product_id.supplier_taxes_id.filtered(
                    lambda t: t.company_id == quotation.company_id).ids)],
            }) for line in missing]})
        return True

    # ---- amendment control --------------------------------------------------------------
    @api.model_create_multi
    def create(self, vals_list):
        to_invalidate = self.env['idp.purchase.request']
        if not self.env.su:
            requests = self.env['idp.purchase.request'].browse(
                [v['request_id'] for v in vals_list if v.get('request_id')])
            requests._idp_check_edit_rights('offers')
            to_invalidate = requests._idp_prepare_invalidation(
                2, _("Supplier quotation added after approval"))
        records = super().create(vals_list)
        if to_invalidate:
            to_invalidate._idp_invalidate_approvals(
                2, _("Supplier quotation added after approval"))
        return records

    def write(self, vals):
        if self.env.su:
            return super().write(vals)
        if 'request_id' in vals and any(q.request_id.id != vals['request_id'] for q in self):
            raise UserError(_("A quotation cannot be moved to another request."))
        self.request_id._idp_check_edit_rights('offers')
        relevant = QUOTATION_RELEVANT & set(vals)
        to_invalidate = self.env['idp.purchase.request']
        reason = False
        if relevant:
            changed = self.filtered(lambda q: any(_differs(q, f, vals[f]) for f in relevant))
            if changed:
                if {'partner_id', 'currency_id'} & set(vals):
                    executed = changed.line_ids.purchase_line_ids.filtered(
                        lambda p: not p.cancelled and p.receipt_line_ids.filtered(
                            lambda r: r.state != 'cancel'))
                    if executed:
                        raise UserError(_(
                            "Supplier or currency cannot change: receiving documents already "
                            "exist for this quotation."))
                if vals.get('state') == 'cancel' and changed.line_ids.filtered(
                        lambda q: not qty_is_zero(self.env, q.awarded_qty)):
                    raise UserError(_(
                        "Remove the awarded quantities before withdrawing a quotation."))
                reason = _("Supplier quotation changed after approval (%s)",
                           ", ".join(sorted(self._fields[f].string for f in relevant)))
                to_invalidate = changed.request_id._idp_prepare_invalidation(2, reason)
        res = super().write(vals)
        if to_invalidate:
            to_invalidate._idp_invalidate_approvals(2, reason)
        return res

    @api.ondelete(at_uninstall=False)
    def _unlink_except_used(self):
        for quotation in self:
            if quotation.line_ids.purchase_line_ids or quotation.line_ids.filtered(
                    lambda q: not qty_is_zero(self.env, q.awarded_qty)):
                raise UserError(_(
                    "Quotation %s has awarded offers or supplier purchases; withdraw it instead.",
                    quotation.display_name))

    def unlink(self):
        if not self.env.su:
            self.request_id._idp_check_edit_rights('offers')
        return super().unlink()


class IdpQuotationLine(models.Model):
    """A supplier's offer for one purchase request line."""
    _name = 'idp.quotation.line'
    _description = 'Supplier Offer Line'
    _order = 'request_line_id, comparable_price_unit, id'
    _check_company_auto = True

    quotation_id = fields.Many2one(
        'idp.quotation', required=True, ondelete='cascade', index=True)
    request_id = fields.Many2one(
        related='quotation_id.request_id', store=True, index=True)
    request_line_id = fields.Many2one(
        'idp.purchase.request.line', string="Request Line", required=True, ondelete='cascade',
        index=True, domain="[('request_id', '=', request_id), ('cancelled', '=', False)]")
    partner_id = fields.Many2one(related='quotation_id.partner_id', store=True, string="Supplier")
    currency_id = fields.Many2one(related='quotation_id.currency_id', store=True)
    company_id = fields.Many2one(related='quotation_id.company_id', store=True)
    project_id = fields.Many2one(related='quotation_id.project_id', store=True)
    company_currency_id = fields.Many2one(related='company_id.currency_id', string="Company Currency")
    quotation_ref = fields.Char(related='quotation_id.reference', string="Quotation Ref.")
    quotation_date = fields.Date(related='quotation_id.date', store=True)
    quotation_state = fields.Selection(related='quotation_id.state', store=True)
    request_currency_id = fields.Many2one(
        related='request_id.currency_id', string="Request Currency")
    request_state = fields.Selection(related='request_id.state')
    name = fields.Char(related='request_line_id.name', string="Description")
    product_id = fields.Many2one(related='request_line_id.product_id')
    uom_id = fields.Many2one(related='request_line_id.uom_id')
    requested_qty = fields.Float(related='request_line_id.quantity', string="Requested Qty")

    product_qty = fields.Float(string="Quoted Qty", digits='Product Unit', required=True,
                               default=1.0)
    price_unit = fields.Float(string="Unit Price", digits='Product Price')
    discount = fields.Float(string="Discount (%)", digits='Discount')
    tax_ids = fields.Many2many(
        'account.tax', 'idp_quotation_line_tax_rel', 'line_id', 'tax_id', string="Taxes",
        domain="[('type_tax_use', '=', 'purchase'), ('company_id', 'parent_of', company_id)]")
    price_subtotal = fields.Monetary(compute='_compute_prices', store=True, string="Subtotal")
    price_tax = fields.Monetary(compute='_compute_prices', store=True, string="Tax")
    price_total = fields.Monetary(compute='_compute_prices', store=True, string="Quotation Total")
    delivery_date = fields.Date()
    lead_time_days = fields.Integer(string="Lead Time (days)")
    has_attachment = fields.Boolean(
        compute='_compute_has_attachment', store=True, string="Attached")

    awarded_qty = fields.Float(string="Awarded Qty", digits='Product Unit', default=0.0)
    awarded_subtotal = fields.Monetary(compute='_compute_prices', store=True)
    awarded_total = fields.Monetary(compute='_compute_prices', store=True)
    comparable_price_unit = fields.Monetary(
        string="Comparable Unit Price", compute='_compute_comparable', store=True,
        currency_field='request_currency_id',
        help="Unit price net of discount, excluding taxes, in the request currency "
             "(converted at the quotation date).")
    awarded_subtotal_company = fields.Monetary(
        string="Awarded Untaxed (Company Currency)", compute='_compute_comparable', store=True,
        currency_field='company_currency_id')
    awarded_total_company = fields.Monetary(
        string="Awarded Total (Company Currency)", compute='_compute_comparable', store=True,
        currency_field='company_currency_id')
    awarded_amount_request_cur = fields.Monetary(
        string="Awarded Amount (Request Currency)", compute='_compute_comparable', store=True,
        currency_field='request_currency_id')
    is_valid = fields.Boolean(compute='_compute_is_valid', store=True, string="Valid Offer")
    is_lowest = fields.Boolean(compute='_compute_lowest', store=True, string="Lowest Price")
    needs_justification = fields.Boolean(compute='_compute_lowest', store=True)
    justification = fields.Text(string="Justification (higher price)")
    selection_remarks = fields.Text()
    selection_state = fields.Selection(
        [('not_selected', 'Not Selected'), ('proposed', 'Proposed'),
         ('confirmed', 'Confirmed'), ('cancel', 'Withdrawn')],
        compute='_compute_selection_state', store=True)
    purchase_line_ids = fields.One2many(
        'idp.supplier.purchase.line', 'quotation_line_id', string="Supplier Purchase Lines")

    @api.depends('price_unit', 'discount', 'tax_ids', 'product_qty', 'awarded_qty',
                 'currency_id', 'partner_id')
    def _compute_prices(self):
        for line in self:
            net = line.price_unit * (1.0 - (line.discount or 0.0) / 100.0)
            for prefix, qty in (('price', line.product_qty), ('awarded', line.awarded_qty)):
                if line.tax_ids and line.currency_id:
                    res = line.tax_ids.compute_all(
                        net, currency=line.currency_id, quantity=qty,
                        product=line.product_id, partner=line.partner_id)
                    untaxed, total = res['total_excluded'], res['total_included']
                else:
                    untaxed = total = (line.currency_id.round(net * qty)
                                       if line.currency_id else net * qty)
                if prefix == 'price':
                    line.price_subtotal = untaxed
                    line.price_total = total
                    line.price_tax = total - untaxed
                else:
                    line.awarded_subtotal = untaxed
                    line.awarded_total = total

    @api.depends('quotation_id.attachment_ids')
    def _compute_has_attachment(self):
        for line in self:
            line.has_attachment = bool(line.quotation_id.attachment_ids)

    @api.depends('price_unit', 'discount', 'currency_id', 'request_id.currency_id',
                 'quotation_id.date', 'awarded_subtotal', 'awarded_total', 'company_id')
    def _compute_comparable(self):
        for line in self:
            target = line.request_id.currency_id
            net = line.price_unit * (1.0 - (line.discount or 0.0) / 100.0)
            date = line.quotation_id.date or fields.Date.context_today(line)
            company = line.company_id or self.env.company
            if line.currency_id:
                line.awarded_subtotal_company = line.currency_id._convert(
                    line.awarded_subtotal, company.currency_id, company, date)
                line.awarded_total_company = line.currency_id._convert(
                    line.awarded_total, company.currency_id, company, date)
            else:
                line.awarded_subtotal_company = line.awarded_subtotal
                line.awarded_total_company = line.awarded_total
            if not target or not line.currency_id:
                line.comparable_price_unit = net
                line.awarded_amount_request_cur = line.awarded_subtotal
                continue
            line.comparable_price_unit = line.currency_id._convert(
                net, target, company, date, round=False)
            line.awarded_amount_request_cur = line.currency_id._convert(
                line.awarded_subtotal, target, company, date)

    @api.depends('quotation_id.state', 'quotation_id.validity_date', 'price_unit', 'product_qty')
    def _compute_is_valid(self):
        today = fields.Date.context_today(self)
        for line in self:
            line.is_valid = line._idp_is_valid_offer(today)

    @api.depends('request_line_id.quotation_line_ids.comparable_price_unit',
                 'request_line_id.quotation_line_ids.is_valid', 'awarded_qty')
    def _compute_lowest(self):
        for line in self:
            siblings = line.request_line_id.quotation_line_ids.filtered('is_valid')
            prices = siblings.mapped('comparable_price_unit')
            lowest = min(prices) if prices else 0.0
            currency = line.request_id.currency_id
            precision = (currency.decimal_places + 2) if currency else 4
            is_lowest = bool(prices) and line.is_valid and round(
                line.comparable_price_unit - lowest, precision) <= 0
            line.is_lowest = is_lowest
            line.needs_justification = (
                not qty_is_zero(self.env, line.awarded_qty) and bool(prices) and not is_lowest)

    @api.depends('awarded_qty', 'quotation_id.state', 'request_id.state', 'purchase_line_ids')
    def _compute_selection_state(self):
        for line in self:
            if line.quotation_id.state == 'cancel':
                line.selection_state = 'cancel'
            elif qty_is_zero(self.env, line.awarded_qty):
                line.selection_state = 'not_selected'
            elif line.request_id.state == 'approved' and line.purchase_line_ids.filtered(
                    lambda p: not p.cancelled):
                line.selection_state = 'confirmed'
            else:
                line.selection_state = 'proposed'

    def _idp_is_valid_offer(self, date=None):
        self.ensure_one()
        date = date or fields.Date.context_today(self)
        quotation = self.quotation_id
        return bool(
            quotation.state == 'active'
            and self.price_unit > 0
            and self.product_qty > 0
            and (not quotation.validity_date or quotation.validity_date >= date))

    def _idp_is_awarded(self):
        self.ensure_one()
        return bool(
            not qty_is_zero(self.env, self.awarded_qty)
            and self.quotation_id.state == 'active'
            and not self.request_line_id.cancelled)

    def _idp_prepare_purchase_line_vals(self):
        self.ensure_one()
        rline = self.request_line_id
        return {
            'request_line_id': rline.id,
            'name': rline.name,
            'product_id': rline.product_id.id,
            'line_type': rline.line_type,
            'requires_coc': rline.requires_coc,
            'uom_id': rline.uom_id.id,
            'product_qty': self.awarded_qty,
            'price_unit': self.price_unit,
            'discount': self.discount,
            'tax_ids': [Command.set(self.tax_ids.ids)],
            'account_id': rline.account_id.id,
            'analytic_distribution': rline.analytic_distribution,
        }

    @api.constrains('awarded_qty', 'product_qty', 'price_unit', 'discount')
    def _check_values(self):
        for line in self:
            if line.awarded_qty < 0 or line.product_qty < 0 or line.price_unit < 0:
                raise ValidationError(_("Quantities and prices cannot be negative."))
            if not 0.0 <= line.discount <= 100.0:
                raise ValidationError(_("The discount must be between 0 and 100%."))
            if qty_compare(self.env, line.awarded_qty, line.product_qty) > 0:
                raise ValidationError(_(
                    "%(supplier)s / '%(line)s': the awarded quantity cannot exceed the quoted "
                    "quantity.", supplier=line.partner_id.display_name,
                    line=line.request_line_id.name))
            active_plines = line.purchase_line_ids.filtered(lambda p: not p.cancelled)
            received = sum(active_plines.mapped('qty_received'))
            if active_plines and qty_compare(self.env, line.awarded_qty, received) < 0:
                raise ValidationError(_(
                    "%(supplier)s / '%(line)s': the awarded quantity cannot be reduced below the "
                    "%(qty)s already received or certified.",
                    supplier=line.partner_id.display_name, line=line.request_line_id.name,
                    qty=received))

    @api.constrains('request_line_id', 'quotation_id')
    def _check_request_line(self):
        for line in self:
            if line.request_line_id.request_id != line.quotation_id.request_id:
                raise ValidationError(_(
                    "An offer line must refer to a line of the quotation's purchase request."))

    # ---- amendment control --------------------------------------------------------------
    @api.model_create_multi
    def create(self, vals_list):
        to_invalidate = self.env['idp.purchase.request']
        if not self.env.su:
            quotations = self.env['idp.quotation'].browse(
                [v['quotation_id'] for v in vals_list if v.get('quotation_id')])
            quotations.request_id._idp_check_edit_rights('offers')
            to_invalidate = quotations.request_id._idp_prepare_invalidation(
                2, _("Supplier offer added after approval"))
        records = super().create(vals_list)
        if to_invalidate:
            to_invalidate._idp_invalidate_approvals(2, _("Supplier offer added after approval"))
        return records

    def write(self, vals):
        if self.env.su:
            return super().write(vals)
        if 'quotation_id' in vals and any(q.quotation_id.id != vals['quotation_id'] for q in self):
            raise UserError(_("An offer line cannot be moved to another quotation."))
        self.request_id._idp_check_edit_rights('offers')
        relevant = OFFER_LINE_RELEVANT & set(vals)
        to_invalidate = self.env['idp.purchase.request']
        reason = False
        if relevant:
            changed = self.filtered(lambda q: any(_differs(q, f, vals[f]) for f in relevant))
            if changed:
                reason = _("Supplier offer changed after approval (%s)",
                           ", ".join(sorted(self._fields[f].string for f in relevant)))
                to_invalidate = changed.request_id._idp_prepare_invalidation(2, reason)
        res = super().write(vals)
        if to_invalidate:
            to_invalidate._idp_invalidate_approvals(2, reason)
        return res

    @api.ondelete(at_uninstall=False)
    def _unlink_except_used(self):
        for line in self:
            if line.purchase_line_ids or not qty_is_zero(self.env, line.awarded_qty):
                raise UserError(_(
                    "Offer of %s is awarded or used by a supplier purchase and cannot be deleted.",
                    line.partner_id.display_name))

    def unlink(self):
        to_invalidate = self.env['idp.purchase.request']
        if not self.env.su:
            self.request_id._idp_check_edit_rights('offers')
            to_invalidate = self.request_id._idp_prepare_invalidation(
                2, _("Supplier offer removed after approval"))
        res = super().unlink()
        if to_invalidate:
            to_invalidate._idp_invalidate_approvals(2, _("Supplier offer removed after approval"))
        return res

    # ---- selection helpers --------------------------------------------------------------
    def action_award_remaining(self):
        """Award this offer the quantity of its request line not yet awarded elsewhere."""
        for line in self:
            others = line.request_line_id.quotation_line_ids.filtered(
                lambda q: q != line and q.quotation_state == 'active')
            remaining = line.request_line_id.quantity - sum(others.mapped('awarded_qty'))
            line.awarded_qty = max(min(remaining, line.product_qty), 0.0)
        return True

    def action_unaward(self):
        self.write({'awarded_qty': 0.0})
        return True
