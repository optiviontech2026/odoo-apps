from odoo import Command, _, api, fields, models
from odoo.exceptions import AccessError, UserError, ValidationError

from .idp_common import (
    GROUP_MANAGER, GROUP_RECEIVER, GROUP_VERIFIER, check_groups, qty_compare, qty_is_zero,
    strip_default_protected,
)

RECEIPT_TYPES = [
    ('grn', 'Goods Received Note'),
    ('coc', 'Certificate of Completion'),
    ('acceptance', 'Service Acceptance'),
]
RECEIPT_STATES = [
    ('draft', 'Draft'),
    ('verified', 'Verified'),
    ('done', 'Confirmed'),
    ('cancel', 'Cancelled'),
]
PROTECTED = {'state', 'verified_by_id', 'verified_date', 'approved_by_id', 'approved_date',
             'cancel_reason', 'picking_ids', 'name', 'verified_signature', 'approved_signature',
             'backorder_of_id'}
ALWAYS_WRITABLE = {'message_main_attachment_id', 'activity_ids'}


class IdpReceipt(models.Model):
    """Receiving / completion document: Goods Received Note (GRN), Certificate of Completion
    (COC) or service acceptance. Each type has its own numbering sequence."""
    _name = 'idp.receipt'
    _description = 'Goods Receipt / Service Completion'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'idp.signature.mixin']
    _order = 'date desc, id desc'
    _check_company_auto = True

    name = fields.Char(string="Number", readonly=True, copy=False, default='/', index='trigram')
    receipt_type = fields.Selection(RECEIPT_TYPES, required=True, readonly=True, index=True,
                                    default=lambda self: self.env.context.get(
                                        'default_receipt_type', 'grn'))
    purchase_id = fields.Many2one(
        'idp.supplier.purchase', string="Supplier Purchase", required=True, index=True,
        check_company=True, domain="[('state', '=', 'confirmed')]", tracking=True)
    partner_id = fields.Many2one(related='purchase_id.partner_id', store=True, string="Supplier")
    request_id = fields.Many2one(related='purchase_id.request_id', store=True, index=True,
                                 string="Purchase Request")
    project_id = fields.Many2one(related='purchase_id.project_id', store=True, index=True)
    company_id = fields.Many2one(related='purchase_id.company_id', store=True, index=True)
    currency_id = fields.Many2one(related='purchase_id.currency_id')
    date = fields.Date(required=True, default=fields.Date.context_today, tracking=True,
                       string="Date")
    date_from = fields.Date(string="Service Period From")
    date_to = fields.Date(string="Service Period To")
    service_description = fields.Text()
    location_id = fields.Many2one(
        'stock.location', string="Receiving Location", check_company=True,
        domain="[('usage', '=', 'internal')]", default=lambda self: self._default_location())
    user_id = fields.Many2one(
        'res.users', string="Received / Accepted By", default=lambda self: self.env.user,
        readonly=True)
    verified_by_id = fields.Many2one('res.users', string="Verified By", readonly=True)
    verified_date = fields.Datetime(readonly=True)
    approved_by_id = fields.Many2one('res.users', string="Approved By", readonly=True)
    approved_date = fields.Datetime(readonly=True)
    verified_signature = fields.Binary(string="Verifier Signature", attachment=True,
                                       readonly=True, copy=False)
    approved_signature = fields.Binary(string="Confirmation Signature", attachment=True,
                                       readonly=True, copy=False)
    backorder_of_id = fields.Many2one('idp.receipt', string="Backorder Of", readonly=True,
                                      copy=False, index='btree_not_null')
    backorder_ids = fields.One2many('idp.receipt', 'backorder_of_id', string="Backorders")
    state = fields.Selection(RECEIPT_STATES, default='draft', required=True, tracking=True,
                             index=True, copy=False)
    line_ids = fields.One2many('idp.receipt.line', 'receipt_id', string="Lines", copy=True)
    remarks = fields.Text()
    attachment_ids = fields.Many2many(
        'ir.attachment', 'idp_receipt_attachment_rel', 'receipt_id', 'attachment_id',
        string="Attachments / Supporting Evidence")
    cancel_reason = fields.Text(readonly=True, copy=False)
    picking_ids = fields.Many2many(
        'stock.picking', 'idp_receipt_picking_rel', 'receipt_id', 'picking_id',
        string="Inventory Transfers", readonly=True, copy=False, groups='stock.group_stock_user')
    has_pickings = fields.Boolean(compute='_compute_has_pickings')
    amount_accepted = fields.Monetary(compute='_compute_amounts', string="Accepted Value")
    bill_ids = fields.Many2many(
        'account.move', compute='_compute_bills', string="Vendor Bills", compute_sudo=True)
    bill_count = fields.Integer(compute='_compute_bills', compute_sudo=True)

    def _default_location(self):
        warehouse = self.env['stock.warehouse'].search(
            [('company_id', '=', self.env.company.id)], limit=1)
        return warehouse.lot_stock_id

    @api.depends('line_ids.accepted_value')
    def _compute_amounts(self):
        for receipt in self:
            receipt.amount_accepted = sum(receipt.line_ids.mapped('accepted_value'))

    def _compute_bills(self):
        for receipt in self:
            receipt.bill_ids = receipt.line_ids.invoice_line_ids.move_id
            receipt.bill_count = len(receipt.bill_ids)

    def _compute_has_pickings(self):
        for receipt in self:
            receipt.has_pickings = bool(receipt.sudo().picking_ids)

    # ---- rights -----------------------------------------------------------------------------
    def _idp_check_rights(self):
        for receipt in self:
            if receipt.receipt_type == 'grn':
                check_groups(self.env, _("Only goods receivers can process Goods Received Notes."),
                             GROUP_RECEIVER, GROUP_MANAGER)
            else:
                check_groups(self.env, _(
                    "Only service completion verifiers can process certificates of completion "
                    "and service acceptances."), GROUP_VERIFIER, GROUP_MANAGER)

    # ---- ORM ----------------------------------------------------------------------------------
    @api.model_create_multi
    def create(self, vals_list):
        if not self.env.su:
            for vals in vals_list:
                if vals.get('name') == '/':
                    vals.pop('name')
                forbidden = strip_default_protected(vals, PROTECTED)
                if forbidden:
                    raise AccessError(_("Workflow fields cannot be set directly."))
        for vals in vals_list:
            vals.setdefault('receipt_type', self.env.context.get('default_receipt_type', 'grn'))
            if vals['receipt_type'] == 'grn' and not vals.get('location_id'):
                purchase = self.env['idp.supplier.purchase'].browse(vals.get('purchase_id'))
                if purchase.project_id.location_id:
                    vals['location_id'] = purchase.project_id.location_id.id
        records = super().create(vals_list)
        for receipt in records:
            receipt._idp_check_rights()
            receipt.purchase_id._idp_check_executable()
            receipt.sudo().name = receipt.company_id._idp_next_number(
                receipt.receipt_type, receipt.date)
            if not receipt.line_ids:
                receipt._idp_load_lines()
        return records

    def write(self, vals):
        if not self.env.su:
            forbidden = PROTECTED.intersection(vals)
            if forbidden:
                raise AccessError(_(
                    "Workflow fields cannot be changed directly; use the document actions."))
            if 'receipt_type' in vals and any(r.receipt_type != vals['receipt_type']
                                              for r in self):
                raise UserError(_("The document type cannot be changed."))
            if set(vals) - ALWAYS_WRITABLE:
                for receipt in self:
                    if receipt.state != 'draft':
                        raise UserError(_(
                            "%s is no longer a draft and cannot be modified.", receipt.name))
                self._idp_check_rights()
        return super().write(vals)

    @api.ondelete(at_uninstall=False)
    def _unlink_except_confirmed(self):
        for receipt in self:
            if receipt.state != 'draft':
                raise UserError(_(
                    "%s has been processed and cannot be deleted; cancel it with a reason.",
                    receipt.name))

    @api.onchange('purchase_id')
    def _onchange_purchase_id(self):
        if self.receipt_type == 'grn' and self.purchase_id.project_id.location_id:
            self.location_id = self.purchase_id.project_id.location_id
        if self.purchase_id and self.state == 'draft':
            self.line_ids = [Command.clear()] + [
                Command.create(vals) for vals in self._idp_prepare_line_vals()]

    def _idp_prepare_line_vals(self):
        self.ensure_one()
        vals_list = []
        for pline in self.purchase_id.line_ids.filtered(
                lambda l: not l.cancelled and l.receipt_method == self.receipt_type
                and qty_compare(self.env, l.qty_to_receive, 0.0) > 0):
            vals_list.append({
                'purchase_line_id': pline.id,
                'qty_received': pline.qty_to_receive,
            })
        return vals_list

    def _idp_load_lines(self):
        for receipt in self:
            vals_list = receipt._idp_prepare_line_vals()
            if vals_list:
                receipt.with_context(idp_loading=True).write(
                    {'line_ids': [Command.create(v) for v in vals_list]})

    def action_load_remaining(self):
        for receipt in self:
            if receipt.state != 'draft':
                raise UserError(_("Only draft documents can be reloaded."))
            receipt.line_ids.unlink()
            receipt._idp_load_lines()
        return True

    # ---- checks -----------------------------------------------------------------------------
    def _idp_check_quantities(self):
        env = self.env
        for receipt in self:
            receipt.purchase_id._idp_check_executable()
            if receipt.receipt_type == 'grn' and not receipt.location_id:
                raise UserError(_("Set the receiving location of %s.", receipt.name))
            if receipt.receipt_type == 'coc' and receipt.date_from and receipt.date_to \
                    and receipt.date_from > receipt.date_to:
                raise UserError(_("The service period end must follow its start."))
            positive = receipt.line_ids.filtered(
                lambda l: qty_compare(env, l.qty_received, 0.0) > 0)
            if not positive:
                raise UserError(_("%s has no quantity to confirm.", receipt.name))
            per_pline = {}
            for line in receipt.line_ids:
                pline = line.purchase_line_id
                if pline.purchase_id != receipt.purchase_id:
                    raise UserError(_("All lines must belong to supplier purchase %s.",
                                      receipt.purchase_id.name))
                if pline.cancelled:
                    raise UserError(_("Line '%s' was cancelled by an amendment.", pline.name))
                if pline.receipt_method != receipt.receipt_type:
                    raise UserError(_(
                        "Line '%(line)s' must be processed through a %(doc)s.", line=pline.name,
                        doc=dict(RECEIPT_TYPES)[pline.receipt_method]))
                if line.qty_received < 0 or line.qty_rejected < 0:
                    raise UserError(_("Quantities cannot be negative."))
                if qty_compare(env, line.qty_rejected, line.qty_received) > 0:
                    raise UserError(_("Line '%s': rejected quantity exceeds the received quantity.",
                                      pline.name))
                per_pline[pline] = per_pline.get(pline, 0.0) + line.qty_accepted
            for pline, accepted_now in per_pline.items():
                previous = sum(pline.receipt_line_ids.filtered(
                    lambda r: r.state == 'done' and r.receipt_id != receipt).mapped('qty_accepted'))
                open_qty = pline.product_qty - pline.qty_closed
                if qty_compare(env, previous + accepted_now, open_qty) > 0:
                    raise UserError(_(
                        "Line '%(line)s': accepting %(now)s would exceed the approved open "
                        "quantity %(ordered)s (already accepted: %(prev)s). Receipts beyond "
                        "approved quantities are blocked unless an approved amendment increases "
                        "the purchase quantity (closed quantities can be reopened on the "
                        "supplier purchase).", line=pline.name, now=accepted_now,
                        ordered=open_qty, prev=previous))

    # ---- workflow ---------------------------------------------------------------------------
    def _idp_shortages(self):
        """{purchase line: quantity still open after this GRN} for the lines of this GRN."""
        self.ensure_one()
        result = {}
        for pline in self.line_ids.purchase_line_id:
            previous = sum(pline.receipt_line_ids.filtered(
                lambda r: r.state == 'done' and r.receipt_id != self).mapped('qty_accepted'))
            now = sum(self.line_ids.filtered(
                lambda l: l.purchase_line_id == pline).mapped('qty_accepted'))
            remaining = pline.product_qty - pline.qty_closed - previous - now
            if qty_compare(self.env, remaining, 0.0) > 0:
                result[pline] = remaining
        return result

    def action_confirm(self):
        """Confirm a GRN or a service acceptance.

        A GRN receiving less than the open quantity asks (depending on the company setting)
        whether to create a backorder or to close the remaining quantity."""
        for receipt in self:
            if receipt.receipt_type == 'coc':
                raise UserError(_("Certificates of completion are verified then approved."))
            if receipt.state != 'draft':
                raise UserError(_("%s is not a draft.", receipt.name))
            receipt._idp_check_rights()
            receipt._idp_check_quantities()
        decision = self.env.context.get('idp_backorder')
        grns = self.filtered(lambda r: r.receipt_type == 'grn')
        if not decision and grns:
            policy = grns[:1].company_id.idp_grn_backorder
            if policy == 'ask' and any(grn._idp_shortages() for grn in grns):
                if len(self) > 1:
                    raise UserError(_("Confirm partial GRNs one at a time."))
                return {
                    'type': 'ir.actions.act_window',
                    'res_model': 'idp.grn.backorder.wizard',
                    'view_mode': 'form',
                    'target': 'new',
                    'name': _("Partial Receipt"),
                    'context': {'default_receipt_id': self.id},
                }
            decision = 'close' if policy == 'never' else 'backorder'
        gate = self._idp_signature_gate('action_confirm', _("Sign and Confirm"))
        if gate:
            if decision:
                gate['context']['idp_backorder'] = decision
            return gate
        signature = self._idp_current_signature()
        for receipt in self:
            shortages = receipt._idp_shortages() if receipt.receipt_type == 'grn' else {}
            receipt._idp_finalize_lines()
            receipt.sudo().write({
                'state': 'done',
                'approved_by_id': self.env.uid,
                'approved_date': fields.Datetime.now(),
                'approved_signature': signature or False,
            })
            if receipt.receipt_type == 'grn':
                receipt._idp_create_stock_receipt()
            receipt.message_post(body=_("%s confirmed.", receipt.name))
            if shortages:
                receipt._idp_process_shortages(shortages, decision or 'backorder')
        return True

    def _idp_process_shortages(self, shortages, decision):
        self.ensure_one()
        summary = ", ".join("%s: %s %s" % (pl.name, qty, pl.uom_id.name)
                            for pl, qty in shortages.items())
        if decision == 'close':
            for pline, qty in shortages.items():
                pline.sudo().qty_closed = pline.qty_closed + qty
            self.message_post(body=_("No backorder: remaining quantities closed (%s).", summary))
            self.purchase_id.sudo().message_post(body=_(
                "%(grn)s: remaining quantities closed without backorder (%(lines)s).",
                grn=self.name, lines=summary))
            return self.env['idp.receipt']
        backorder = self.create({
            'purchase_id': self.purchase_id.id,
            'receipt_type': 'grn',
            'location_id': self.location_id.id,
            'remarks': _("Backorder of %s", self.name),
            'line_ids': [Command.create({'purchase_line_id': pline.id, 'qty_received': qty})
                         for pline, qty in shortages.items()],
        })
        backorder.sudo().backorder_of_id = self
        self.message_post(body=_("Backorder %(bo)s created for: %(lines)s",
                                 bo=backorder._get_html_link(), lines=summary))
        return backorder

    def action_verify(self):
        for receipt in self:
            if receipt.receipt_type != 'coc' or receipt.state != 'draft':
                raise UserError(_("Only draft certificates of completion can be verified."))
            receipt._idp_check_rights()
            receipt._idp_check_quantities()
        gate = self._idp_signature_gate('action_verify', _("Sign and Verify"))
        if gate:
            return gate
        signature = self._idp_current_signature()
        for receipt in self:
            receipt.sudo().write({
                'state': 'verified',
                'verified_by_id': self.env.uid,
                'verified_date': fields.Datetime.now(),
                'verified_signature': signature or False,
            })
            receipt.message_post(body=_("Certificate verified."))
        return True

    def action_approve(self):
        for receipt in self:
            if receipt.receipt_type != 'coc' or receipt.state != 'verified':
                raise UserError(_("Only verified certificates of completion can be approved."))
            receipt._idp_check_rights()
            if receipt.company_id.idp_coc_separate_approver \
                    and receipt.verified_by_id == self.env.user:
                raise AccessError(_(
                    "Segregation of duties: the certificate must be approved by a user other "
                    "than its verifier."))
            receipt._idp_check_quantities()
        gate = self._idp_signature_gate('action_approve', _("Sign and Approve"))
        if gate:
            return gate
        signature = self._idp_current_signature()
        for receipt in self:
            receipt._idp_finalize_lines()
            receipt.sudo().write({
                'state': 'done',
                'approved_by_id': self.env.uid,
                'approved_date': fields.Datetime.now(),
                'approved_signature': signature or False,
            })
            receipt.message_post(body=_("Certificate of completion approved."))
        return True

    def action_reset_to_draft(self):
        for receipt in self:
            if receipt.state != 'verified':
                raise UserError(_("Only verified certificates can be reset to draft."))
            receipt._idp_check_rights()
            receipt.sudo().write({'state': 'draft', 'verified_by_id': False,
                                  'verified_date': False, 'verified_signature': False})
        return True

    def action_open_cancel_wizard(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'idp.cancel.wizard',
            'view_mode': 'form',
            'target': 'new',
            'name': _("Cancel %s", self.name),
            'context': {'default_res_model': self._name, 'default_res_id': self.id},
        }

    def _idp_action_cancel(self, reason):
        for receipt in self:
            if receipt.state == 'cancel':
                continue
            receipt._idp_check_rights()
            active_bill_lines = receipt.line_ids.sudo().invoice_line_ids.filtered(
                lambda aml: aml.parent_state != 'cancel')
            if active_bill_lines:
                raise UserError(_(
                    "%s is referenced by vendor bills (%s). Cancel the draft bills or reverse "
                    "the posted ones first.", receipt.name,
                    ", ".join(active_bill_lines.move_id.mapped('display_name'))))
            if receipt.state == 'done' and receipt.receipt_type == 'grn':
                receipt._idp_return_stock()
            receipt.sudo().write({'state': 'cancel', 'cancel_reason': reason})
            receipt.message_post(body=_("Cancelled: %s", reason))
        return True

    def _idp_finalize_lines(self):
        for line in self.line_ids:
            previous = sum(line.purchase_line_id.receipt_line_ids.filtered(
                lambda r: r.state == 'done' and r.receipt_id != line.receipt_id
            ).mapped('qty_accepted'))
            line.sudo().qty_previous_done = previous
        self.line_ids.filtered(lambda l: qty_is_zero(self.env, l.qty_received)).sudo().unlink()

    # ---- inventory integration ------------------------------------------------------------
    def _idp_create_stock_receipt(self):
        self.ensure_one()
        company = self.company_id
        if not company.idp_grn_stock_moves:
            return
        lines = self.line_ids.filtered(
            lambda l: l.purchase_line_id.product_id.type == 'consu'
            and not qty_is_zero(self.env, l.qty_accepted))
        if not lines:
            return
        Picking = self.env['stock.picking'].sudo().with_company(company)
        warehouse = self.location_id.warehouse_id or self.env['stock.warehouse'].sudo().search(
            [('company_id', '=', company.id)], limit=1)
        picking_type = warehouse.in_type_id
        if not picking_type:
            return
        supplier_location = self.partner_id.with_company(company).property_stock_supplier \
            or self.env.ref('stock.stock_location_suppliers')
        moves = []
        for line in lines:
            pline = line.purchase_line_id
            price = self.currency_id._convert(
                pline.price_net, company.currency_id, company, self.date, round=False)
            moves.append(Command.create({
                'product_id': pline.product_id.id,
                'product_uom_qty': line.qty_accepted,
                'product_uom': pline.uom_id.id,
                'location_id': supplier_location.id,
                'location_dest_id': self.location_id.id,
                'price_unit': price,
                'company_id': company.id,
                'origin': self.name,
            }))
        picking = Picking.create({
            'picking_type_id': picking_type.id,
            'partner_id': self.partner_id.id,
            'origin': self.name,
            'location_id': supplier_location.id,
            'location_dest_id': self.location_id.id,
            'company_id': company.id,
            'move_ids': moves,
        })
        picking.action_confirm()
        for move in picking.move_ids:
            move.quantity = move.product_uom_qty
            move.picked = True
        if not picking.move_ids.filtered(lambda m: m.product_id.tracking != 'none'):
            picking._action_done()
        else:
            self.message_post(body=_(
                "Inventory receipt %s requires lot/serial numbers and was left ready for the "
                "warehouse to validate.", picking.name))
        self.sudo().picking_ids = [Command.link(picking.id)]

    def _idp_return_stock(self):
        self.ensure_one()
        for picking in self.sudo().picking_ids.filtered(
                lambda p: p.picking_type_id.code == 'incoming'):
            if picking.state == 'done':
                wizard = self.env['stock.return.picking'].sudo().with_context(
                    active_id=picking.id, active_model='stock.picking').create(
                    {'picking_id': picking.id})
                for return_line in wizard.product_return_moves:
                    return_line.quantity = return_line.move_id.quantity
                returned = wizard._create_return()
                for move in returned.move_ids:
                    move.quantity = move.product_uom_qty
                    move.picked = True
                returned._action_done()
                self.sudo().picking_ids = [Command.link(returned.id)]
            elif picking.state != 'cancel':
                picking.action_cancel()

    # ---- navigation -------------------------------------------------------------------------
    def action_view_bills(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id('account.action_move_in_invoice_type')
        action['domain'] = [('id', 'in', self.bill_ids.ids)]
        action['context'] = {'create': False}
        return action

    def action_view_pickings(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id('stock.action_picking_tree_all')
        action['domain'] = [('id', 'in', self.picking_ids.ids)]
        action['context'] = {'create': False}
        return action

    def action_create_vendor_bill(self):
        return self.purchase_id.action_create_vendor_bill()


class IdpReceiptLine(models.Model):
    _name = 'idp.receipt.line'
    _description = 'Goods Receipt / Service Completion Line'
    _order = 'receipt_id, id'
    _check_company_auto = True

    receipt_id = fields.Many2one('idp.receipt', required=True, ondelete='cascade', index=True)
    receipt_type = fields.Selection(related='receipt_id.receipt_type', store=True)
    state = fields.Selection(related='receipt_id.state', store=True, string="Status")
    date = fields.Date(related='receipt_id.date', store=True)
    company_id = fields.Many2one(related='receipt_id.company_id', store=True, index=True)
    currency_id = fields.Many2one(related='receipt_id.currency_id')
    purchase_line_id = fields.Many2one(
        'idp.supplier.purchase.line', string="Purchase Line", required=True, index=True,
        ondelete='restrict', check_company=True)
    purchase_id = fields.Many2one(related='purchase_line_id.purchase_id', store=True)
    request_line_id = fields.Many2one(related='purchase_line_id.request_line_id', store=True)
    partner_id = fields.Many2one(related='purchase_line_id.partner_id', store=True,
                                 string="Supplier")
    name = fields.Char(related='purchase_line_id.name', string="Description")
    product_id = fields.Many2one(related='purchase_line_id.product_id')
    uom_id = fields.Many2one(related='purchase_line_id.uom_id')
    qty_ordered = fields.Float(related='purchase_line_id.product_qty', string="Ordered Qty")
    qty_previous_done = fields.Float(digits='Product Unit', readonly=True, copy=False)
    qty_previous = fields.Float(
        string="Previously Accepted", compute='_compute_progress', digits='Product Unit')
    qty_received = fields.Float(string="Qty Now", digits='Product Unit', default=0.0)
    qty_rejected = fields.Float(string="Rejected Qty", digits='Product Unit', default=0.0)
    qty_accepted = fields.Float(
        string="Accepted Qty", compute='_compute_qty_accepted', store=True, digits='Product Unit')
    qty_remaining = fields.Float(
        string="Remaining Qty", compute='_compute_progress', digits='Product Unit')
    completion_pct = fields.Float(
        string="Completion % (now)", digits=(16, 2),
        help="Optional: completion percentage certified now. It is converted into the "
             "equivalent quantity of the approved scope.")
    cumulative_pct = fields.Float(
        string="Cumulative %", compute='_compute_progress', digits=(16, 2))
    price_net = fields.Float(related='purchase_line_id.price_net', string="Approved Net Price")
    accepted_value = fields.Monetary(compute='_compute_progress')
    remaining_value = fields.Monetary(compute='_compute_progress')
    remarks = fields.Char()

    invoice_line_ids = fields.One2many('account.move.line', 'idp_receipt_line_id',
                                       string="Bill Lines")
    qty_billed = fields.Float(compute='_compute_billing', store=True, digits='Product Unit')
    qty_reserved = fields.Float(
        string="On Draft Bills", compute='_compute_billing', store=True, digits='Product Unit')
    qty_to_bill = fields.Float(compute='_compute_billing', store=True, digits='Product Unit')

    @api.depends('qty_received', 'qty_rejected')
    def _compute_qty_accepted(self):
        for line in self:
            line.qty_accepted = max((line.qty_received or 0.0) - (line.qty_rejected or 0.0), 0.0)

    @api.depends('state', 'qty_previous_done', 'qty_accepted', 'purchase_line_id.product_qty',
                 'purchase_line_id.receipt_line_ids.state',
                 'purchase_line_id.receipt_line_ids.qty_accepted')
    def _compute_progress(self):
        for line in self:
            pline = line.purchase_line_id
            if line.state in ('done', 'cancel'):
                previous = line.qty_previous_done
            else:
                previous = sum(pline.receipt_line_ids.filtered(
                    lambda r: r.state == 'done' and r.id != line._origin.id
                ).mapped('qty_accepted'))
            line.qty_previous = previous
            accepted = line.qty_accepted if line.state != 'cancel' else 0.0
            ordered = pline.product_qty
            line.qty_remaining = max(ordered - previous - accepted, 0.0)
            line.cumulative_pct = ((previous + accepted) / ordered * 100.0) if ordered else 0.0
            currency = line.currency_id
            value = accepted * line.price_net
            remaining_value = line.qty_remaining * line.price_net
            line.accepted_value = currency.round(value) if currency else value
            line.remaining_value = currency.round(remaining_value) if currency else remaining_value

    @api.depends('qty_accepted', 'state', 'invoice_line_ids.quantity',
                 'invoice_line_ids.parent_state', 'invoice_line_ids.move_id.move_type')
    def _compute_billing(self):
        for line in self:
            billed, reserved = line._idp_billing_quantities()
            line.qty_billed = billed
            line.qty_reserved = reserved
            available = line.qty_accepted - billed - reserved if line.state == 'done' else 0.0
            line.qty_to_bill = max(available, 0.0)

    def _idp_billing_quantities(self, exclude=None):
        """Return (posted billed qty net of refunds, qty reserved on draft bills)."""
        self.ensure_one()
        billed = reserved = 0.0
        for aml in self.sudo().invoice_line_ids:
            if exclude and aml in exclude:
                continue
            move_type = aml.move_id.move_type
            if move_type == 'in_invoice':
                if aml.parent_state == 'posted':
                    billed += aml.quantity
                elif aml.parent_state == 'draft':
                    reserved += aml.quantity
            elif move_type == 'in_refund' and aml.parent_state == 'posted':
                billed -= aml.quantity
        return billed, reserved

    @api.onchange('completion_pct')
    def _onchange_completion_pct(self):
        if self.completion_pct and self.purchase_line_id:
            self.qty_received = self.purchase_line_id.uom_id.round(
                self.purchase_line_id.product_qty * self.completion_pct / 100.0)

    @api.model
    def _idp_apply_pct(self, vals, pline):
        if vals.get('completion_pct') and pline:
            vals['qty_received'] = pline.uom_id.round(
                pline.product_qty * vals['completion_pct'] / 100.0)
        return vals

    @api.model_create_multi
    def create(self, vals_list):
        PLine = self.env['idp.supplier.purchase.line']
        for vals in vals_list:
            self._idp_apply_pct(vals, PLine.browse(vals.get('purchase_line_id')))
        lines = super().create(vals_list)
        if not self.env.su:
            for receipt in lines.receipt_id:
                if receipt.state != 'draft':
                    raise UserError(_("%s is no longer a draft.", receipt.name))
                receipt._idp_check_rights()
        return lines

    def write(self, vals):
        if not self.env.su:
            for line in self:
                if line.receipt_id.state != 'draft':
                    raise UserError(_("%s is no longer a draft.", line.receipt_id.name))
            self.receipt_id._idp_check_rights()
            if 'qty_previous_done' in vals:
                raise AccessError(_("This value is set by the system."))
        if vals.get('completion_pct'):
            for line in self:
                pline = self.env['idp.supplier.purchase.line'].browse(
                    vals.get('purchase_line_id')) or line.purchase_line_id
                super(IdpReceiptLine, line).write(self._idp_apply_pct(dict(vals), pline))
            return True
        return super().write(vals)

    @api.ondelete(at_uninstall=False)
    def _unlink_except_confirmed(self):
        if self.env.su:
            return
        for line in self:
            if line.receipt_id.state != 'draft':
                raise UserError(_("Lines of a processed document cannot be deleted."))

    @api.constrains('qty_received', 'qty_rejected', 'completion_pct', 'purchase_line_id')
    def _check_line(self):
        for line in self:
            if line.qty_received < 0 or line.qty_rejected < 0:
                raise ValidationError(_("Quantities cannot be negative."))
            if line.completion_pct < 0 or line.completion_pct > 100:
                raise ValidationError(_("The completion percentage must be between 0 and 100."))
            if line.receipt_type != 'grn' and not qty_is_zero(self.env, line.qty_rejected):
                raise ValidationError(_("Only goods receipts record rejected quantities."))
            if line.purchase_line_id.purchase_id != line.receipt_id.purchase_id:
                raise ValidationError(_(
                    "The line must belong to the document's supplier purchase."))
            if line.purchase_line_id.receipt_method != line.receipt_type:
                raise ValidationError(_(
                    "Purchase line '%(line)s' must be processed through a %(doc)s.",
                    line=line.purchase_line_id.name,
                    doc=dict(RECEIPT_TYPES)[line.purchase_line_id.receipt_method]))
