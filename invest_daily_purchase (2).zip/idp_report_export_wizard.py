import datetime
import io
from collections import OrderedDict

from odoo import _, api, fields, models
from odoo.exceptions import UserError

STATUS_FILTERS = [
    ('all', 'All (except cancelled / rejected)'),
    ('in_approval', 'In Approval'),
    ('approved', 'Approved for Purchase'),
    ('to_receive', 'Awaiting Receipt / Completion'),
    ('to_bill', 'Awaiting Billing'),
    ('billed', 'Fully Billed'),
    ('everything', 'Everything (incl. cancelled / rejected)'),
]
GROUPINGS = [
    ('project_vendor', 'Project > Vendor'),
    ('vendor_project', 'Vendor > Project'),
    ('project', 'Project'),
    ('vendor', 'Vendor'),
    ('department', 'Department'),
    ('none', 'No grouping'),
]


class IdpReportExportWizard(models.TransientModel):
    _name = 'idp.report.export.wizard'
    _description = 'Export Purchase Report'

    company_id = fields.Many2one('res.company', required=True,
                                 default=lambda self: self.env.company)
    company_currency_id = fields.Many2one(related='company_id.currency_id')
    date_from = fields.Date(string="Request Date From")
    date_to = fields.Date(string="Request Date To")
    project_ids = fields.Many2many(
        'idp.project', string="Projects",
        domain="[('company_id', '=', company_id)]",
        context={'active_test': False})
    partner_ids = fields.Many2many('res.partner', string="Vendors")
    department_ids = fields.Many2many('hr.department', string="Departments")
    requester_ids = fields.Many2many('res.users', string="Requesters",
                                     domain=[('share', '=', False)])
    status_filter = fields.Selection(STATUS_FILTERS, string="Status", default='all',
                                     required=True)
    include_unawarded = fields.Boolean(
        string="Include Lines Without Selected Vendor", default=True)
    group_by = fields.Selection(GROUPINGS, string="Group By", default='project_vendor',
                                required=True)
    excel_file = fields.Binary(readonly=True, attachment=False)
    excel_filename = fields.Char(readonly=True)

    # ---- data ---------------------------------------------------------------------------
    def _get_domain(self):
        self.ensure_one()
        domain = [('company_id', '=', self.company_id.id)]
        if self.date_from:
            domain.append(('date_request', '>=', self.date_from))
        if self.date_to:
            domain.append(('date_request', '<=', self.date_to))
        if self.project_ids:
            domain.append(('project_id', 'in', self.project_ids.ids))
        if self.partner_ids:
            domain.append(('partner_id', 'in', self.partner_ids.ids))
        if self.department_ids:
            domain.append(('department_id', 'in', self.department_ids.ids))
        if self.requester_ids:
            domain.append(('requester_id', 'in', self.requester_ids.ids))
        if not self.include_unawarded:
            domain.append(('is_awarded', '=', True))
        status = self.status_filter
        if status != 'everything':
            domain.append(('request_state', 'not in', ('cancel', 'rejected')))
        if status == 'in_approval':
            domain.append(('request_state', 'in', ('submitted', 'offers', 'approval')))
        elif status == 'approved':
            domain.append(('request_state', '=', 'approved'))
        elif status == 'to_receive':
            domain += [('request_state', '=', 'approved'), ('qty_to_receive', '>', 0)]
        elif status == 'to_bill':
            domain.append(('qty_to_bill', '>', 0))
        elif status == 'billed':
            domain.append(('billing_status', '=', 'full'))
        return domain

    def _get_rows(self):
        return self.env['idp.purchase.report'].search(
            self._get_domain(), order='date_request, request_name, id')

    def _group_keys(self):
        return {
            'project_vendor': ['project_id', 'partner_id'],
            'vendor_project': ['partner_id', 'project_id'],
            'project': ['project_id'],
            'vendor': ['partner_id'],
            'department': ['department_id'],
            'none': [],
        }[self.group_by]

    def _columns(self):
        """(label, type, getter) — type follows Odoo's export cell types."""
        def sel(fname):
            return lambda row, d: dict(row._fields[fname]._description_selection(
                row.env)).get(row[fname]) or ''

        def m2o(fname):
            return lambda row, d: row[fname].display_name or ''

        return [
            (_("Request Number"), 'char', lambda r, d: r.request_name or ''),
            (_("Request Date"), 'date', lambda r, d: r.date_request),
            (_("Project"), 'char', m2o('project_id')),
            (_("Department"), 'char', m2o('department_id')),
            (_("Requester"), 'char', m2o('requester_id')),
            (_("Purpose"), 'char', lambda r, d: d['purpose']),
            (_("Description"), 'char', lambda r, d: r.description or ''),
            (_("Product"), 'char', m2o('product_id')),
            (_("Type"), 'char', sel('line_type')),
            (_("Receiving Document"), 'char', sel('receipt_method')),
            (_("Vendor"), 'char', m2o('partner_id')),
            (_("Quotation Ref."), 'char', lambda r, d: r.quotation_ref or ''),
            (_("Supplier Purchase"), 'char', m2o('supplier_purchase_id')),
            (_("Confirmation Date"), 'date', lambda r, d: r.date_confirmed),
            (_("Unit"), 'char', m2o('uom_id')),
            (_("Requested Qty"), 'float', lambda r, d: r.qty_requested),
            (_("Ordered Qty"), 'float', lambda r, d: r.qty_ordered),
            (_("Received / Certified Qty"), 'float', lambda r, d: r.qty_received),
            (_("Outstanding Qty"), 'float', lambda r, d: r.qty_to_receive),
            (_("Billed Qty"), 'float', lambda r, d: r.qty_billed),
            (_("Unit Price"), 'float', lambda r, d: r.price_unit),
            (_("Discount (%)"), 'float', lambda r, d: r.discount),
            (_("Vendor Currency"), 'char', lambda r, d: r.currency_id.name or ''),
            (_("Untaxed (Vendor Currency)"), 'float', lambda r, d: r.amount_currency),
            (_("Estimated (%s)", self.company_currency_id.name), 'monetary',
             lambda r, d: r.amount_estimated),
            (_("Untaxed (%s)", self.company_currency_id.name), 'monetary',
             lambda r, d: r.amount_untaxed),
            (_("Total Incl. Taxes (%s)", self.company_currency_id.name), 'monetary',
             lambda r, d: r.amount_total),
            (_("Variance vs Estimate"), 'monetary', lambda r, d: r.amount_variance),
            (_("Received Value"), 'monetary', lambda r, d: r.amount_received),
            (_("Billed Amount"), 'monetary', lambda r, d: r.amount_billed),
            (_("Amount to Bill"), 'monetary', lambda r, d: r.amount_to_bill),
            (_("Approval Status"), 'char', sel('request_state')),
            (_("Progress"), 'char', sel('progress_status')),
            (_("Pending Level"), 'char', m2o('current_level_id')),
            (_("Approved By"), 'char', lambda r, d: d['approvals']),
            (_("GRN / COC / Acceptance"), 'char', lambda r, d: d['documents']),
            (_("Vendor Bills"), 'char', lambda r, d: d['bills']),
        ]

    def _filters_summary(self):
        self.ensure_one()

        def names(records):
            return ", ".join(records.mapped('display_name')) or self.env._("All")
        return [
            (_("Company"), self.company_id.name),
            (_("Request Date From"), self.date_from or ''),
            (_("Request Date To"), self.date_to or ''),
            (_("Projects"), names(self.project_ids)),
            (_("Vendors"), names(self.partner_ids)),
            (_("Departments"), names(self.department_ids)),
            (_("Requesters"), names(self.requester_ids)),
            (_("Status"), dict(STATUS_FILTERS)[self.status_filter]),
            (_("Lines Without Vendor"), _("Included") if self.include_unawarded
             else _("Excluded")),
            (_("Group By"), dict(GROUPINGS)[self.group_by]),
            (_("Generated On"), fields.Datetime.context_timestamp(
                self, fields.Datetime.now()).strftime('%Y-%m-%d %H:%M')),
            (_("Generated By"), self.env.user.name),
        ]

    def _build_tree(self, rows):
        """Nested OrderedDict of groups following ``group_by``; leaves are row lists."""
        keys = self._group_keys()

        undefined = _("Undefined")

        def label(row, fname):
            return row[fname].display_name or undefined

        def build(records, depth):
            if depth >= len(keys):
                return list(records)
            groups = OrderedDict()
            for row in records:
                groups.setdefault(label(row, keys[depth]), []).append(row)
            return OrderedDict(
                (name, build(items, depth + 1))
                for name, items in sorted(groups.items(), key=lambda kv: kv[0].lower()))
        return build(rows, 0)

    # ---- Excel (Odoo native export layout) -------------------------------------------------
    def _build_xlsx(self, rows):
        """Build the workbook with the same formats as Odoo's list / grouped export."""
        import xlsxwriter  # noqa: PLC0415  (dependency of Odoo itself)
        columns = self._columns()
        details = rows._idp_export_details()
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        decimals = self.company_currency_id.decimal_places or 2
        money_fmt = '#,##0.%s' % ('0' * decimals)
        header_style = workbook.add_format({'bold': True})
        base_style = workbook.add_format({'text_wrap': True})
        date_style = workbook.add_format({'text_wrap': True, 'num_format': 'yyyy-mm-dd'})
        float_style = workbook.add_format({'text_wrap': True, 'num_format': '#,##0.00'})
        monetary_style = workbook.add_format({'text_wrap': True, 'num_format': money_fmt})
        header_bold = {'text_wrap': True, 'bold': True, 'bg_color': '#e9ecef'}
        header_bold_style = workbook.add_format(header_bold)
        header_bold_float = workbook.add_format(dict(header_bold, num_format='#,##0.00'))
        header_bold_monetary = workbook.add_format(dict(header_bold, num_format=money_fmt))

        sheet = workbook.add_worksheet(_("Purchase Report")[:31])
        for col, (label, _type, _getter) in enumerate(columns):
            sheet.write(0, col, label, header_style)
        sheet.set_column(0, max(0, len(columns) - 1), 30)
        sheet.freeze_panes(1, 0)

        sum_types = ('float', 'monetary')
        sum_cols = {col for col, c in enumerate(columns) if c[1] in sum_types}
        # quantities of different units / prices are not summed in group rows
        no_sum = {_("Unit Price"), _("Discount (%)"), _("Untaxed (Vendor Currency)")}

        def write_row(row_idx, row):
            for col, (_label, ctype, getter) in enumerate(columns):
                value = getter(row, details[row.id])
                if ctype == 'date':
                    if value:
                        sheet.write_datetime(row_idx, col, datetime.datetime.combine(
                            value, datetime.time()), date_style)
                    else:
                        sheet.write_blank(row_idx, col, None, base_style)
                elif ctype == 'float':
                    sheet.write_number(row_idx, col, value or 0.0, float_style)
                elif ctype == 'monetary':
                    sheet.write_number(row_idx, col, value or 0.0, monetary_style)
                else:
                    sheet.write(row_idx, col, (value or '').replace('\r', ' '), base_style)

        def flatten(node):
            if isinstance(node, list):
                return node
            return [row for child in node.values() for row in flatten(child)]

        def write_group(row_idx, name, node, depth):
            members = flatten(node)
            sheet.write(row_idx, 0, '%s%s (%s)' % ('    ' * depth, name, len(members)),
                        header_bold_style)
            for col in range(1, len(columns)):
                label, ctype, getter = columns[col]
                if col in sum_cols and label not in no_sum:
                    total = sum((getter(r, details[r.id]) or 0.0) for r in members)
                    sheet.write_number(row_idx, col, total, header_bold_monetary
                                       if ctype == 'monetary' else header_bold_float)
                else:
                    sheet.write(row_idx, col, '', header_bold_style)
            row_idx += 1
            if isinstance(node, list):
                for row in node:
                    write_row(row_idx, row)
                    row_idx += 1
            else:
                for child_name, child in node.items():
                    row_idx = write_group(row_idx, child_name, child, depth + 1)
            return row_idx

        tree = self._build_tree(rows)
        row_idx = 1
        if isinstance(tree, list):
            for row in tree:
                write_row(row_idx, row)
                row_idx += 1
        else:
            for name, node in tree.items():
                row_idx = write_group(row_idx, name, node, 0)
        # grand total row, same style as group headers
        if rows:
            sheet.write(row_idx, 0, _("Total (%s)", len(rows)), header_bold_style)
            for col in range(1, len(columns)):
                label, ctype, getter = columns[col]
                if col in sum_cols and label not in no_sum:
                    total = sum((getter(r, details[r.id]) or 0.0) for r in rows)
                    sheet.write_number(row_idx, col, total, header_bold_monetary
                                       if ctype == 'monetary' else header_bold_float)
                else:
                    sheet.write(row_idx, col, '', header_bold_style)

        info = workbook.add_worksheet(_("Filters")[:31])
        info.write(0, 0, _("Filter"), header_style)
        info.write(0, 1, _("Value"), header_style)
        info.set_column(0, 1, 30)
        for idx, (label, value) in enumerate(self._filters_summary(), start=1):
            info.write(idx, 0, label, base_style)
            if isinstance(value, datetime.date):
                info.write_datetime(idx, 1, datetime.datetime.combine(value, datetime.time()),
                                    date_style)
            else:
                info.write(idx, 1, value or '', base_style)
        workbook.close()
        return output.getvalue()

    def action_export_excel(self):
        self.ensure_one()
        rows = self._get_rows()
        if not rows:
            raise UserError(_("No purchase data matches these filters."))
        content = self._build_xlsx(rows)
        stamp = fields.Date.context_today(self).strftime('%Y%m%d')
        parts = [_("Purchase Report")]
        if len(self.project_ids) == 1:
            parts.append(self.project_ids.code)
        if len(self.partner_ids) == 1:
            parts.append(self.partner_ids.name)
        filename = "%s - %s.xlsx" % (" - ".join(parts), stamp)
        import base64  # noqa: PLC0415
        self.write({'excel_file': base64.b64encode(content), 'excel_filename': filename})
        return {
            'type': 'ir.actions.act_url',
            'url': '/web/content/%s/%s/excel_file/%s?download=true' % (
                self._name, self.id, filename),
            'target': 'self',
        }

    def action_open_report(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id(
            'invest_daily_purchase.action_idp_purchase_report')
        action['domain'] = self._get_domain()
        action['context'] = {}
        return action

    def action_print_pdf(self):
        self.ensure_one()
        if not self._get_rows():
            raise UserError(_("No purchase data matches these filters."))
        return self.env.ref('invest_daily_purchase.action_report_idp_purchase_analysis') \
            .report_action(self)

    # ---- helpers for the PDF template ---------------------------------------------------
    def _idp_pdf_groups(self):
        """[(group label, rows, totals dict)] using the first grouping level."""
        self.ensure_one()
        rows = self._get_rows()
        keys = self._group_keys()
        result = []
        if not keys:
            return [(False, rows, self._idp_totals(rows))]
        groups = OrderedDict()
        for row in rows:
            groups.setdefault(row[keys[0]].display_name or _("Undefined"),
                              self.env['idp.purchase.report'])
            groups[row[keys[0]].display_name or _("Undefined")] |= row
        for name in sorted(groups, key=str.lower):
            result.append((name, groups[name], self._idp_totals(groups[name])))
        return result

    @api.model
    def _idp_totals(self, rows):
        return {fname: sum(rows.mapped(fname)) for fname in (
            'amount_estimated', 'amount_untaxed', 'amount_total', 'amount_received',
            'amount_billed', 'amount_to_bill')}
