from odoo import api, fields, models

APPROVAL_STATES = [
    ('pending', 'Pending'),
    ('approved', 'Approved'),
    ('rejected', 'Rejected'),
    ('returned', 'Returned for Correction'),
    ('invalidated', 'Invalidated'),
]


class IdpRequestApproval(models.Model):
    """One approval step of a purchase request.

    Records are created and updated only by the request's workflow methods (under sudo);
    users have read-only access, so approvals cannot be forged through the API.
    Earlier rounds and invalidated steps are kept as approval history.
    """
    _name = 'idp.request.approval'
    _description = 'Purchase Request Approval Step'
    _order = 'request_id, round desc, position, id'

    request_id = fields.Many2one(
        'idp.purchase.request', required=True, ondelete='cascade', index=True)
    company_id = fields.Many2one(related='request_id.company_id', store=True)
    level_id = fields.Many2one('idp.approval.level', string="Approval Level Setup", required=True,
                               ondelete='restrict')
    name = fields.Char(string="Level", required=True)
    position = fields.Integer(string="Level #", required=True)
    round = fields.Integer(string="Approval Round", required=True, default=1)
    is_offer_gate = fields.Boolean(
        string="Second-Level (Offer Gate)", compute='_compute_is_offer_gate', store=True)
    state = fields.Selection(APPROVAL_STATES, default='pending', required=True, index=True)
    user_id = fields.Many2one('res.users', string="Acted By")
    date = fields.Datetime(string="Action Date")
    comment = fields.Text()
    invalidation_reason = fields.Text()
    signature = fields.Binary(string="Digital Signature", attachment=True, copy=False)
    override = fields.Boolean(
        string="Approved with Exception",
        help="Second-level 'Fix & Approve': missing requirements were fixed or waived.")
    override_reason = fields.Text(string="Exception Reason")
    waived_issues = fields.Text(string="Fixed / Waived Requirements")

    # Threshold evaluation retained at approval time
    threshold_checked = fields.Boolean()
    limit_currency_id = fields.Many2one('res.currency', string="Limit Currency")
    limit_amount = fields.Monetary(currency_field='limit_currency_id')
    estimated_amount_limit = fields.Monetary(
        string="Estimated Total (Limit Currency)", currency_field='limit_currency_id')
    selected_amount_limit = fields.Monetary(
        string="Selected Supplier Total (Limit Currency)", currency_field='limit_currency_id')
    basis_amount = fields.Monetary(
        string="Threshold Basis", currency_field='limit_currency_id',
        help="Higher of the estimated total and the selected supplier total.")
    threshold_exceeded = fields.Boolean(string="Limit Exceeded")
    rate_date = fields.Date(string="Exchange Rate Date")
    rate_used = fields.Float(
        string="Exchange Rate Used", digits=(16, 8),
        help="Rate used to convert the request currency into the limit currency.")
    rate_details = fields.Text(string="Rates Used (all currencies)")

    @api.depends('position')
    def _compute_is_offer_gate(self):
        for approval in self:
            approval.is_offer_gate = approval.position == 2
