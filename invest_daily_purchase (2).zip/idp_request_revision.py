from odoo import fields, models


class IdpRequestRevision(models.Model):
    """Snapshot of a request's approved values taken before an amendment invalidated approvals."""
    _name = 'idp.request.revision'
    _description = 'Purchase Request Revision Snapshot'
    _order = 'request_id, id desc'

    request_id = fields.Many2one(
        'idp.purchase.request', required=True, ondelete='cascade', index=True)
    company_id = fields.Many2one(related='request_id.company_id', store=True)
    date = fields.Datetime(default=fields.Datetime.now, required=True)
    user_id = fields.Many2one('res.users', default=lambda self: self.env.user, required=True)
    round = fields.Integer(string="Approval Round")
    reason = fields.Text(required=True)
    snapshot = fields.Html(string="Previous Values", sanitize=True, readonly=True)
