from odoo import _, fields, models
from odoo.exceptions import UserError

from .idp_signature_mixin import SIGNABLE_METHODS


class IdpSignWizard(models.TransientModel):
    _name = 'idp.sign.wizard'
    _description = 'Sign a Purchase Document'

    res_model = fields.Char(required=True)
    res_ids = fields.Char(required=True)
    method = fields.Char(required=True)
    signature = fields.Binary(string="Your Signature", default=lambda self: self.env.user.idp_signature)
    save_signature = fields.Boolean(
        string="Save as my signature", default=True,
        help="Reuse this signature automatically next time (My Profile > Preferences).")

    def action_sign(self):
        self.ensure_one()
        if self.method not in SIGNABLE_METHODS.get(self.res_model, ()):
            raise UserError(_("This action cannot be signed here."))
        if not self.signature:
            raise UserError(_("Please draw your signature."))
        if self.save_signature:
            self.env.user.write({'idp_signature': self.signature})
        ids = [int(i) for i in self.res_ids.split(',') if i.strip()]
        records = self.env[self.res_model].browse(ids).exists()
        result = getattr(records.with_context(idp_signature=self.signature), self.method)()
        if isinstance(result, dict):
            return result
        return {'type': 'ir.actions.act_window_close'}
