from odoo import _, models

# Workflow methods that may be (re)called by the signing wizard, per model.
SIGNABLE_METHODS = {
    'idp.purchase.request': {'action_submit'},
    'idp.receipt': {'action_confirm', 'action_verify', 'action_approve'},
}
# Context keys carried through the signing wizard.
CARRIED_CONTEXT = ('idp_backorder',)


class IdpSignatureMixin(models.AbstractModel):
    _name = 'idp.signature.mixin'
    _description = 'Digital Signature Helpers'

    def _idp_current_signature(self):
        """Signature given for this action, else the user's saved signature."""
        return self.env.context.get('idp_signature') or self.env.user.sudo().idp_signature or False

    def _idp_signature_gate(self, method, title):
        """Return the signing wizard action when a signature is required but missing."""
        if self._idp_current_signature():
            return False
        company = self[:1].company_id or self.env.company
        if not company.idp_signature_required:
            return False
        ctx = {
            'default_res_model': self._name,
            'default_res_ids': ','.join(str(i) for i in self.ids),
            'default_method': method,
        }
        for key in CARRIED_CONTEXT:
            if self.env.context.get(key):
                ctx[key] = self.env.context[key]
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'idp.sign.wizard',
            'view_mode': 'form',
            'target': 'new',
            'name': title or _("Sign"),
            'context': ctx,
        }
