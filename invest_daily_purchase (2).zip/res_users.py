from odoo import fields, models


class ResUsers(models.Model):
    _inherit = 'res.users'

    idp_signature = fields.Binary(
        string="Purchase Signature", copy=False, attachment=True,
        help="Your digital signature, applied when you submit requests, approve levels and "
             "confirm receiving documents in Invest and Daily Purchases.")

    @property
    def SELF_READABLE_FIELDS(self):
        return super().SELF_READABLE_FIELDS + ['idp_signature']

    @property
    def SELF_WRITEABLE_FIELDS(self):
        return super().SELF_WRITEABLE_FIELDS + ['idp_signature']
