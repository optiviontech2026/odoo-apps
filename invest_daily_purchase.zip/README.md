# Invest and Daily Purchases (Odoo 19)

Technical name: `invest_daily_purchase` · Version 19.0.1.1.1 · License LGPL-3

> **Upload checklist (Odoo.sh / GitHub).** This package keeps every file in **one folder**
> (only the app icon sits in `static/description`), so it can't break when files are uploaded
> without their sub-folders. The only rule: in your repository, `__manifest__.py` must be
> directly inside a folder named `invest_daily_purchase` at the top level of the repo:
> `invest_daily_purchase/__manifest__.py` ✔ — `invest_daily_purchase/invest_daily_purchase/__manifest__.py` ✘.
> Delete any older copy of the folder first.

Purchase requests for goods and services with configurable sequential approvals, mandatory
supplier offers above a configurable limit, side-by-side quotation comparison, split awards,
supplier purchases, Goods Received Notes (GRN), Certificates of Completion (COC), service
acceptances and controlled vendor billing through standard Odoo Accounting.

**New in 1.1:** projects with their own request numbering, project and date chosen on each
request, prints based on the company Document Layout with approval names and signature lines,
and a Purchase Report section with Excel export by project, vendor and other filters.

Depends on the standard Odoo 19 modules: `mail`, `account`, `stock`, `hr`, `analytic`.

---

## 1. Installation

1. Right-click `invest_daily_purchase.zip` → **Extract All** (keep the suggested folder name). You
   get one folder `invest_daily_purchase` with `__manifest__.py` directly inside. Copy that folder
   into one of your custom addons directories (or the top level of your Odoo.sh repository), e.g.
   `/opt/odoo/custom-addons/invest_daily_purchase`.
2. Make sure that directory is in the `addons_path` of your Odoo configuration file:
   ```ini
   addons_path = /opt/odoo/odoo/addons,/opt/odoo/custom-addons
   ```
3. Restart the Odoo service (`sudo systemctl restart odoo`, or however your server is run).
4. In Odoo, activate **developer mode** (Settings → Activate the developer mode).
5. Go to **Apps → Update Apps List**, search for **Invest and Daily Purchases** and click **Activate**.
   Accounting, Inventory and Employees are installed automatically if they are not already.

Command-line alternative:
```bash
odoo-bin -c /etc/odoo/odoo.conf -d <your_database> -i invest_daily_purchase --stop-after-init
```
Upgrade after replacing the files with a newer version (e.g. from 1.0 to 1.1 — no data is lost;
Apps → Invest and Daily Purchases → Upgrade does the same):
```bash
odoo-bin -c /etc/odoo/odoo.conf -d <your_database> -u invest_daily_purchase --stop-after-init
```

Printing PDF documents needs `wkhtmltopdf` on the server — the same requirement as standard Odoo
reports. Use the build **with patched Qt** (0.12.6.1, from github.com/wkhtmltopdf/packaging);
the plain distribution package prints the pages but leaves the company header/footer empty.

## 2. First configuration

### 2.1 Settings — *Invest & Daily Purchases → Configuration → Settings*
| Setting | Meaning |
|---|---|
| Approval Levels | Opens the level list (see 2.2). At least two active levels are required. |
| Projects | Opens the project list (see 2.4). |
| Project Required on Requests | Every request must have a project before it can be submitted. |
| Document Layout | Opens Odoo's Document Layout configurator (logo, colours, font, layout style) used by all prints. |
| Limit | Amount above which supplier offers are mandatory before second-level approval. A total **equal** to the limit does not trigger the requirement. |
| Limit Currency | Company currency used for the limit. Amounts in other currencies are converted with the system rate of the approval date; the rate is stored on the approval step. |
| Taxes | Whether the selected supplier total is compared with or without taxes. |
| Minimum Offers | Number of valid, attached offers (distinct suppliers) required per awarded line above the limit. Default 1. |
| Numbering Sequences | Separate sequences for Purchase Requests, GRNs, COCs, service acceptances and supplier purchases. |
| Purchase Journal | Journal used for vendor bills. **Bill numbers always follow this journal's own numbering**; the module never numbers bills itself. |
| Post Accepted Goods to Inventory | Confirmed GRNs receive accepted goods quantities into the GRN receiving location (validated inventory receipt; returned automatically if the GRN is cancelled). |
| COC Approver Must Differ From Verifier | Optional segregation of duties on Certificates of Completion. |

### 2.2 Approval levels — *Configuration → Approval Levels*
Two levels are created on installation ("First-Level Approval" and "Second-Level Approval"),
authorized for the roles *First-Level Approver* and *Second-Level Approver*. For each level you
can set authorized **users** and/or **roles** (groups). Levels are completed in sequence order:

* **Level 1** – approves the need on estimated prices.
* **Level 2** – supplier-offer gate: supplier selection and agreed prices are always required;
  above the limit the required number of attached offers is also enforced.
* **Level 3+** – any additional approvals you add.

### 2.3 Users — *Settings → Users*, section *Invest and Daily Purchases*
| Role | Can do |
|---|---|
| Requester | Create requests, see own requests |
| Approver / First-Level / Second-Level Approver | See all requests; approve levels they are authorized for |
| Procurement Officer | Record quotations, award suppliers, amend requests after submission |
| Goods Receiver | Create and confirm GRNs |
| Service Completion Verifier | Create, verify and approve COCs and service acceptances |
| Accountant | Create draft vendor bills from accepted quantities (also gets Accounting *Billing* rights) |
| Module Administrator | Everything above + configuration |

Approver roles only give visibility — the right to approve a given level comes from the level
configuration.

### 2.4 Projects — *Configuration → Projects* (or Settings → Configure Projects)
Create a project with a name and a short **code** (e.g. `HOR`). A dedicated, gap-free numbering
sequence is created automatically with the prefix `CODE/<year>/` and 4 digits, so the project's
requests are numbered `HOR/2026/0001`, `HOR/2026/0002`, … independently of other projects. On
the project's *Request Numbering* tab you can change the prefix, number of digits, next number
and whether numbering restarts every year. Requests without a project keep the general `PR/`
sequence. An optional analytic account is copied to the request lines (and then to supplier
purchases and vendor bills).

## 3. Process

1. **Request** (Requester): choose the **project** and **request date** first (the number comes
   from the project's sequence and its year from the request date; changing the project while in
   draft renumbers the request; both are locked after submission), then purpose, department,
   currency, attachments and lines. Each line is
   *Consumable Goods* (received by GRN) or *Service* (with "Requires Certificate of Completion"
   → COC, otherwise → service acceptance). Mixed requests are supported. **Submit**.
2. **First-level approval** on estimated prices. The request is evaluated against the limit.
3. **Supplier offers / selection** (Procurement): *Manage Supplier Quotations* — one quotation per
   supplier document (one attachment can cover several lines). On the request's *Supplier Offers*
   tab, award quantities (a line can be split between suppliers). The *Comparison* tab shows
   prices side by side, converted to the request currency, lowest highlighted — it is never
   selected automatically; a higher-priced award needs a justification.
4. **Second-level approval**: blocked until awarded quantities equal requested quantities and
   prices are recorded. If the higher of the estimate and the selected supplier total is
   **strictly greater** than the limit, it is also blocked until the required attached offers exist
   (red banner and *Requests → Blocked by Missing Offers*).
5. **Additional approvals**, then **Approved for Purchase**: one supplier purchase per supplier /
   company / currency is created with only that supplier's quantities and prices. No bill is
   created at this point.
6. **Receiving**: GRN for goods (received / accepted / rejected, partial deliveries), COC for
   services (quantity or completion %, cumulative max 100 %, verified then approved), service
   acceptance for other services. Only confirmed, accepted quantities become billable.
7. **Billing** (Accountant): *Create Vendor Bill* appears only when billable quantities exist. A
   draft bill per supplier / company / currency is created in the configured journal; enter the
   supplier's invoice number as *Supplier Invoice Reference*. Quantities on draft bills are
   reserved; cancelling a draft releases them; posted bills are corrected by credit note.

**Amendments**: after approval, a procurement officer can change quantities, prices, suppliers,
currencies or quotation attachments. Affected approvals are invalidated (line changes → from
level 1, offer changes → from level 2), supplier purchases go *On Hold* (no receipts or bills), the
previous values are kept in a revision snapshot and re-approval updates the supplier purchases.

## 4. Controls enforced on the server
* Only authorized users can act on the pending level; levels are strictly sequential.
* Workflow fields (status, approvals, supplier purchases) cannot be written through the API;
  approval steps and supplier purchases are read-only for every user.
* Receipts beyond approved quantities are blocked; accepted quantities can only be billed once
  (posted + draft bills ≤ accepted); bill lines must keep the approved price, discount, supplier,
  currency and unit — checked again when the bill is posted.
* Confirmed documents cannot be deleted; cancellation requires a reason and is refused while
  bills reference the document.
* Multi-company record rules on every model; requesters only see their own requests.

## 5. Printing
All prints use `web.external_layout`, i.e. the company's **Document Layout**
(Settings → Companies → Configure Document Layout): layout style, logo, colours, font, header,
footer and paper format — the same as Odoo's own purchase orders and invoices.

* **Purchase Request** (Print menu on the request): project, date, requester, lines with selected
  vendors, totals and an **Approvals & Signatures** table: *Requested by* plus every configured
  approval level by name. Approved levels show the approver's name and date; pending levels are
  blank so the paper copy can be signed by hand. Before submission the configured levels are listed.
* **Purchase Order** (Print menu on the supplier purchase): vendor address block, lines, taxes,
  totals and the same signature table.
* **Goods Received Note** and **Certificate of Completion**: with their own signature rows.

## 6. Reporting and Excel export
*Reporting → Purchase Report* — one row per selected vendor and request line (lines without a
selected vendor appear once), with project, vendor, department, requester, product, quantities
(requested, ordered, received, billed), estimated / ordered / received / billed amounts in company
currency, approval status and progress. Pivot (project × vendor by default), list and graph views,
filters and group-by for project, vendor, department, requester, status and month.

Three ways to get Excel:
1. **Reporting → Export to Excel**: choose dates, projects, vendors, departments, requesters,
   status and grouping (e.g. Project > Vendor), then *Export to Excel*. The file uses Odoo's own
   export layout (bold header row, grey group rows "Name (count)" with totals, same number and date
   formats) and adds approvers, GRN/COC numbers and vendor bill numbers, plus a *Filters* sheet.
   *Print PDF* gives the same data in the company document layout; *Open Analysis* opens the pivot.
2. **Pivot view** download button (Odoo standard xlsx).
3. **List view → select lines → Export**, choose the saved export template
   **"Purchase Report by Project & Vendor"** (Odoo's standard export dialog).

## 7. Menus and reports
Requests (My / All / Pending My Approval / Blocked by Missing Offers), Supplier Offers
(Quotations, Quotation Comparison), Supplier Purchases, Receiving (GRN, COC, Service
Acceptances, Outstanding), Billing (Awaiting Billing, Vendor Bills), Reporting (Purchase Report,
Export to Excel, Supplier Purchase Lines Analysis, Estimated vs Selected Cost, Outstanding,
Awaiting Billing), Configuration (Settings, Projects, Approval Levels, Numbering Sequences).

## 8. Automated tests
The automated tests are kept out of this deployment package (Odoo only runs tests from a `tests`
sub-folder, which is the kind of sub-folder that broke the upload). This exact code passed all 40 of
them. Ask for the developer package to run them yourself. They cover the 13 required acceptance scenarios plus workflow, permission and web-form
paths. Run them on a **test** database:
```bash
odoo-bin -c /etc/odoo/odoo.conf -d <test_database> -u invest_daily_purchase \
         --test-tags /invest_daily_purchase --stop-after-init
```

| # | Scenario | Test |
|---|---|---|
| 1 | Below limit: attachments optional, selection & prices required | `test_01_*`, `test_01b_*` |
| 2 | Above limit without offers: L1 ok, L2 blocked | `test_02_*` |
| 3 | Above limit with valid offers: L2 available | `test_03_*`, `test_03b_*` |
| 4 | Equal to limit: offers not mandatory | `test_04_*` |
| 5 | Selected total above limit, estimate below | `test_05_*`, `test_05b_*` (foreign currency) |
| 6 | Lines to different suppliers → separate purchases and bills | `test_06_*` |
| 7 | One line split between suppliers | `test_07_*` |
| 8 | Partial goods receipt | `test_08_*` |
| 9 | Partial service completion | `test_09_*`, `test_09b_*` |
| 10 | Draft bill reservation / no duplicates | `test_10_*`, `test_10b_*` |
| 11 | Price / quantity / supplier / attachment change → re-approval | `test_11_*`, `test_11b/c/d_*` |
| 12 | Independent GRN/COC numbering, journal bill numbering | `test_12_*` |
| 13 | Unauthorized users and direct API calls blocked | `test_13_*` (both files), `test_sequential_*` |
| — | Projects, sequences, prints with signatures, report and Excel export | `test_idp_projects_reports.py` |

## 9. Design notes
* Supplier purchases are module records (`idp.supplier.purchase`), not standard Purchase
  Orders, so that Odoo's own purchase receipt/billing rules cannot bypass the GRN/COC and
  approval controls. Suppliers, taxes, currencies, journals, analytic distribution, inventory
  locations and vendor bills are standard Odoo objects.
* A request in the middle of an amendment cannot be rejected (that would orphan the existing
  supplier purchases); use *Return for Correction* instead.
* Offer validity: an offer counts as valid if its quotation is not withdrawn, has a positive
  price and quantity, and is not past its *Valid Until* date on the approval date.
