from . import idp_common
from . import res_company
from . import res_config_settings
from . import idp_approval_level
from . import idp_project
from . import idp_request_approval
from . import idp_request_revision
from . import idp_purchase_request
from . import idp_purchase_request_line
from . import idp_quotation
from . import idp_supplier_purchase
from . import idp_receipt
from . import account_move
from . import idp_purchase_report
from . import idp_request_action_wizard
from . import idp_cancel_wizard
from . import idp_bill_wizard
from . import idp_report_export_wizard


def _idp_post_init(env):
    """Point every company at the module's default numbering sequences."""
    env['res.company'].search([])._idp_set_default_sequences()
