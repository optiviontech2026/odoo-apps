from odoo import _, api, fields, models
from odoo.exceptions import UserError


class IdpProject(models.Model):
    """Purchase project. Each project owns a numbering sequence for its purchase requests."""
    _name = 'idp.project'
    _description = 'Purchase Project'
    _inherit = ['mail.thread']
    _order = 'code, id'
    _check_company_auto = True

    name = fields.Char(required=True, tracking=True, translate=True)
    code = fields.Char(
        required=True, tracking=True,
        help="Short code used as the default prefix of the project's request numbers.")
    active = fields.Boolean(default=True, tracking=True)
    company_id = fields.Many2one(
        'res.company', required=True, default=lambda self: self.env.company, index=True)
    company_currency_id = fields.Many2one(related='company_id.currency_id', string="Company Currency")
    manager_id = fields.Many2one('res.users', string="Project Manager", tracking=True,
                                 domain=[('share', '=', False)])
    analytic_account_id = fields.Many2one(
        'account.analytic.account', string="Analytic Account", check_company=True,
        help="Default analytic distribution of the project's request lines (carried to "
             "supplier purchases and vendor bills).")
    date_start = fields.Date(string="Start Date")
    date_end = fields.Date(string="End Date")
    description = fields.Text()

    sequence_id = fields.Many2one(
        'ir.sequence', string="Request Sequence", readonly=True, copy=False,
        help="Separate numbering sequence of this project's purchase requests.")
    sequence_prefix = fields.Char(
        related='sequence_id.prefix', readonly=False, string="Number Prefix")
    sequence_padding = fields.Integer(
        related='sequence_id.padding', readonly=False, string="Number Digits")
    sequence_number_next = fields.Integer(
        related='sequence_id.number_next_actual', readonly=False, string="Next Number")
    sequence_use_date_range = fields.Boolean(
        related='sequence_id.use_date_range', readonly=False, string="Restart Every Year")
    next_number_preview = fields.Char(compute='_compute_next_number_preview',
                                      string="Next Request Number")

    request_ids = fields.One2many('idp.purchase.request', 'project_id', string="Requests")
    request_count = fields.Integer(compute='_compute_stats')
    purchase_count = fields.Integer(compute='_compute_stats')
    amount_estimated = fields.Monetary(
        compute='_compute_stats', currency_field='company_currency_id',
        string="Estimated (Active Requests)")
    amount_ordered = fields.Monetary(
        compute='_compute_stats', currency_field='company_currency_id',
        string="Ordered (Untaxed)")

    _code_company_uniq = models.Constraint(
        'UNIQUE(code, company_id)', 'The project code must be unique per company.')

    @api.depends('code', 'name')
    def _compute_display_name(self):
        for project in self:
            project.display_name = f"[{project.code}] {project.name}" if project.code \
                else (project.name or '')

    @api.depends('sequence_id.prefix', 'sequence_id.padding', 'sequence_id.number_next_actual')
    def _compute_next_number_preview(self):
        for project in self:
            sequence = project.sequence_id.sudo()
            if not sequence:
                project.next_number_preview = False
                continue
            project.next_number_preview = sequence.get_next_char(sequence.number_next_actual)

    def _compute_stats(self):
        Line = self.env['idp.supplier.purchase.line'].sudo()
        for project in self:
            requests = project.request_ids.filtered(
                lambda r: r.state not in ('rejected', 'cancel'))
            project.request_count = len(project.request_ids)
            project.amount_estimated = sum(requests.line_ids.filtered(
                lambda l: not l.cancelled).mapped('est_subtotal_company'))
            lines = Line.search([('project_id', '=', project.id), ('cancelled', '=', False),
                                 ('state', '!=', 'cancel')])
            project.purchase_count = len(lines.purchase_id)
            project.amount_ordered = sum(lines.mapped('price_subtotal_company'))

    @api.model
    def _idp_sequence_vals(self, code, company_id, name):
        return {
            'name': _("Purchase Requests - %s", name or code),
            'implementation': 'no_gap',
            'prefix': '%s/%%(year)s/' % (code or '').strip().upper(),
            'padding': 4,
            'number_next': 1,
            'number_increment': 1,
            'company_id': company_id,
        }

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('code'):
                vals['code'] = vals['code'].strip().upper()
        projects = super().create(vals_list)
        for project in projects:
            if not project.sequence_id:
                project.sequence_id = self.env['ir.sequence'].sudo().create(
                    self._idp_sequence_vals(project.code, project.company_id.id, project.name))
        return projects

    def write(self, vals):
        if vals.get('code'):
            vals['code'] = vals['code'].strip().upper()
            for project in self:
                sequence = project.sequence_id.sudo()
                old_prefix = '%s/%%(year)s/' % (project.code or '')
                if sequence and sequence.prefix == old_prefix:
                    sequence.prefix = '%s/%%(year)s/' % vals['code']
        res = super().write(vals)
        if 'name' in vals:
            for project in self.filtered('sequence_id'):
                project.sequence_id.sudo().name = _("Purchase Requests - %s", project.name)
        return res

    @api.ondelete(at_uninstall=False)
    def _unlink_except_used(self):
        for project in self:
            if project.request_ids:
                raise UserError(_(
                    "Project %s has purchase requests and cannot be deleted; archive it instead.",
                    project.display_name))

    def _idp_next_request_number(self, date=None):
        self.ensure_one()
        if not self.sequence_id:
            self.sequence_id = self.env['ir.sequence'].sudo().create(
                self._idp_sequence_vals(self.code, self.company_id.id, self.name))
        sequence = self.sequence_id.sudo()
        if date:
            sequence = sequence.with_context(ir_sequence_date=fields.Date.to_string(date))
        return sequence.next_by_id(sequence_date=date)

    def action_view_requests(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id(
            'invest_daily_purchase.action_idp_purchase_request')
        action['domain'] = [('project_id', '=', self.id)]
        action['context'] = {'default_project_id': self.id}
        return action

    def action_view_report(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id(
            'invest_daily_purchase.action_idp_purchase_report')
        action['domain'] = [('project_id', '=', self.id)]
        return action
