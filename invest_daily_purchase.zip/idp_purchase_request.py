from markupsafe import Markup, escape

from odoo import _, api, fields, models
from odoo.exceptions import AccessError, UserError, ValidationError
from odoo.tools import format_amount

from .idp_common import (
    BILLING_STATUS, GROUP_ACCOUNTANT, GROUP_MANAGER, GROUP_PROCUREMENT, RECEIPT_STATUS,
    check_groups, qty_compare, qty_is_zero, strip_default_protected, user_has_any,
)

REQUEST_STATES = [
    ('draft', 'Draft'),
    ('submitted', 'Submitted'),
    ('offers', 'Supplier Offers / Selection'),
    ('approval', 'Additional Approvals'),
    ('approved', 'Approved for Purchase'),
    ('rejected', 'Rejected'),
    ('cancel', 'Cancelled'),
]

PROGRESS_STATES = [
    ('draft', 'Draft'),
    ('submitted', 'Submitted'),
    ('offers', 'First-Level Approved / Supplier Offers & Selection'),
    ('approval', 'Second-Level Approved / Additional Approvals'),
    ('approved', 'Approved for Purchase'),
    ('partial_received', 'Partially Received / Completed'),
    ('received', 'Fully Received / Completed'),
    ('partial_billed', 'Partially Billed'),
    ('billed', 'Fully Billed'),
    ('rejected', 'Rejected'),
    ('cancel', 'Cancelled'),
]

# Fields that only the workflow methods may change (they run under sudo).
PROTECTED_FIELDS = {
    'state', 'approval_round', 'approval_ids', 'supplier_purchase_ids', 'revision_ids',
    'cancel_reason', 'name',
}
# Header fields that can only be changed while the request is a draft.
DRAFT_ONLY_FIELDS = {'currency_id', 'company_id', 'requester_id', 'date_request', 'project_id'}
# Header fields procurement may still adjust after submission (no impact on amounts).
POST_SUBMIT_EDITABLE = {'purpose', 'department_id', 'attachment_ids'}



class IdpPurchaseRequest(models.Model):
    _name = 'idp.purchase.request'
    _description = 'Purchase Request'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'date_request desc, id desc'
    _check_company_auto = True

    name = fields.Char(
        string="Request Number", default=lambda self: _('New'), readonly=True, copy=False,
        index='trigram', tracking=True)
    date_request = fields.Date(
        string="Request Date", default=fields.Date.context_today, required=True, tracking=True)
    requester_id = fields.Many2one(
        'res.users', string="Requester", required=True, default=lambda self: self.env.user,
        domain=[('share', '=', False)], tracking=True, index=True)
    department_id = fields.Many2one(
        'hr.department', string="Department", default=lambda self: self._default_department(),
        tracking=True, check_company=True)
    company_id = fields.Many2one(
        'res.company', required=True, default=lambda self: self.env.company, index=True)
    company_currency_id = fields.Many2one(related='company_id.currency_id', string="Company Currency")
    project_id = fields.Many2one(
        'idp.project', string="Project", tracking=True, index=True, check_company=True,
        domain="[('company_id', '=', company_id)]",
        help="The request number is taken from the project's own sequence.")
    project_required = fields.Boolean(related='company_id.idp_project_required')
    purpose = fields.Text(string="Purpose / Justification", tracking=True)
    currency_id = fields.Many2one(
        'res.currency', required=True, tracking=True,
        default=lambda self: self.env.company.currency_id)
    attachment_ids = fields.Many2many(
        'ir.attachment', 'idp_request_attachment_rel', 'request_id', 'attachment_id',
        string="Supporting Attachments")
    line_ids = fields.One2many('idp.purchase.request.line', 'request_id', string="Lines", copy=True)
    quotation_ids = fields.One2many('idp.quotation', 'request_id', string="Supplier Quotations")
    quotation_line_ids = fields.One2many(
        'idp.quotation.line', 'request_id', string="Supplier Offers")

    # ---- approval workflow -------------------------------------------------------------
    state = fields.Selection(
        REQUEST_STATES, string="Approval Status", default='draft', required=True, copy=False,
        tracking=True, index=True)
    approval_round = fields.Integer(default=0, copy=False, readonly=True)
    approval_ids = fields.One2many(
        'idp.request.approval', 'request_id', string="Approval History", copy=False)
    current_round_approval_ids = fields.Many2many(
        'idp.request.approval', compute='_compute_current_round_approvals', string="Approvals")
    current_approval_id = fields.Many2one(
        'idp.request.approval', compute='_compute_current_approval', store=True,
        string="Pending Approval Step")
    current_level_id = fields.Many2one(
        'idp.approval.level', related='current_approval_id.level_id', store=True,
        string="Pending Level")
    revision_ids = fields.One2many('idp.request.revision', 'request_id', copy=False)
    revision_count = fields.Integer(compute='_compute_counts')
    cancel_reason = fields.Text(copy=False, readonly=True)

    # ---- amounts ------------------------------------------------------------------------
    amount_estimated = fields.Monetary(
        string="Estimated Total", compute='_compute_amounts', store=True)
    amount_selected = fields.Monetary(
        string="Selected Supplier Total", compute='_compute_amounts', store=True,
        help="Untaxed total of awarded supplier offers converted into the request currency "
             "at each quotation's date.")
    amount_variance = fields.Monetary(
        string="Selected vs Estimated", compute='_compute_amounts', store=True)
    limit_amount = fields.Monetary(
        related='company_id.idp_amount_limit', currency_field='limit_currency_id',
        string="Mandatory Offers Limit")
    limit_currency_id = fields.Many2one(
        'res.currency', related='company_id.idp_limit_currency_id', string="Limit Currency")
    threshold_basis_amount = fields.Monetary(
        string="Threshold Basis (today)", compute='_compute_threshold',
        currency_field='limit_currency_id')
    threshold_exceeded = fields.Boolean(
        string="Above Limit", compute='_compute_threshold', search='_search_threshold_exceeded')
    offers_blocked = fields.Boolean(
        string="Blocked by Missing Offers", compute='_compute_threshold',
        search='_search_offers_blocked')
    idp_blocking_message = fields.Text(compute='_compute_threshold')
    comparison_html = fields.Html(
        string="Offer Comparison", compute='_compute_comparison_html', sanitize=False)

    # ---- receiving / billing status -------------------------------------------------------
    receipt_status = fields.Selection(
        RECEIPT_STATUS, string="Receipt / Completion Status", compute='_compute_statuses',
        store=True)
    billing_status = fields.Selection(
        BILLING_STATUS, compute='_compute_statuses', store=True)
    progress_status = fields.Selection(
        PROGRESS_STATES, string="Progress", compute='_compute_statuses', store=True, index=True)
    has_billable = fields.Boolean(compute='_compute_statuses', store=True)

    supplier_purchase_ids = fields.One2many(
        'idp.supplier.purchase', 'request_id', string="Supplier Purchases", copy=False)
    receipt_ids = fields.One2many('idp.receipt', 'request_id', string="Receipts", copy=False)
    bill_ids = fields.Many2many(
        'account.move', compute='_compute_bills', string="Vendor Bills", compute_sudo=True)
    quotation_count = fields.Integer(compute='_compute_counts')
    purchase_count = fields.Integer(compute='_compute_counts')
    grn_count = fields.Integer(compute='_compute_counts')
    coc_count = fields.Integer(compute='_compute_counts')
    acceptance_count = fields.Integer(compute='_compute_counts')
    bill_count = fields.Integer(compute='_compute_counts')

    # ---- UI helpers ---------------------------------------------------------------------
    can_approve = fields.Boolean(compute='_compute_can_approve', search='_search_can_approve')
    can_amend = fields.Boolean(compute='_compute_can_amend')
    is_amendment = fields.Boolean(compute='_compute_counts')

    # -------------------------------------------------------------------------------------
    # Defaults / computes
    # -------------------------------------------------------------------------------------
    @api.model
    def _default_department(self):
        employee = self.env['hr.employee'].sudo().search(
            [('user_id', '=', self.env.uid), ('company_id', 'in', [False, self.env.company.id])],
            limit=1)
        return employee.department_id

    @api.onchange('requester_id')
    def _onchange_requester_id(self):
        if self.requester_id:
            employee = self.env['hr.employee'].sudo().search(
                [('user_id', '=', self.requester_id.id)], limit=1)
            if employee.department_id:
                self.department_id = employee.department_id

    @api.depends('approval_ids.round', 'approval_round')
    def _compute_current_round_approvals(self):
        for request in self:
            request.current_round_approval_ids = request.approval_ids.filtered(
                lambda a: a.round == request.approval_round).sorted('position')

    @api.depends('approval_ids.state', 'approval_ids.round', 'approval_ids.position',
                 'approval_round', 'state')
    def _compute_current_approval(self):
        for request in self:
            pending = request.approval_ids.filtered(
                lambda a: a.round == request.approval_round and a.state == 'pending')
            if request.state in ('submitted', 'offers', 'approval') and pending:
                request.current_approval_id = pending.sorted(lambda a: (a.position, a.id))[0]
            else:
                request.current_approval_id = False

    @api.depends('line_ids.est_subtotal', 'line_ids.cancelled', 'line_ids.selected_amount')
    def _compute_amounts(self):
        for request in self:
            lines = request.line_ids.filtered(lambda line: not line.cancelled)
            request.amount_estimated = sum(lines.mapped('est_subtotal'))
            request.amount_selected = sum(lines.mapped('selected_amount'))
            request.amount_variance = request.amount_selected - request.amount_estimated

    @api.depends_context('uid')
    @api.depends('state', 'line_ids', 'quotation_line_ids', 'company_id')
    def _compute_threshold(self):
        for request in self:
            request.threshold_basis_amount = 0.0
            request.threshold_exceeded = False
            request.offers_blocked = False
            request.idp_blocking_message = False
            if not request.id or not request.company_id:
                continue
            data = request._idp_threshold_data()
            request.threshold_basis_amount = data['basis_amount']
            request.threshold_exceeded = data['exceeded']
            if request.state == 'offers':
                issues, _data, offers_missing = request._idp_second_level_issues()
                request.offers_blocked = offers_missing
                if issues:
                    header = self._idp_block_message() if offers_missing else _(
                        "Second-level approval is not yet possible:")
                    request.idp_blocking_message = header + "\n" + "\n".join(
                        "• %s" % issue for issue in issues)

    def _search_threshold_exceeded(self, operator, value):
        return self._idp_search_python_flag('threshold_exceeded', operator, value,
                                            [('state', 'not in', ('cancel',))])

    def _search_offers_blocked(self, operator, value):
        return self._idp_search_python_flag('offers_blocked', operator, value,
                                            [('state', '=', 'offers')])

    def _idp_search_python_flag(self, fname, operator, value, base_domain):
        if operator != 'in':
            return NotImplemented
        candidates = self.search(base_domain)
        matching = candidates.filtered(fname)
        if True in value:
            return [('id', 'in', matching.ids)]
        return [('id', 'not in', matching.ids)]

    @api.depends_context('uid')
    @api.depends('current_approval_id')
    def _compute_can_approve(self):
        for request in self:
            approval = request.current_approval_id
            request.can_approve = bool(
                approval and approval.level_id._idp_user_can_approve(self.env.user))

    def _search_can_approve(self, operator, value):
        if operator != 'in':
            return NotImplemented
        levels = self.env['idp.approval.level'].sudo().search([]).filtered(
            lambda level: level._idp_user_can_approve(self.env.user))
        domain = [('state', 'in', ('submitted', 'offers', 'approval')),
                  ('current_level_id', 'in', levels.ids)]
        if True in value:
            return domain
        return [('id', 'not in', self.search(domain).ids)]

    @api.depends_context('uid')
    @api.depends('state')
    def _compute_can_amend(self):
        is_procurement = user_has_any(self.env, GROUP_PROCUREMENT, GROUP_MANAGER)
        for request in self:
            request.can_amend = is_procurement and request.state not in ('rejected', 'cancel')

    @api.depends(
        'state',
        'supplier_purchase_ids.state',
        'supplier_purchase_ids.line_ids.product_qty',
        'supplier_purchase_ids.line_ids.qty_received',
        'supplier_purchase_ids.line_ids.qty_billed',
        'supplier_purchase_ids.line_ids.qty_to_bill',
    )
    def _compute_statuses(self):
        for request in self:
            lines = request.supplier_purchase_ids.filtered(
                lambda p: p.state != 'cancel').line_ids.filtered(
                lambda line: not line.cancelled and not qty_is_zero(self.env, line.product_qty))
            received_any = any(not qty_is_zero(self.env, line.qty_received) for line in lines)
            received_all = bool(lines) and all(
                qty_compare(self.env, line.qty_received, line.product_qty) >= 0 for line in lines)
            billed_any = any(not qty_is_zero(self.env, line.qty_billed) for line in lines)
            billed_all = bool(lines) and all(
                qty_compare(self.env, line.qty_billed, line.product_qty) >= 0 for line in lines)
            request.receipt_status = 'full' if received_all else ('partial' if received_any else 'no')
            request.billing_status = 'full' if billed_all else ('partial' if billed_any else 'no')
            request.has_billable = any(
                not qty_is_zero(self.env, line.qty_to_bill) for line in lines)
            if request.state != 'approved':
                request.progress_status = request.state
            elif billed_all:
                request.progress_status = 'billed'
            elif billed_any:
                request.progress_status = 'partial_billed'
            elif received_all:
                request.progress_status = 'received'
            elif received_any:
                request.progress_status = 'partial_received'
            else:
                request.progress_status = 'approved'

    def _compute_bills(self):
        for request in self:
            if not request._origin.id:
                request.bill_ids = False
                continue
            request.bill_ids = self.env['account.move.line'].sudo().search([
                ('idp_purchase_line_id.purchase_id.request_id', '=', request._origin.id),
            ]).move_id.filtered(lambda m: m.move_type in ('in_invoice', 'in_refund'))

    def _compute_counts(self):
        for request in self:
            request.quotation_count = len(request.quotation_ids)
            request.purchase_count = len(request.supplier_purchase_ids)
            request.grn_count = len(request.receipt_ids.filtered(lambda r: r.receipt_type == 'grn'))
            request.coc_count = len(request.receipt_ids.filtered(lambda r: r.receipt_type == 'coc'))
            request.acceptance_count = len(
                request.receipt_ids.filtered(lambda r: r.receipt_type == 'acceptance'))
            request.bill_count = len(request.sudo().bill_ids)
            request.revision_count = len(request.revision_ids)
            request.is_amendment = bool(request.supplier_purchase_ids.filtered(
                lambda p: p.state == 'on_hold'))

    @api.depends('quotation_line_ids.comparable_price_unit', 'quotation_line_ids.awarded_qty',
                 'line_ids', 'currency_id')
    def _compute_comparison_html(self):
        for request in self:
            request.comparison_html = request._idp_render_comparison()

    def _idp_render_comparison(self):
        self.ensure_one()
        qlines = self.quotation_line_ids.filtered(lambda q: q.quotation_state != 'cancel')
        if not qlines:
            return Markup('<p class="text-muted">%s</p>') % _("No supplier offers recorded yet.")
        partners = qlines.partner_id.sorted('name')
        head = Markup('').join(
            Markup('<th class="text-center">%s</th>') % partner.display_name for partner in partners)
        rows = []
        for line in self.line_ids.sorted(lambda r: (r.sequence, r.id)):
            line_q = qlines.filtered(lambda q: q.request_line_id == line)
            cells = []
            for partner in partners:
                offers = line_q.filtered(lambda q: q.partner_id == partner)
                if not offers:
                    cells.append(Markup('<td class="text-center text-muted">-</td>'))
                    continue
                parts = []
                for offer in offers:
                    style = 'background-color:#d1e7dd;' if offer.is_lowest else ''
                    awarded = ''
                    if not qty_is_zero(self.env, offer.awarded_qty):
                        awarded = Markup('<br/><b>&#10003; %s %s</b>') % (
                            _("Awarded"), offer.awarded_qty)
                    original = ''
                    if offer.currency_id != self.currency_id:
                        original = Markup('<br/><small class="text-muted">%s</small>') % (
                            format_amount(self.env, offer.price_unit, offer.currency_id))
                    parts.append(Markup('<div style="%s padding:2px 4px;">%s%s%s</div>') % (
                        style,
                        format_amount(self.env, offer.comparable_price_unit, self.currency_id),
                        original, awarded))
                cells.append(Markup('<td class="text-end">%s</td>') % Markup('').join(parts))
            label = escape(line.name or '')
            if line.cancelled:
                label = Markup('<s>%s</s>') % label
            rows.append(Markup('<tr><td>%s<br/><small class="text-muted">%s %s</small></td>%s</tr>') % (
                label, line.quantity, line.uom_id.name or '', Markup('').join(cells)))
        legend = _("Comparable unit prices in %(currency)s (net of discount, excluding taxes, "
                   "converted at each quotation date). Lowest comparable price highlighted in "
                   "green. The lowest offer is never selected automatically.",
                   currency=self.currency_id.name)
        return Markup(
            '<table class="table table-sm table-bordered o_idp_comparison">'
            '<thead><tr><th>%s</th>%s</tr></thead><tbody>%s</tbody></table>'
            '<p class="text-muted small">%s</p>') % (
            _("Request Line"), head, Markup('').join(rows), legend)

    # -------------------------------------------------------------------------------------
    # ORM overrides
    # -------------------------------------------------------------------------------------
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not self.env.su:
                vals.pop('name', None)
                forbidden = strip_default_protected(vals, PROTECTED_FIELDS)
                if forbidden:
                    raise AccessError(_("Workflow fields cannot be set directly: %s",
                                        ", ".join(sorted(forbidden))))
            company = self.env['res.company'].browse(vals.get('company_id')) or self.env.company
            project = self.env['idp.project'].browse(vals.get('project_id'))
            vals['name'] = self._idp_new_number(company, project, vals.get('date_request'))
        return super().create(vals_list)

    @api.model
    def _idp_new_number(self, company, project, date=None):
        date = fields.Date.to_date(date) if date else fields.Date.context_today(self)
        if project:
            return project._idp_next_request_number(date)
        return company._idp_next_number('request', date)

    def write(self, vals):
        if not self.env.su:
            forbidden = PROTECTED_FIELDS.intersection(vals)
            if forbidden:
                raise AccessError(_(
                    "Workflow fields cannot be changed directly; use the request actions. (%s)",
                    ", ".join(sorted(forbidden))))
            for request in self:
                if request.state == 'draft':
                    continue
                touched = set(vals) - {'message_main_attachment_id'}
                if DRAFT_ONLY_FIELDS & touched:
                    raise UserError(_(
                        "Request %s has been submitted: currency, company, requester and date "
                        "can only be changed after it is returned to draft.", request.name))
                if touched & POST_SUBMIT_EDITABLE:
                    if request.state in ('rejected', 'cancel'):
                        raise UserError(_("Request %s is closed.", request.name))
                    check_groups(self.env, _(
                        "Only procurement officers can change a submitted request."),
                        GROUP_PROCUREMENT, GROUP_MANAGER)
        renumber = self.env['idp.purchase.request']
        if 'project_id' in vals:
            renumber = self.filtered(
                lambda r: r.state == 'draft' and r.project_id.id != (vals['project_id'] or False))
        res = super().write(vals)
        for request in renumber:
            old_name = request.name
            new_name = self._idp_new_number(request.company_id, request.project_id,
                                            request.date_request)
            request.sudo().write({'name': new_name})
            request.message_post(body=_("Project changed: request renumbered from %(old)s to "
                                        "%(new)s.", old=old_name, new=new_name))
        return res

    @api.ondelete(at_uninstall=False)
    def _unlink_except_confirmed(self):
        for request in self:
            if request.state != 'draft' or request.approval_ids or request.supplier_purchase_ids:
                raise UserError(_(
                    "Request %s cannot be deleted once it has been submitted. "
                    "Cancel it with a reason instead.", request.name))

    def copy_data(self, default=None):
        vals_list = super().copy_data(default=default)
        for vals in vals_list:
            vals.pop('name', None)
        return vals_list

    # -------------------------------------------------------------------------------------
    # Threshold & second-level checks
    # -------------------------------------------------------------------------------------
    def _idp_awarded_offers(self):
        return self.quotation_line_ids.filtered(lambda q: q._idp_is_awarded())

    def _idp_threshold_data(self, date=None):
        """Evaluate the request against the mandatory-offer limit.

        Uses the higher of the estimated total and the selected supplier total, both converted
        to the limit currency with the system rate of ``date`` (the approval date)."""
        self.ensure_one()
        company = self.company_id
        Currency = self.env['res.currency']
        limit_currency = company._idp_limit_currency()
        date = date or fields.Date.context_today(self)
        estimated = self.currency_id._convert(
            self.amount_estimated, limit_currency, company, date)
        rates = {self.currency_id: Currency._get_conversion_rate(
            self.currency_id, limit_currency, company, date)}
        selected = 0.0
        for offer in self._idp_awarded_offers():
            amount = offer.awarded_total if company.idp_limit_tax_mode == 'included' \
                else offer.awarded_subtotal
            selected += offer.currency_id._convert(amount, limit_currency, company, date)
            if offer.currency_id not in rates:
                rates[offer.currency_id] = Currency._get_conversion_rate(
                    offer.currency_id, limit_currency, company, date)
        basis = max(estimated, selected)
        exceeded = limit_currency.compare_amounts(basis, company.idp_amount_limit) > 0
        return {
            'date': date,
            'limit_currency': limit_currency,
            'limit_amount': company.idp_amount_limit,
            'estimated_amount': estimated,
            'selected_amount': selected,
            'basis_amount': basis,
            'exceeded': exceeded,
            'rate': rates[self.currency_id],
            'rates': rates,
        }

    @api.model
    def _idp_threshold_vals(self, data):
        details = "\n".join(
            "1 %s = %.8f %s" % (cur.name, rate, data['limit_currency'].name)
            for cur, rate in data['rates'].items())
        return {
            'threshold_checked': True,
            'limit_currency_id': data['limit_currency'].id,
            'limit_amount': data['limit_amount'],
            'estimated_amount_limit': data['estimated_amount'],
            'selected_amount_limit': data['selected_amount'],
            'basis_amount': data['basis_amount'],
            'threshold_exceeded': data['exceeded'],
            'rate_date': data['date'],
            'rate_used': data['rate'],
            'rate_details': details,
        }

    def _idp_second_level_issues(self, date=None):
        """Return (issues, threshold data, offers_missing) for second-level approval."""
        self.ensure_one()
        env = self.env
        date = date or fields.Date.context_today(self)
        issues = []
        data = self._idp_threshold_data(date)
        lines = self.line_ids.filtered(lambda line: not line.cancelled)
        if not lines:
            issues.append(_("The request has no active lines."))
        for line in lines:
            if qty_compare(env, line.awarded_qty, line.quantity) != 0:
                issues.append(_(
                    "Line '%(line)s': awarded quantity %(awarded)s must equal the requested "
                    "quantity %(requested)s.",
                    line=line.name, awarded=line.awarded_qty, requested=line.quantity))
        awarded = self._idp_awarded_offers()
        for offer in awarded:
            if offer.currency_id.compare_amounts(offer.price_unit, 0.0) <= 0:
                issues.append(_("Offer of %(supplier)s for '%(line)s' has no agreed unit price.",
                                supplier=offer.partner_id.display_name,
                                line=offer.request_line_id.name))
            if offer.needs_justification and not (offer.justification or '').strip():
                issues.append(_(
                    "Offer of %(supplier)s for '%(line)s' is not the lowest comparable price: "
                    "enter a justification.",
                    supplier=offer.partner_id.display_name, line=offer.request_line_id.name))
        offers_missing = False
        if data['exceeded']:
            min_offers = max(self.company_id.idp_min_offers, 1)
            for line in lines:
                line_offers = line.quotation_line_ids
                valid_suppliers = line_offers.filtered(
                    lambda q: q._idp_is_valid_offer(date) and q.has_attachment).partner_id
                if len(valid_suppliers) < min_offers:
                    offers_missing = True
                    issues.append(_(
                        "Line '%(line)s': %(count)s valid attached supplier offer(s) recorded, "
                        "%(required)s required.",
                        line=line.name, count=len(valid_suppliers), required=min_offers))
                for offer in line_offers.filtered(lambda q: q._idp_is_awarded()):
                    if not (offer._idp_is_valid_offer(date) and offer.has_attachment):
                        offers_missing = True
                        issues.append(_(
                            "Awarded offer of %(supplier)s for '%(line)s' must be valid and have "
                            "the supplier quotation attached.",
                            supplier=offer.partner_id.display_name, line=line.name))
        return issues, data, offers_missing

    def _idp_signature_rows(self):
        """Rows printed in the signature block: requester, then every approval level.

        Approved levels show the approver and date; pending levels are left blank so the
        printed document can be signed by hand."""
        self.ensure_one()
        self = self.sudo()  # approval data is printed on the document for every reader
        rows = [{
            'label': _("Requested by"),
            'name': self.requester_id.name,
            'date': self.date_request,
            'status': False,
        }]
        steps = self.current_round_approval_ids.filtered(
            lambda a: a.state != 'invalidated').sorted(lambda a: (a.position, a.id))
        if steps:
            seen = set()
            for step in steps:
                if step.position in seen:
                    continue
                seen.add(step.position)
                # prefer the approved step of a level when several exist in the round
                same = steps.filtered(lambda a: a.position == step.position)
                step = same.filtered(lambda a: a.state == 'approved')[:1] or same[-1]
                approved = step.state == 'approved'
                rows.append({
                    'label': step.name,
                    'name': step.user_id.name if approved else False,
                    'date': fields.Datetime.context_timestamp(self, step.date).date()
                    if approved and step.date else False,
                    'status': dict(step._fields['state'].selection).get(step.state)
                    if step.state != 'pending' else False,
                })
        else:
            for level in self.env['idp.approval.level']._idp_get_levels(self.company_id):
                rows.append({'label': level.name, 'name': False, 'date': False,
                             'status': False})
        return rows

    @api.model
    def _idp_block_message(self):
        return _("Second-level approval is blocked because this purchase exceeds the configured "
                 "limit. Upload the required supplier offers and complete supplier pricing and "
                 "selection.")

    # -------------------------------------------------------------------------------------
    # Workflow
    # -------------------------------------------------------------------------------------
    def _idp_current_round(self):
        self.ensure_one()
        return self.approval_ids.filtered(lambda a: a.round == self.approval_round)

    def _idp_check_owner_or_procurement(self):
        for request in self:
            if self.env.su or request.requester_id == self.env.user \
                    or request.create_uid == self.env.user:
                continue
            check_groups(self.env, _("Only the requester or a procurement officer can do this."),
                         GROUP_PROCUREMENT, GROUP_MANAGER)

    def _idp_check_submittable(self):
        self.ensure_one()
        if self.company_id.idp_project_required and not self.project_id:
            raise UserError(_("Select the project of request %s before submitting.", self.name))
        if self.project_id and not self.project_id.active:
            raise UserError(_("Project %s is archived.", self.project_id.display_name))
        if not (self.purpose or '').strip():
            raise UserError(_("Enter the purchase purpose / justification before submitting."))
        lines = self.line_ids.filtered(lambda line: not line.cancelled)
        if not lines:
            raise UserError(_("Add at least one request line before submitting."))
        for line in lines:
            if qty_compare(self.env, line.quantity, 0.0) <= 0:
                raise UserError(_("Line '%s' must have a positive quantity.", line.name))
            if line.est_price_unit < 0:
                raise UserError(_("Line '%s' cannot have a negative estimated price.", line.name))
            if not line.uom_id:
                raise UserError(_("Line '%s' needs a unit of measure.", line.name))

    def action_submit(self):
        self._idp_check_owner_or_procurement()
        Level = self.env['idp.approval.level']
        for request in self:
            if request.state != 'draft':
                raise UserError(_("Only draft requests can be submitted."))
            request._idp_check_submittable()
            levels = Level._idp_get_levels(request.company_id)
            if len(levels) < 2:
                raise UserError(_(
                    "At least two active approval levels must be configured for %s before "
                    "requests can be submitted.", request.company_id.name))
            new_round = request.approval_round + 1
            self.env['idp.request.approval'].sudo().create([{
                'request_id': request.id,
                'level_id': level.id,
                'name': level.name,
                'position': position,
                'round': new_round,
            } for position, level in enumerate(levels, start=1)])
            request.sudo().write({'state': 'submitted', 'approval_round': new_round})
            request.message_post(body=_("Request submitted for approval (round %s).", new_round))
        return True

    def action_open_approval_wizard(self):
        self.ensure_one()
        action_type = self.env.context.get('idp_action', 'approve')
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'idp.request.action.wizard',
            'view_mode': 'form',
            'target': 'new',
            'name': {
                'approve': _("Approve"),
                'reject': _("Reject"),
                'return': _("Return for Correction"),
            }.get(action_type, _("Approve")),
            'context': {'default_request_id': self.id, 'default_action': action_type},
        }

    def action_open_cancel_wizard(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'idp.cancel.wizard',
            'view_mode': 'form',
            'target': 'new',
            'name': _("Cancel Request"),
            'context': {'default_res_model': self._name, 'default_res_id': self.id},
        }

    def _idp_get_pending_approval_checked(self):
        self.ensure_one()
        if self.state not in ('submitted', 'offers', 'approval'):
            raise UserError(_("Request %s is not waiting for approval.", self.name))
        approval = self.current_approval_id
        if not approval:
            raise UserError(_("Request %s has no pending approval step.", self.name))
        if not approval.level_id._idp_user_can_approve(self.env.user):
            raise AccessError(_(
                "You are not authorized to act on approval level '%(level)s' of %(request)s.",
                level=approval.name, request=self.name))
        return approval

    def _idp_action_approve(self, comment=False):
        self.ensure_one()
        approval = self._idp_get_pending_approval_checked()
        today = fields.Date.context_today(self)
        if approval.is_offer_gate:
            issues, data, offers_missing = self._idp_second_level_issues(today)
            if issues:
                header = self._idp_block_message() if offers_missing else _(
                    "Second-level approval is blocked:")
                raise UserError(header + "\n" + "\n".join("• %s" % i for i in issues))
        else:
            data = self._idp_threshold_data(today)
        vals = dict(self._idp_threshold_vals(data), state='approved', user_id=self.env.uid,
                    date=fields.Datetime.now(), comment=comment or False)
        approval.sudo().write(vals)
        body = _("Approval level '%(level)s' approved.", level=approval.name)
        if comment:
            body += Markup("<br/>") + escape(comment)
        if approval.position == 1 and data['exceeded']:
            body += Markup("<br/>") + _(
                "Purchase amount %(amount)s exceeds the limit %(limit)s: %(count)s supplier "
                "offer(s) are mandatory before second-level approval.",
                amount=format_amount(self.env, data['basis_amount'], data['limit_currency']),
                limit=format_amount(self.env, data['limit_amount'], data['limit_currency']),
                count=self.company_id.idp_min_offers)
        self.message_post(body=body)
        self.invalidate_recordset(['current_approval_id'])
        next_step = self.current_approval_id
        if not next_step:
            self._idp_finalize()
        else:
            self.sudo().write({'state': 'offers' if next_step.is_offer_gate else 'approval'})
        return True

    def _idp_action_reject(self, comment):
        self.ensure_one()
        if not (comment or '').strip():
            raise UserError(_("A comment is mandatory to reject a request."))
        approval = self._idp_get_pending_approval_checked()
        if self.supplier_purchase_ids.filtered(lambda p: p.state != 'cancel'):
            raise UserError(_(
                "This request already has confirmed supplier purchases (amendment in progress). "
                "Return it for correction instead of rejecting it."))
        approval.sudo().write({'state': 'rejected', 'user_id': self.env.uid,
                               'date': fields.Datetime.now(), 'comment': comment})
        self._idp_current_round().filtered(lambda a: a.state == 'pending').sudo().write(
            {'state': 'invalidated', 'invalidation_reason': _("Request rejected.")})
        self.sudo().write({'state': 'rejected'})
        self.message_post(body=_("Rejected at level '%(level)s': %(comment)s",
                                 level=approval.name, comment=comment))
        return True

    def _idp_action_return(self, comment, return_to='draft'):
        self.ensure_one()
        if not (comment or '').strip():
            raise UserError(_("A comment is mandatory to return a request for correction."))
        approval = self._idp_get_pending_approval_checked()
        now = fields.Datetime.now()
        current = self._idp_current_round()
        if return_to == 'draft':
            if self.supplier_purchase_ids.filtered(lambda p: p.state != 'cancel'):
                raise UserError(_(
                    "Supplier purchases already exist for this request: return it to the "
                    "supplier offers stage instead of draft."))
            approval.sudo().write({'state': 'returned', 'user_id': self.env.uid, 'date': now,
                                   'comment': comment})
            (current.filtered(lambda a: a.state == 'pending') - approval).sudo().write(
                {'state': 'invalidated', 'invalidation_reason': _("Returned to draft.")})
            self.sudo().write({'state': 'draft'})
        else:
            if approval.position < 2:
                raise UserError(_(
                    "The supplier offers stage has not been reached yet; return the request "
                    "to draft instead."))
            approval.sudo().write({'state': 'returned', 'user_id': self.env.uid, 'date': now,
                                   'comment': comment})
            others = current.filtered(
                lambda a: a.position >= 2 and a.state in ('pending', 'approved')) - approval
            others.sudo().write({'state': 'invalidated', 'invalidation_reason': _(
                "Returned for correction at level '%s'.", approval.name)})
            self._idp_recreate_pending(current.filtered(lambda a: a.position >= 2))
            self.sudo().write({'state': 'offers'})
        self.message_post(body=_("Returned for correction at level '%(level)s': %(comment)s",
                                 level=approval.name, comment=comment))
        return True

    def _idp_recreate_pending(self, approvals):
        """Create fresh pending steps (same round) for the levels of ``approvals``."""
        self.ensure_one()
        seen = set()
        vals_list = []
        for approval in approvals.sorted('position'):
            if approval.position in seen:
                continue
            seen.add(approval.position)
            vals_list.append({
                'request_id': self.id,
                'level_id': approval.level_id.id,
                'name': approval.name,
                'position': approval.position,
                'round': self.approval_round,
            })
        if vals_list:
            self.env['idp.request.approval'].sudo().create(vals_list)

    def _idp_finalize(self):
        """All approval levels completed: confirm offers and create supplier purchases."""
        self.ensure_one()
        issues, _data, _missing = self._idp_second_level_issues()
        if issues:
            raise UserError(_("The request cannot be finalized:\n%s",
                              "\n".join("• %s" % i for i in issues)))
        self.sudo()._idp_sync_supplier_purchases()
        self.sudo().write({'state': 'approved'})
        self.message_post(body=_(
            "All approval levels completed. Supplier offers confirmed and supplier purchases "
            "created/updated."))

    def _idp_sync_supplier_purchases(self):
        """Create or update supplier purchases from the awarded offers.

        Purchases are grouped by supplier, company and currency and hold only the quantities
        and prices awarded to that supplier."""
        self.ensure_one()
        Purchase = self.env['idp.supplier.purchase']
        PurchaseLine = self.env['idp.supplier.purchase.line']
        existing_lines = self.supplier_purchase_ids.line_ids.filtered(lambda l: not l.cancelled)
        kept = PurchaseLine
        for offer in self._idp_awarded_offers().sorted(
                lambda q: (q.partner_id.id, q.request_line_id.sequence, q.id)):
            vals = offer._idp_prepare_purchase_line_vals()
            sp_line = existing_lines.filtered(lambda l: l.quotation_line_id == offer)[:1]
            if sp_line and sp_line.purchase_id.partner_id == offer.partner_id \
                    and sp_line.purchase_id.currency_id == offer.currency_id:
                sp_line.write(vals)
                kept |= sp_line
                continue
            if sp_line:
                sp_line._idp_retire()
            purchase = self.supplier_purchase_ids.filtered(
                lambda p: p.partner_id == offer.partner_id
                and p.currency_id == offer.currency_id and p.state != 'cancel')[:1]
            if not purchase:
                purchase = Purchase.create({
                    'request_id': self.id,
                    'partner_id': offer.partner_id.id,
                    'company_id': self.company_id.id,
                    'currency_id': offer.currency_id.id,
                })
            kept |= PurchaseLine.create(dict(vals, purchase_id=purchase.id,
                                             quotation_line_id=offer.id))
        (existing_lines - kept)._idp_retire()
        for purchase in self.supplier_purchase_ids:
            active_lines = purchase.line_ids.filtered(lambda l: not l.cancelled)
            if not active_lines:
                purchase.write({'state': 'cancel'})
            elif purchase.state != 'cancel':
                purchase.write({'state': 'confirmed'})
        return True

    # -------------------------------------------------------------------------------------
    # Amendments / re-approval
    # -------------------------------------------------------------------------------------
    def _idp_check_edit_rights(self, what=None):
        """Raise unless the current user may change lines / offers of these requests."""
        if self.env.su:
            return
        for request in self:
            if request.state in ('rejected', 'cancel'):
                raise UserError(_("Request %s is closed and cannot be modified.", request.name))
            if request.state == 'draft' and what == 'lines':
                continue
            check_groups(self.env, _(
                "Only procurement officers can change request %s after submission.",
                request.name), GROUP_PROCUREMENT, GROUP_MANAGER)

    def _idp_needs_invalidation(self, from_position):
        self.ensure_one()
        return bool(self._idp_current_round().filtered(
            lambda a: a.position >= from_position and a.state == 'approved'))

    def _idp_prepare_invalidation(self, from_position, reason):
        """Snapshot requests whose approvals will be invalidated by a pending change."""
        requests = self.filtered(lambda r: r._idp_needs_invalidation(from_position))
        for request in requests:
            request._idp_create_revision(reason)
        return requests

    def _idp_invalidate_approvals(self, from_position, reason):
        for request in self:
            current = request._idp_current_round()
            affected = current.filtered(
                lambda a: a.position >= from_position and a.state in ('approved', 'pending'))
            if not affected.filtered(lambda a: a.state == 'approved'):
                continue
            affected.sudo().write({'state': 'invalidated', 'invalidation_reason': reason})
            request._idp_recreate_pending(affected)
            new_state = {1: 'submitted', 2: 'offers'}.get(from_position, 'approval')
            request.sudo().write({'state': new_state})
            on_hold = request.supplier_purchase_ids.filtered(lambda p: p.state == 'confirmed')
            on_hold.sudo().write({'state': 'on_hold'})
            request.message_post(body=_(
                "Approvals from level %(position)s onward were invalidated: %(reason)s. "
                "Re-approval is required.", position=from_position, reason=reason))

    def _idp_create_revision(self, reason):
        self.ensure_one()
        self.env['idp.request.revision'].sudo().create({
            'request_id': self.id,
            'round': self.approval_round,
            'reason': reason,
            'snapshot': self._idp_render_snapshot(),
        })

    def _idp_render_snapshot(self):
        self.ensure_one()
        line_rows = Markup('').join(
            Markup('<tr><td>%s</td><td>%s</td><td>%s</td><td class="text-end">%s</td>'
                   '<td class="text-end">%s</td><td>%s</td></tr>') % (
                line.name, dict(line._fields['line_type'].selection).get(line.line_type),
                line.uom_id.name or '', line.quantity,
                format_amount(self.env, line.est_price_unit, self.currency_id),
                _("Cancelled") if line.cancelled else '')
            for line in self.line_ids)
        offer_rows = Markup('').join(
            Markup('<tr><td>%s</td><td>%s</td><td class="text-end">%s</td>'
                   '<td class="text-end">%s</td><td class="text-end">%s%%</td><td>%s</td>'
                   '<td>%s</td></tr>') % (
                offer.request_line_id.name, offer.partner_id.display_name, offer.awarded_qty,
                format_amount(self.env, offer.price_unit, offer.currency_id), offer.discount,
                ", ".join(offer.tax_ids.mapped('name')),
                ", ".join(offer.quotation_id.attachment_ids.mapped('name')))
            for offer in self._idp_awarded_offers())
        approval_rows = Markup('').join(
            Markup('<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>') % (
                approval.name, dict(approval._fields['state'].selection).get(approval.state),
                approval.user_id.name or '', approval.date or '')
            for approval in self._idp_current_round())
        return Markup(
            '<h5>%s</h5><table class="table table-sm"><thead><tr><th>%s</th><th>%s</th>'
            '<th>%s</th><th>%s</th><th>%s</th><th></th></tr></thead><tbody>%s</tbody></table>'
            '<h5>%s</h5><table class="table table-sm"><thead><tr><th>%s</th><th>%s</th>'
            '<th>%s</th><th>%s</th><th>%s</th><th>%s</th><th>%s</th></tr></thead><tbody>%s'
            '</tbody></table><h5>%s</h5><table class="table table-sm"><tbody>%s</tbody></table>'
        ) % (
            _("Request Lines"), _("Description"), _("Type"), _("UoM"), _("Quantity"),
            _("Est. Price"), line_rows,
            _("Awarded Offers"), _("Line"), _("Supplier"), _("Awarded Qty"), _("Unit Price"),
            _("Discount"), _("Taxes"), _("Attachments"), offer_rows,
            _("Approvals"), approval_rows)

    # -------------------------------------------------------------------------------------
    # Cancellation / reset
    # -------------------------------------------------------------------------------------
    def _idp_action_cancel(self, reason):
        for request in self:
            if request.state == 'cancel':
                continue
            if request.state == 'draft':
                request._idp_check_owner_or_procurement()
            else:
                check_groups(self.env, _("Only procurement officers can cancel a submitted "
                                         "request."), GROUP_PROCUREMENT, GROUP_MANAGER)
            if request.receipt_ids.filtered(lambda r: r.state in ('verified', 'done')):
                raise UserError(_(
                    "Request %s has confirmed receipts or certificates; cancel them first.",
                    request.name))
            if request.sudo().bill_ids.filtered(lambda m: m.state != 'cancel'):
                raise UserError(_("Request %s has vendor bills.", request.name))
            request.receipt_ids.filtered(lambda r: r.state == 'draft').sudo().write(
                {'state': 'cancel', 'cancel_reason': reason})
            request._idp_current_round().filtered(lambda a: a.state == 'pending').sudo().write(
                {'state': 'invalidated', 'invalidation_reason': _("Request cancelled.")})
            request.supplier_purchase_ids.sudo().write({'state': 'cancel'})
            request.sudo().write({'state': 'cancel', 'cancel_reason': reason})
            request.message_post(body=_("Request cancelled: %s", reason))
        return True

    def action_reset_to_draft(self):
        self._idp_check_owner_or_procurement()
        for request in self:
            if request.state not in ('rejected', 'cancel'):
                raise UserError(_("Only rejected or cancelled requests can be reset to draft."))
            if request.supplier_purchase_ids.filtered(lambda p: p.state != 'cancel'):
                raise UserError(_("Request %s still has supplier purchases.", request.name))
            request.sudo().write({'state': 'draft', 'cancel_reason': False})
            request.message_post(body=_("Request reset to draft."))
        return True

    # -------------------------------------------------------------------------------------
    # Billing
    # -------------------------------------------------------------------------------------
    def action_create_vendor_bill(self):
        check_groups(self.env, _("Only accountants can create vendor bills."),
                     GROUP_ACCOUNTANT, GROUP_MANAGER)
        purchases = self.supplier_purchase_ids.filtered(lambda p: p.state == 'confirmed')
        return purchases.action_create_vendor_bill()

    # -------------------------------------------------------------------------------------
    # Smart buttons
    # -------------------------------------------------------------------------------------
    def _idp_action_open(self, xmlid, records, extra_ctx=None):
        action = self.env['ir.actions.act_window']._for_xml_id(xmlid)
        action['domain'] = [('id', 'in', records.ids)]
        ctx = {'create': False}
        ctx.update(extra_ctx or {})
        action['context'] = ctx
        if len(records) == 1:
            action['views'] = [(False, 'form')]
            action['res_id'] = records.id
        return action

    def action_view_quotations(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id(
            'invest_daily_purchase.action_idp_quotation')
        action['domain'] = [('request_id', '=', self.id)]
        action['context'] = {'default_request_id': self.id}
        return action

    def action_view_comparison(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id(
            'invest_daily_purchase.action_idp_quotation_comparison')
        action['domain'] = [('request_id', '=', self.id)]
        action['context'] = {'search_default_group_request_line': 1}
        return action

    def action_view_purchases(self):
        self.ensure_one()
        return self._idp_action_open('invest_daily_purchase.action_idp_supplier_purchase',
                                     self.supplier_purchase_ids)

    def action_view_grns(self):
        self.ensure_one()
        return self._idp_action_open(
            'invest_daily_purchase.action_idp_grn',
            self.receipt_ids.filtered(lambda r: r.receipt_type == 'grn'))

    def action_view_cocs(self):
        self.ensure_one()
        return self._idp_action_open(
            'invest_daily_purchase.action_idp_coc',
            self.receipt_ids.filtered(lambda r: r.receipt_type == 'coc'))

    def action_view_acceptances(self):
        self.ensure_one()
        return self._idp_action_open(
            'invest_daily_purchase.action_idp_acceptance',
            self.receipt_ids.filtered(lambda r: r.receipt_type == 'acceptance'))

    def action_view_bills(self):
        self.ensure_one()
        return self._idp_action_open('account.action_move_in_invoice_type', self.bill_ids,
                                     {'default_move_type': 'in_invoice'})

    def action_view_revisions(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'idp.request.revision',
            'name': _("Revisions"),
            'view_mode': 'list,form',
            'domain': [('request_id', '=', self.id)],
            'context': {'create': False},
        }

    @api.constrains('company_id', 'department_id')
    def _check_department_company(self):
        for request in self:
            dept_company = request.department_id.company_id
            if dept_company and dept_company != request.company_id:
                raise ValidationError(_("The department belongs to another company."))
