from odoo import _, api, fields, models
from odoo.exceptions import UserError


class IdpRequestActionWizard(models.TransientModel):
    _name = 'idp.request.action.wizard'
    _description = 'Approve / Reject / Return Purchase Request'

    request_id = fields.Many2one('idp.purchase.request', required=True)
    action = fields.Selection(
        [('approve', 'Approve'), ('reject', 'Reject'), ('return', 'Return for Correction')],
        required=True, default='approve')
    level_name = fields.Char(related='request_id.current_approval_id.name', string="Level")
    comment = fields.Text()
    return_to = fields.Selection(
        [('draft', 'Requester (back to draft)'),
         ('offers', 'Procurement (supplier offers / selection)')],
        default='draft')
    can_return_to_offers = fields.Boolean(compute='_compute_can_return_to_offers')
    threshold_info = fields.Text(compute='_compute_threshold_info')

    @api.depends('request_id')
    def _compute_can_return_to_offers(self):
        for wizard in self:
            approval = wizard.request_id.current_approval_id
            wizard.can_return_to_offers = bool(approval and approval.position >= 2)

    @api.depends('request_id', 'action')
    def _compute_threshold_info(self):
        for wizard in self:
            request = wizard.request_id
            if not request:
                wizard.threshold_info = False
                continue
            data = request._idp_threshold_data()
            wizard.threshold_info = _(
                "Threshold basis: %(basis).2f %(cur)s (estimate %(est).2f, selected %(sel).2f) "
                "vs limit %(limit).2f %(cur)s — %(result)s",
                basis=data['basis_amount'], cur=data['limit_currency'].name,
                est=data['estimated_amount'], sel=data['selected_amount'],
                limit=data['limit_amount'],
                result=_("ABOVE limit: supplier offers mandatory") if data['exceeded']
                else _("within limit"))

    def action_confirm(self):
        self.ensure_one()
        request = self.request_id
        if self.action == 'approve':
            request._idp_action_approve(self.comment)
        elif self.action == 'reject':
            request._idp_action_reject(self.comment)
        elif self.action == 'return':
            if self.return_to == 'offers' and not self.can_return_to_offers:
                raise UserError(_("The supplier offers stage has not been reached yet."))
            request._idp_action_return(self.comment, self.return_to or 'draft')
        return {'type': 'ir.actions.act_window_close'}
