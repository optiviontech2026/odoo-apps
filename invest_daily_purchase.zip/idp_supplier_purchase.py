from odoo import _, api, fields, models
from odoo.exceptions import UserError

from .idp_common import (
    BILLING_STATUS, GROUP_ACCOUNTANT, GROUP_MANAGER, GROUP_RECEIVER, GROUP_VERIFIER, LINE_TYPES,
    RECEIPT_METHODS, RECEIPT_STATUS, check_groups, qty_compare, qty_is_zero,
)


class IdpSupplierPurchase(models.Model):
    """Confirmed purchase towards one supplier (equivalent of a purchase order).

    Created only by the final approval of a purchase request; users cannot create or edit
    these records directly."""
    _name = 'idp.supplier.purchase'
    _description = 'Supplier Purchase'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'date_confirmed desc, id desc'
    _check_company_auto = True

    name = fields.Char(string="Purchase Number", readonly=True, copy=False, index='trigram')
    request_id = fields.Many2one(
        'idp.purchase.request', required=True, ondelete='restrict', index=True)
    partner_id = fields.Many2one('res.partner', string="Supplier", required=True, index=True)
    company_id = fields.Many2one('res.company', required=True, index=True)
    currency_id = fields.Many2one('res.currency', required=True)
    date_confirmed = fields.Date(default=fields.Date.context_today, required=True)
    department_id = fields.Many2one(related='request_id.department_id', store=True)
    project_id = fields.Many2one(related='request_id.project_id', store=True, index=True)
    requester_id = fields.Many2one(related='request_id.requester_id', store=True)
    state = fields.Selection(
        [('confirmed', 'Confirmed'), ('on_hold', 'On Hold (Re-approval Pending)'),
         ('cancel', 'Cancelled')], default='confirmed', required=True, tracking=True, index=True)
    line_ids = fields.One2many('idp.supplier.purchase.line', 'purchase_id', string="Lines")
    approval_ids = fields.One2many(related='request_id.approval_ids', string="Approvals")
    amount_untaxed = fields.Monetary(compute='_compute_amounts', store=True)
    amount_tax = fields.Monetary(compute='_compute_amounts', store=True)
    amount_total = fields.Monetary(compute='_compute_amounts', store=True)
    receipt_status = fields.Selection(
        RECEIPT_STATUS, string="Receipt / Completion Status", compute='_compute_statuses',
        store=True)
    billing_status = fields.Selection(BILLING_STATUS, compute='_compute_statuses', store=True)
    has_billable = fields.Boolean(compute='_compute_statuses', store=True)
    to_receive_grn = fields.Boolean(compute='_compute_statuses', store=True)
    to_receive_coc = fields.Boolean(compute='_compute_statuses', store=True)
    to_receive_acceptance = fields.Boolean(compute='_compute_statuses', store=True)
    receipt_ids = fields.One2many('idp.receipt', 'purchase_id', string="Receiving Documents")
    bill_ids = fields.Many2many(
        'account.move', compute='_compute_bills', string="Vendor Bills", compute_sudo=True)
    grn_count = fields.Integer(compute='_compute_counts')
    coc_count = fields.Integer(compute='_compute_counts')
    acceptance_count = fields.Integer(compute='_compute_counts')
    bill_count = fields.Integer(compute='_compute_counts')
    quotation_count = fields.Integer(compute='_compute_counts')

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            company = self.env['res.company'].browse(vals.get('company_id')) or self.env.company
            vals['name'] = company._idp_next_number('purchase')
        return super().create(vals_list)

    @api.depends('line_ids.price_subtotal', 'line_ids.price_total', 'line_ids.cancelled')
    def _compute_amounts(self):
        for purchase in self:
            lines = purchase.line_ids.filtered(lambda l: not l.cancelled)
            purchase.amount_untaxed = sum(lines.mapped('price_subtotal'))
            purchase.amount_total = sum(lines.mapped('price_total'))
            purchase.amount_tax = purchase.amount_total - purchase.amount_untaxed

    @api.depends('line_ids.product_qty', 'line_ids.qty_received', 'line_ids.qty_billed',
                 'line_ids.qty_to_bill', 'line_ids.cancelled', 'line_ids.receipt_method')
    def _compute_statuses(self):
        env = self.env
        for purchase in self:
            lines = purchase.line_ids.filtered(
                lambda l: not l.cancelled and not qty_is_zero(env, l.product_qty))
            received_any = any(not qty_is_zero(env, l.qty_received) for l in lines)
            received_all = bool(lines) and all(
                qty_compare(env, l.qty_received, l.product_qty) >= 0 for l in lines)
            billed_any = any(not qty_is_zero(env, l.qty_billed) for l in lines)
            billed_all = bool(lines) and all(
                qty_compare(env, l.qty_billed, l.product_qty) >= 0 for l in lines)
            purchase.receipt_status = 'full' if received_all else (
                'partial' if received_any else 'no')
            purchase.billing_status = 'full' if billed_all else ('partial' if billed_any else 'no')
            purchase.has_billable = any(not qty_is_zero(env, l.qty_to_bill) for l in lines)
            for method in ('grn', 'coc', 'acceptance'):
                purchase[f'to_receive_{method}'] = any(
                    l.receipt_method == method and qty_compare(env, l.qty_to_receive, 0) > 0
                    for l in lines)

    def _compute_bills(self):
        for purchase in self:
            if not purchase._origin.id:
                purchase.bill_ids = False
                continue
            purchase.bill_ids = self.env['account.move.line'].sudo().search([
                ('idp_purchase_line_id.purchase_id', '=', purchase._origin.id),
            ]).move_id

    def _compute_counts(self):
        for purchase in self:
            receipts = purchase.receipt_ids
            purchase.grn_count = len(receipts.filtered(lambda r: r.receipt_type == 'grn'))
            purchase.coc_count = len(receipts.filtered(lambda r: r.receipt_type == 'coc'))
            purchase.acceptance_count = len(
                receipts.filtered(lambda r: r.receipt_type == 'acceptance'))
            purchase.bill_count = len(purchase.sudo().bill_ids)
            purchase.quotation_count = len(purchase.line_ids.quotation_line_id.quotation_id)

    @api.ondelete(at_uninstall=False)
    def _unlink_except_confirmed(self):
        raise UserError(_("Supplier purchases cannot be deleted; cancel the purchase request "
                          "with a reason instead."))

    def _idp_check_executable(self):
        for purchase in self:
            if purchase.state != 'confirmed':
                raise UserError(_(
                    "Supplier purchase %s is not confirmed (it may be waiting for re-approval "
                    "of an amendment).", purchase.name))

    # ---- actions --------------------------------------------------------------------------
    def _idp_new_receipt_action(self, receipt_type):
        self.ensure_one()
        self._idp_check_executable()
        groups = {'grn': (GROUP_RECEIVER, GROUP_MANAGER)}.get(
            receipt_type, (GROUP_VERIFIER, GROUP_MANAGER))
        check_groups(self.env, _("You are not allowed to create this document."), *groups)
        xmlid = {
            'grn': 'invest_daily_purchase.action_idp_grn',
            'coc': 'invest_daily_purchase.action_idp_coc',
            'acceptance': 'invest_daily_purchase.action_idp_acceptance',
        }[receipt_type]
        action = self.env['ir.actions.act_window']._for_xml_id(xmlid)
        action.update({
            'views': [(False, 'form')],
            'view_mode': 'form',
            'context': {
                'default_purchase_id': self.id,
                'default_receipt_type': receipt_type,
            },
        })
        return action

    def action_create_grn(self):
        return self._idp_new_receipt_action('grn')

    def action_create_coc(self):
        return self._idp_new_receipt_action('coc')

    def action_create_acceptance(self):
        return self._idp_new_receipt_action('acceptance')

    def action_create_vendor_bill(self):
        check_groups(self.env, _("Only accountants can create vendor bills."),
                     GROUP_ACCOUNTANT, GROUP_MANAGER)
        purchases = self.filtered(lambda p: p.state == 'confirmed')
        lines = purchases.line_ids.receipt_line_ids.filtered(
            lambda r: r.state == 'done' and not qty_is_zero(self.env, r.qty_to_bill))
        if not lines:
            raise UserError(_(
                "There is nothing to bill: no confirmed, accepted and unbilled quantity exists."))
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'idp.bill.wizard',
            'view_mode': 'form',
            'target': 'new',
            'name': _("Create Vendor Bill"),
            'context': {'default_purchase_ids': purchases.ids},
        }

    def _idp_open(self, xmlid, records, ctx=None):
        action = self.env['ir.actions.act_window']._for_xml_id(xmlid)
        action['domain'] = [('id', 'in', records.ids)]
        action['context'] = dict({'create': False}, **(ctx or {}))
        if len(records) == 1:
            action['views'] = [(False, 'form')]
            action['res_id'] = records.id
        return action

    def action_view_request(self):
        self.ensure_one()
        return self._idp_open('invest_daily_purchase.action_idp_purchase_request',
                              self.request_id)

    def action_view_quotations(self):
        self.ensure_one()
        return self._idp_open('invest_daily_purchase.action_idp_quotation',
                              self.line_ids.quotation_line_id.quotation_id)

    def action_view_grns(self):
        self.ensure_one()
        return self._idp_open('invest_daily_purchase.action_idp_grn',
                              self.receipt_ids.filtered(lambda r: r.receipt_type == 'grn'))

    def action_view_cocs(self):
        self.ensure_one()
        return self._idp_open('invest_daily_purchase.action_idp_coc',
                              self.receipt_ids.filtered(lambda r: r.receipt_type == 'coc'))

    def action_view_acceptances(self):
        self.ensure_one()
        return self._idp_open('invest_daily_purchase.action_idp_acceptance',
                              self.receipt_ids.filtered(lambda r: r.receipt_type == 'acceptance'))

    def action_view_bills(self):
        self.ensure_one()
        return self._idp_open('account.action_move_in_invoice_type', self.bill_ids,
                              {'default_move_type': 'in_invoice'})


class IdpSupplierPurchaseLine(models.Model):
    _name = 'idp.supplier.purchase.line'
    _description = 'Supplier Purchase Line'
    _inherit = ['analytic.mixin']
    _order = 'purchase_id, sequence, id'
    _check_company_auto = True

    purchase_id = fields.Many2one(
        'idp.supplier.purchase', required=True, ondelete='cascade', index=True)
    request_id = fields.Many2one(related='purchase_id.request_id', store=True, index=True)
    request_line_id = fields.Many2one(
        'idp.purchase.request.line', required=True, ondelete='restrict', index=True)
    quotation_line_id = fields.Many2one(
        'idp.quotation.line', string="Supplier Offer", ondelete='restrict', index=True)
    sequence = fields.Integer(related='request_line_id.sequence', store=True)
    partner_id = fields.Many2one(related='purchase_id.partner_id', store=True, string="Supplier")
    company_id = fields.Many2one(related='purchase_id.company_id', store=True)
    currency_id = fields.Many2one(related='purchase_id.currency_id', store=True)
    department_id = fields.Many2one(related='purchase_id.department_id', store=True)
    project_id = fields.Many2one(related='purchase_id.project_id', store=True, index=True)
    company_currency_id = fields.Many2one(related='company_id.currency_id', string="Company Currency")
    state = fields.Selection(related='purchase_id.state', store=True)
    date_confirmed = fields.Date(related='purchase_id.date_confirmed', store=True)
    name = fields.Char(string="Description", required=True)
    product_id = fields.Many2one('product.product')
    line_type = fields.Selection(LINE_TYPES, required=True)
    requires_coc = fields.Boolean()
    receipt_method = fields.Selection(
        RECEIPT_METHODS, compute='_compute_receipt_method', store=True)
    uom_id = fields.Many2one('uom.uom', required=True)
    product_qty = fields.Float(string="Ordered Qty", digits='Product Unit', required=True)
    price_unit = fields.Float(digits='Product Price', required=True)
    discount = fields.Float(digits='Discount')
    tax_ids = fields.Many2many(
        'account.tax', 'idp_purchase_line_tax_rel', 'line_id', 'tax_id', string="Taxes")
    price_net = fields.Float(compute='_compute_amounts', store=True, digits='Product Price',
                             string="Net Unit Price")
    price_subtotal = fields.Monetary(compute='_compute_amounts', store=True)
    price_total = fields.Monetary(compute='_compute_amounts', store=True)
    price_net_company = fields.Float(
        compute='_compute_amounts', store=True, digits='Product Price',
        string="Net Unit Price (Company Currency)")
    price_subtotal_company = fields.Monetary(
        compute='_compute_amounts', store=True, currency_field='company_currency_id',
        string="Untaxed (Company Currency)")
    price_total_company = fields.Monetary(
        compute='_compute_amounts', store=True, currency_field='company_currency_id',
        string="Total (Company Currency)")
    account_id = fields.Many2one('account.account', string="Expense Account")
    cancelled = fields.Boolean(readonly=True)

    receipt_line_ids = fields.One2many('idp.receipt.line', 'purchase_line_id')
    qty_received = fields.Float(
        string="Accepted / Certified Qty", compute='_compute_quantities', store=True,
        digits='Product Unit')
    qty_rejected = fields.Float(compute='_compute_quantities', store=True, digits='Product Unit')
    qty_to_receive = fields.Float(
        string="Outstanding Qty", compute='_compute_quantities', store=True,
        digits='Product Unit')
    qty_billed = fields.Float(compute='_compute_quantities', store=True, digits='Product Unit')
    qty_reserved = fields.Float(
        string="Qty on Draft Bills", compute='_compute_quantities', store=True,
        digits='Product Unit')
    qty_to_bill = fields.Float(
        string="Qty to Bill", compute='_compute_quantities', store=True, digits='Product Unit')
    amount_to_bill = fields.Monetary(compute='_compute_quantities', store=True)

    @api.depends('line_type', 'requires_coc')
    def _compute_receipt_method(self):
        for line in self:
            if line.line_type == 'goods':
                line.receipt_method = 'grn'
            elif line.requires_coc:
                line.receipt_method = 'coc'
            else:
                line.receipt_method = 'acceptance'

    @api.depends('product_qty', 'price_unit', 'discount', 'tax_ids', 'currency_id',
                 'purchase_id.date_confirmed', 'company_id')
    def _compute_amounts(self):
        for line in self:
            net = line.price_unit * (1.0 - (line.discount or 0.0) / 100.0)
            line.price_net = net
            if line.tax_ids and line.currency_id:
                res = line.tax_ids.compute_all(
                    net, currency=line.currency_id, quantity=line.product_qty,
                    product=line.product_id, partner=line.partner_id)
                line.price_subtotal = res['total_excluded']
                line.price_total = res['total_included']
            else:
                amount = net * line.product_qty
                line.price_subtotal = line.price_total = (
                    line.currency_id.round(amount) if line.currency_id else amount)
            company = line.company_id or self.env.company
            if line.currency_id and line.currency_id != company.currency_id:
                date = line.purchase_id.date_confirmed or fields.Date.context_today(line)
                convert = line.currency_id._convert
                line.price_net_company = convert(net, company.currency_id, company, date,
                                                 round=False)
                line.price_subtotal_company = convert(line.price_subtotal, company.currency_id,
                                                      company, date)
                line.price_total_company = convert(line.price_total, company.currency_id,
                                                   company, date)
            else:
                line.price_net_company = net
                line.price_subtotal_company = line.price_subtotal
                line.price_total_company = line.price_total

    @api.depends('product_qty', 'price_net', 'receipt_line_ids.state',
                 'receipt_line_ids.qty_accepted', 'receipt_line_ids.qty_rejected',
                 'receipt_line_ids.qty_billed', 'receipt_line_ids.qty_reserved')
    def _compute_quantities(self):
        for line in self:
            done = line.receipt_line_ids.filtered(lambda r: r.state == 'done')
            line.qty_received = sum(done.mapped('qty_accepted'))
            line.qty_rejected = sum(done.mapped('qty_rejected'))
            line.qty_to_receive = max(line.product_qty - line.qty_received, 0.0)
            line.qty_billed = sum(done.mapped('qty_billed'))
            line.qty_reserved = sum(done.mapped('qty_reserved'))
            line.qty_to_bill = max(line.qty_received - line.qty_billed - line.qty_reserved, 0.0)
            amount = line.qty_to_bill * line.price_net
            line.amount_to_bill = line.currency_id.round(amount) if line.currency_id else amount

    def _idp_retire(self):
        """Cancel lines that are no longer awarded after an amendment."""
        for line in self:
            if line.receipt_line_ids.filtered(lambda r: r.state != 'cancel'):
                raise UserError(_(
                    "Supplier purchase line '%s' already has receiving or completion documents "
                    "and cannot be removed by the amendment.", line.name))
            line.write({'product_qty': 0.0, 'cancelled': True})

    def action_create_vendor_bill(self):
        return self.purchase_id.action_create_vendor_bill()
