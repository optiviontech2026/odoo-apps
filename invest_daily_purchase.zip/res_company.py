from odoo import _, api, fields, models
from odoo.exceptions import ValidationError

SEQUENCE_KINDS = {
    'request': 'idp.purchase.request',
    'grn': 'idp.grn',
    'coc': 'idp.coc',
    'acceptance': 'idp.acceptance',
    'purchase': 'idp.supplier.purchase',
}


class ResCompany(models.Model):
    _inherit = 'res.company'

    idp_amount_limit = fields.Monetary(
        string="Mandatory Offers Limit",
        currency_field='idp_limit_currency_id',
        help="Purchases whose amount is strictly greater than this limit require the minimum "
             "number of supplier offers before second-level approval.")
    idp_limit_currency_id = fields.Many2one(
        'res.currency', string="Limit Currency",
        compute='_compute_idp_limit_currency_id', store=True, readonly=False,
        help="Currency in which the approval limit is expressed. Request and offer amounts are "
             "converted to this currency with the system rate of the approval date.")
    idp_limit_tax_mode = fields.Selection(
        [('excluded', 'Excluding taxes'), ('included', 'Including taxes')],
        string="Limit Basis", default='excluded', required=True)
    idp_min_offers = fields.Integer(string="Minimum Supplier Offers", default=1)
    idp_journal_id = fields.Many2one(
        'account.journal', string="Purchase Journal",
        domain="[('type', '=', 'purchase'), ('company_id', '=', id)]",
        help="Journal used to create vendor bills. Bill numbers follow this journal's numbering.")
    idp_request_sequence_id = fields.Many2one('ir.sequence', string="Purchase Request Sequence")
    idp_grn_sequence_id = fields.Many2one('ir.sequence', string="GRN Sequence")
    idp_coc_sequence_id = fields.Many2one('ir.sequence', string="COC Sequence")
    idp_acceptance_sequence_id = fields.Many2one('ir.sequence', string="Service Acceptance Sequence")
    idp_purchase_sequence_id = fields.Many2one('ir.sequence', string="Supplier Purchase Sequence")
    idp_grn_stock_moves = fields.Boolean(
        string="Post Accepted Goods to Inventory", default=True,
        help="When a GRN is confirmed, accepted quantities of goods products are received into "
             "the GRN receiving location through a validated inventory receipt.")
    idp_project_required = fields.Boolean(
        string="Project Required on Requests",
        help="Every purchase request must belong to a project (numbered by the project's own "
             "sequence).")
    idp_coc_separate_approver = fields.Boolean(
        string="COC Approver Must Differ From Verifier",
        help="Segregation of duties: the user approving a Certificate of Completion must be "
             "different from the user who verified it.")

    @api.depends('currency_id')
    def _compute_idp_limit_currency_id(self):
        for company in self:
            if not company.idp_limit_currency_id:
                company.idp_limit_currency_id = company.currency_id

    @api.constrains('idp_min_offers', 'idp_amount_limit')
    def _check_idp_settings(self):
        for company in self:
            if company.idp_min_offers < 1:
                raise ValidationError(_("The minimum number of supplier offers must be at least one."))
            if company.idp_amount_limit < 0:
                raise ValidationError(_("The mandatory offers limit cannot be negative."))

    def _idp_set_default_sequences(self):
        for company in self:
            vals = {}
            for kind, code in SEQUENCE_KINDS.items():
                fname = f'idp_{kind}_sequence_id'
                if not company[fname]:
                    seq = self.env.ref(f'invest_daily_purchase.seq_{code.replace(".", "_")}',
                                       raise_if_not_found=False)
                    if seq:
                        vals[fname] = seq.id
            if not company.idp_journal_id:
                journal = self.env['account.journal'].search([
                    ('type', '=', 'purchase'), ('company_id', '=', company.id)], limit=1)
                if journal:
                    vals['idp_journal_id'] = journal.id
            if vals:
                company.write(vals)

    def _idp_next_number(self, kind, date=None):
        """Return the next number of the given module sequence for this company."""
        self.ensure_one()
        ctx = {'ir_sequence_date': fields.Date.to_string(date)} if date else {}
        sequence = self[f'idp_{kind}_sequence_id'].sudo().with_context(**ctx)
        if sequence:
            return sequence.next_by_id(sequence_date=date)
        number = self.env['ir.sequence'].sudo().with_company(self).with_context(
            **ctx).next_by_code(SEQUENCE_KINDS[kind], sequence_date=date)
        return number or '/'

    def _idp_get_purchase_journal(self):
        self.ensure_one()
        journal = self.idp_journal_id
        if not journal:
            journal = self.env['account.journal'].search([
                ('type', '=', 'purchase'), ('company_id', '=', self.id)], limit=1)
        return journal

    def _idp_limit_currency(self):
        self.ensure_one()
        return self.idp_limit_currency_id or self.currency_id
