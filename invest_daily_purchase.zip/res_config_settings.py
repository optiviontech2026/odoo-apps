from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    idp_amount_limit = fields.Monetary(
        related='company_id.idp_amount_limit', readonly=False,
        currency_field='idp_limit_currency_id')
    idp_limit_currency_id = fields.Many2one(
        related='company_id.idp_limit_currency_id', readonly=False)
    idp_limit_tax_mode = fields.Selection(
        related='company_id.idp_limit_tax_mode', readonly=False)
    idp_min_offers = fields.Integer(related='company_id.idp_min_offers', readonly=False)
    idp_journal_id = fields.Many2one(related='company_id.idp_journal_id', readonly=False)
    idp_request_sequence_id = fields.Many2one(
        related='company_id.idp_request_sequence_id', readonly=False)
    idp_grn_sequence_id = fields.Many2one(related='company_id.idp_grn_sequence_id', readonly=False)
    idp_coc_sequence_id = fields.Many2one(related='company_id.idp_coc_sequence_id', readonly=False)
    idp_acceptance_sequence_id = fields.Many2one(
        related='company_id.idp_acceptance_sequence_id', readonly=False)
    idp_purchase_sequence_id = fields.Many2one(
        related='company_id.idp_purchase_sequence_id', readonly=False)
    idp_grn_stock_moves = fields.Boolean(related='company_id.idp_grn_stock_moves', readonly=False)
    idp_coc_separate_approver = fields.Boolean(
        related='company_id.idp_coc_separate_approver', readonly=False)
    idp_project_required = fields.Boolean(
        related='company_id.idp_project_required', readonly=False)
    idp_approval_level_count = fields.Integer(compute='_compute_idp_counts')
    idp_project_count = fields.Integer(compute='_compute_idp_counts')

    def _compute_idp_counts(self):
        for settings in self:
            domain = [('company_id', '=', settings.company_id.id)]
            settings.idp_approval_level_count = self.env['idp.approval.level'].search_count(domain)
            settings.idp_project_count = self.env['idp.project'].search_count(domain)

    def action_idp_open_projects(self):
        action = self.env['ir.actions.act_window']._for_xml_id(
            'invest_daily_purchase.action_idp_project')
        action['context'] = {'default_company_id': self.company_id.id}
        action['domain'] = [('company_id', '=', self.company_id.id)]
        return action

    def action_idp_open_approval_levels(self):
        action = self.env['ir.actions.act_window']._for_xml_id(
            'invest_daily_purchase.action_idp_approval_level')
        action['context'] = {'default_company_id': self.company_id.id}
        action['domain'] = [('company_id', '=', self.company_id.id)]
        return action
