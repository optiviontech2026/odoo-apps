{
    'name': 'Journal & Account Restriction',
    'version': '19.0.1.1.0',
    'category': 'Accounting/Accounting',
    'summary': 'Restrict users to selected journals and accounts '
               '(archived ones included) without access errors on cross-journal reconciliations',
    'description': """
Journal & Account Restriction
=============================

Adds a *Journal & Account Restrictions* section to the **Access Rights** tab of the user form.

* **Journal access**: all journals, only the selected journals, or all journals except the selected ones.
  Active **and archived** journals can be selected.
* **Account access**: all accounts, only the selected accounts, or all accounts except the selected ones.
  Active **and archived** accounts can be selected.

Users with the **Administrator** role always have access to all journals and accounts,
whatever is selected on their user form.

A restricted user does not see (list, search, open, print, edit) the journals, accounts,
journal entries, journal items, payments, bank statements, analytic items and invoice
analysis lines outside of his access.

Cross-journal reconciliations (e.g. a cashier payment in a Cash journal reconciled by the
accountant with a vendor bill in the Purchase journal) no longer raise access errors for
users who can only see one side of the reconciliation: the hidden side is simply left out.
""",
    'author': 'Optivion Tech',
    'license': 'LGPL-3',
    'depends': ['account'],
    'data': [
        'security/journal_account_restriction_rules.xml',
        'views/res_users_views.xml',
    ],
    'installable': True,
    'application': False,
}
