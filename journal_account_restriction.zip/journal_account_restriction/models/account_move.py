from odoo import _, api, models

from .tools import filter_readable, is_restricted_user


class AccountMove(models.Model):
    _inherit = 'account.move'

    @api.model
    def _restriction_no_access_notification(self, record_name):
        """ Action displaying a warning instead of an access error when the user tries to
        open a document (from a reconciliation) he is not allowed to access. """
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'type': 'warning',
                'title': _("Restricted Document"),
                'message': _(
                    "%(document)s is in a journal or uses an account you don't have access to.",
                    document=record_name,
                ),
                'sticky': False,
            },
        }

    @api.depends_context('uid')
    def _compute_payment_count(self):
        """ payment_count is computed as superuser: only count the payments the user can
        open, so the smart button matches what 'open_payments' displays. """
        super()._compute_payment_count()
        if is_restricted_user(self.env):
            for move in self:
                move.payment_count = len(filter_readable(move.sudo().reconciled_payment_ids))

    def open_payments(self):
        if is_restricted_user(self.env):
            payments = filter_readable(self.sudo().reconciled_payment_ids).with_env(self.env)
            return payments._get_records_action(name=_("Payments"))
        return super().open_payments()

    def _get_reconciled_invoices_partials(self):
        """ Used by the payment receipt: an invoice visible by the user can also be paid by
        payments in journals he can't access. Like the payments widget of the invoice form
        (computed as superuser by Odoo), list them without raising an access error. """
        if is_restricted_user(self.env) and not self.env.su:
            self.check_access('read')
            return super(AccountMove, self.sudo())._get_reconciled_invoices_partials()
        return super()._get_reconciled_invoices_partials()

    def action_open_business_doc(self):
        """ Called by the payments widget of invoices/bills: the counterpart of a
        reconciliation can be in a journal the user can't access. """
        self.ensure_one()
        if is_restricted_user(self.env) and not filter_readable(self):
            return self._restriction_no_access_notification(self.sudo().display_name)
        return super().action_open_business_doc()
