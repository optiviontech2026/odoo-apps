from odoo import api, models

from .tools import is_restricted_user


def _sudo_plan(plan):
    """ Return a copy of a reconciliation plan (nested lists of account.move.line) as superuser. """
    return [_sudo_plan(item) if isinstance(item, list) else item.sudo() for item in plan]


def _plan_lines(plan, lines):
    for item in plan:
        if isinstance(item, list):
            lines = _plan_lines(item, lines)
        else:
            lines |= item
    return lines


class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    @api.model
    def _reconcile_plan(self, reconciliation_plan):
        """ A reconciliation touches more than the reconciled items: the counterpart journal
        entries (payment state, matching numbers...) and it may generate exchange difference
        or cash basis entries in other journals. For a restricted user, check he can edit the
        items he reconciles, then let the reconciliation run as superuser. """
        if self.env.su or not is_restricted_user(self.env):
            return super()._reconcile_plan(reconciliation_plan)
        _plan_lines(reconciliation_plan, self.env['account.move.line']).check_access('write')
        return super(AccountMoveLine, self.sudo())._reconcile_plan(_sudo_plan(reconciliation_plan))

    def open_reconcile_view(self):
        """ The matched items can be in journals the user can't access: find them as
        superuser, the action domain is still filtered by the record rules. """
        if self.env.su or not is_restricted_user(self.env):
            return super().open_reconcile_view()
        self.check_access('read')
        return super(AccountMoveLine, self.sudo()).open_reconcile_view()

    def action_unreconcile_match_entries(self):
        """ Unreconcile from the journal items list: the matched counterparts may be hidden. """
        if self.env.su or not is_restricted_user(self.env):
            return super().action_unreconcile_match_entries()
        active_ids = self.env.context.get('active_ids')
        if active_ids:
            lines = self.env['account.move.line'].browse(active_ids)
            lines.check_access('write')
            lines.sudo()._all_reconciled_lines().remove_move_reconcile()
