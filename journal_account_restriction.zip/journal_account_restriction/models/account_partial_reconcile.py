from odoo import _, models
from odoo.exceptions import AccessError

from .tools import is_restricted_user


class AccountPartialReconcile(models.Model):
    _inherit = 'account.partial.reconcile'

    def unlink(self):
        """ Removing a reconciliation (reset to draft / cancel a payment or a bill, 'Unreconcile'
        in the payments widget...) updates both sides of it, including the side in a journal
        the user can't access. The user must be allowed to edit at least one side of each
        reconciliation; the rest runs as superuser. """
        if not self or self.env.su or not is_restricted_user(self.env):
            return super().unlink()
        self.check_access('unlink')
        for partial in self:
            lines = partial.sudo().debit_move_id | partial.sudo().credit_move_id
            if not lines.with_env(self.env)._filtered_access('write'):
                raise AccessError(_(
                    "You can't remove a reconciliation between journal items you don't have access to."))
        return super(AccountPartialReconcile, self.sudo()).unlink()
