from odoo import api, models

from .tools import filter_readable, is_restricted_user


class AccountPayment(models.Model):
    _inherit = 'account.payment'

    # The values below are filtered for restricted users: their cache must depend on the
    # user and on sudo mode (business code reading them as superuser, e.g. the payment
    # state computation, keeps getting the complete, unfiltered values).
    @api.depends_context('uid')
    def _compute_stat_buttons_from_reconciliation(self):
        """ The reconciled invoices/bills/statement lines of a payment may live in journals
        the user can't access (e.g. a cashier payment reconciled by the accountant with a
        vendor bill). Standard code reads them and raises an AccessError: compute as
        superuser, then only keep what the user is allowed to see. """
        if self.env.su or not is_restricted_user(self.env):
            return super()._compute_stat_buttons_from_reconciliation()

        payments_sudo = self.sudo()
        super(AccountPayment, payments_sudo)._compute_stat_buttons_from_reconciliation()
        values = []
        for pay_sudo in payments_sudo:
            values.append((
                filter_readable(pay_sudo.reconciled_invoice_ids),
                filter_readable(pay_sudo.reconciled_bill_ids),
                filter_readable(pay_sudo.reconciled_statement_line_ids),
            ))
        for pay, (invoices, bills, statement_lines) in zip(self, values):
            invoices = invoices.with_env(self.env)
            pay.reconciled_invoice_ids = invoices
            pay.reconciled_invoices_count = len(invoices)
            pay.reconciled_bill_ids = bills.with_env(self.env)
            pay.reconciled_bills_count = len(bills)
            pay.reconciled_statement_line_ids = statement_lines.with_env(self.env)
            pay.reconciled_statement_lines_count = len(statement_lines)
            if len(set(invoices.mapped('move_type'))) == 1 and invoices[0].move_type == 'out_refund':
                pay.reconciled_invoices_type = 'credit_note'
            else:
                pay.reconciled_invoices_type = 'invoice'

    @api.depends_context('uid')
    def _compute_duplicate_payment_ids(self):
        """ Possible duplicates are found with SQL: hide the ones the user can't read. """
        super()._compute_duplicate_payment_ids()
        if not self.env.su and is_restricted_user(self.env):
            for payment in self:
                payment.duplicate_payment_ids = filter_readable(payment.duplicate_payment_ids)

    def unlink(self):
        if self.env.su or not is_restricted_user(self.env):
            return super().unlink()
        # Standard code recomputes the payment state of the invoices linked to the payments,
        # but the user only sees the invoices he can access: recompute all of them.
        linked_invoices = self.sudo().invoice_ids
        res = super().unlink()
        linked_invoices = linked_invoices.exists()
        if linked_invoices:
            self.env.add_to_compute(linked_invoices._fields['payment_state'], linked_invoices)
        return res

    def action_open_business_doc(self):
        self.ensure_one()
        if is_restricted_user(self.env) and not filter_readable(self):
            return self.env['account.move']._restriction_no_access_notification(self.sudo().display_name)
        return super().action_open_business_doc()
