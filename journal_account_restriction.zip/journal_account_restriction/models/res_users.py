from odoo import _, api, fields, models
from odoo.fields import Command, Domain

RESTRICTION_FIELDS = {
    'journal_restriction_mode',
    'restriction_journal_ids',
    'account_restriction_mode',
    'restriction_account_ids',
}


class ResUsers(models.Model):
    _inherit = 'res.users'

    journal_restriction_mode = fields.Selection(
        selection=[
            ('none', "All Journals"),
            ('allow', "Only Selected Journals"),
            ('deny', "All Journals Except Selected"),
        ],
        string="Journal Access",
        default='none',
        required=True,
        groups='base.group_erp_manager',
        help="All Journals: no restriction.\n"
             "Only Selected Journals: the user only sees the selected journals and their entries, "
             "items, payments and statements.\n"
             "All Journals Except Selected: the selected journals and everything posted in them "
             "are hidden from the user.",
    )
    restriction_journal_ids = fields.Many2many(
        comodel_name='account.journal',
        relation='res_users_restriction_journal_rel',
        column1='user_id',
        column2='journal_id',
        string="Journals",
        # keep archived journals visible/selectable in the field
        context={'active_test': False},
        groups='base.group_erp_manager',
    )
    account_restriction_mode = fields.Selection(
        selection=[
            ('none', "All Accounts"),
            ('allow', "Only Selected Accounts"),
            ('deny', "All Accounts Except Selected"),
        ],
        string="Account Access",
        default='none',
        required=True,
        groups='base.group_erp_manager',
        help="All Accounts: no restriction.\n"
             "Only Selected Accounts: the user only sees the selected accounts; journal entries "
             "having at least one item on another account are hidden.\n"
             "All Accounts Except Selected: the selected accounts are hidden, as well as every "
             "journal entry having at least one item on them.",
    )
    restriction_account_ids = fields.Many2many(
        comodel_name='account.account',
        relation='res_users_restriction_account_rel',
        column1='user_id',
        column2='account_id',
        string="Accounts",
        # keep archived accounts visible/selectable in the field
        context={'active_test': False},
        groups='base.group_erp_manager',
    )

    # -------------------------------------------------------------------------
    # CRUD: the record rules domains are cached per user, flush that cache
    # -------------------------------------------------------------------------

    @api.model_create_multi
    def create(self, vals_list):
        users = super().create(vals_list)
        if any(RESTRICTION_FIELDS & vals.keys() for vals in vals_list):
            self.env.registry.clear_cache()
        return users

    def write(self, vals):
        res = super().write(vals)
        if RESTRICTION_FIELDS & vals.keys():
            self.env.registry.clear_cache()
        return res

    # -------------------------------------------------------------------------
    # HELPERS
    # -------------------------------------------------------------------------

    def _has_journal_account_restriction(self):
        """ Whether the user is restricted on journals and/or accounts.
        Users with the Administrator role (Settings) always have access to everything,
        whatever is selected on their user form. """
        self.ensure_one()
        user = self.sudo()
        if user._is_system():
            return False
        return user.journal_restriction_mode != 'none' or user.account_restriction_mode != 'none'

    @api.model
    def _restriction_ids_domain(self, mode, field_name, ids, nullable=False):
        if mode == 'allow':
            domain = Domain(field_name, 'in', ids)
            if nullable:
                domain |= Domain(field_name, '=', False)
            return domain
        if mode == 'deny':
            # 'not in' also matches empty values
            return Domain(field_name, 'not in', ids)
        return Domain.TRUE

    def _restriction_journal_domain(self, field_name='journal_id'):
        return self._restriction_ids_domain(
            self.journal_restriction_mode, field_name, self.restriction_journal_ids.ids)

    def _restriction_account_domain(self, field_name='account_id', nullable=True):
        return self._restriction_ids_domain(
            self.account_restriction_mode, field_name, self.restriction_account_ids.ids, nullable=nullable)

    def _restriction_move_domain(self):
        """ Journal entries visible by the user: in an accessible journal and having
        no journal item on a forbidden account. """
        domain = self._restriction_journal_domain('journal_id')
        if self.account_restriction_mode != 'none':
            forbidden_line = ~self._restriction_account_domain('account_id')
            domain &= Domain('line_ids', 'not any', forbidden_line)
        return domain

    def _restriction_move_line_domain(self):
        """ Journal items visible by the user: the ones of the visible journal entries. """
        domain = self._restriction_journal_domain('journal_id')
        if self.account_restriction_mode != 'none':
            domain &= Domain('move_id', 'any', self._restriction_move_domain())
        return domain

    def _restriction_payment_domain(self):
        domain = self._restriction_journal_domain('journal_id')
        if self.account_restriction_mode != 'none':
            domain &= self._restriction_account_domain('outstanding_account_id')
            domain &= self._restriction_account_domain('destination_account_id')
            domain &= Domain('move_id', '=', False) | Domain('move_id', 'any', self._restriction_move_domain())
        return domain

    def _restriction_analytic_line_domain(self):
        if self.journal_restriction_mode == 'none' and self.account_restriction_mode == 'none':
            return Domain.TRUE
        return (
            Domain('move_line_id', '=', False)
            | Domain('move_line_id', 'any', self._restriction_move_line_domain())
        )

    def _restriction_invoice_report_domain(self):
        domain = self._restriction_journal_domain('journal_id')
        if self.account_restriction_mode != 'none':
            domain &= Domain('move_id', 'any', self._restriction_move_domain())
        return domain

    def _get_journal_account_restriction_domain(self, model_name):
        """ Domain used by the record rules of this module (see security xml).

        :param model_name: the model the record rule applies on.
        :return: a domain (as a list) of the records the user is allowed to access.
        """
        self.ensure_one()
        user = self.sudo().with_context(active_test=False)
        if not user._has_journal_account_restriction():
            return []
        builders = {
            'account.journal': lambda: user._restriction_journal_domain('id'),
            'account.account': lambda: user._restriction_account_domain('id', nullable=False),
            'account.move': user._restriction_move_domain,
            'account.move.line': user._restriction_move_line_domain,
            'account.payment': user._restriction_payment_domain,
            'account.bank.statement': lambda: user._restriction_journal_domain('journal_id'),
            'account.analytic.line': user._restriction_analytic_line_domain,
            'account.invoice.report': user._restriction_invoice_report_domain,
        }
        builder = builders.get(model_name)
        return list(builder()) if builder else []

    # -------------------------------------------------------------------------
    # ACTIONS
    # -------------------------------------------------------------------------

    def action_restriction_add_journal_accounts(self):
        """ Add to the allowed accounts the accounts the selected journals need to work:
        default/suspense/profit/loss accounts, outstanding accounts of the payment methods
        and the default receivable/payable accounts of their companies. """
        IrDefault = self.env['ir.default'].sudo()
        for user in self.sudo():
            journals = user.restriction_journal_ids
            accounts = (
                journals.default_account_id
                | journals.suspense_account_id
                | journals.profit_account_id
                | journals.loss_account_id
                | journals.inbound_payment_method_line_ids.payment_account_id
                | journals.outbound_payment_method_line_ids.payment_account_id
            )
            for company in journals.company_id:
                chart = self.env['account.chart.template'].with_context(
                    allowed_company_ids=company.root_id.ids).sudo()
                for xmlid in ('account_journal_payment_debit_account_id',
                              'account_journal_payment_credit_account_id'):
                    accounts |= chart.ref(xmlid, raise_if_not_found=False) or self.env['account.account']
                for field_name in ('property_account_receivable_id', 'property_account_payable_id'):
                    account_id = IrDefault._get('res.partner', field_name, company_id=company.id)
                    if account_id:
                        accounts |= self.env['account.account'].browse(account_id).exists()
            new_accounts = accounts - user.restriction_account_ids
            if new_accounts:
                user.restriction_account_ids = [Command.link(account.id) for account in new_accounts]
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'type': 'success',
                'message': _("The accounts used by the selected journals have been added."),
                'next': {'type': 'ir.actions.client', 'tag': 'soft_reload'},
            },
        }
