""" Small helpers shared by the overrides of this module. """


def is_restricted_user(env):
    """ Whether the real user of ``env`` has a journal/account restriction.
    Works in sudo environments too (``env.user`` keeps the real uid). """
    return env.user._has_journal_account_restriction()


def filter_readable(records):
    """ Return the subset of ``records`` the real user of their environment is
    allowed to read (record rules included), even if ``records`` is sudo-ed.
    The result keeps the environment of ``records``. """
    if not records:
        return records
    real_records = records.with_env(records.env(su=False))
    return real_records._filtered_access('read').with_env(records.env)
