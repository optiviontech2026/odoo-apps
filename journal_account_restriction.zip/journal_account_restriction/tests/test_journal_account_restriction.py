from lxml import etree

from odoo import Command
from odoo.exceptions import AccessError
from odoo.tests import Form, new_test_user, tagged

from odoo.addons.account.tests.common import AccountTestInvoicingCommon


@tagged('post_install', '-at_install')
class TestJournalAccountRestriction(AccountTestInvoicingCommon):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        company = cls.company_data['company']
        cls.cash_journal = cls.company_data['default_journal_cash']
        cls.bank_journal = cls.company_data['default_journal_bank']
        cls.purchase_journal = cls.company_data['default_journal_purchase']
        cls.sale_journal = cls.company_data['default_journal_sale']
        cls.misc_journal = cls.company_data['default_journal_misc']
        cls.payable_account = cls.company_data['default_account_payable']

        # Cashier: only the cash journal
        cls.cashier = new_test_user(
            cls.env, login='jar_cashier', name='Cashier',
            groups='base.group_user,account.group_account_invoice',
            company_id=company.id, company_ids=[Command.set(company.ids)],
        )
        # Accountant: every journal except the cash journal
        cls.accountant = new_test_user(
            cls.env, login='jar_accountant', name='Accountant',
            groups='base.group_user,account.group_account_user',
            company_id=company.id, company_ids=[Command.set(company.ids)],
        )
        cls.env['res.users'].sudo().browse(cls.cashier.id).write({
            'journal_restriction_mode': 'allow',
            'restriction_journal_ids': [Command.set(cls.cash_journal.ids)],
        })
        cls.env['res.users'].sudo().browse(cls.accountant.id).write({
            'journal_restriction_mode': 'deny',
            'restriction_journal_ids': [Command.set(cls.cash_journal.ids)],
        })

    # -------------------------------------------------------------------------
    # Helpers
    # -------------------------------------------------------------------------

    def _read_list_view(self, records, view_ref=None):
        """ Read records the way the web client does it for a list view. """
        model = records.browse()
        view_id = self.env.ref(view_ref).id if view_ref else False
        views = model.get_views([(view_id, 'list')])
        arch = etree.fromstring(views['views']['list']['arch'])
        fields_info = views['models'][model._name]['fields']
        spec = {}
        for node in arch.iterchildren('field'):
            name = node.get('name')
            ftype = fields_info.get(name, {}).get('type')
            if ftype in ('many2one', 'many2many', 'one2many'):
                spec[name] = {'fields': {'display_name': {}}}
            else:
                spec[name] = {}
        return model.web_search_read([('id', 'in', records.ids)], spec)

    def _create_cashier_payment(self, amount=1000.0):
        payment = self.env['account.payment'].with_user(self.cashier).create({
            'payment_type': 'outbound',
            'partner_type': 'supplier',
            'partner_id': self.partner_a.id,
            'amount': amount,
            'journal_id': self.cash_journal.id,
        })
        payment.action_post()
        return payment.with_env(self.env)

    def _create_bill(self, amount=1000.0):
        return self.init_invoice('in_invoice', partner=self.partner_a, amounts=[amount], post=True)

    def _reconcile(self, bill, payment):
        lines = (bill.line_ids | payment.move_id.line_ids).filtered(
            lambda l: l.account_id == self.payable_account and not l.reconciled)
        lines.reconcile()

    def _open_everything_as(self, user, payment, bill):
        """ Open, as ``user``, every screen of the reconciliation he has access to. """
        if payment.with_user(user).has_access('read'):
            pay_form = Form(payment.with_user(user))
            self.assertTrue(pay_form.amount)
            self._read_list_view(payment.with_user(user))
            if payment.move_id:
                Form(payment.move_id.with_user(user))
                self._read_list_view(payment.move_id.line_ids.with_user(user))
                payment.move_id.line_ids.with_user(user).open_reconcile_view()
        if bill.with_user(user).has_access('read'):
            Form(bill.with_user(user))
            self._read_list_view(bill.with_user(user), 'account.view_in_invoice_bill_tree')
            self._read_list_view(bill.line_ids.with_user(user))
            bill.line_ids.with_user(user).open_reconcile_view()
            bill.with_user(user).open_payments()

    # -------------------------------------------------------------------------
    # Tests
    # -------------------------------------------------------------------------

    def test_archived_journals_and_accounts_are_selectable(self):
        archived_journal = self.misc_journal.copy({'name': 'Old Misc', 'code': 'OLDM'})
        archived_journal.active = False
        archived_account = self.company_data['default_account_expense'].copy()
        archived_account.active = False
        user = self.env['res.users'].sudo().browse(self.cashier.id)
        user.write({
            'restriction_journal_ids': [Command.link(archived_journal.id)],
            'account_restriction_mode': 'deny',
            'restriction_account_ids': [Command.set(archived_account.ids)],
        })
        self.assertIn(archived_journal, user.restriction_journal_ids)
        self.assertIn(archived_account, user.restriction_account_ids)
        # The user form (Access Rights tab) displays the archived records too
        user_form = Form(user, view='base.view_users_form')
        self.assertIn(archived_journal.id, user_form.restriction_journal_ids.ids)
        self.assertIn(archived_account.id, user_form.restriction_account_ids.ids)

    def test_journal_visibility(self):
        Journal = self.env['account.journal']
        cashier_journals = Journal.with_user(self.cashier).search([])
        self.assertEqual(cashier_journals, self.cash_journal)
        accountant_journals = Journal.with_user(self.accountant).search([])
        self.assertNotIn(self.cash_journal, accountant_journals)
        self.assertIn(self.purchase_journal, accountant_journals)

        bill = self._create_bill()
        payment = self._create_cashier_payment()
        Move = self.env['account.move']
        self.assertFalse(Move.with_user(self.cashier).search([('id', '=', bill.id)]))
        self.assertTrue(Move.with_user(self.cashier).search([('id', '=', payment.move_id.id)]))
        self.assertTrue(Move.with_user(self.accountant).search([('id', '=', bill.id)]))
        self.assertFalse(Move.with_user(self.accountant).search([('id', '=', payment.move_id.id)]))
        self.assertFalse(self.env['account.payment'].with_user(self.accountant).search([('id', '=', payment.id)]))
        self.assertFalse(self.env['account.move.line'].with_user(self.cashier).search([('move_id', '=', bill.id)]))
        with self.assertRaises(AccessError):
            bill.with_user(self.cashier).read(['name'])
        with self.assertRaises(AccessError):
            payment.with_user(self.accountant).read(['name'])
        # the cashier can't create entries in other journals
        with self.assertRaises(AccessError):
            self.env['account.move'].with_user(self.cashier).create({
                'move_type': 'in_invoice',
                'journal_id': self.purchase_journal.id,
                'partner_id': self.partner_a.id,
            })

    def test_cashier_payment_reconciled_with_bill_by_accountant(self):
        """ The cashier (cash journal only) pays, the accountant (no access to the cash
        journal... and an unrestricted user) reconcile with the bill: nobody gets an error. """
        bill = self._create_bill()
        payment = self._create_cashier_payment()
        self._reconcile(bill, payment)
        self.assertIn(bill.payment_state, ('paid', 'in_payment'))
        self.assertEqual(payment.reconciled_bill_ids, bill)  # unrestricted user sees the link

        for user in (self.cashier, self.accountant):
            self._open_everything_as(user, payment, bill)

        # cashier side: the bill is hidden, no smart button to it
        pay_cashier = payment.with_user(self.cashier)
        self.assertFalse(pay_cashier.reconciled_bill_ids)
        self.assertEqual(pay_cashier.reconciled_bills_count, 0)
        self.assertTrue(pay_cashier.is_reconciled)

        # accountant side: the payment line is shown in the bill, but can't be opened
        bill_accountant = bill.with_user(self.accountant)
        widget = bill_accountant.invoice_payments_widget
        self.assertEqual(len(widget['content']), 1)
        self.assertEqual(bill_accountant.payment_count, 0)
        action = self.env['account.move'].with_user(self.accountant).browse(
            widget['content'][0]['move_id']).action_open_business_doc()
        self.assertEqual(action['tag'], 'display_notification')

    def test_register_payment_wizard_link(self):
        """ Payment registered from the bill (links payment <-> bill without matching). """
        bill = self._create_bill()
        payment = self.env['account.payment.register'].with_context(
            active_model='account.move', active_ids=bill.ids,
        ).create({'journal_id': self.cash_journal.id})._create_payments()
        self.assertIn(bill.payment_state, ('paid', 'in_payment'))
        self._open_everything_as(self.cashier, payment, bill)
        self._open_everything_as(self.accountant, payment, bill)

    def test_cashier_resets_and_edits_reconciled_payment(self):
        bill = self._create_bill()
        payment = self._create_cashier_payment()
        self._reconcile(bill, payment)
        pay_cashier = payment.with_user(self.cashier)
        pay_cashier.action_draft()  # Odoo 19 keeps the reconciliation of draft entries
        self._open_everything_as(self.cashier, payment, bill)
        with Form(pay_cashier) as pay_form:
            pay_form.amount = 900.0  # changes the reconciled items -> unreconcile both sides
        self.assertEqual(bill.payment_state, 'not_paid')
        pay_cashier.action_post()
        self._reconcile(bill, payment)
        pay_cashier.action_cancel()
        self.assertEqual(bill.payment_state, 'not_paid')
        self.assertFalse(payment.move_id.line_ids.matched_debit_ids | payment.move_id.line_ids.matched_credit_ids)
        pay_cashier.action_draft()
        pay_cashier.unlink()
        self.assertFalse(payment.exists())
        self.assertEqual(bill.payment_state, 'not_paid')

    def test_accountant_resets_cancels_and_edits_reconciled_bill(self):
        bill = self._create_bill()
        payment = self._create_cashier_payment()
        self._reconcile(bill, payment)
        bill_accountant = bill.with_user(self.accountant)
        bill_accountant.button_draft()
        self.assertEqual(bill.state, 'draft')
        self._open_everything_as(self.accountant, payment, bill)
        with Form(bill_accountant) as bill_form:
            with bill_form.invoice_line_ids.edit(0) as line_form:
                line_form.price_unit = 800.0  # changes the reconciled items -> unreconcile
        self.assertFalse(payment.is_reconciled)
        bill_accountant.action_post()
        self._reconcile(bill, payment)
        bill_accountant.button_cancel()
        self.assertEqual(bill.state, 'cancel')
        self.assertFalse(payment.is_reconciled)

    def test_unreconcile_from_widget_and_list(self):
        bill = self._create_bill()
        payment = self._create_cashier_payment()
        self._reconcile(bill, payment)
        partial_id = bill.invoice_payments_widget['content'][0]['partial_id']
        bill.with_user(self.accountant).js_remove_outstanding_partial(partial_id)
        self.assertEqual(bill.payment_state, 'not_paid')

        self._reconcile(bill, payment)
        lines = payment.move_id.line_ids.filtered(lambda l: l.account_id == self.payable_account)
        self.env['account.move.line'].with_user(self.cashier).with_context(
            active_ids=lines.ids).action_unreconcile_match_entries()
        self.assertEqual(bill.payment_state, 'not_paid')

    def test_restricted_user_reconciles(self):
        """ A restricted user with both journals reconciles (and can't reconcile hidden items). """
        reconciler = new_test_user(
            self.env, login='jar_reconciler', name='Reconciler',
            groups='base.group_user,account.group_account_user',
            company_id=self.company_data['company'].id,
        )
        self.env['res.users'].sudo().browse(reconciler.id).write({
            'journal_restriction_mode': 'allow',
            'restriction_journal_ids': [Command.set((self.cash_journal | self.purchase_journal).ids)],
        })
        bill = self._create_bill()
        payment = self._create_cashier_payment()
        lines = (bill.line_ids | payment.move_id.line_ids).filtered(lambda l: l.account_id == self.payable_account)
        lines.with_user(reconciler).reconcile()
        self.assertIn(bill.payment_state, ('paid', 'in_payment'))
        self._open_everything_as(self.cashier, payment, bill)

        bill2 = self._create_bill()
        payment2 = self._create_cashier_payment()
        lines = (bill2.line_ids | payment2.move_id.line_ids).filtered(lambda l: l.account_id == self.payable_account)
        with self.assertRaises(AccessError):
            lines.with_user(self.cashier).reconcile()

    def test_exchange_difference_in_hidden_journal(self):
        """ Reconciling items in foreign currency creates an exchange difference entry in the
        exchange journal, which the reconciling user can't access. """
        eur = self.setup_other_currency('EUR')  # 3.0 in 2016, 2.0 in 2017
        company = self.company_data['company']
        exchange_journal = company.currency_exchange_journal_id
        self.assertTrue(exchange_journal)
        reconciler = new_test_user(
            self.env, login='jar_fx_reconciler', name='FX Reconciler',
            groups='base.group_user,account.group_account_user',
            company_id=company.id,
        )
        self.env['res.users'].sudo().browse(reconciler.id).write({
            'journal_restriction_mode': 'allow',
            'restriction_journal_ids': [Command.set((self.cash_journal | self.purchase_journal).ids)],
        })
        self.assertNotIn(exchange_journal, self.cash_journal | self.purchase_journal)
        bill = self.init_invoice('in_invoice', partner=self.partner_a, amounts=[300.0],
                                 invoice_date='2016-01-01', currency=eur, post=True)
        payment = self.env['account.payment'].with_user(self.cashier).create({
            'payment_type': 'outbound',
            'partner_type': 'supplier',
            'partner_id': self.partner_a.id,
            'amount': 300.0,
            'currency_id': eur.id,
            'date': '2017-01-01',
            'journal_id': self.cash_journal.id,
        })
        payment.action_post()
        lines = (bill.line_ids | payment.move_id.line_ids).filtered(
            lambda l: l.account_id == self.payable_account)
        lines.with_user(reconciler).reconcile()
        self.assertIn(bill.payment_state, ('paid', 'in_payment'))
        exchange_move = (lines.matched_debit_ids | lines.matched_credit_ids).exchange_move_id
        self.assertTrue(exchange_move)
        self.assertEqual(exchange_move.journal_id, exchange_journal)
        self.assertFalse(exchange_move.with_user(reconciler).has_access('read'))
        self._open_everything_as(reconciler, payment, bill)
        self._open_everything_as(self.cashier, payment, bill)
        # unreconcile reverses the exchange entry in the hidden journal
        lines.with_user(reconciler).remove_move_reconcile()
        self.assertEqual(bill.payment_state, 'not_paid')

    def test_dashboard_and_partner(self):
        bill = self._create_bill()
        payment = self._create_cashier_payment()
        self._reconcile(bill, payment)
        for user in (self.cashier, self.accountant):
            journals = self.env['account.journal'].with_user(user).search([])
            journals.read(['kanban_dashboard', 'kanban_dashboard_graph', 'json_activity_data'])
            Form(self.partner_a.with_user(user))
        self.env['account.journal'].with_user(self.accountant).search([]).read(['kanban_dashboard'])

    def test_reports(self):
        """ Payment receipt & bill PDF when the bill is paid from several journals. """
        bank_user = new_test_user(
            self.env, login='jar_bank_user', name='Bank User',
            groups='base.group_user,account.group_account_user',
            company_id=self.company_data['company'].id,
        )
        self.env['res.users'].sudo().browse(bank_user.id).write({
            'journal_restriction_mode': 'allow',
            'restriction_journal_ids': [Command.set((self.bank_journal | self.purchase_journal).ids)],
        })
        bill = self._create_bill()
        cash_payment = self._create_cashier_payment(400.0)
        self._reconcile(bill, cash_payment)
        bank_payment = self.env['account.payment.register'].with_context(
            active_model='account.move', active_ids=bill.ids,
        ).create({'journal_id': self.bank_journal.id})._create_payments()
        self.assertIn(bill.payment_state, ('paid', 'in_payment'))

        Report = self.env['ir.actions.report']
        Report.with_user(bank_user)._render_qweb_html('account.action_report_payment_receipt', bank_payment.ids)
        Report.with_user(bank_user)._render_qweb_html('account.account_invoices', bill.ids)
        Report.with_user(self.accountant)._render_qweb_html('account.account_invoices', bill.ids)
        Report.with_user(self.cashier)._render_qweb_html('account.action_report_payment_receipt', cash_payment.ids)
        self._open_everything_as(bank_user, bank_payment, bill)
        self._open_everything_as(bank_user, cash_payment, bill)

    def test_account_restriction_deny(self):
        expense = self.company_data['default_account_expense']
        user = self.env['res.users'].sudo().browse(self.accountant.id)
        user.write({
            'account_restriction_mode': 'deny',
            'restriction_account_ids': [Command.set(expense.ids)],
        })
        bill = self._create_bill()  # has an expense line
        entry = self.env['account.move'].create({
            'move_type': 'entry',
            'journal_id': self.misc_journal.id,
            'line_ids': [
                Command.create({'account_id': self.company_data['default_account_revenue'].id, 'credit': 50}),
                Command.create({'account_id': self.company_data['default_account_receivable'].id, 'debit': 50}),
            ],
        })
        entry.action_post()
        Account = self.env['account.account'].with_user(self.accountant)
        self.assertNotIn(expense, Account.search([]))
        Move = self.env['account.move'].with_user(self.accountant)
        self.assertFalse(Move.search([('id', '=', bill.id)]))
        self.assertTrue(Move.search([('id', '=', entry.id)]))
        Line = self.env['account.move.line'].with_user(self.accountant)
        self.assertFalse(Line.search([('move_id', '=', bill.id)]), "all items of a hidden entry are hidden")
        self.assertEqual(Line.search([('move_id', '=', entry.id)]), entry.line_ids)
        self.assertFalse(Line.search([('account_id', '=', expense.id)]))
        Form(entry.with_user(self.accountant))
        self.assertFalse(self.env['account.invoice.report'].with_user(self.accountant).search(
            [('move_id', '=', bill.id)]))

    def test_account_restriction_allow_with_journal_accounts(self):
        user = self.env['res.users'].sudo().browse(self.cashier.id)
        user.write({'account_restriction_mode': 'allow'})
        user.action_restriction_add_journal_accounts()
        self.assertIn(self.cash_journal.default_account_id, user.restriction_account_ids)
        self.assertIn(self.payable_account, user.restriction_account_ids)
        bill = self._create_bill()
        payment = self._create_cashier_payment()
        self._reconcile(bill, payment)
        self.assertTrue(payment.with_user(self.cashier).has_access('read'))
        self._open_everything_as(self.cashier, payment, bill)
        self.assertNotIn(
            self.company_data['default_account_expense'],
            self.env['account.account'].with_user(self.cashier).search([]))

    def test_payment_state_logic_unchanged(self):
        """ The payment state uses the reconciled bills (hidden to the user): a recompute
        triggered by the restricted user must give the same result. """
        bank_cashier = new_test_user(
            self.env, login='jar_bank_cashier', name='Bank Cashier',
            groups='base.group_user,account.group_account_invoice',
            company_id=self.company_data['company'].id,
        )
        self.env['res.users'].sudo().browse(bank_cashier.id).write({
            'journal_restriction_mode': 'allow',
            'restriction_journal_ids': [Command.set(self.bank_journal.ids)],
        })
        bill = self._create_bill()
        payment = self.env['account.payment'].with_user(bank_cashier).create({
            'payment_type': 'outbound',
            'partner_type': 'supplier',
            'partner_id': self.partner_a.id,
            'amount': 1000.0,
            'journal_id': self.bank_journal.id,
        })
        payment.action_post()
        payment = payment.with_env(self.env)
        self._reconcile(bill, payment)
        expected_state = payment.state
        payment_user = payment.with_user(bank_cashier)
        self.assertFalse(payment_user.reconciled_bill_ids)
        self.env.add_to_compute(payment._fields['state'], payment_user)
        self.assertEqual(payment_user.state, expected_state)
        self.env.invalidate_all()
        self.assertEqual(payment.reconciled_bill_ids, bill)
        self.assertEqual(payment_user.reconciled_bills_count, 0)

    def test_administrator_role_always_has_full_access(self):
        """ Users with the Administrator role are never restricted, even with journals or
        accounts selected on their form; removing the role applies the restriction at once. """
        admin = new_test_user(
            self.env, login='jar_admin', name='Restricted Admin',
            groups='base.group_user,base.group_system,account.group_account_manager',
            company_id=self.company_data['company'].id,
        )
        admin_sudo = self.env['res.users'].sudo().browse(admin.id)
        admin_sudo.write({
            'journal_restriction_mode': 'allow',
            'restriction_journal_ids': [Command.set(self.cash_journal.ids)],
            'account_restriction_mode': 'deny',
            'restriction_account_ids': [Command.set(self.company_data['default_account_expense'].ids)],
        })
        self.assertEqual(admin_sudo.role, 'group_system')
        bill = self._create_bill()
        payment = self._create_cashier_payment()
        self._reconcile(bill, payment)

        def visible_to_admin():
            return (
                self.env['account.journal'].with_user(admin).search_count([('id', '=', self.purchase_journal.id)])
                and self.env['account.move'].with_user(admin).search_count([('id', '=', bill.id)])
                and self.env['account.account'].with_user(admin).search_count(
                    [('id', '=', self.company_data['default_account_expense'].id)])
            )

        self.assertTrue(visible_to_admin())
        self._open_everything_as(admin, payment, bill)
        self.assertEqual(payment.with_user(admin).reconciled_bills_count, 1)

        # Role back to "User": the restriction applies
        admin_sudo.group_ids = [Command.unlink(self.env.ref('base.group_system').id)]
        self.assertNotEqual(admin_sudo.role, 'group_system')
        self.assertFalse(visible_to_admin())

        # Administrator again: full access again
        admin_sudo.group_ids = [Command.link(self.env.ref('base.group_system').id)]
        self.assertTrue(visible_to_admin())

    def test_unrestricted_user_unchanged(self):
        bill = self._create_bill()
        payment = self._create_cashier_payment()
        self._reconcile(bill, payment)
        self.assertEqual(payment.reconciled_bills_count, 1)
        self.assertEqual(bill.payment_count, 1)
        self._open_everything_as(self.env.user, payment, bill)
