# Purchase Report by Period  (Odoo 19)

Technical name: `purchase_report_period`   Depends on: `purchase`

## What it does
* Adds **Purchase > Reporting > Purchase Report by Period** (visible to Purchase Administrators (same as the Reporting menu)).
* Opens a window where you choose: **period (From / To)**, **Vendors**, **Product categories**, and which orders to include.
  Empty selections mean "all".
* **Print PDF** - A4 landscape report: Executive Summary (KPIs, charts with amount + quantity, observations),
  Category/Product report with subtotals + grand total, and Vendor/Product report with subtotals + grand total.
  Table headers repeat on every page, page numbers in the footer.
* **Export Excel** - workbook with Summary (native charts), Category Report, Vendor Report and Source Data.
  Report lines are `SUMPRODUCT` formulas on the Source Data sheet, subtotals/totals are formulas, and a
  reconciliation row compares each report to the source total.

## Data source
`purchase.order.line` (order line of confirmed orders: product_qty, price_unit (shown as "Average cost"), discount, price_subtotal).
* Lines with a section/note (`display_type`) or without a product are ignored.
* "Confirmed" = state `purchase`; the wizard can also include RFQs (everything except cancelled).
* Period filter uses the order date (`date_order`) in the current user's time zone.
* Vendor = the commercial partner of the order partner (contacts roll up to their company).
* Currencies are never mixed: each currency gets its own sections (PDF) / sheets (Excel).
* Same product + identical unit price in the same group is combined; different prices stay on separate lines.
  Unit prices are never summed in subtotals / totals.
* Discount amount = quantity x unit price x discount % ; Total after discount = line untaxed subtotal
  (`price_subtotal`). If these do not reconcile (e.g. tax-included prices) the report says so and keeps the source amounts.
* "Main category" in the charts = the top-level (root) product category of the product.

## Install
1. Copy the `purchase_report_period` folder into an addons path of your Odoo 19 server.
2. Restart Odoo, enable developer mode, *Apps -> Update Apps List*.
3. Install **Purchase Report by Period**.
If an older build of this module is installed, **uninstall it first**, then install this one (or upgrade it from Apps).
Excel export needs the `xlsxwriter` Python package (already required by standard Odoo).
PDF needs `wkhtmltopdf` (standard Odoo requirement).

## Notes
* The wizard model has an access rule (`security/ir.model.access.csv`). Odoo hides a menu whose action points to a
  model the user cannot read, so this rule is required for the menu to appear under Reporting.
* Colours: Odoo base palette (purple #714B67, teal #017E84). The PDF can be printed in light or dark mode
  (field *PDF color mode*); the Excel workbook always uses the light palette. Palette: `_palette()` in
  `wizard/purchase_report_wizard.py`.
* Font: the PDF and Excel use the document font set on the company (Settings > Document Layout), with Odoo's
  Arabic-capable fallbacks, so English and Arabic text use the same font as the rest of Odoo.
