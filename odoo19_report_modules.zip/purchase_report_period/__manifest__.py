# -*- coding: utf-8 -*-
{
    'name': 'Purchase Report by Period',
    'version': '19.0.1.0.0',
    'category': 'Inventory/Purchase',
    'summary': 'Purchase report by period, vendor and product category (PDF + Excel) from purchase order lines',
    'description': """
Purchase Report by Period
=================
Wizard (period, vendor, product category) that prints a landscape A4 PDF and exports an Excel workbook.
Source data: purchase.order.line.
""",
    'author': 'Custom',
    'license': 'LGPL-3',
    'depends': ['purchase'],
    'data': [
        'security/ir.model.access.csv',
        'views/purchase_report_line_views.xml',
        'wizard/purchase_report_wizard_views.xml',
        'report/purchase_report_report.xml',
        'report/purchase_report_report_templates.xml',
    ],
    'installable': True,
    'application': False,
}
