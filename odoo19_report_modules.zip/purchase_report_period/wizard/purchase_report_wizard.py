# -*- coding: utf-8 -*-
import base64
import io
from collections import OrderedDict
from datetime import datetime, time

import pytz

from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


def fmt_amt(v):
    return '{:,.2f}'.format(v or 0.0)


def fmt_amt0(v):
    return '{:,.0f}'.format(v or 0.0)


def fmt_qty(v):
    v = v or 0.0
    return ('{:,.0f}' if abs(v - round(v)) < 1e-9 else '{:,.3f}').format(v)


def fmt_price(v):
    s = '{:,.4f}'.format(v or 0.0)
    head, _dot, dec = s.partition('.')
    dec = dec.rstrip('0').ljust(2, '0')
    return '%s.%s' % (head, dec)


# Colour themes. 'report' = the design of the HTML reports; 'odoo' = Odoo base colours.
BASE_THEMES = {
    'report': {'primary': '#3A3F47', 'secondary': '#6B7280', 'tint': '#E5E7EB', 'hdrbg': '#3A3F47',
               'hdrfg': '#FFFFFF', 'bar3': '#9CA3AF', 'dark': '#6B7280'},
    'odoo': {'primary': '#714B67', 'secondary': '#017E84', 'tint': '#EFE7ED', 'hdrbg': '#714B67',
             'hdrfg': '#FFFFFF', 'bar3': '#A98BA0', 'dark': '#714B67'},
}


def mix_hex(c1, c2, t):
    """Mix two #RRGGBB colours: t=0 gives c1, t=1 gives c2."""
    a = [int(c1[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(c2[i:i + 2], 16) for i in (1, 3, 5)]
    return '#%02X%02X%02X' % tuple(round(x + (y - x) * t) for x, y in zip(a, b))


class PurchaseReportWizard(models.TransientModel):
    _name = 'purchase.report.wizard'
    _description = 'Purchase Report by Period Wizard'

    company_id = fields.Many2one(
        'res.company', required=True, default=lambda self: self.env.company)
    date_from = fields.Date(
        string='From', required=True,
        default=lambda self: fields.Date.context_today(self).replace(day=1))
    date_to = fields.Date(
        string='To', required=True, default=fields.Date.context_today)
    partner_ids = fields.Many2many(
        'res.partner', 'purchase_report_wiz_partner_rel', 'wizard_id', 'partner_id', string='Vendors',
        help='Leave empty to include all vendors.')
    categ_ids = fields.Many2many(
        'product.category', 'purchase_report_wiz_categ_rel', 'wizard_id', 'categ_id', string='Product categories',
        domain=[],
        help='Leave empty to include all categories. Sub-categories are included.')
    color_theme = fields.Selection(
        [('report', 'Report design (as the HTML report)'), ('odoo', 'Odoo colours')],
        string='Design', default='report', required=True)
    color_mode = fields.Selection(
        [('light', 'Light'), ('dark', 'Dark')], string='PDF color mode',
        default='light', required=True,
        help='Light or dark page for the PDF (the Excel file always uses the light colours).')
    state_filter = fields.Selection(
        [('confirmed', 'Confirmed purchase orders'), ('all', 'All except cancelled')],
        string='Orders', default='confirmed', required=True)

    # ------------------------------------------------------------------ checks
    @api.constrains('date_from', 'date_to')
    def _check_dates(self):
        for wiz in self:
            if wiz.date_from and wiz.date_to and wiz.date_from > wiz.date_to:
                raise ValidationError(_('The "From" date must not be after the "To" date.'))

    # ------------------------------------------------------------------ helpers
    def _palette(self, mode=None, theme=None):
        """Colour palette: `theme` 'report' (same design as the HTML reports) or 'odoo' (Odoo purple/teal);
        `mode` 'light' or 'dark'."""
        mode = mode or self.color_mode or 'light'
        base = dict(BASE_THEMES[theme or self.color_theme or 'report'])
        if mode == 'dark':
            acc = base['dark']
            return {
                'primary': acc, 'secondary': base['secondary'], 'bg': '#1B1E24', 'surface': '#262A31',
                'text': '#E9ECEF', 'muted': '#A5ABB3', 'border': '#3A3F47',
                'tint': mix_hex(acc, '#1B1E24', 0.30), 'tinttext': mix_hex(acc, '#FFFFFF', 0.70),
                'ttl': mix_hex(acc, '#FFFFFF', 0.65), 'hdrbg': acc, 'hdrfg': '#FFFFFF',
                'bar1': mix_hex(base['primary'], '#FFFFFF', 0.45), 'bar2': mix_hex(base['secondary'], '#FFFFFF', 0.35),
                'bar3': mix_hex(base['bar3'], '#FFFFFF', 0.20),
            }
        return {
            'primary': base['primary'], 'secondary': base['secondary'], 'bg': '#FFFFFF',
            'surface': mix_hex(base['tint'], '#FFFFFF', 0.50), 'text': '#000000', 'muted': '#777777',
            'border': '#DDDDDD', 'tint': base['tint'], 'tinttext': base['primary'], 'ttl': base['primary'],
            'hdrbg': base['hdrbg'], 'hdrfg': base['hdrfg'],
            'bar1': base['primary'], 'bar2': base['secondary'], 'bar3': base['bar3'],
        }

    def _font_name(self):
        """The document font configured on the company (Settings > Document Layout)."""
        self.ensure_one()
        font = getattr(self.company_id, 'font', False) or 'Lato'
        return str(font).replace('_', ' ')

    def _font_family(self):
        """Company font first, then the fonts Odoo ships for Arabic and other scripts."""
        return ('"%s", "Odoo Unicode Support Noto", "Noto Sans Arabic", Tajawal, '
                'system-ui, "Segoe UI", sans-serif' % self._font_name())

    def _period_label(self):
        self.ensure_one()
        f = '%d %B %Y'
        if self.date_from == self.date_to:
            return self.date_from.strftime(f)
        return '%s - %s' % (self.date_from.strftime(f), self.date_to.strftime(f))

    def _file_stem(self):
        self.ensure_one()
        if self.date_from == self.date_to:
            d = str(self.date_from)
        else:
            d = '%s_to_%s' % (self.date_from, self.date_to)
        return 'Purchases-%s' % d

    def _get_domain(self):
        self.ensure_one()
        tz = pytz.timezone(self.env.user.tz or 'UTC')
        start = tz.localize(datetime.combine(self.date_from, time.min)).astimezone(pytz.utc).replace(tzinfo=None)
        end = tz.localize(datetime.combine(self.date_to, time(23, 59, 59))).astimezone(pytz.utc).replace(tzinfo=None)
        domain = [
            ('display_type', '=', False),
            ('product_id', '!=', False),
            ('company_id', '=', self.company_id.id),
            ('order_id.date_order', '>=', start),
            ('order_id.date_order', '<=', end),
        ]
        if self.state_filter == 'confirmed':
            domain.append(('order_id.state', 'in', ['purchase']))
        else:
            domain.append(('order_id.state', '!=', 'cancel'))
        if self.partner_ids:
            domain.append(('order_id.partner_id.commercial_partner_id', 'in',
                           self.partner_ids.commercial_partner_id.ids))
        if self.categ_ids:
            domain.append(('product_id.categ_id', 'child_of', self.categ_ids.ids))
        return domain

    @staticmethod
    def _main_categ(categ):
        while categ.parent_id:
            categ = categ.parent_id
        return categ

    @staticmethod
    def _group(raw, key):
        """Group by `key` then by (product, unit price): identical prices are combined,
        different prices stay on separate lines. Unit prices are never summed."""
        groups = OrderedDict()
        for r in raw:
            g = groups.setdefault(r[key], OrderedDict())
            k = (r['product'], round(r['price'], 6))
            ln = g.setdefault(k, {'product': r['product'], 'price': r['price'],
                                  'qty': 0.0, 'gross': 0.0, 'disc': 0.0, 'net': 0.0})
            for f in ('qty', 'gross', 'disc', 'net'):
                ln[f] += r[f]
        out = []
        for name, lines in groups.items():
            lines = sorted(lines.values(), key=lambda x: (-x['net'], x['product']))
            out.append({
                'name': name, 'lines': lines,
                'qty': sum(x['qty'] for x in lines), 'gross': sum(x['gross'] for x in lines),
                'disc': sum(x['disc'] for x in lines), 'net': sum(x['net'] for x in lines),
            })
        out.sort(key=lambda g: (-g['net'], g['name']))
        return out

    @staticmethod
    def _items(groups):
        return [{'name': g['name'], 'net': g['net'], 'qty': g['qty']} for g in groups]

    @staticmethod
    def _bars(items, limit=9):
        items = list(items)
        if len(items) > limit:
            rest = items[limit - 1:]
            items = items[:limit - 1] + [{
                'name': _('Other (%s more)') % len(rest),
                'net': sum(i['net'] for i in rest), 'qty': sum(i['qty'] for i in rest)}]
        mx = max([abs(i['net']) for i in items] or [0.0]) or 1.0
        return [dict(i, bar=round(abs(i['net']) / mx * 100.0, 1)) for i in items]

    # ------------------------------------------------------------------ data
    def _prepare_data(self):
        """Return one section per currency (currencies are never mixed)."""
        self.ensure_one()
        Line = self.env['purchase.order.line']
        lines = Line.search(self._get_domain(), order='order_id, id')
        by_cur = OrderedDict()
        for line in lines:
            by_cur.setdefault(line.currency_id, []).append(line)
        return [self._build_section(cur, lns) for cur, lns in by_cur.items()]

    def _build_section(self, cur, lines):
        self.ensure_one()
        raw = []
        for l in lines:
            qty = l.product_qty
            price = l.price_unit
            pct = l['discount'] if 'discount' in l._fields else 0.0
            gross = qty * price
            categ = l.product_id.categ_id
            raw.append({
                'order': l.order_id.name or '',
                'date': (fields.Datetime.context_timestamp(self, l.order_id.date_order).strftime('%Y-%m-%d %H:%M')
                         if l.order_id.date_order else ''),
                'partner': l.order_id.partner_id.commercial_partner_id.name or '',
                'categ': categ.complete_name or categ.name or '',
                'main': self._main_categ(categ).name or '',
                'product': l.product_id.with_context(display_default_code=False).display_name,
                'qty': qty, 'price': price, 'pct': pct,
                'gross': gross, 'disc': gross * pct / 100.0, 'net': l.price_subtotal,
            })
        totals = {k: sum(r[k] for r in raw) for k in ('qty', 'gross', 'disc', 'net')}
        cats = self._group(raw, 'categ')
        parts = self._group(raw, 'partner')
        mains = {}
        for r in raw:
            m = mains.setdefault(r['main'], {'name': r['main'], 'net': 0.0, 'qty': 0.0})
            m['net'] += r['net']
            m['qty'] += r['qty']
        mains = sorted(mains.values(), key=lambda x: (-x['net'], x['name']))

        def disc_items(key):
            d = {}
            for r in raw:
                if abs(r['disc']) < 1e-9:
                    continue
                x = d.setdefault(r[key], {'name': r[key], 'net': 0.0, 'qty': 0.0})
                x['net'] += r['disc']
                x['qty'] += r['qty']
            return sorted(d.values(), key=lambda x: (-x['net'], x['name']))

        net_word = 'purchases'
        obs = []
        if cats:
            obs.append('Largest category: %s - %s %s net %s (%s of total).' % (
                cats[0]['name'], fmt_amt(cats[0]['net']), cur.name, net_word,
                '{:.1%}'.format(cats[0]['net'] / totals['net']) if totals['net'] else 'n/a'))
        if parts:
            obs.append('Largest vendor: %s - %s %s net %s (%s of total).' % (
                parts[0]['name'], fmt_amt(parts[0]['net']), cur.name, net_word,
                '{:.1%}'.format(parts[0]['net'] / totals['net']) if totals['net'] else 'n/a'))
        full = [(g['name'], l) for g in cats for l in g['lines']
                if l['disc'] > 0 and abs(l['net']) < 0.005 and l['gross'] > 0]
        if len(full) > 3:
            obs.append('Fully discounted: %s product lines, e.g. %s - total discount %s %s.' % (
                len(full), ', '.join(l['product'] for _c, l in full[:3]),
                fmt_amt(sum(l['disc'] for _c, l in full)), cur.name))
        else:
            for cname, l in full:
                obs.append('Fully discounted: %s (%s) - %s units at %s each; the discount of %s '
                           'equals the gross value, so net is 0.00.' % (
                               l['product'], cname, fmt_qty(l['qty']), fmt_price(l['price']), fmt_amt(l['disc'])))
        diff = totals['gross'] - totals['disc'] - totals['net']
        if abs(diff) > 0.005:
            obs.append('Reconciliation: gross %s - discounts %s differs from net %s by %s. The source amounts '
                       'are kept unchanged; the gap may come from tax-included prices or another adjustment.' % (
                           fmt_amt(totals['gross']), fmt_amt(totals['disc']), fmt_amt(totals['net']), fmt_amt(diff)))
        else:
            obs.append('Reconciliation: gross %s - discounts %s = net %s; every line matches, '
                       'so no tax or other adjustment applies.' % (
                           fmt_amt(totals['gross']), fmt_amt(totals['disc']), fmt_amt(totals['net'])))
        return {
            'code': cur.name, 'symbol': cur.symbol or cur.name,
            'totals': totals, 'raw': raw, 'cats': cats, 'parts': parts, 'mains': mains,
            'main_chart': self._bars(mains), 'cat_chart': self._bars(self._items(cats)),
            'part_chart': self._bars(self._items(parts)),
            'disc_part': self._bars(disc_items('partner'), 16),
            'disc_prod': self._bars(disc_items('product'), 16),
            'obs': obs, 'n_lines': len(raw),
        }

    # ------------------------------------------------------------------ actions
    def _get_sections_or_raise(self):
        self.ensure_one()
        sections = self._prepare_data()
        if not sections:
            raise UserError(_('No purchase order lines found for the selected period and filters.'))
        return sections

    def _domain_json(self):
        """The search domain with datetimes turned into strings (safe inside an action dict)."""
        out = []
        for leaf in self._get_domain():
            if isinstance(leaf, (tuple, list)) and len(leaf) == 3:
                field, op, val = leaf
                if isinstance(val, datetime):
                    val = fields.Datetime.to_string(val)
                leaf = (field, op, val)
            out.append(leaf)
        return out

    def action_view_screen(self):
        """On-screen report: lines grouped Currency > Vendor > Product. Click a group to
        expand all its order lines; the arrow button on a line opens the order."""
        self.ensure_one()
        self._get_sections_or_raise()
        view = self.env.ref('purchase_report_period.view_purchase_report_line_list')
        search = self.env.ref('purchase_report_period.view_purchase_report_line_search')
        return {
            'type': 'ir.actions.act_window',
            'name': 'Purchase Report - %s' % self._period_label(),
            'res_model': 'purchase.order.line',
            'view_mode': 'list',
            'views': [(view.id, 'list')],
            'search_view_id': [search.id, 'search'],
            'domain': self._domain_json(),
            'context': {'group_by': ['currency_id', 'partner_id', 'product_id'], 'create': False},
            'target': 'current',
        }

    def action_print_pdf(self):
        self.ensure_one()
        self._get_sections_or_raise()
        return self.env.ref('purchase_report_period.action_report_purchase_report').report_action(self)

    def action_export_xlsx(self):
        self.ensure_one()
        sections = self._get_sections_or_raise()
        content = self._build_xlsx(sections)
        att = self.env['ir.attachment'].create({
            'name': '%s.xlsx' % self._file_stem(),
            'type': 'binary',
            'datas': base64.b64encode(content),
            'res_model': self._name,
            'res_id': self.id,
            'mimetype': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        })
        return {'type': 'ir.actions.act_url',
                'url': '/web/content/%s?download=true' % att.id, 'target': 'self'}

    # ------------------------------------------------------------------ excel
    def _build_xlsx(self, sections):
        import xlsxwriter
        company_name = self.company_id.name or ''
        period = self._period_label()
        buf = io.BytesIO()
        wb = xlsxwriter.Workbook(buf, {'in_memory': True})
        base = {'font_name': self._font_name(), 'font_size': 10}

        def F(**kw):
            d = dict(base)
            d.update(kw)
            return wb.add_format(d)

        pal = self._palette('light', self.color_theme)
        NAVY, MID, LIGHT, HBG, HFG = pal['primary'], pal['secondary'], pal['tint'], pal['hdrbg'], pal['hdrfg']
        AMT = '#,##0.00;[Red]-#,##0.00'
        f_title = F(bold=True, font_size=16, font_color=HFG, bg_color=HBG, valign='vcenter')
        f_sub = F(font_color='#FFFFFF', bg_color=MID)
        f_head = F(bold=True, font_color=HFG, bg_color=HBG, text_wrap=True, valign='vcenter')
        f_headr = F(bold=True, font_color=HFG, bg_color=HBG, text_wrap=True, valign='vcenter', align='right')
        f_lbl = F(bold=True, font_color=NAVY)
        f_txt = F(bottom=4, bottom_color='#BFBFBF')
        f_bold = F(bold=True, bottom=4, bottom_color='#BFBFBF')
        f_grey = F(font_color='#7F7F7F', bottom=4, bottom_color='#BFBFBF')
        f_amt = F(num_format=AMT, bottom=4, bottom_color='#BFBFBF')
        f_price = F(num_format='#,##0.00##', font_color='#0000FF', bottom=4, bottom_color='#BFBFBF')
        f_sublbl = F(bold=True, font_color=NAVY, bg_color=LIGHT, top=1, bottom=1)
        f_subamt = F(bold=True, font_color=NAVY, bg_color=LIGHT, top=1, bottom=1, num_format=AMT)
        f_totlbl = F(bold=True, font_size=12, font_color='#FFFFFF', bg_color=NAVY)
        f_totamt = F(bold=True, font_size=12, font_color='#FFFFFF', bg_color=NAVY, num_format=AMT)
        f_note = F(italic=True, font_size=9, font_color='#7F7F7F')
        f_noteamt = F(italic=True, font_size=9, font_color='#7F7F7F', num_format=AMT)
        f_pct = F(num_format='0.0%', bottom=4, bottom_color='#BFBFBF')
        f_wrap = F(text_wrap=True, valign='top')
        multi = len(sections) > 1

        for s in sections:
            sfx = ' ' + s['code'] if multi else ''

            def nm(base_name):
                return (base_name + sfx)[:31]

            raw, t = s['raw'], s['totals']
            int_qty = all(abs(r['qty'] - round(r['qty'])) < 1e-9 for r in raw)
            QTY = '#,##0;[Red]-#,##0' if int_qty else '#,##0.00;[Red]-#,##0.00'
            f_qty = F(num_format=QTY, bottom=4, bottom_color='#BFBFBF')
            f_subqty = F(bold=True, font_color=NAVY, bg_color=LIGHT, top=1, bottom=1, num_format=QTY)
            f_totqty = F(bold=True, font_size=12, font_color='#FFFFFF', bg_color=NAVY, num_format=QTY)
            f_noteqty = F(italic=True, font_size=9, font_color='#7F7F7F', num_format=QTY)
            ws_s = wb.add_worksheet(nm('Summary'))
            ws_c = wb.add_worksheet(nm('Category Report'))
            ws_p = wb.add_worksheet(nm('Vendor Report'))
            ws_d = wb.add_worksheet(nm('Source Data'))
            n = len(raw)
            src = ws_d.get_name()

            def rng(col):
                return "'%s'!$%s$2:$%s$%s" % (src, col, col, n + 1)

            # ---- source data
            heads = ['Order', 'Order date', 'Vendor', 'Category', 'Main category', 'Product',
                     'Quantity', 'Average cost', 'Discount %', 'Discount amount', 'Net amount (untaxed)']
            for c, h in enumerate(heads):
                ws_d.write(0, c, h, f_headr if c >= 6 else f_head)
            for i, r in enumerate(raw, start=1):
                vals = [r['order'], r['date'], r['partner'], r['categ'], r['main'], r['product']]
                for c, v in enumerate(vals):
                    ws_d.write(i, c, v)
                ws_d.write_number(i, 6, r['qty'], f_qty)
                ws_d.write_number(i, 7, r['price'], F(num_format='#,##0.00##'))
                ws_d.write_number(i, 8, r['pct'], F(num_format='0.00'))
                ws_d.write_number(i, 9, r['disc'], f_amt)
                ws_d.write_number(i, 10, r['net'], f_amt)
            for c, w in enumerate([16, 17, 30, 30, 20, 38, 11, 13, 10, 15, 18]):
                ws_d.set_column(c, c, w)
            ws_d.freeze_panes(1, 0)

            # ---- category / partner reports
            def report(ws, title, groups, keycol, head):
                ws.hide_gridlines(2)
                ws.merge_range(0, 0, 0, 5, title, f_title)
                ws.set_row(0, 28)
                ws.merge_range(1, 0, 1, 5, '%s | %s | All amounts in %s' % (company_name, period, s['code']), f_sub)
                for c, h in enumerate([head, 'Product', 'Quantity', 'Average cost', 'Discount amount',
                                       'Total amount after discounts']):
                    ws.write(3, c, h, f_head if c < 2 else f_headr)
                ws.set_row(3, 30)
                r, subs = 4, []
                for g in groups:
                    first = r
                    for i, l in enumerate(g['lines']):
                        x = r + 1
                        crit = "(%s=$A%s)*(%s=$B%s)*(ROUND(%s,6)=ROUND($D%s,6))" % (rng(keycol), x, rng('F'), x, rng('H'), x)
                        ws.write(r, 0, g['name'], f_grey if i else f_bold)
                        ws.write(r, 1, l['product'], f_txt)
                        ws.write_formula(r, 2, '=SUMPRODUCT(%s*%s)' % (crit, rng('G')), f_qty, l['qty'])
                        ws.write_number(r, 3, l['price'], f_price)
                        ws.write_formula(r, 4, '=SUMPRODUCT(%s*%s)' % (crit, rng('J')), f_amt, l['disc'])
                        ws.write_formula(r, 5, '=SUMPRODUCT(%s*%s)' % (crit, rng('K')), f_amt, l['net'])
                        r += 1
                    ws.merge_range(r, 0, r, 1, 'Subtotal - %s' % g['name'], f_sublbl)
                    ws.write_blank(r, 3, None, f_subamt)
                    for c, L, val, fm in ((2, 'C', g['qty'], f_subqty), (4, 'E', g['disc'], f_subamt),
                                          (5, 'F', g['net'], f_subamt)):
                        ws.write_formula(r, c, '=SUM(%s%s:%s%s)' % (L, first + 1, L, r), fm, val)
                    subs.append(r)
                    r += 1
                ws.merge_range(r, 0, r, 1, 'GRAND TOTAL', f_totlbl)
                ws.write_blank(r, 3, None, f_totamt)
                for c, L, val, fm in ((2, 'C', t['qty'], f_totqty), (4, 'E', t['disc'], f_totamt),
                                      (5, 'F', t['net'], f_totamt)):
                    ws.write_formula(r, c, '=' + '+'.join('%s%s' % (L, x + 1) for x in subs), fm, val)
                ws.set_row(r, 22)
                ws.write(r + 2, 0, 'Source total (Source Data sheet)', f_note)
                ws.write(r + 3, 0, 'Difference (report - source)', f_note)
                for c, L, SL, val, fm in ((2, 'C', 'G', t['qty'], f_noteqty), (4, 'E', 'J', t['disc'], f_noteamt),
                                          (5, 'F', 'K', t['net'], f_noteamt)):
                    ws.write_formula(r + 2, c, '=SUM(%s)' % rng(SL), fm, val)
                    ws.write_formula(r + 3, c, '=%s%s-%s%s' % (L, r + 1, L, r + 3), fm, 0)
                ws.write(r + 5, 0, 'Identical unit prices are combined; different prices are separate lines. '
                                   'Unit prices are never summed.', f_note)
                for c, w in enumerate([34, 44, 13, 14, 17, 24]):
                    ws.set_column(c, c, w)
                ws.freeze_panes(4, 0)
                ws.set_landscape()
                ws.fit_to_pages(1, 0)
                ws.repeat_rows(3)
                return subs

            csubs = report(ws_c, 'Category and Product Report', s['cats'], 'D', 'Category')
            psubs = report(ws_p, 'Vendor and Product Report', s['parts'], 'C', 'Vendor')

            # ---- summary
            ws = ws_s
            ws.hide_gridlines(2)
            ws.merge_range(0, 0, 0, 10, company_name, f_title)
            ws.set_row(0, 32)
            ws.merge_range(1, 0, 1, 10, 'Purchase Report - Executive Summary', f_sub)
            for i, (a, b) in enumerate([('Company', company_name), ('Reporting period', period),
                                        ('Currency', s['code'])]):
                ws.write(3 + i, 0, a, f_lbl)
                ws.write(3 + i, 1, b)
            ws.write(7, 0, 'Key figures', f_head)
            ws.write(7, 1, 'Amount', f_headr)
            kpis = [
                ('Gross purchases before discounts', '=SUMPRODUCT(%s*%s)' % (rng('G'), rng('H')), t['gross'], f_amt),
                ('Discounts', '=SUM(%s)' % rng('J'), t['disc'], f_amt),
                ('Net purchases after discounts', '=SUM(%s)' % rng('K'), t['net'], f_totamt),
                ('Ordered quantity (units)', '=SUM(%s)' % rng('G'), t['qty'], f_qty),
            ]
            for i, (lab, fo, val, fm) in enumerate(kpis):
                ws.write(8 + i, 0, lab, f_totlbl if i == 2 else f_txt)
                ws.write_formula(8 + i, 1, fo, fm, val)
            top = 14
            sn = ws.get_name()

            def table(col0, title, items, formulas):
                ws.write(top - 1, col0, title, f_head)
                ws.write(top - 1, col0 + 1, 'Net purchases', f_headr)
                ws.write(top - 1, col0 + 2, 'Quantity', f_headr)
                for i, it in enumerate(items):
                    ws.write(top + i, col0, it['name'], f_txt)
                    fn, fq = formulas(i, it)
                    ws.write_formula(top + i, col0 + 1, fn, f_amt, it['net'])
                    ws.write_formula(top + i, col0 + 2, fq, f_qty, it['qty'])

            mains = s['mains']
            table(0, 'Main category', mains, lambda i, it: (
                '=SUMPRODUCT((%s=$A%s)*%s)' % (rng('E'), top + i + 1, rng('K')),
                '=SUMPRODUCT((%s=$A%s)*%s)' % (rng('E'), top + i + 1, rng('G'))))
            table(4, 'Category', s['cats'], lambda i, it: (
                "='%s'!F%s" % (ws_c.get_name(), csubs[i] + 1), "='%s'!C%s" % (ws_c.get_name(), csubs[i] + 1)))
            table(8, 'Vendor', s['parts'], lambda i, it: (
                "='%s'!F%s" % (ws_p.get_name(), psubs[i] + 1), "='%s'!C%s" % (ws_p.get_name(), psubs[i] + 1)))
            for c, w in enumerate([36, 18, 12, 3, 36, 18, 12, 3, 36, 18, 12]):
                ws.set_column(c, c, w)
            longest = max(len(mains), len(s['cats']), len(s['parts']))
            crow = top + longest + 2
            for col0, title, count, color in ((0, 'Net by main category', len(mains), NAVY),
                                              (4, 'Net by category', len(s['cats']), MID),
                                              (8, 'Net by vendor', len(s['parts']), pal['bar3'])):
                ch = wb.add_chart({'type': 'bar'})
                ch.add_series({
                    'name': title,
                    'categories': [sn, top, col0, top + count - 1, col0],
                    'values': [sn, top, col0 + 1, top + count - 1, col0 + 1],
                    'fill': {'color': color},
                    'data_labels': {'value': True, 'num_format': '#,##0.00'},
                })
                ch.set_title({'name': '%s (%s)' % (title, s['code']), 'name_font': {'size': 11}})
                ch.set_legend({'none': True})
                ch.set_y_axis({'reverse': True})
                ch.set_size({'width': 470, 'height': 300})
                ws.insert_chart(crow, col0, ch)
            orow = crow + 17
            ws.write(orow, 0, 'Key observations', f_head)
            for c in range(1, 11):
                ws.write_blank(orow, c, None, f_head)
            for i, o in enumerate(s['obs'], start=1):
                ws.merge_range(orow + i, 0, orow + i, 10, o, f_wrap)
                ws.set_row(orow + i, 30)
            ws.set_landscape()
            ws.fit_to_pages(1, 0)

        wb.close()
        return buf.getvalue()
