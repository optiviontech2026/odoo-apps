# -*- coding: utf-8 -*-
{
    'name': 'Sales Report by Period',
    'version': '19.0.1.0.0',
    'category': 'Sales/Reporting',
    'summary': 'Sales report by period, customer and main product category (PDF + Excel) from sale order lines',
    'description': """
Sales Report by Period
=================
Wizard (period, customer, main product category) that prints a landscape A4 PDF and exports an Excel workbook.
Source data: sale.order.line.
""",
    'author': 'Custom',
    'license': 'LGPL-3',
    'depends': ['sale'],
    'data': [
        'security/ir.model.access.csv',
        'views/sales_report_line_views.xml',
        'wizard/sales_report_wizard_views.xml',
        'report/sales_report_report.xml',
        'report/sales_report_report_templates.xml',
    ],
    'installable': True,
    'application': False,
}
