# -*- coding: utf-8 -*-
from odoo import models


class OrderLine(models.Model):
    _inherit = 'sale.order.line'

    def action_open_sales_report_order(self):
        # Open the order of this line (used by the on-screen report).
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'res_model': self.order_id._name,
            'res_id': self.order_id.id,
            'view_mode': 'form',
            'target': 'current',
        }
