# -*- coding: utf-8 -*-
from markupsafe import Markup

from odoo import api, models

from ..wizard.sales_report_wizard import fmt_amt, fmt_amt0, fmt_qty, fmt_price


def build_css(p, family):
    """Stylesheet of the PDF (light or dark) built from the Odoo base palette."""
    return Markup(
        "html,body{background:%(bg)s;color:%(text)s;}"
        ".rpt{font-family:%(fam)s;color:%(text)s;}"
        ".ttl{font-weight:bold;color:%(ttl)s;border-bottom:1px solid %(border)s;padding-bottom:3px;margin-bottom:6px;font-size:12px;}"
        ".hdr{background:%(hdrbg)s;color:%(hdrfg)s;}"
        ".ftr{font-size:9px;color:%(muted)s;border-top:1px solid %(primary)s;padding-top:4px;}"
        ".rt{width:100%%;border-collapse:collapse;font-size:11px;}"
        ".rt th{background:%(hdrbg)s;color:%(hdrfg)s;padding:5px 6px;text-align:left;border-bottom:2px solid %(primary)s;}"
        ".rt td{padding:3px 6px;border-bottom:1px solid %(border)s;}"
        ".rt .r{text-align:right;}"
        ".rt tr.sub td{background:%(tint)s;color:%(tinttext)s;font-weight:bold;border-top:1px solid %(primary)s;border-bottom:1px solid %(primary)s;}"
        ".rt tr.tot td{background:%(primary)s;color:#fff;font-weight:bold;font-size:12px;}"
        ".rt thead{display:table-header-group;}"
        ".rt tr{page-break-inside:avoid;}"
        ".kpi td{border:1px solid %(primary)s;padding:8px 12px;background:%(surface)s;width:25%%;}"
        ".kpi td.net{background:%(primary)s;color:#fff;}"
        ".kpi .lbl{font-size:9px;letter-spacing:.4px;text-transform:uppercase;}"
        ".kpi .val{font-size:20px;font-weight:bold;margin:3px 0;}"
        "h4.sec{color:%(ttl)s;margin:0 0 8px 0;font-size:15px;}"
        % dict(p, fam=family))


class ReportSalesReportWizard(models.AbstractModel):
    _name = 'report.sales_report_period.report_sales_report'
    _description = 'Sales Report by Period (PDF)'

    @api.model
    def _get_report_values(self, docids, data=None):
        docs = self.env['sales.report.wizard'].browse(docids)
        first = docs[:1]
        data_by_doc = {d.id: d._prepare_data() for d in docs}
        currencies = sorted({sec['code'] for secs in data_by_doc.values() for sec in secs})
        return {
            'doc_ids': docids,
            'doc_model': 'sales.report.wizard',
            'docs': docs,
            'data_by_doc': data_by_doc,
            'company_name': first.company_id.name or '',
            'period': first._period_label() if first else '',
            'currencies': ', '.join(currencies),
            'fmt_amt': fmt_amt,
            'fmt_amt0': fmt_amt0,
            'fmt_qty': fmt_qty,
            'fmt_price': fmt_price,
            'pal': first._palette() if first else {},
            'css': build_css(first._palette(), first._font_family()) if first else '',
        }
