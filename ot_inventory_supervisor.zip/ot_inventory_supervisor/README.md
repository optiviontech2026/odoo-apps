# Inventory Supervisor Access (Odoo 19)

*Optivion Tech*

Adds a **Supervisor** level to **Settings › Users › Access Rights › Inventory**,
between *User* and *Administrator*.

## What a Supervisor gets

| Area | Supervisor |
|---|---|
| Overview, Transfers, Products | Yes |
| Reporting (Stock, Moves History, Moves Analysis) | Yes (tickable) |
| Operations › Replenishment / reordering rules | Yes (tickable) |
| **Configuration** menu | **Always hidden** |
| **Physical Inventory** | **Hidden and blocked** (tickable) |
| **Sales Price / Cost** | **Read-only** in every product view and blocked on the server (tickable) |

## Detailed rights (check boxes)

When **Supervisor** is selected in the Inventory drop-down of a user, a section
**"Inventory Supervisor — Detailed Access Rights"** appears under the access
rights. The defaults below are ticked automatically; untick or tick as needed,
then save.

| Check box | Default | What it controls |
|---|---|---|
| Validate Transfers | ✔ | *Validate* button and the *Validate* action |
| Cancel Transfers | ✔ | *Cancel* button (also when an SO/PO cancels its transfers) |
| Delete Transfers | ✔ | Deleting draft / cancelled transfers |
| Create Returns | ✔ | *Return* button and return wizard |
| Scrap Products | ✔ | Scrap menu, *Scrap* action, scrap validation |
| Create & Edit Products | ✔ | Create / edit products (prices stay locked) |
| Replenishment | ✔ | Replenishment menu, reordering rules |
| Inventory Reporting | ✔ | Reporting menu |
| Edit Sales Price | ✘ | Unlock Sales Price |
| Edit Cost | ✘ | Unlock Cost |
| Physical Inventory | ✘ | Physical Inventory menu, counting and applying adjustments |

**Landed Costs** (✘ by default) comes from the small add-on
`ot_inventory_supervisor_landed_costs`, which installs automatically on new
databases that have *Landed Costs*. On an existing database, install
"Inventory Supervisor Access - Landed Costs" from Apps once. It gives the same
Landed Costs access as an Inventory Administrator (menu, create / compute /
validate / cancel, and the Landed Costs buttons on vendor bills). Posting the
journal entry also needs Accounting rights, as for an Administrator.

Each right is a normal group named `Inventory Supervisor: …` (visible under
*Extra Rights* in debug mode), so it also works with imports and the Groups menu.

## Notes

* Restrictions apply only to Supervisors. Inventory *User* and *Administrator*
  behave exactly as in standard Odoo.
* Every restriction is enforced on the server too, not only by hiding buttons.
* Choosing another Inventory level removes the detailed rights automatically.
* After changing a user's rights, the user should refresh the browser.
* Before uninstalling, move Supervisors to another Inventory level (uninstalling
  deletes the Supervisor group and its users lose Inventory access).

## Tests

```
odoo-bin -d <db> -u ot_inventory_supervisor --test-enable --test-tags /ot_inventory_supervisor --stop-after-init
```
