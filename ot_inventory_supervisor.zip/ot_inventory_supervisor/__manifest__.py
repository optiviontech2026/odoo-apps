{
    'name': 'Inventory Supervisor Access',
    'version': '19.0.1.1.0',
    'summary': 'New Inventory access level: all operations without Configuration '
               'and Physical Inventory, locked Sales Price and Cost, plus '
               'detailed rights you can tick per user.',
    'description': """
Inventory Supervisor Access
===========================
Adds a **Supervisor** level to the Inventory access rights (between User and
Administrator).

* Full Inventory operations, Reporting and Replenishment
* No Configuration menu, no Physical Inventory
* Sales Price and Cost are read-only (views and server side)
* Once the level is selected on a user, a "Detailed Access Rights" section
  appears with check boxes to fine-tune what the user can do.
""",
    'author': 'Optivion Tech',
    'category': 'Inventory/Inventory',
    'license': 'LGPL-3',
    'depends': ['stock'],
    'data': [
        'security/ot_inventory_supervisor_security.xml',
        'security/ir.model.access.csv',
        'views/res_users_views.xml',
    ],
    'installable': True,
    'application': False,
}
