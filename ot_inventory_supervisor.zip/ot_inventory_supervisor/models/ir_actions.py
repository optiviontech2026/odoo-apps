from odoo import api, models

from .rights import RESTRICTED_BINDINGS, has_right, is_restricted


class IrActionsActions(models.Model):
    _inherit = 'ir.actions.actions'

    @api.model
    def get_bindings(self, model_name):
        """Remove "Validate" / "Scrap" from the Actions menu of a Supervisor
        that does not have the matching right."""
        result = super().get_bindings(model_name)
        if not is_restricted(self.env):
            return result
        blocked_ids = set()
        for xmlid, right in RESTRICTED_BINDINGS.items():
            if not has_right(self.env, right):
                action = self.env.ref(xmlid, raise_if_not_found=False)
                if action and action.sudo().binding_model_id.model == model_name:
                    blocked_ids.add(action.id)
        if not blocked_ids:
            return result
        filtered = {}
        for binding_type, actions in result.items():
            actions = [action for action in actions if action.get('id') not in blocked_ids]
            if actions:
                filtered[binding_type] = actions
        return filtered
