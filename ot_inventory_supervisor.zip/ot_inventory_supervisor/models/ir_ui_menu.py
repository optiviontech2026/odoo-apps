from odoo import api, models, tools

from .rights import RESTRICTED_MENUS, has_right, is_restricted


class IrUiMenu(models.Model):
    _inherit = 'ir.ui.menu'

    @api.model
    @tools.ormcache('frozenset(self.env.user._get_group_ids())', 'debug')
    def _visible_menu_ids(self, debug=False):
        """Hide Configuration / Physical Inventory / Scrap for Supervisors.

        The result only depends on the user's groups, so it is safe to cache it
        with the same key as the standard method.
        """
        visible = super()._visible_menu_ids(debug)
        if not is_restricted(self.env):
            return visible

        hidden = set()
        for xmlid, right in RESTRICTED_MENUS.items():
            if right is None or not has_right(self.env, right):
                menu = self.env.ref(xmlid, raise_if_not_found=False)
                if menu:
                    hidden.add(menu.id)
        if not hidden & visible:
            return visible

        menus = self.sudo().with_context({}).browse(visible)
        parent_of = {menu.id: menu.parent_id.id for menu in menus}
        has_action = {menu.id for menu in menus if menu.action}

        def is_hidden(menu_id):
            while menu_id:
                if menu_id in hidden:
                    return True
                menu_id = parent_of.get(menu_id)
            return False

        result = {menu_id for menu_id in visible if not is_hidden(menu_id)}
        # drop folder menus that became empty (e.g. "Adjustments")
        while True:
            parents = {parent_of[menu_id] for menu_id in result if parent_of.get(menu_id)}
            empty = {menu_id for menu_id in result if menu_id not in has_action and menu_id not in parents}
            # keep top-level application menus (they have no parent)
            empty = {menu_id for menu_id in empty if parent_of.get(menu_id)}
            if not empty:
                break
            result -= empty
        return frozenset(result)
