from odoo import api, models
from odoo.exceptions import AccessError
from odoo.tools import float_compare

from .rights import get_rights, has_right, is_restricted, lock_arch_fields

# right -> price fields it protects, per model
_PRICE_FIELDS = {
    'product.template': {'sale_price': ('list_price',), 'cost': ('standard_price',)},
    'product.product': {'sale_price': ('lst_price', 'list_price'), 'cost': ('standard_price',)},
}
_COPY_CTX = 'ot_inv_copying_product'


class OtInvPriceGuard(models.AbstractModel):
    """Shared logic that locks Sales Price / Cost for Inventory Supervisors."""
    _name = 'ot.inv.price.guard'
    _description = 'Inventory Supervisor price lock'

    @api.model
    def _ot_inv_locked_price_fields(self):
        """Price fields the current user may not change on this model."""
        if not is_restricted(self.env):
            return {}
        locked = {}
        for right, fnames in _PRICE_FIELDS.get(self._name, {}).items():
            if not has_right(self.env, right):
                for fname in fnames:
                    locked[fname] = right
        return locked

    def _ot_inv_raise_price(self, right):
        raise AccessError(self.env._(
            'You are not allowed to change the %(field)s of products.\n'
            'Ask your Inventory Administrator to tick "%(right)s" in your access rights.',
            field=self.env._('Sales Price') if right == 'sale_price' else self.env._('Cost'),
            right=self.env._(get_rights(self.env)[right][3]),
        ))

    def _ot_inv_check_price_write(self, vals):
        if self.env.context.get(_COPY_CTX):
            return
        locked = self._ot_inv_locked_price_fields()
        if not locked:
            return
        digits = self.env['decimal.precision'].precision_get('Product Price')
        for fname, right in locked.items():
            if fname not in vals:
                continue
            new_value = vals[fname] or 0.0
            for record in self:
                if float_compare(record[fname] or 0.0, new_value, precision_digits=digits):
                    self._ot_inv_raise_price(right)

    def _ot_inv_check_price_create(self, vals_list):
        if self.env.context.get(_COPY_CTX):
            return
        locked = self._ot_inv_locked_price_fields()
        if not locked:
            return
        digits = self.env['decimal.precision'].precision_get('Product Price')
        defaults = self.default_get(list(locked))
        for fname, right in locked.items():
            default = defaults.get(fname) or 0.0
            for vals in vals_list:
                if fname in vals and float_compare(vals[fname] or 0.0, default or 0.0,
                                                   precision_digits=digits):
                    self._ot_inv_raise_price(right)

    def _ot_inv_check_price_copy(self, default):
        locked = self._ot_inv_locked_price_fields()
        for fname, right in locked.items():
            if default and fname in default:
                self._ot_inv_raise_price(right)

    @api.model
    def get_view(self, view_id=None, view_type='form', **options):
        result = super().get_view(view_id, view_type, **options)
        locked = self._ot_inv_locked_price_fields()
        if locked:
            result['arch'] = lock_arch_fields(result['arch'], set(locked))
        return result


class ProductTemplate(models.Model):
    _name = 'product.template'
    _inherit = ['product.template', 'ot.inv.price.guard']

    @api.model_create_multi
    def create(self, vals_list):
        self._ot_inv_check_price_create(vals_list)
        return super().create(vals_list)

    def write(self, vals):
        self._ot_inv_check_price_write(vals)
        return super().write(vals)

    def copy(self, default=None):
        self._ot_inv_check_price_copy(default)
        return super(ProductTemplate, self.with_context(**{_COPY_CTX: True})).copy(default=default) \
            .with_context(**{_COPY_CTX: False})


class ProductProduct(models.Model):
    _name = 'product.product'
    _inherit = ['product.product', 'ot.inv.price.guard']

    @api.model_create_multi
    def create(self, vals_list):
        self._ot_inv_check_price_create(vals_list)
        return super().create(vals_list)

    def write(self, vals):
        self._ot_inv_check_price_write(vals)
        return super().write(vals)

    def copy(self, default=None):
        self._ot_inv_check_price_copy(default)
        return super(ProductProduct, self.with_context(**{_COPY_CTX: True})).copy(default=default) \
            .with_context(**{_COPY_CTX: False})
