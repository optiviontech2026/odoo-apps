from odoo import api, fields, models
from odoo.fields import Command

from .rights import RIGHTS, RIGHT_FIELDS, SUPERVISOR_GROUP

_ADMIN = 'base.group_erp_manager'


class ResUsers(models.Model):
    _inherit = 'res.users'

    ot_inv_is_supervisor = fields.Boolean(
        string='Inventory Supervisor', compute='_compute_ot_inv_rights', groups=_ADMIN)
    # Technical: remembers (inside the open form) that the default rights were
    # already applied, so unticking everything does not re-tick the defaults.
    ot_inv_defaults_applied = fields.Boolean(
        compute='_compute_ot_inv_defaults_applied', groups=_ADMIN)

    # Detailed rights (one group each, see security xml)
    ot_inv_allow_validate = fields.Boolean(
        string='Validate Transfers', groups=_ADMIN,
        compute='_compute_ot_inv_rights', readonly=False,
        help='Validate receipts, deliveries and internal transfers.')
    ot_inv_allow_cancel = fields.Boolean(
        string='Cancel Transfers', groups=_ADMIN,
        compute='_compute_ot_inv_rights', readonly=False,
        help='Cancel transfers that are not done yet (also applies when a Sales or '
             'Purchase order cancels its transfers).')
    ot_inv_allow_delete = fields.Boolean(
        string='Delete Transfers', groups=_ADMIN,
        compute='_compute_ot_inv_rights', readonly=False,
        help='Delete draft or cancelled transfers.')
    ot_inv_allow_return = fields.Boolean(
        string='Create Returns', groups=_ADMIN,
        compute='_compute_ot_inv_rights', readonly=False,
        help='Create returns from done transfers.')
    ot_inv_allow_scrap = fields.Boolean(
        string='Scrap Products', groups=_ADMIN,
        compute='_compute_ot_inv_rights', readonly=False,
        help='Access the Scrap menu and validate scrap orders.')
    ot_inv_allow_product = fields.Boolean(
        string='Create & Edit Products', groups=_ADMIN,
        compute='_compute_ot_inv_rights', readonly=False,
        help='Create products and edit product details. Sales Price and Cost stay '
             'locked unless allowed below.')
    ot_inv_allow_replenish = fields.Boolean(
        string='Replenishment', groups=_ADMIN,
        compute='_compute_ot_inv_rights', readonly=False,
        help='Access Operations > Replenishment and manage reordering rules.')
    ot_inv_allow_reporting = fields.Boolean(
        string='Inventory Reporting', groups=_ADMIN,
        compute='_compute_ot_inv_rights', readonly=False,
        help='Access the Reporting menu (Stock, Locations, Moves History, Moves Analysis).')
    ot_inv_allow_sale_price = fields.Boolean(
        string='Edit Sales Price', groups=_ADMIN,
        compute='_compute_ot_inv_rights', readonly=False,
        help='Change the Sales Price of products. Off by default.')
    ot_inv_allow_cost = fields.Boolean(
        string='Edit Cost', groups=_ADMIN,
        compute='_compute_ot_inv_rights', readonly=False,
        help='Change the Cost of products. Off by default.')
    ot_inv_allow_inventory = fields.Boolean(
        string='Physical Inventory', groups=_ADMIN,
        compute='_compute_ot_inv_rights', readonly=False,
        help='Access Physical Inventory, count stock and apply inventory adjustments. '
             'Off by default.')

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------
    @api.model
    def _ot_inv_rights_spec(self):
        """{key: (field name, group xml id, ticked by default, label)}.

        Override in add-on modules to add rights (each with its own boolean
        field using ``compute='_compute_ot_inv_rights', readonly=False`` and an
        onchange calling ``_onchange_ot_inv_rights``).
        """
        return dict(RIGHTS)

    @api.model
    def _ot_inv_right_fields(self):
        return [spec[0] for spec in self._ot_inv_rights_spec().values() if spec[0] in self._fields]

    @api.model
    def _ot_inv_supervisor_group(self):
        return self.env.ref(SUPERVISOR_GROUP, raise_if_not_found=False)

    @api.model
    def _ot_inv_right_groups(self):
        """Return {field name: group record} for every detailed right."""
        result = {}
        for fname, xmlid, _default, _label in self._ot_inv_rights_spec().values():
            group = self.env.ref(xmlid, raise_if_not_found=False)
            if group:
                result[fname] = group
        return result

    @api.model
    def _ot_inv_default_groups(self):
        groups = self.env['res.groups']
        for fname, xmlid, default, _label in self._ot_inv_rights_spec().values():
            if default:
                groups |= self.env.ref(xmlid, raise_if_not_found=False) or groups.browse()
        return groups

    # ------------------------------------------------------------------
    # compute / inverse
    # ------------------------------------------------------------------
    @api.depends('group_ids')
    def _compute_ot_inv_rights(self):
        supervisor = self._ot_inv_supervisor_group()
        rights = self._ot_inv_right_groups()
        for user in self:
            group_ids = set(user.group_ids._origin.ids)
            user.ot_inv_is_supervisor = bool(supervisor) and supervisor.id in group_ids
            for fname in self._ot_inv_right_fields():
                group = rights.get(fname)
                user[fname] = bool(group) and group.id in group_ids

    def _compute_ot_inv_defaults_applied(self):
        # No @api.depends on purpose: based on the *saved* user, then driven by
        # the onchange methods below while the form is open.
        supervisor = self._ot_inv_supervisor_group()
        for user in self:
            user.ot_inv_defaults_applied = bool(supervisor) and supervisor in user._origin.group_ids

    def _ot_inv_apply_rights(self, right_vals):
        """Add / remove the right groups according to ``{field name: bool}``.

        Done here rather than in an inverse method: the boolean fields share one
        compute method, so Odoo would protect (and blank) all of them while one
        is being written.
        """
        rights = self._ot_inv_right_groups()
        for user in self:
            current = set(user.group_ids.ids)
            commands = []
            for fname, value in right_vals.items():
                group = rights.get(fname)
                if not group:
                    continue
                if value and group.id not in current:
                    commands.append(Command.link(group.id))
                elif not value and group.id in current:
                    commands.append(Command.unlink(group.id))
            if commands:
                user.write({'group_ids': commands})

    # ------------------------------------------------------------------
    # form behaviour
    # ------------------------------------------------------------------
    @api.onchange('group_ids')
    def _onchange_ot_inv_group_ids(self):
        """Tick the default rights when the Supervisor level is picked and clear
        all detailed rights when another level is picked."""
        supervisor = self._ot_inv_supervisor_group()
        if not supervisor:
            return
        right_groups = self.env['res.groups'].union(*self._ot_inv_right_groups().values())
        for user in self:
            current = user.group_ids._origin
            if supervisor in current:
                if not user.ot_inv_defaults_applied:
                    if not (current & right_groups):
                        user.group_ids = current | self._ot_inv_default_groups()
                    user.ot_inv_defaults_applied = True
            else:
                if current & right_groups:
                    user.group_ids = current - right_groups
                user.ot_inv_defaults_applied = False

    @api.onchange(*RIGHT_FIELDS)
    def _onchange_ot_inv_rights(self):
        """Keep the groups in sync while ticking the check boxes."""
        supervisor = self._ot_inv_supervisor_group()
        rights = self._ot_inv_right_groups()
        for user in self:
            current = user.group_ids._origin
            new = current
            for fname, group in rights.items():
                new = (new | group) if user[fname] else (new - group)
            if new != current:
                user.group_ids = new
            if supervisor and supervisor in current:
                # the admin is choosing the rights by hand: never re-apply defaults
                user.ot_inv_defaults_applied = True

    # ------------------------------------------------------------------
    # keep data consistent outside the form (imports, RPC, level changes)
    # ------------------------------------------------------------------
    @api.model_create_multi
    def create(self, vals_list):
        clean_list, rights_list = [], []
        right_fields = self._ot_inv_right_fields()
        for vals in vals_list:
            vals = dict(vals)
            rights_list.append({f: vals.pop(f) for f in right_fields if f in vals})
            clean_list.append(vals)
        users = super().create(clean_list)
        for user, right_vals in zip(users, rights_list):
            if right_vals:
                user._ot_inv_apply_rights(right_vals)
        users._ot_inv_clean_rights()
        return users

    def write(self, vals):
        vals = dict(vals)
        right_vals = {f: vals.pop(f) for f in self._ot_inv_right_fields() if f in vals}
        res = super().write(vals) if vals else True
        if right_vals:
            self._ot_inv_apply_rights(right_vals)
        if 'group_ids' in vals or right_vals:
            self._ot_inv_clean_rights()
        return res

    def _ot_inv_clean_rights(self):
        """Detailed rights only make sense with the Supervisor level: drop them
        from users that are not (or no longer) Supervisors."""
        supervisor = self._ot_inv_supervisor_group()
        if not supervisor:
            return
        right_groups = self.env['res.groups'].union(*self._ot_inv_right_groups().values())
        to_clean = self.sudo().filtered(
            lambda u: supervisor not in u.group_ids and (u.group_ids & right_groups))
        if to_clean:
            to_clean.write({'group_ids': [Command.unlink(g.id) for g in right_groups]})
