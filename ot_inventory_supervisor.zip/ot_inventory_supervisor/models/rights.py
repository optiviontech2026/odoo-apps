"""Single place that describes the Supervisor level and its detailed rights."""

from lxml import etree

from odoo.exceptions import AccessError
from odoo.tools.translate import LazyTranslate

_lt = LazyTranslate(__name__)

MODULE = 'ot_inventory_supervisor'
SUPERVISOR_GROUP = f'{MODULE}.group_stock_supervisor'
MANAGER_GROUP = 'stock.group_stock_manager'

# key -> (res.users boolean field, group xml id, ticked by default, label)
# "Ticked by default" = automatically ticked the moment the Supervisor level is
# selected on a user form; the admin can then untick / tick as needed.
RIGHTS = {
    'validate': ('ot_inv_allow_validate', f'{MODULE}.group_inv_allow_validate', True,
                 _lt('Validate Transfers')),
    'cancel': ('ot_inv_allow_cancel', f'{MODULE}.group_inv_allow_cancel', True,
               _lt('Cancel Transfers')),
    'delete': ('ot_inv_allow_delete', f'{MODULE}.group_inv_allow_delete', True,
               _lt('Delete Transfers')),
    'return': ('ot_inv_allow_return', f'{MODULE}.group_inv_allow_return', True,
               _lt('Create Returns')),
    'scrap': ('ot_inv_allow_scrap', f'{MODULE}.group_inv_allow_scrap', True,
              _lt('Scrap Products')),
    'product': ('ot_inv_allow_product', f'{MODULE}.group_inv_allow_product', True,
                _lt('Create & Edit Products')),
    'replenish': ('ot_inv_allow_replenish', f'{MODULE}.group_inv_allow_replenish', True,
                  _lt('Replenishment')),
    'reporting': ('ot_inv_allow_reporting', f'{MODULE}.group_inv_allow_reporting', True,
                  _lt('Inventory Reporting')),
    'sale_price': ('ot_inv_allow_sale_price', f'{MODULE}.group_inv_allow_sale_price', False,
                   _lt('Edit Sales Price')),
    'cost': ('ot_inv_allow_cost', f'{MODULE}.group_inv_allow_cost', False,
             _lt('Edit Cost')),
    'inventory': ('ot_inv_allow_inventory', f'{MODULE}.group_inv_allow_inventory', False,
                  _lt('Physical Inventory')),
}

RIGHT_FIELDS = tuple(spec[0] for spec in RIGHTS.values())

# Menus hidden for a Supervisor (None = always hidden, otherwise the right that shows it)
RESTRICTED_MENUS = {
    'stock.menu_stock_config_settings': None,
    'stock.menu_action_inventory_tree': 'inventory',
    'stock.menu_stock_scrap': 'scrap',
}

# Actions in the "Actions" (gear) menu hidden when the right is missing
RESTRICTED_BINDINGS = {
    'stock.action_validate_picking': 'validate',
    'stock.action_scrap': 'scrap',
}


def is_restricted(env):
    """True when the current user works with the Supervisor level.

    Inventory Administrators and superuser calls (sudo) are never restricted.
    """
    if env.su:
        return False
    user = env.user
    return user._has_group(SUPERVISOR_GROUP) and not user._has_group(MANAGER_GROUP)


def get_rights(env):
    """All detailed rights of this database (add-on modules can add their own
    by overriding ``res.users._ot_inv_rights_spec``)."""
    return env['res.users']._ot_inv_rights_spec()


def has_right(env, right):
    """True if the current user may use ``right`` (always True for non-Supervisors)."""
    if not is_restricted(env):
        return True
    return env.user._has_group(get_rights(env)[right][1])


def check_right(env, right):
    """Raise an AccessError if the current Supervisor user lacks ``right``."""
    if has_right(env, right):
        return
    raise AccessError(env._(
        'You are not allowed to do this: "%(right)s" is not enabled on your user.\n'
        'Ask your Inventory Administrator to tick it in your Inventory Supervisor access rights.',
        right=env._(get_rights(env)[right][3]),
    ))


def lock_arch_fields(arch, field_names):
    """Return ``arch`` with the given fields made read-only (and never saved)."""
    if not field_names:
        return arch
    node = etree.fromstring(arch)
    changed = False
    for field in node.iter('field'):
        if field.get('name') in field_names:
            field.set('readonly', '1')
            field.attrib.pop('force_save', None)
            changed = True
    return etree.tostring(node, encoding='unicode') if changed else arch


def hide_arch_buttons(arch, button_names):
    """Return ``arch`` with every <button> whose name is in ``button_names`` hidden."""
    if not button_names:
        return arch
    node = etree.fromstring(arch)
    changed = False
    for button in node.iter('button'):
        if button.get('name') in button_names:
            button.set('invisible', '1')
            changed = True
    return etree.tostring(node, encoding='unicode') if changed else arch
