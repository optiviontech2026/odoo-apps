from odoo import api, models

from .rights import check_right, has_right, hide_arch_buttons, is_restricted


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    @api.model
    def get_view(self, view_id=None, view_type='form', **options):
        """Hide the buttons a Supervisor is not allowed to use."""
        result = super().get_view(view_id, view_type, **options)
        if not is_restricted(self.env):
            return result
        buttons = set()
        if not has_right(self.env, 'validate'):
            buttons.add('button_validate')
        if not has_right(self.env, 'cancel'):
            buttons.add('action_cancel')
        if not has_right(self.env, 'scrap'):
            buttons.add('button_scrap')
        if not has_right(self.env, 'return'):
            return_action = self.env.ref('stock.act_stock_return_picking', raise_if_not_found=False)
            if return_action:
                buttons.add(str(return_action.id))
        result['arch'] = hide_arch_buttons(result['arch'], buttons)
        return result

    def button_validate(self):
        check_right(self.env, 'validate')
        return super().button_validate()

    def action_cancel(self):
        check_right(self.env, 'cancel')
        return super().action_cancel()

    def button_scrap(self):
        check_right(self.env, 'scrap')
        return super().button_scrap()

    @api.ondelete(at_uninstall=False)
    def _unlink_ot_inv_check_right(self):
        check_right(self.env, 'delete')
