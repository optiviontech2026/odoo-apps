from odoo import api, models

from .rights import check_right, has_right

# fields that are only written while counting stock (Physical Inventory)
_COUNT_FIELDS = ('inventory_quantity', 'inventory_quantity_auto_apply')


class StockQuant(models.Model):
    _inherit = 'stock.quant'

    # ------------------------------------------------------------------
    # read-only stock views for Supervisors without "Physical Inventory"
    # ------------------------------------------------------------------
    def _set_view_context(self):
        self = super()._set_view_context()
        if not has_right(self.env, 'inventory'):
            self = self.with_context(inventory_mode=False)
        return self

    @api.model
    def _get_quants_action(self, extend=False):
        if not has_right(self.env, 'inventory'):
            self = self.with_context(inventory_mode=False)
        return super()._get_quants_action(extend=extend)

    # ------------------------------------------------------------------
    # server-side blocking of Physical Inventory
    # ------------------------------------------------------------------
    @api.model
    def action_view_inventory(self):
        check_right(self.env, 'inventory')
        return super().action_view_inventory()

    def action_apply_inventory(self, date=None):
        check_right(self.env, 'inventory')
        return super().action_apply_inventory(date=date)

    def action_set_inventory_quantity(self):
        check_right(self.env, 'inventory')
        return super().action_set_inventory_quantity()

    def action_set_inventory_quantity_zero(self):
        check_right(self.env, 'inventory')
        return super().action_set_inventory_quantity_zero()

    def action_clear_inventory_quantity(self):
        check_right(self.env, 'inventory')
        return super().action_clear_inventory_quantity()

    def action_apply_all(self):
        check_right(self.env, 'inventory')
        return super().action_apply_all()

    def action_reset(self):
        check_right(self.env, 'inventory')
        return super().action_reset()

    @api.model_create_multi
    def create(self, vals_list):
        if self._is_inventory_mode() and any(f in vals for vals in vals_list for f in _COUNT_FIELDS):
            check_right(self.env, 'inventory')
        return super().create(vals_list)

    def write(self, vals):
        if self._is_inventory_mode() and any(f in vals for f in _COUNT_FIELDS):
            check_right(self.env, 'inventory')
        return super().write(vals)
