from odoo import models

from .rights import check_right


class StockScrap(models.Model):
    _inherit = 'stock.scrap'

    def action_validate(self):
        check_right(self.env, 'scrap')
        return super().action_validate()

    def do_scrap(self):
        check_right(self.env, 'scrap')
        return super().do_scrap()
