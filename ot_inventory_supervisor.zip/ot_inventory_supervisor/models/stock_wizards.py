from odoo import models

from .rights import check_right


class StockReturnPicking(models.TransientModel):
    _inherit = 'stock.return.picking'

    def action_create_returns(self):
        check_right(self.env, 'return')
        return super().action_create_returns()

    def action_create_returns_all(self):
        check_right(self.env, 'return')
        return super().action_create_returns_all()

    def action_create_exchanges(self):
        check_right(self.env, 'return')
        return super().action_create_exchanges()


class StockRequestCount(models.TransientModel):
    _inherit = 'stock.request.count'

    def action_request_count(self):
        check_right(self.env, 'inventory')
        return super().action_request_count()
