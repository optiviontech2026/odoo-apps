from lxml import etree

from odoo.exceptions import AccessError
from odoo.fields import Command
from odoo.tests import Form, TransactionCase, new_test_user, tagged

from odoo.addons.ot_inventory_supervisor.models.rights import RIGHTS, RIGHT_FIELDS

DEFAULT_ON = [spec[0] for spec in RIGHTS.values() if spec[2]]
DEFAULT_OFF = [spec[0] for spec in RIGHTS.values() if not spec[2]]


@tagged('post_install', '-at_install')
class TestSupervisorAccess(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.supervisor_group = cls.env.ref('ot_inventory_supervisor.group_stock_supervisor')
        cls.sup = new_test_user(cls.env, 'ot_sup', groups='base.group_user')
        cls.sup.write({'group_ids': [Command.link(cls.supervisor_group.id)]})
        cls.stock_user = new_test_user(cls.env, 'ot_stock_user', groups='stock.group_stock_user')
        cls.stock_admin = new_test_user(cls.env, 'ot_stock_admin', groups='stock.group_stock_manager,product.group_product_manager')
        cls.product = cls.env['product.product'].create({
            'name': 'OT Test Product', 'is_storable': True, 'list_price': 10.0, 'standard_price': 5.0,
        })
        cls.warehouse = cls.env['stock.warehouse'].search([('company_id', '=', cls.env.company.id)], limit=1)
        cls.stock_location = cls.warehouse.lot_stock_id
        cls.env['stock.quant']._update_available_quantity(cls.product, cls.stock_location, 50)

    def set_rights(self, user, **rights):
        user.write({f'ot_inv_allow_{key}': value for key, value in rights.items()})

    def visible_menus(self, user):
        ids = self.env['ir.ui.menu'].with_user(user)._visible_menu_ids()
        return ids

    def make_receipt(self, user):
        picking_type = self.warehouse.in_type_id
        picking = self.env['stock.picking'].with_user(user).create({
            'picking_type_id': picking_type.id,
            'location_id': self.env.ref('stock.stock_location_suppliers').id,
            'location_dest_id': self.stock_location.id,
            'move_ids': [Command.create({
                'product_id': self.product.id,
                'product_uom_qty': 3,
                'location_id': self.env.ref('stock.stock_location_suppliers').id,
                'location_dest_id': self.stock_location.id,
            })],
        })
        picking.action_confirm()
        picking.move_ids.quantity = 3
        return picking

    # ------------------------------------------------------------------
    # level & user form
    # ------------------------------------------------------------------
    def test_level_order_in_inventory_privilege(self):
        privilege = self.env.ref('stock.res_groups_privilege_inventory')
        hierarchy = self.env['res.groups']._get_view_group_hierarchy()
        names = [self.env['res.groups'].browse(gid).name
                 for gid in hierarchy['privileges'][privilege.id]['group_ids']]
        self.assertEqual(names, ['User', 'Supervisor', 'Administrator'])

    def test_form_select_level_ticks_defaults(self):
        user = new_test_user(self.env, 'ot_form_user', groups='base.group_user')
        with Form(user, view='base.view_users_form') as form:
            self.assertFalse(form.ot_inv_is_supervisor)
            form.group_ids.add(self.supervisor_group)
            self.assertTrue(form.ot_inv_is_supervisor)
            for fname in DEFAULT_ON:
                self.assertTrue(form[fname], fname)
            for fname in DEFAULT_OFF:
                self.assertFalse(form[fname], fname)
            # untick everything: the defaults must not come back
            for fname in DEFAULT_ON:
                form[fname] = False
            form.ot_inv_allow_cost = True
        for fname in RIGHT_FIELDS:
            self.assertEqual(user[fname], fname == 'ot_inv_allow_cost', fname)
        self.assertTrue(user.has_group('ot_inventory_supervisor.group_inv_allow_cost'))
        self.assertFalse(user.has_group('ot_inventory_supervisor.group_inv_allow_validate'))

    def test_switching_level_clears_rights(self):
        user = new_test_user(self.env, 'ot_switch_user', groups='base.group_user')
        user.write({'group_ids': [Command.link(self.supervisor_group.id)]})
        self.set_rights(user, validate=True, reporting=True)
        self.assertTrue(user.ot_inv_allow_validate)
        user.write({'group_ids': [Command.unlink(self.supervisor_group.id),
                                  Command.link(self.env.ref('stock.group_stock_manager').id)]})
        for fname in RIGHT_FIELDS:
            self.assertFalse(user[fname], fname)

    # ------------------------------------------------------------------
    # menus & action bindings
    # ------------------------------------------------------------------
    def test_menus(self):
        config = self.env.ref('stock.menu_stock_config_settings').id
        physical = self.env.ref('stock.menu_action_inventory_tree').id
        scrap = self.env.ref('stock.menu_stock_scrap').id
        adjustments = self.env.ref('stock.menu_stock_adjustments').id
        reporting = self.env.ref('stock.menu_warehouse_report').id
        replenish = self.env.ref('stock.menu_reordering_rules_replenish').id

        self.set_rights(self.sup, scrap=True, reporting=True, replenish=True)
        menus = self.visible_menus(self.sup)
        self.assertNotIn(config, menus)
        self.assertNotIn(physical, menus)
        self.assertIn(scrap, menus)
        self.assertIn(reporting, menus)
        self.assertIn(replenish, menus)

        self.set_rights(self.sup, scrap=False, reporting=False, replenish=False)
        menus = self.visible_menus(self.sup)
        self.assertNotIn(scrap, menus)
        self.assertNotIn(adjustments, menus, 'empty Adjustments folder must disappear')
        self.assertNotIn(reporting, menus)
        self.assertNotIn(replenish, menus)

        self.set_rights(self.sup, inventory=True)
        self.assertIn(physical, self.visible_menus(self.sup))

        # standard levels are untouched
        self.assertIn(physical, self.visible_menus(self.stock_user))
        self.assertIn(config, self.visible_menus(self.stock_admin))

    def test_validate_binding_hidden(self):
        validate_action = self.env.ref('stock.action_validate_picking')
        self.set_rights(self.sup, validate=False)
        bindings = self.env['ir.actions.actions'].with_user(self.sup).get_bindings('stock.picking')
        self.assertNotIn(validate_action.id, [a['id'] for a in bindings.get('action', [])])
        self.set_rights(self.sup, validate=True)
        bindings = self.env['ir.actions.actions'].with_user(self.sup).get_bindings('stock.picking')
        self.assertIn(validate_action.id, [a['id'] for a in bindings.get('action', [])])

    # ------------------------------------------------------------------
    # prices
    # ------------------------------------------------------------------
    def test_prices_locked(self):
        self.set_rights(self.sup, product=True)
        template = self.product.product_tmpl_id.with_user(self.sup)
        arch = etree.fromstring(template.get_view(view_type='form')['arch'])
        for fname in ('list_price', 'standard_price'):
            nodes = arch.xpath(f"//field[@name='{fname}']")
            self.assertTrue(nodes)
            self.assertTrue(all(node.get('readonly') == '1' for node in nodes), fname)

        template.write({'name': 'Renamed by supervisor'})  # other fields are fine
        with self.assertRaises(AccessError):
            template.write({'list_price': 99.0})
        with self.assertRaises(AccessError):
            template.write({'standard_price': 99.0})
        with self.assertRaises(AccessError):
            self.product.with_user(self.sup).write({'standard_price': 1.0})
        with self.assertRaises(AccessError):
            self.env['product.template'].with_user(self.sup).create({'name': 'X', 'list_price': 7.0})
        new_product = self.env['product.template'].with_user(self.sup).create({'name': 'No price'})
        self.assertEqual(new_product.list_price, 1.0)
        template.copy()  # duplicating keeps the price, allowed

        self.set_rights(self.sup, sale_price=True)
        template.write({'list_price': 99.0})
        with self.assertRaises(AccessError):
            template.write({'standard_price': 99.0})
        self.set_rights(self.sup, cost=True)
        template.write({'standard_price': 99.0})

        # Inventory Administrators are never restricted
        self.product.product_tmpl_id.with_user(self.stock_admin).write({'list_price': 12.0})

    def test_product_right(self):
        self.set_rights(self.sup, product=False)
        with self.assertRaises(AccessError):
            self.env['product.template'].with_user(self.sup).create({'name': 'Nope'})
        self.set_rights(self.sup, product=True)
        self.env['product.template'].with_user(self.sup).create({'name': 'Yes'})

    # ------------------------------------------------------------------
    # transfers
    # ------------------------------------------------------------------
    def test_validate_right(self):
        self.set_rights(self.sup, validate=False)
        picking = self.make_receipt(self.sup)
        arch = etree.fromstring(picking.get_view(view_type='form')['arch'])
        self.assertTrue(all(b.get('invisible') == '1' for b in arch.xpath("//button[@name='button_validate']")))
        with self.assertRaises(AccessError):
            picking.button_validate()
        self.set_rights(self.sup, validate=True)
        picking.with_user(self.sup).button_validate()
        self.assertEqual(picking.state, 'done')
        # a standard Inventory User is not affected by the module
        receipt = self.make_receipt(self.stock_user)
        receipt.button_validate()
        self.assertEqual(receipt.state, 'done')

    def test_cancel_and_delete_rights(self):
        self.set_rights(self.sup, cancel=False, delete=False)
        picking = self.make_receipt(self.sup)
        with self.assertRaises(AccessError):
            picking.action_cancel()
        self.set_rights(self.sup, cancel=True)
        picking.with_user(self.sup).action_cancel()
        with self.assertRaises(AccessError):
            picking.with_user(self.sup).unlink()
        self.set_rights(self.sup, delete=True)
        picking.with_user(self.sup).unlink()

    def test_return_right(self):
        self.set_rights(self.sup, validate=True, **{'return': False})
        picking = self.make_receipt(self.sup)
        picking.button_validate()
        wizard = Form(self.env['stock.return.picking'].with_user(self.sup).with_context(
            active_id=picking.id, active_model='stock.picking')).save()
        with self.assertRaises(AccessError):
            wizard.action_create_returns()
        self.set_rights(self.sup, **{'return': True})
        wizard.product_return_moves.quantity = 3
        wizard.with_user(self.sup).action_create_returns()
        self.assertTrue(picking.return_ids)

    # ------------------------------------------------------------------
    # physical inventory
    # ------------------------------------------------------------------
    def test_physical_inventory_blocked(self):
        self.set_rights(self.sup, inventory=False)
        Quant = self.env['stock.quant'].with_user(self.sup)
        with self.assertRaises(AccessError):
            Quant.action_view_inventory()
        quant = Quant.search([('product_id', '=', self.product.id),
                              ('location_id', '=', self.stock_location.id)], limit=1)
        with self.assertRaises(AccessError):
            quant.with_context(inventory_mode=True).write({'inventory_quantity': 10})
        with self.assertRaises(AccessError):
            quant.action_apply_inventory()
        # "On Hand" opens a read-only (non inventory mode) list
        action = self.product.with_user(self.sup).action_open_quants()
        self.assertFalse(action.get('context', {}).get('inventory_mode'))

        self.set_rights(self.sup, inventory=True)
        quant = quant.with_user(self.sup).with_context(inventory_mode=True)
        quant.write({'inventory_quantity': 10})
        quant.action_apply_inventory()
        self.assertEqual(self.product.qty_available, 10)
