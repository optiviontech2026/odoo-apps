{
    'name': 'Inventory Supervisor Access - Landed Costs',
    'version': '19.0.1.0.0',
    'summary': 'Adds a "Landed Costs" check box to the Inventory Supervisor rights '
               '(same Landed Costs access as an Inventory Administrator).',
    'author': 'Optivion Tech',
    'category': 'Inventory/Inventory',
    'license': 'LGPL-3',
    'depends': ['ot_inventory_supervisor', 'stock_landed_costs'],
    'data': [
        'security/ot_inventory_supervisor_landed_costs_security.xml',
        'security/ir.model.access.csv',
        'views/res_users_views.xml',
        'views/account_move_views.xml',
    ],
    'auto_install': True,
    'installable': True,
}
