from odoo import api, fields, models
from odoo.tools.translate import LazyTranslate

_lt = LazyTranslate(__name__)

LANDED_COSTS_RIGHT = (
    'ot_inv_allow_landed_costs',
    'ot_inventory_supervisor_landed_costs.group_inv_allow_landed_costs',
    False,  # not ticked by default
    _lt('Landed Costs'),
)


class ResUsers(models.Model):
    _inherit = 'res.users'

    ot_inv_allow_landed_costs = fields.Boolean(
        string='Landed Costs', groups='base.group_erp_manager',
        compute='_compute_ot_inv_rights', readonly=False,
        help='Full Landed Costs access, like an Inventory Administrator: create, compute, '
             'validate and cancel landed costs, and create them from vendor bills. '
             'Validating also needs Accounting rights to post the journal entry. Off by default.')

    @api.model
    def _ot_inv_rights_spec(self):
        spec = super()._ot_inv_rights_spec()
        spec['landed_costs'] = LANDED_COSTS_RIGHT
        return spec

    @api.onchange('ot_inv_allow_landed_costs')
    def _onchange_ot_inv_allow_landed_costs(self):
        self._onchange_ot_inv_rights()
