from lxml import etree

from odoo.exceptions import AccessError
from odoo.fields import Command
from odoo.tests import Form, new_test_user, tagged

from odoo.addons.stock_landed_costs.tests.test_stockvaluationlayer import TestStockValuationLCCommon


@tagged('-at_install', 'post_install')
class TestSupervisorLandedCosts(TestStockValuationLCCommon):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.product1.categ_id.write({'property_cost_method': 'average', 'property_valuation': 'real_time'})
        cls.supervisor_group = cls.env.ref('ot_inventory_supervisor.group_stock_supervisor')
        cls.lc_group = cls.env.ref('ot_inventory_supervisor_landed_costs.group_inv_allow_landed_costs')
        # Supervisor that also has Billing rights (needed to post the journal entry,
        # exactly like an Inventory Administrator)
        cls.sup = new_test_user(cls.env, 'ot_lc_sup', groups='base.group_user,account.group_account_invoice',
                                company_ids=[Command.set(cls.env.company.ids)], company_id=cls.env.company.id)
        cls.sup.write({'group_ids': [Command.link(cls.supervisor_group.id)]})

    def _visible_menus(self):
        return self.env['ir.ui.menu'].with_user(self.sup)._visible_menu_ids()

    def _bill_arch(self):
        view = self.env['account.move'].with_user(self.sup).get_view(view_type='form')
        return etree.fromstring(view['arch'])

    def test_checkbox_off_by_default(self):
        user = new_test_user(self.env, 'ot_lc_form', groups='base.group_user')
        with Form(user, view='base.view_users_form') as form:
            form.group_ids.add(self.supervisor_group)
            self.assertTrue(form.ot_inv_allow_validate)
            self.assertFalse(form.ot_inv_allow_landed_costs)
            form.ot_inv_allow_landed_costs = True
        self.assertIn(self.lc_group, user.group_ids)
        # shown under "Restricted by default", right after Physical Inventory
        arch = etree.fromstring(self.env['res.users'].get_view(view_id=self.env.ref('base.view_users_form').id)['arch'])
        field = arch.xpath("//field[@name='ot_inv_allow_landed_costs']")[0]
        self.assertEqual(field.getprevious().get('name'), 'ot_inv_allow_inventory')

    def test_no_access_without_right(self):
        self.sup.ot_inv_allow_landed_costs = False
        with self.assertRaises(AccessError):
            self.env['stock.landed.cost'].with_user(self.sup).search([])
        self.assertNotIn(self.env.ref('stock_landed_costs.menu_stock_landed_cost').id, self._visible_menus())
        self.assertFalse(self._bill_arch().xpath("//button[@name='button_create_landed_costs']"))

    def test_full_access_with_right(self):
        self.sup.write({'ot_inv_allow_landed_costs': True, 'ot_inv_allow_scrap': False,
                        'ot_inv_allow_inventory': False, 'ot_inv_allow_cost': False})
        menus = self._visible_menus()
        self.assertIn(self.env.ref('stock_landed_costs.menu_stock_landed_cost').id, menus)
        self.assertIn(self.env.ref('stock.menu_stock_adjustments').id, menus)
        self.assertTrue(self._bill_arch().xpath("//button[@name='button_create_landed_costs']"))

        move = self._make_in_move(self.product1, 10, unit_cost=10)
        self.assertEqual(self.product1.standard_price, 10)

        LandedCost = self.env['stock.landed.cost'].with_user(self.sup)
        form = Form(LandedCost)
        form.account_journal_id = self.stock_journal
        form.picking_ids.add(move.picking_id)
        with form.cost_lines.new() as line:
            line.product_id = self.productlc1
            line.price_unit = 50
        lc = form.save()
        lc.compute_landed_cost()
        lc.button_validate()
        self.assertEqual(lc.state, 'done')
        self.assertTrue(lc.account_move_id)
        # the cost moved with the landed cost even though "Edit Cost" is off
        self.assertEqual(self.product1.standard_price, 15)

        draft = LandedCost.create({'account_journal_id': self.stock_journal.id,
                                   'picking_ids': [Command.link(move.picking_id.id)]})
        draft.write({'description': 'edited'})
        draft.button_cancel()
        self.assertEqual(draft.state, 'cancel')
        draft.unlink()

    def test_right_removed_with_level(self):
        self.sup.ot_inv_allow_landed_costs = True
        self.sup.write({'group_ids': [Command.unlink(self.supervisor_group.id),
                                      Command.link(self.env.ref('stock.group_stock_user').id)]})
        self.assertNotIn(self.lc_group, self.sup.group_ids)
