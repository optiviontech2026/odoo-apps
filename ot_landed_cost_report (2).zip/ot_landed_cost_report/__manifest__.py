# -*- coding: utf-8 -*-
{
    'name': 'Landed Cost Report',
    'version': '19.0.1.2.0',
    'summary': 'Landed cost report by date, journal entry, transfer and amount '
               'with PDF and Excel export',
    'description': """
Landed Cost Report
==================
Adds a "Print Report" button to Inventory > Operations > Landed Costs.
It opens a window to choose the period (Today by default, ready periods,
or your own dates) and prints the report to PDF or Excel with:

* Date of the landed cost
* Journal entry number created by the landed cost
* Inventory transfer (receipt) the cost was added to
* Landed cost amount added to each transfer, with the total

The Landed Costs list also shows the journal entry, transfers and total.
A "Landed Costs" smart button is added on transfers that received a landed cost.
    """,
    'author': 'Optivion Tech',
    'category': 'Supply Chain/Inventory',
    'depends': ['stock_landed_costs'],
    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'wizard/landed_cost_report_wizard_views.xml',
        'views/landed_cost_report_views.xml',
        'views/stock_picking_views.xml',
        'views/stock_landed_cost_views.xml',
        'report/landed_cost_report_actions.xml',
        'report/landed_cost_report_templates.xml',
    ],
    'installable': True,
    'application': False,
    'license': 'LGPL-3',
}
