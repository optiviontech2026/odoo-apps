# -*- coding: utf-8 -*-
from odoo import fields, models
from odoo.tools.sql import SQL


class OtLandedCostReport(models.Model):
    """One line per (landed cost, transfer).

    The amount of a line is the part of the landed cost that was added to the
    moves of that transfer (sum of the valuation adjustment lines), so the
    total of the report always matches the total of the landed costs.
    """
    _name = 'ot.landed.cost.report'
    _description = 'Landed Cost Report'
    _auto = False
    _rec_name = 'name'
    _order = 'date desc, id desc'
    # fields read by the SQL query: flushed to the database before any search
    _depends = {
        'stock.landed.cost': [
            'name', 'date', 'state', 'account_move_id', 'account_journal_id',
            'vendor_bill_id', 'company_id', 'amount_total', 'picking_ids',
        ],
        'stock.valuation.adjustment.lines': ['cost_id', 'move_id', 'additional_landed_cost'],
        'stock.move': ['picking_id'],
        'stock.picking': ['picking_type_id', 'date_done', 'origin', 'partner_id'],
        'res.company': ['currency_id'],
    }

    landed_cost_id = fields.Many2one('stock.landed.cost', 'Landed Cost', readonly=True)
    name = fields.Char('Reference', readonly=True)
    date = fields.Date('Date', readonly=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('done', 'Posted'),
        ('cancel', 'Cancelled'),
    ], string='Status', readonly=True)
    account_move_id = fields.Many2one('account.move', 'Journal Entry', readonly=True)
    account_journal_id = fields.Many2one('account.journal', 'Journal', readonly=True)
    vendor_bill_id = fields.Many2one('account.move', 'Vendor Bill', readonly=True)
    picking_id = fields.Many2one('stock.picking', 'Transfer', readonly=True)
    picking_type_id = fields.Many2one('stock.picking.type', 'Operation Type', readonly=True)
    picking_date = fields.Datetime('Transfer Date', readonly=True)
    origin = fields.Char('Source Document', readonly=True)
    partner_id = fields.Many2one('res.partner', 'Partner', readonly=True)
    company_id = fields.Many2one('res.company', 'Company', readonly=True)
    currency_id = fields.Many2one('res.currency', 'Currency', readonly=True)
    amount = fields.Monetary(
        'Landed Cost Amount', readonly=True, currency_field='currency_id',
        help="Part of the landed cost added to this transfer.")
    landed_cost_total = fields.Monetary(
        'Landed Cost Total', readonly=True, currency_field='currency_id',
        aggregator=None,
        help="Total of the whole landed cost document (all its transfers).")

    @property
    def _table_query(self) -> SQL:
        return SQL("""
            WITH adj_by_picking AS (
                SELECT adj.cost_id,
                       sm.picking_id,
                       SUM(adj.additional_landed_cost) AS amount
                  FROM stock_valuation_adjustment_lines adj
                  JOIN stock_move sm ON sm.id = adj.move_id
                 GROUP BY adj.cost_id, sm.picking_id
            ),
            adj_count AS (
                SELECT cost_id, COUNT(*) AS nbr
                  FROM stock_valuation_adjustment_lines
                 GROUP BY cost_id
            ),
            picking_count AS (
                SELECT stock_landed_cost_id AS cost_id, COUNT(*) AS nbr
                  FROM stock_landed_cost_stock_picking_rel
                 GROUP BY stock_landed_cost_id
            )
            SELECT
                -- stable id built from the landed cost and the transfer
                lc.id::bigint * 1000000000 + COALESCE(rel.stock_picking_id, 0) AS id,
                lc.id AS landed_cost_id,
                lc.name AS name,
                lc.date AS date,
                lc.state AS state,
                lc.account_move_id AS account_move_id,
                lc.account_journal_id AS account_journal_id,
                lc.vendor_bill_id AS vendor_bill_id,
                rel.stock_picking_id AS picking_id,
                sp.picking_type_id AS picking_type_id,
                sp.date_done AS picking_date,
                sp.origin AS origin,
                sp.partner_id AS partner_id,
                lc.company_id AS company_id,
                rc.currency_id AS currency_id,
                lc.amount_total AS landed_cost_total,
                CASE
                    -- split computed by Odoo (always the case once posted)
                    WHEN adj_count.cost_id IS NOT NULL THEN COALESCE(adj.amount, 0.0)
                    -- draft not computed yet: one transfer (or none) gets everything
                    WHEN COALESCE(pc.nbr, 0) <= 1 THEN lc.amount_total
                    -- draft not computed yet with several transfers: equal split
                    ELSE lc.amount_total / pc.nbr
                END AS amount
            FROM stock_landed_cost lc
            JOIN res_company rc ON rc.id = lc.company_id
            LEFT JOIN stock_landed_cost_stock_picking_rel rel
                   ON rel.stock_landed_cost_id = lc.id
            LEFT JOIN stock_picking sp ON sp.id = rel.stock_picking_id
            LEFT JOIN adj_by_picking adj
                   ON adj.cost_id = lc.id AND adj.picking_id = rel.stock_picking_id
            LEFT JOIN adj_count ON adj_count.cost_id = lc.id
            LEFT JOIN picking_count pc ON pc.cost_id = lc.id
        """)

    def action_open_landed_cost(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'stock.landed.cost',
            'res_id': self.landed_cost_id.id,
            'view_mode': 'form',
            'target': 'current',
        }
