# -*- coding: utf-8 -*-
from odoo import fields, models


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    ot_landed_cost_count = fields.Integer(
        'Landed Costs', compute='_compute_ot_landed_cost',
        groups='stock.group_stock_manager')
    ot_landed_cost_amount = fields.Monetary(
        'Landed Cost Amount', compute='_compute_ot_landed_cost',
        currency_field='ot_company_currency_id',
        groups='stock.group_stock_manager',
        help="Total posted landed costs added to this transfer.")
    ot_company_currency_id = fields.Many2one(
        related='company_id.currency_id', string='Company Currency')

    def _compute_ot_landed_cost(self):
        data = {}
        if self.ids:
            groups = self.env['ot.landed.cost.report']._read_group(
                [('picking_id', 'in', self.ids), ('state', '=', 'done')],
                ['picking_id'], ['__count', 'amount:sum'])
            data = {picking.id: (count, amount) for picking, count, amount in groups}
        for picking in self:
            count, amount = data.get(picking.id, (0, 0.0))
            picking.ot_landed_cost_count = count
            picking.ot_landed_cost_amount = amount

    def action_view_ot_landed_costs(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id(
            'ot_landed_cost_report.action_ot_landed_cost_report')
        action['domain'] = [('picking_id', '=', self.id)]
        action['context'] = {'search_default_posted': 1}
        return action
