# -*- coding: utf-8 -*-
from odoo import api, models


class ReportOtLandedCost(models.AbstractModel):
    _name = 'report.ot_landed_cost_report.report_landed_cost'
    _description = 'Landed Cost Report PDF'

    @api.model
    def _get_report_values(self, docids, data=None):
        wizards = self.env['ot.landed.cost.report.wizard'].browse(docids)
        return {
            'doc_ids': docids,
            'doc_model': 'ot.landed.cost.report.wizard',
            'docs': wizards,
            'report_data': {wizard.id: wizard._get_report_data() for wizard in wizards},
        }
