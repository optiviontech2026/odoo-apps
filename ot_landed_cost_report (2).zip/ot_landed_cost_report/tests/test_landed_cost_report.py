# -*- coding: utf-8 -*-
import base64
import io

from odoo import fields
from odoo.fields import Command
from odoo.tests import tagged

from odoo.addons.stock_landed_costs.tests.common import TestStockLandedCostsCommon


@tagged('post_install', '-at_install')
class TestOtLandedCostReport(TestStockLandedCostsCommon):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.product1 = cls.env['product.product'].create({
            'name': 'Report Product',
            'is_storable': True,
            'categ_id': cls.stock_account_product_categ.id,
        })
        cls.productlc1 = cls.env['product.product'].create({
            'name': 'Freight',
            'type': 'service',
            'categ_id': cls.stock_account_product_categ.id,
            'landed_cost_ok': True,
        })

    def _make_receipt(self, product, quantity, unit_cost):
        po = self.env['purchase.order'].create({
            'partner_id': self.partner_a.id,
            'order_line': [Command.create({
                'product_id': product.id,
                'product_qty': quantity,
                'price_unit': unit_cost,
                'tax_ids': [Command.clear()],
            })],
        })
        po.button_confirm()
        receipt = po.picking_ids
        receipt.move_ids.quantity = receipt.move_ids.product_uom_qty
        receipt.button_validate()
        return receipt

    def _new_lc(self, pickings, amount, validate=True):
        lc = self.env['stock.landed.cost'].create({
            'account_journal_id': self.stock_journal.id,
            'picking_ids': [Command.set(pickings.ids)],
            'cost_lines': [Command.create({
                'product_id': self.productlc1.id,
                'price_unit': amount,
                'split_method': 'by_quantity',
                'account_id': self.company_data['default_account_expense'].id,
            })],
        })
        if validate:
            lc.compute_landed_cost()
            lc.button_validate()
        return lc

    def test_report_lines_and_exports(self):
        Report = self.env['ot.landed.cost.report']
        picking1 = self._make_receipt(self.product1, 10, 10)
        picking2 = self._make_receipt(self.product1, 30, 10)

        # one landed cost split on two receipts by quantity: 25 / 75
        lc_multi = self._new_lc(picking1 | picking2, 100)
        # one landed cost on a single receipt
        lc_single = self._new_lc(picking1, 30)
        # draft, not computed, on two receipts -> equal split 20 / 20
        lc_draft = self._new_lc(picking1 | picking2, 40, validate=False)

        self.assertEqual(lc_multi.state, 'done')
        self.assertTrue(lc_multi.account_move_id, "a journal entry must be created")

        lines = Report.search([('landed_cost_id', '=', lc_multi.id)])
        self.assertEqual(len(lines), 2)
        by_picking = {line.picking_id: line for line in lines}
        self.assertAlmostEqual(by_picking[picking1].amount, 25.0)
        self.assertAlmostEqual(by_picking[picking2].amount, 75.0)
        for line in lines:
            self.assertEqual(line.account_move_id, lc_multi.account_move_id)
            self.assertEqual(line.date, lc_multi.date)
            self.assertEqual(line.name, lc_multi.name)
            self.assertAlmostEqual(line.landed_cost_total, 100.0)
            self.assertEqual(line.partner_id, picking1.partner_id)

        single = Report.search([('landed_cost_id', '=', lc_single.id)])
        self.assertEqual(single.picking_id, picking1)
        self.assertAlmostEqual(single.amount, 30.0)
        self.assertEqual(single.account_move_id, lc_single.account_move_id)

        draft = Report.search([('landed_cost_id', '=', lc_draft.id)])
        self.assertEqual(draft.mapped('state'), ['draft', 'draft'])
        self.assertEqual(draft.mapped('amount'), [20.0, 20.0])
        self.assertFalse(draft.account_move_id)

        # report total equals landed cost totals
        groups = Report._read_group([('state', '=', 'done')], [], ['amount:sum'])
        self.assertAlmostEqual(groups[0][0], 130.0)

        # smart button on the transfer (posted only)
        picking1.invalidate_recordset()
        self.assertEqual(picking1.ot_landed_cost_count, 2)
        self.assertAlmostEqual(picking1.ot_landed_cost_amount, 55.0)
        self.assertAlmostEqual(picking2.ot_landed_cost_amount, 75.0)
        action = picking1.action_view_ot_landed_costs()
        self.assertEqual(action['res_model'], 'ot.landed.cost.report')

        # row click opens the landed cost
        open_action = single.action_open_landed_cost()
        self.assertEqual(open_action['res_id'], lc_single.id)

        # wizard
        today = fields.Date.context_today(lc_multi)
        wizard = self.env['ot.landed.cost.report.wizard'].create({
            'date_from': today.replace(day=1),
            'date_to': today,
        })
        data = wizard._get_report_data()
        self.assertEqual(len(data['lines']), 3)
        self.assertAlmostEqual(data['total'], 130.0)
        wizard.state_filter = 'draft_done'
        self.assertEqual(len(wizard._get_lines()), 5)
        wizard.state_filter = 'done'
        wizard.picking_ids = picking2
        self.assertEqual(len(wizard._get_lines()), 1)
        wizard.picking_ids = False

        view_action = wizard.action_view()
        self.assertEqual(Report.search_count(view_action['domain']), 3)

        # excel export
        xlsx_action = wizard.action_export_xlsx()
        self.assertEqual(xlsx_action['type'], 'ir.actions.act_url')
        import openpyxl  # noqa: PLC0415
        book = openpyxl.load_workbook(io.BytesIO(base64.b64decode(wizard.excel_file)))
        sheet = book.active
        header_row = 6
        self.assertEqual(sheet.cell(header_row, 4).value, 'Journal Entry')
        rows = list(sheet.iter_rows(min_row=header_row + 1, max_row=header_row + 3, values_only=True))
        self.assertEqual({r[2] for r in rows}, {lc_multi.name, lc_single.name})
        self.assertEqual({r[3] for r in rows}, {lc_multi.account_move_id.name, lc_single.account_move_id.name})
        self.assertEqual({r[4] for r in rows}, {picking1.name, picking2.name})
        self.assertAlmostEqual(sum(r[10] for r in rows), 130.0)
        self.assertTrue(str(sheet.cell(header_row + 4, 11).value).startswith('=SUM('))

        # pdf (html rendering, wkhtmltopdf not needed)
        html = self.env['ir.actions.report']._render_qweb_html(
            'ot_landed_cost_report.action_report_ot_landed_cost', wizard.ids)[0].decode()
        for expected in (lc_multi.name, lc_single.name, lc_multi.account_move_id.name,
                         picking1.name, picking2.name, 'Landed Cost Report'):
            self.assertIn(expected, html)

    def test_wizard_period(self):
        from datetime import date  # noqa: PLC0415
        from freezegun import freeze_time  # noqa: PLC0415
        from odoo.tests import Form  # noqa: PLC0415

        with freeze_time('2026-11-15'):
            # opens on today, dates can be changed
            form = Form(self.env['ot.landed.cost.report.wizard'])
            self.assertEqual(form.period, 'today')
            self.assertEqual((form.date_from, form.date_to), (date(2026, 11, 15), date(2026, 11, 15)))

            form.period = 'this_month'
            self.assertEqual((form.date_from, form.date_to), (date(2026, 11, 1), date(2026, 11, 30)))
            self.assertEqual(form.period, 'this_month')
            form.period = 'last_month'
            self.assertEqual((form.date_from, form.date_to), (date(2026, 10, 1), date(2026, 10, 31)))
            form.period = 'this_quarter'
            self.assertEqual((form.date_from, form.date_to), (date(2026, 10, 1), date(2026, 12, 31)))
            form.period = 'this_year'
            self.assertEqual((form.date_from, form.date_to), (date(2026, 1, 1), date(2026, 12, 31)))

            # changing a date by hand switches to Custom and keeps the dates
            form.date_from = date(2026, 3, 5)
            self.assertEqual(form.period, 'custom')
            form.date_to = date(2026, 4, 20)
            wizard = form.save()
            self.assertEqual((wizard.date_from, wizard.date_to), (date(2026, 3, 5), date(2026, 4, 20)))
            self.assertEqual(wizard._get_report_data()['period'], '03/05/2026 to 04/20/2026')

            wizard.write({'period': 'today'})
            self.assertEqual(wizard._get_report_data()['period'], '11/15/2026')

    def test_print_button_in_landed_costs(self):
        action = self.env.ref('ot_landed_cost_report.action_ot_landed_cost_report_wizard')
        arch = self.env['stock.landed.cost'].get_views(
            [(self.env.ref('stock_landed_costs.view_stock_landed_cost_tree').id, 'list')])['views']['list']['arch']
        self.assertIn('name="%s"' % action.id, arch)
        self.assertIn('Print Report', arch)
        for fname in ('account_move_id', 'picking_ids', 'amount_total'):
            self.assertIn('name="%s"' % fname, arch)
        # nothing added to Inventory > Reporting
        reporting = self.env.ref('stock.menu_warehouse_report')
        self.assertFalse(self.env['ir.ui.menu'].search([
            ('id', 'child_of', reporting.id),
            ('action', 'like', 'ot.landed.cost'),
        ]))
