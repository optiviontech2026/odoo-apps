# -*- coding: utf-8 -*-
import base64
import io

import xlsxwriter
from dateutil.relativedelta import relativedelta
from xlsxwriter.utility import xl_rowcol_to_cell

from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.tools import date_utils
from odoo.tools.misc import format_date


class OtLandedCostReportWizard(models.TransientModel):
    _name = 'ot.landed.cost.report.wizard'
    _description = 'Landed Cost Report Wizard'

    period = fields.Selection([
        ('today', 'Today'),
        ('this_month', 'This Month'),
        ('last_month', 'Last Month'),
        ('this_quarter', 'This Quarter'),
        ('this_year', 'This Year'),
        ('custom', 'Custom'),
    ], string='Period', required=True, default='today',
        help="Pick a ready period, or change the dates to use your own period.")
    date_from = fields.Date(
        'From', required=True, compute='_compute_dates', store=True, readonly=False,
        precompute=True)
    date_to = fields.Date(
        'To', required=True, compute='_compute_dates', store=True, readonly=False,
        precompute=True)
    company_id = fields.Many2one(
        'res.company', 'Company', required=True,
        default=lambda self: self.env.company)
    state_filter = fields.Selection([
        ('done', 'Posted only'),
        ('draft_done', 'Draft and Posted'),
    ], string='Status', required=True, default='done')
    picking_ids = fields.Many2many(
        'stock.picking', 'ot_lc_report_wizard_picking_rel', 'wizard_id', 'picking_id',
        string='Transfers', domain="[('company_id', '=', company_id)]",
        help="Leave empty to include all transfers.")
    partner_ids = fields.Many2many(
        'res.partner', 'ot_lc_report_wizard_partner_rel', 'wizard_id', 'partner_id',
        string='Partners',
        help="Leave empty to include all partners.")
    excel_file = fields.Binary('Excel File', readonly=True, attachment=False)
    excel_filename = fields.Char('Excel File Name', readonly=True)

    # ------------------------------------------------------------------
    # Period
    # ------------------------------------------------------------------
    def _get_period_dates(self, period):
        """Return (date_from, date_to) for a ready period, None for 'custom'."""
        today = fields.Date.context_today(self)
        if period == 'today':
            return today, today
        if period == 'this_month':
            return date_utils.start_of(today, 'month'), date_utils.end_of(today, 'month')
        if period == 'last_month':
            last_month = date_utils.start_of(today, 'month') - relativedelta(months=1)
            return last_month, date_utils.end_of(last_month, 'month')
        if period == 'this_quarter':
            return date_utils.get_quarter(today)
        if period == 'this_year':
            return date_utils.start_of(today, 'year'), date_utils.end_of(today, 'year')
        return None

    @api.depends('period')
    def _compute_dates(self):
        for wizard in self:
            dates = wizard._get_period_dates(wizard.period)
            if dates:
                wizard.date_from, wizard.date_to = dates
            elif not wizard.date_from or not wizard.date_to:
                today = fields.Date.context_today(wizard)
                wizard.date_from = wizard.date_from or today
                wizard.date_to = wizard.date_to or today

    @api.onchange('date_from', 'date_to')
    def _onchange_dates_set_custom(self):
        """Dates changed by hand: switch the period to Custom."""
        for wizard in self:
            if wizard.period != 'custom' and \
                    wizard._get_period_dates(wizard.period) != (wizard.date_from, wizard.date_to):
                wizard.period = 'custom'

    @api.constrains('date_from', 'date_to')
    def _check_dates(self):
        for wizard in self:
            if wizard.date_from and wizard.date_to and wizard.date_from > wizard.date_to:
                raise ValidationError(self.env._("The start date must be before the end date."))

    # ------------------------------------------------------------------
    # Data
    # ------------------------------------------------------------------
    def _get_domain(self):
        self.ensure_one()
        states = ['done'] if self.state_filter == 'done' else ['draft', 'done']
        domain = [
            ('date', '>=', self.date_from),
            ('date', '<=', self.date_to),
            ('company_id', '=', self.company_id.id),
            ('state', 'in', states),
        ]
        if self.picking_ids:
            domain.append(('picking_id', 'in', self.picking_ids.ids))
        if self.partner_ids:
            domain.append(('partner_id', 'child_of', self.partner_ids.ids))
        return domain

    def _get_lines(self):
        self.ensure_one()
        return self.env['ot.landed.cost.report'].search(
            self._get_domain(), order='date, id')

    def _get_report_data(self):
        """Values shared by the PDF and the Excel export."""
        self.ensure_one()
        lines = self._get_lines()
        currency = self.company_id.currency_id
        return {
            'lines': lines,
            'currency': currency,
            'total': currency.round(sum(lines.mapped('amount'))),
            'landed_cost_count': len(lines.landed_cost_id),
            'picking_count': len(lines.picking_id),
            'period': self._get_period_label(),
            'state_label': dict(self._fields['state_filter']._description_selection(self.env))[self.state_filter],
        }

    def _get_period_label(self):
        self.ensure_one()
        if self.date_from == self.date_to:
            return format_date(self.env, self.date_from)
        return self.env._(
            "%(date_from)s to %(date_to)s",
            date_from=format_date(self.env, self.date_from),
            date_to=format_date(self.env, self.date_to))

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------
    def action_view(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id(
            'ot_landed_cost_report.action_ot_landed_cost_report')
        action['domain'] = self._get_domain()
        action['context'] = {}
        action['display_name'] = self.env._("Landed Cost Report") + " (%s)" % self._get_report_data()['period']
        return action

    def action_print_pdf(self):
        self.ensure_one()
        return self.env.ref('ot_landed_cost_report.action_report_ot_landed_cost').report_action(self)

    def action_export_xlsx(self):
        self.ensure_one()
        content = self._generate_xlsx()
        filename = "%s_%s_%s.xlsx" % (
            self.env._("Landed_Cost_Report"), self.date_from, self.date_to)
        self.write({
            'excel_file': base64.b64encode(content),
            'excel_filename': filename,
        })
        return {
            'type': 'ir.actions.act_url',
            'url': '/web/content?model=%s&id=%s&field=excel_file&filename_field=excel_filename&download=true'
                   % (self._name, self.id),
            'target': 'download',
        }

    # ------------------------------------------------------------------
    # Excel
    # ------------------------------------------------------------------
    def _generate_xlsx(self):
        self.ensure_one()
        _ = self.env._
        data = self._get_report_data()
        lines = data['lines']
        currency = data['currency']
        if not lines:
            raise UserError(_("There are no landed costs for the selected filters."))

        state_labels = dict(
            self.env['ot.landed.cost.report']._fields['state']._description_selection(self.env))
        lang = self.env['res.lang']._get_data(code=self.env.lang or 'en_US')
        decimals = '0' * currency.decimal_places
        num_format = '#,##0.%s' % decimals if decimals else '#,##0'

        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        sheet = workbook.add_worksheet(_("Landed Costs")[:31])
        if lang.direction == 'rtl':
            sheet.right_to_left()

        f_title = workbook.add_format({'bold': True, 'font_size': 16})
        f_sub = workbook.add_format({'bold': True, 'font_size': 11})
        f_info = workbook.add_format({'font_size': 10, 'font_color': '#555555'})
        f_head = workbook.add_format({
            'bold': True, 'bg_color': '#714B67', 'font_color': '#FFFFFF',
            'border': 1, 'align': 'center', 'valign': 'vcenter', 'text_wrap': True})
        f_text = workbook.add_format({'border': 1, 'valign': 'top'})
        f_date = workbook.add_format({'border': 1, 'valign': 'top', 'num_format': 'yyyy-mm-dd', 'align': 'left'})
        f_dt = workbook.add_format({'border': 1, 'valign': 'top', 'num_format': 'yyyy-mm-dd hh:mm', 'align': 'left'})
        f_amount = workbook.add_format({'border': 1, 'valign': 'top', 'num_format': num_format})
        f_total_lbl = workbook.add_format({'bold': True, 'border': 1, 'bg_color': '#F2F2F2', 'align': 'right'})
        f_total = workbook.add_format({'bold': True, 'border': 1, 'bg_color': '#F2F2F2', 'num_format': num_format})

        headers = [
            (_("#"), 5),
            (_("Date"), 12),
            (_("Landed Cost"), 18),
            (_("Journal Entry"), 20),
            (_("Transfer"), 20),
            (_("Transfer Date"), 17),
            (_("Source Document"), 18),
            (_("Partner"), 28),
            (_("Vendor Bill"), 20),
            (_("Status"), 11),
            (_("Amount (%s)", currency.name), 18),
        ]
        last_col = len(headers) - 1

        sheet.merge_range(0, 0, 0, last_col, _("Landed Cost Report"), f_title)
        sheet.merge_range(1, 0, 1, last_col, self.company_id.name, f_sub)
        sheet.merge_range(2, 0, 2, last_col, _("Period: %s", data['period']), f_info)
        sheet.merge_range(3, 0, 3, last_col, _("Status: %s", data['state_label']), f_info)

        header_row = 5
        sheet.set_row(header_row, 30)
        for col, (title, width) in enumerate(headers):
            sheet.write(header_row, col, title, f_head)
            sheet.set_column(col, col, width)

        row = header_row + 1
        for index, line in enumerate(lines, start=1):
            picking_date = line.picking_date and fields.Datetime.context_timestamp(
                self, line.picking_date).replace(tzinfo=None)
            sheet.write_number(row, 0, index, f_text)
            sheet.write_datetime(row, 1, fields.Datetime.to_datetime(line.date), f_date)
            sheet.write_string(row, 2, line.name or '', f_text)
            sheet.write_string(row, 3, line.account_move_id.name or '', f_text)
            sheet.write_string(row, 4, line.picking_id.name or '', f_text)
            if picking_date:
                sheet.write_datetime(row, 5, picking_date, f_dt)
            else:
                sheet.write_blank(row, 5, None, f_text)
            sheet.write_string(row, 6, line.origin or '', f_text)
            sheet.write_string(row, 7, line.partner_id.display_name or '', f_text)
            sheet.write_string(row, 8, line.vendor_bill_id.name or '', f_text)
            sheet.write_string(row, 9, state_labels.get(line.state, ''), f_text)
            sheet.write_number(row, 10, line.amount, f_amount)
            row += 1

        sheet.merge_range(row, 0, row, last_col - 1, _("Total"), f_total_lbl)
        sheet.write_formula(
            row, last_col,
            '=SUM(%s:%s)' % (xl_rowcol_to_cell(header_row + 1, last_col),
                             xl_rowcol_to_cell(row - 1, last_col)),
            f_total, data['total'])

        sheet.freeze_panes(header_row + 1, 0)
        sheet.autofilter(header_row, 0, row - 1, last_col)
        sheet.set_landscape()
        sheet.set_paper(9)  # A4
        sheet.fit_to_pages(1, 0)
        sheet.repeat_rows(header_row)

        workbook.close()
        return output.getvalue()
