# Partner Statement of Account (Odoo 19)

Adds a **Statements** tab right after the *Accounting / Invoicing* tab on the contact form, with two reports:

| Report | Accounts | Positive balance means |
|---|---|---|
| Customer Statement | Receivable | the customer owes you |
| Vendor Statement | Payable | you owe the vendor |

Columns: **Date · Sequence · Reference / Description · Amount** (debit and credit merged, signed) **· Balance** (running),
with an opening-balance row, a closing-balance row and a summary (opening, total debit, total credit, closing).
The header band shows the partner name and the statement period.

## Install
1. Copy the `partner_statement_report` folder into your custom addons path.
2. Restart Odoo, then *Apps → Update Apps List*, search **Partner Statement** and install.
   (Depends on `account` and `contacts`.)

## Use
* Contact → **Statements** tab → *Customer Statement* or *Vendor Statement*.
* Pick a period (this/last month, quarter, financial year, all dates, or a custom range),
  optionally include draft entries, check the live preview, then **Print PDF** or **Export Excel**.
* **Only Unreconciled**: lists only transactions still open (not fully reconciled) on the end date, with their
  open amount; partly paid items show their original amount underneath. Open items older than the start date go
  into the opening balance, so the closing balance is still the total outstanding. Reconciliations made after the
  end date are ignored, so a statement "as at 31/03" shows what was open on 31/03.
* **Amount**: *Full Amount* (original amounts) or *Residual Amount* - the open amount, taken from
  Odoo's **Residual** for the company currency and **Residual in Currency** for other currencies (as at the
  end date; for a statement ending today it is exactly the value of those fields). Fully reconciled
  transactions are not shown. Ticking *Only Unreconciled* selects Residual Amount by default; choose
  Full Amount to list open items with their original amount instead.
* **Currencies** (needs multi-currency enabled):
  * *Company Currency* - one table in the company currency. Tick **Show Amount in Currency** to add an
    "Amount in Currency" column (transaction currency amount, for foreign-currency transactions).
  * *Separate by Currency* - one section per transaction currency, each with its own opening, running and
    closing balance in that currency.
  * *Currencies* - limit the statement to some currencies (empty = all).
* Several partners at once: Contacts list → select → *Actions → Partner Statement*
  (one PDF page set / one Excel sheet per partner).

## Design & colours
* **PDF Layout** (in the dialog, default in Settings):
  * *With Logo & Company Layout* – the standard Odoo document layout (Settings → General Settings →
    *Document Layout*): logo, layout style (Light, Boxed, Bold, Striped…), font, header and footer.
  * *Plain (No Logo)* – no logo, company header or footer, only page numbers. Set the **Top Margin (mm)** to
    leave room for pre-printed letterhead paper. Paper size / other margins: Settings → Technical →
    Paper Format → *Partner Statement - Plain (A4)*.
* Header and highlight colours can be changed in the dialog for each print. Accounting managers can tick
  *Save Design as Company Default*, or set the defaults in Settings → Invoicing/Accounting → *Partner Statements*.
* The QWeb templates are standard views (`partner_statement_report.report_partner_statement_document`,
  `statement_header_band`, `statement_table`), so they can be edited or inherited like any Odoo report.
* Arabic translation and right-to-left layout are included (RTL PDFs need `rtlcss` on the server,
  as for every Odoo report).

## Notes
* Contacts of a company are included in the company's statement.
* Each journal entry is one line (an invoice with several installments shows once).
* Tests: `odoo-bin -d <db> -i partner_statement_report --test-tags /partner_statement_report --stop-after-init`
