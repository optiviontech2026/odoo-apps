{
    'name': 'Partner Statement of Account',
    'version': '19.0.1.3.0',
    'category': 'Accounting/Accounting',
    'summary': 'Customer & Vendor statements on the contact form, with PDF / Excel export and custom colours',
    'description': """
Partner Statement of Account
============================
Adds a "Statements" tab next to the Accounting (Invoicing) tab on the contact form with two reports:

* Customer Statement (receivable accounts)
* Vendor Statement (payable accounts)

Each statement shows: Date, Sequence, Reference / Description, Amount (debit and credit merged
into one signed column) and a running Balance, with an opening and closing balance.

Features
--------
* Period selection (this/last month, quarter, financial year, all dates or a custom range)
* Option to show only unreconciled (open) transactions
* Full or residual amounts (Residual / Residual in Currency)
* Multi-currency: optional "Amount in Currency" column, or one section per currency
* PDF export using the standard Odoo 19 document layout (logo, header, footer, fonts),
  or a plain version without logo / header / footer (adjustable top margin for letterhead paper)
* Excel (.xlsx) export with live running-balance formulas
* Adjustable header / highlight colours per print, with company defaults in Settings
* Batch printing from the contacts list (Action menu)
""",
    'author': 'Jabal Al Zmroud',
    'license': 'LGPL-3',
    'depends': ['account', 'contacts'],
    'data': [
        'security/ir.model.access.csv',
        'report/partner_statement_report.xml',
        'report/partner_statement_templates.xml',
        'wizard/partner_statement_wizard_views.xml',
        'views/res_partner_views.xml',
        'views/res_config_settings_views.xml',
    ],
    'installable': True,
    'application': False,
}
