import re

from odoo import api, fields, models

DEFAULT_HEADER_COLOR = '#1F4E79'
HEX_COLOR_RE = re.compile(r'^#?([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$')


def normalize_hex(color, fallback=DEFAULT_HEADER_COLOR):
    """Return a '#RRGGBB' string, or the fallback if the value is not a valid hex colour."""
    match = HEX_COLOR_RE.match((color or '').strip())
    if not match:
        return fallback
    value = match.group(1)
    if len(value) == 3:
        value = ''.join(c * 2 for c in value)
    return '#' + value.upper()


def _rgb(color):
    color = normalize_hex(color)
    return tuple(int(color[i:i + 2], 16) for i in (1, 3, 5))


def lighten(color, ratio=0.85):
    """Mix a colour with white. ratio=0 keeps the colour, ratio=1 gives white."""
    r, g, b = _rgb(color)
    mix = [round(c + (255 - c) * ratio) for c in (r, g, b)]
    return '#%02X%02X%02X' % tuple(mix)


def contrast_text(color):
    """Black or white, whichever reads better on the given background."""
    r, g, b = _rgb(color)
    luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255
    return '#212529' if luminance > 0.6 else '#FFFFFF'


class ResCompany(models.Model):
    _inherit = 'res.company'

    partner_statement_header_color = fields.Char(
        string="Statement Header Colour",
        help="Background colour of the statement title line and table header. "
             "Leave empty to use the company's document layout primary colour.",
    )
    partner_statement_highlight_color = fields.Char(
        string="Statement Highlight Colour",
        help="Background colour of the opening / closing balance rows. "
             "Leave empty to use a light tint of the header colour.",
    )

    partner_statement_pdf_layout = fields.Selection(
        [
            ('company', "With Logo & Company Layout"),
            ('plain', "Plain (No Logo)"),
        ],
        string="Statement PDF Layout", default='company', required=True,
        help="With Logo & Company Layout: uses the company document layout (logo, header, footer, font).\n"
             "Plain: no logo, header or footer, only page numbers - e.g. for pre-printed letterhead paper.",
    )
    partner_statement_margin_top = fields.Integer(
        string="Statement Top Margin (mm)", default=12,
        help="Top margin of the plain PDF. Increase it to leave space for a pre-printed letterhead.",
    )

    def _get_partner_statement_colors(self):
        """Effective (header, highlight) colours for this company."""
        self.ensure_one()
        header = normalize_hex(
            self.partner_statement_header_color or self.primary_color or DEFAULT_HEADER_COLOR
        )
        highlight = normalize_hex(self.partner_statement_highlight_color, fallback=lighten(header))
        return header, highlight

    @api.model
    def _normalize_statement_color_vals(self, vals):
        for key in ('partner_statement_header_color', 'partner_statement_highlight_color'):
            if vals.get(key):
                vals[key] = normalize_hex(vals[key], fallback=False)
        return vals

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            self._normalize_statement_color_vals(vals)
        return super().create(vals_list)

    def write(self, vals):
        return super().write(self._normalize_statement_color_vals(vals))
