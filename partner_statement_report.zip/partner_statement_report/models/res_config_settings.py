from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    partner_statement_header_color = fields.Char(
        related='company_id.partner_statement_header_color', readonly=False,
    )
    partner_statement_highlight_color = fields.Char(
        related='company_id.partner_statement_highlight_color', readonly=False,
    )
    partner_statement_pdf_layout = fields.Selection(
        related='company_id.partner_statement_pdf_layout', readonly=False,
    )
    partner_statement_margin_top = fields.Integer(
        related='company_id.partner_statement_margin_top', readonly=False,
    )
