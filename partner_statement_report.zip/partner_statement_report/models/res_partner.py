from odoo import models


class ResPartner(models.Model):
    _inherit = 'res.partner'

    def _action_open_statement_wizard(self, statement_type):
        self.ensure_one()
        partner = self.commercial_partner_id
        title = {
            'customer': self.env._("Customer Statement"),
            'vendor': self.env._("Vendor Statement"),
        }.get(statement_type, self.env._("Partner Statement"))
        return {
            'type': 'ir.actions.act_window',
            'name': f"{title} - {partner.display_name}",
            'res_model': 'partner.statement.wizard',
            'view_mode': 'form',
            'views': [(False, 'form')],
            'target': 'new',
            'context': {
                'default_partner_ids': partner.ids,
                'default_statement_type': statement_type,
                'dialog_size': 'extra-large',
            },
        }

    def action_open_customer_statement(self):
        return self._action_open_statement_wizard('customer')

    def action_open_vendor_statement(self):
        return self._action_open_statement_wizard('vendor')
