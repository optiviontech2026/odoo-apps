from odoo import api, models


class ReportPartnerStatement(models.AbstractModel):
    _name = 'report.partner_statement_report.report_partner_statement'
    _description = 'Partner Statement PDF Report'

    @api.model
    def _get_report_values(self, docids, data=None):
        wizards = self.env['partner.statement.wizard'].browse(docids)
        wizards._check_dates()
        statements = []
        for wizard in wizards:
            statements.extend(wizard._get_all_statements())
        return {
            'doc_ids': docids,
            'doc_model': 'partner.statement.wizard',
            'docs': wizards,
            'statements': statements,
        }


class ReportPartnerStatementPlain(models.AbstractModel):
    _name = 'report.partner_statement_report.report_partner_statement_plain'
    _inherit = 'report.partner_statement_report.report_partner_statement'
    _description = 'Partner Statement PDF Report (Plain)'
