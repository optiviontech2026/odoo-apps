import base64
import io

from odoo import Command, fields
from odoo.exceptions import UserError
from odoo.tests import Form, tagged

from odoo.addons.account.tests.common import AccountTestInvoicingCommon


@tagged('post_install', '-at_install')
class TestPartnerStatement(AccountTestInvoicingCommon):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        d = fields.Date.from_string
        no_tax = []
        # before the period -> opening balance 500
        cls.inv_old = cls.init_invoice('out_invoice', cls.partner_a, d('2025-12-15'), post=True, amounts=[500], taxes=no_tax)
        # inside the period
        cls.inv_1 = cls.init_invoice('out_invoice', cls.partner_a, d('2026-01-10'), post=True, amounts=[1000], taxes=no_tax)
        cls.env['account.payment.register'].with_context(
            active_model='account.move', active_ids=cls.inv_1.ids,
        ).create({'payment_date': d('2026-01-20'), 'amount': 300})._create_payments()
        cls.refund = cls.init_invoice('out_refund', cls.partner_a, d('2026-02-05'), post=True, amounts=[200], taxes=no_tax)
        # draft and after-period entries must be ignored by default
        cls.draft = cls.init_invoice('out_invoice', cls.partner_a, d('2026-02-10'), post=False, amounts=[50], taxes=no_tax)
        cls.inv_late = cls.init_invoice('out_invoice', cls.partner_a, d('2026-04-01'), post=True, amounts=[999], taxes=no_tax)
        # vendor side for the same partner
        cls.bill = cls.init_invoice('in_invoice', cls.partner_a, d('2026-01-12'), post=True, amounts=[700], taxes=no_tax)
        # partner_b has a 2-installment payment term -> must still be a single row
        cls.inv_b = cls.init_invoice('out_invoice', cls.partner_b, d('2026-01-15'), post=True, amounts=[1000], taxes=no_tax)

    def _wizard(self, partners, statement_type='customer', **vals):
        return self.env['partner.statement.wizard'].create({
            'partner_ids': [fields.Command.set(partners.ids)],
            'statement_type': statement_type,
            'period': 'custom',
            'date_from': '2026-01-01',
            'date_to': '2026-03-31',
            **vals,
        })

    def _sec(self, partner, statement_type='customer', **vals):
        """Data of the single (company currency) section of a statement."""
        st = self._wizard(partner, statement_type, **vals)._get_statement_data(partner)
        self.assertEqual(len(st['sections']), 1)
        return st['sections'][0]

    def test_customer_statement(self):
        sec = self._sec(self.partner_a)
        self.assertEqual(sec['opening_balance'], 500)
        self.assertEqual([l['amount'] for l in sec['lines']], [1000, -300, -200])
        self.assertEqual([l['balance'] for l in sec['lines']], [1500, 1200, 1000])
        self.assertEqual(sec['closing_balance'], 1000)
        self.assertEqual(sec['total_debit'], 1000)
        self.assertEqual(sec['total_credit'], 500)
        self.assertEqual(sec['lines'][0]['sequence'], self.inv_1.name)
        self.assertEqual(sec['lines'][2]['sequence'], self.refund.name)
        self.assertIn('Payment', sec['lines'][1]['description'])

    def test_include_draft(self):
        sec = self._sec(self.partner_a, include_draft=True)
        self.assertEqual(sec['closing_balance'], 1050)
        self.assertTrue(any(l['is_draft'] for l in sec['lines']))

    def test_vendor_statement_sign(self):
        sec = self._sec(self.partner_a, 'vendor')
        self.assertEqual(sec['opening_balance'], 0)
        self.assertEqual([l['amount'] for l in sec['lines']], [700])
        self.assertEqual(sec['closing_balance'], 700)

    def test_installments_grouped(self):
        sec = self._sec(self.partner_b)
        self.assertEqual(len(sec['lines']), 1)
        self.assertEqual(sec['closing_balance'], 1000)

    def test_unreconciled_only(self):
        full = self._sec(self.partner_a)
        wizard = self._wizard(self.partner_a, unreconciled_only=True)
        self.assertEqual(wizard.amount_basis, 'residual')  # default for unreconciled statements
        sec = wizard._get_statement_data(self.partner_a)['sections'][0]
        # old unpaid invoice -> opening; paid-in-part invoice shows its open 700; payment is gone
        self.assertEqual(sec['opening_balance'], 500)
        self.assertEqual([l['amount'] for l in sec['lines']], [700, -200])
        self.assertEqual([l['is_partial'] for l in sec['lines']], [True, False])
        self.assertEqual(sec['lines'][0]['other_amount'], 1000)
        self.assertEqual([l['balance'] for l in sec['lines']], [1200, 1000])
        # still the total outstanding amount
        self.assertEqual(sec['closing_balance'], full['closing_balance'])

        vendor = self._sec(self.partner_a, 'vendor', unreconciled_only=True)
        self.assertEqual([l['amount'] for l in vendor['lines']], [700])

    def test_unreconciled_full_amounts(self):
        # open transactions only, but with their original amount (residual as a note)
        sec = self._sec(self.partner_a, unreconciled_only=True, amount_basis='full')
        self.assertEqual(sec['opening_balance'], 500)
        self.assertEqual([l['amount'] for l in sec['lines']], [1000, -200])
        self.assertEqual(sec['lines'][0]['other_amount'], 700)
        self.assertTrue(sec['lines'][0]['is_partial'])

    def test_unreconciled_as_of_end_date(self):
        # partner_b's invoice (2 installments) is paid after the statement end date
        self.env['account.payment.register'].with_context(
            active_model='account.move', active_ids=self.inv_b.ids,
        ).create({'payment_date': '2026-04-15', 'amount': 1000})._create_payments()
        self.assertEqual(self.inv_b.payment_state in ('paid', 'in_payment'), True)

        sec = self._sec(self.partner_b, unreconciled_only=True)
        self.assertEqual([l['amount'] for l in sec['lines']], [1000])  # still open on 31/03
        self.assertFalse(sec['lines'][0]['is_partial'])

        sec = self._sec(self.partner_b, unreconciled_only=True, date_to='2026-04-30')
        self.assertEqual(sec['lines'], [])
        self.assertEqual(sec['closing_balance'], 0)

    # ------------------------------------------------------------------
    # Currencies
    # ------------------------------------------------------------------
    def _setup_currency_data(self):
        """USD (company) invoice 1000, EUR invoice 300 EUR (= 150 USD), EUR payment 100 EUR."""
        d = fields.Date.from_string
        eur = self.setup_other_currency('EUR')  # 1 USD = 2 EUR
        partner = self.env['res.partner'].create({'name': 'Multi Currency Customer'})
        usd_inv = self.init_invoice('out_invoice', partner, d('2026-01-10'), post=True, amounts=[1000], taxes=[])
        eur_inv = self.init_invoice(
            'out_invoice', partner, d('2026-02-01'), post=True, amounts=[300], taxes=[], currency=eur,
        )
        self.env['account.payment.register'].with_context(
            active_model='account.move', active_ids=eur_inv.ids,
        ).create({'payment_date': d('2026-02-15'), 'amount': 100, 'currency_id': eur.id})._create_payments()
        return eur, partner, usd_inv, eur_inv

    def test_amount_in_currency_column(self):
        eur, partner, usd_inv, eur_inv = self._setup_currency_data()
        sec = self._sec(partner, show_amount_currency=True)
        self.assertEqual(sec['currency'], self.env.company.currency_id)
        self.assertEqual([l['amount'] for l in sec['lines']], [1000, 150, -50])
        # only foreign currency transactions get an amount in currency
        self.assertEqual([l['amount_currency'] for l in sec['lines']], [None, 300, -100])
        self.assertEqual(sec['lines'][1]['currency'], eur)

        wizard = self._wizard(partner, show_amount_currency=True)
        html = self.env['ir.actions.report']._render_qweb_html(
            'partner_statement_report.action_report_partner_statement', wizard.ids,
        )[0].decode()
        self.assertIn('Amount in Currency', html)
        self.assertNotIn('Amount in Currency', self.env['ir.actions.report']._render_qweb_html(
            'partner_statement_report.action_report_partner_statement', self._wizard(partner).ids,
        )[0].decode())

    def test_separate_by_currency(self):
        eur, partner, usd_inv, eur_inv = self._setup_currency_data()
        usd = self.env.company.currency_id
        st = self._wizard(partner, currency_mode='by_currency')._get_statement_data(partner)
        self.assertEqual([s['currency'] for s in st['sections']], [usd, eur])
        usd_sec, eur_sec = st['sections']
        self.assertEqual([l['amount'] for l in usd_sec['lines']], [1000])
        self.assertEqual([l['amount'] for l in eur_sec['lines']], [300, -100])
        self.assertEqual([l['balance'] for l in eur_sec['lines']], [300, 200])
        self.assertEqual((eur_sec['total_debit'], eur_sec['total_credit']), (300, 100))
        self.assertEqual(eur_sec['closing_balance'], 200)

        # opening balance is computed per currency
        st = self._wizard(partner, currency_mode='by_currency', date_from='2026-02-10')._get_statement_data(partner)
        self.assertEqual([s['opening_balance'] for s in st['sections']], [1000, 300])
        self.assertEqual([s['closing_balance'] for s in st['sections']], [1000, 200])

        # currency filter, in both modes
        st = self._wizard(partner, currency_mode='by_currency',
                          currency_ids=[Command.set(eur.ids)])._get_statement_data(partner)
        self.assertEqual([s['currency'] for s in st['sections']], [eur])
        sec = self._sec(partner, currency_ids=[Command.set(eur.ids)])
        self.assertEqual([l['amount'] for l in sec['lines']], [150, -50])

    def test_residual_matches_odoo_residual_fields(self):
        eur, partner, usd_inv, eur_inv = self._setup_currency_data()
        usd_line = usd_inv.line_ids.filtered(lambda l: l.account_id.account_type == 'asset_receivable')
        eur_line = eur_inv.line_ids.filtered(lambda l: l.account_id.account_type == 'asset_receivable')

        # by currency: EUR amounts come from "Residual in Currency"
        st = self._wizard(partner, currency_mode='by_currency', amount_basis='residual',
                          date_to='2026-12-31')._get_statement_data(partner)
        usd_sec, eur_sec = st['sections']
        self.assertEqual([l['amount'] for l in usd_sec['lines']], [usd_line.amount_residual])
        self.assertEqual([l['amount'] for l in eur_sec['lines']], [eur_line.amount_residual_currency])
        self.assertEqual(eur_sec['lines'][0]['amount'], 200)
        self.assertEqual(eur_sec['lines'][0]['other_amount'], 300)  # original amount note
        self.assertTrue(eur_sec['lines'][0]['is_partial'])

        # company currency: amounts from "Residual", amount in currency from "Residual in Currency"
        sec = self._sec(partner, amount_basis='residual', show_amount_currency=True, date_to='2026-12-31')
        self.assertEqual([l['amount'] for l in sec['lines']], [usd_line.amount_residual, eur_line.amount_residual])
        self.assertEqual([l['amount'] for l in sec['lines']], [1000, 100])
        self.assertEqual([l['amount_currency'] for l in sec['lines']], [None, eur_line.amount_residual_currency])

        wizard = self._wizard(partner, currency_mode='by_currency', amount_basis='residual')
        html = self.env['ir.actions.report']._render_qweb_html(
            'partner_statement_report.action_report_partner_statement', wizard.ids,
        )[0].decode()
        self.assertIn('Currency: EUR', html)
        self.assertIn('Residual amounts', html)

        wizard.action_export_excel()
        self.assertIn('Residual', wizard.excel_filename)
        self.assertIn('By Currency', wizard.excel_filename)

    def test_currency_excel(self):
        eur, partner, usd_inv, eur_inv = self._setup_currency_data()
        try:
            import openpyxl
        except ImportError:
            return
        for vals, expected in (
            ({'show_amount_currency': True}, 'Amount in Currency'),
            ({'currency_mode': 'by_currency'}, 'Currency: EUR'),
        ):
            wizard = self._wizard(partner, **vals)
            wizard.action_export_excel()
            sheet = openpyxl.load_workbook(io.BytesIO(base64.b64decode(wizard.excel_file))).active
            values = [cell for row in sheet.iter_rows(values_only=True) for cell in row if cell is not None]
            self.assertIn(expected, values)
            if vals.get('show_amount_currency'):
                self.assertIn(300, values)   # amount in EUR
                self.assertIn(150, values)   # amount in USD

    def test_unreconciled_exports(self):
        wizard = self._wizard(self.partner_a, unreconciled_only=True)
        html = self.env['ir.actions.report']._render_qweb_html(
            'partner_statement_report.action_report_partner_statement', wizard.ids,
        )[0].decode()
        self.assertIn('Unreconciled transactions only', html)
        self.assertIn('Original amount', html)

        wizard.action_export_excel()
        self.assertIn('Unreconciled', wizard.excel_filename)
        try:
            import openpyxl
        except ImportError:
            return
        sheet = openpyxl.load_workbook(io.BytesIO(base64.b64decode(wizard.excel_file))).active
        values = [cell for row in sheet.iter_rows(values_only=True) for cell in row if cell]
        self.assertIn('Unreconciled transactions only', values)
        self.assertTrue(any(isinstance(v, str) and 'original amount' in v for v in values))

    def test_period_presets(self):
        wizard = self.env['partner.statement.wizard'].create({
            'partner_ids': [fields.Command.set(self.partner_a.ids)],
            'period': 'all',
        })
        self.assertFalse(wizard.date_from)
        self.assertEqual(wizard.date_to, fields.Date.context_today(wizard))
        wizard.period = 'this_month'
        self.assertEqual(wizard.date_from.day, 1)
        with Form(self.env['partner.statement.wizard'].with_context(
            active_model='res.partner', active_ids=self.partner_a.ids,
        )) as wiz_form:
            wiz_form.period = 'last_year'
            self.assertTrue(wiz_form.preview_html)

    def test_pdf_and_excel_exports(self):
        wizard = self._wizard(self.partner_a | self.partner_b, header_color='#8b0000')
        html, _ = self.env['ir.actions.report']._render_qweb_html(
            'partner_statement_report.action_report_partner_statement', wizard.ids,
        )
        html = html.decode()
        self.assertIn('Customer Statement', html)
        self.assertIn(self.partner_a.name, html)
        self.assertIn('#8B0000', html)
        self.assertIn(self.inv_1.name, html)

        action = wizard.action_export_excel()
        self.assertEqual(action['type'], 'ir.actions.act_url')
        self.assertTrue(wizard.excel_filename.endswith('.xlsx'))
        content = base64.b64decode(wizard.excel_file)
        self.assertEqual(content[:2], b'PK')

        try:
            import openpyxl
        except ImportError:
            return
        workbook = openpyxl.load_workbook(io.BytesIO(content))
        self.assertEqual(len(workbook.sheetnames), 2)

    def test_pdf_layouts(self):
        # company layout: standard report, external layout header / footer
        wizard = self._wizard(self.partner_a)
        action = wizard.action_print_pdf()
        if action.get('type') == 'ir.actions.report':
            self.assertEqual(action['report_name'], 'partner_statement_report.report_partner_statement')
        html = self.env['ir.actions.report']._render_qweb_html(
            'partner_statement_report.action_report_partner_statement', wizard.ids,
        )[0].decode()
        self.assertIn('o_report_layout_', html)
        self.assertNotIn('o_partner_statement_plain', html)

        # plain: own report, no company layout, custom top margin
        wizard = self._wizard(self.partner_a, pdf_layout='plain', plain_margin_top=40)
        action = wizard.action_print_pdf()
        self.assertEqual(action['type'], 'ir.actions.report')
        self.assertEqual(action['report_name'], 'partner_statement_report.report_partner_statement_plain')
        html = self.env['ir.actions.report']._render_qweb_html(
            'partner_statement_report.action_report_partner_statement_plain', wizard.ids,
        )[0].decode()
        self.assertIn('o_partner_statement_plain', html)
        self.assertIn('data-report-margin-top="40"', html)
        self.assertNotIn('o_report_layout_', html)
        self.assertIn(self.inv_1.name, html)
        self.assertIn('Customer Statement', html)

        wizard.plain_margin_top = 500
        with self.assertRaises(UserError):
            wizard.action_print_pdf()

    def test_layout_company_default(self):
        self.env.company.write({'partner_statement_pdf_layout': 'plain', 'partner_statement_margin_top': 45})
        wizard = self.env['partner.statement.wizard'].create({
            'partner_ids': [fields.Command.set(self.partner_a.ids)],
        })
        self.assertEqual(wizard.pdf_layout, 'plain')
        self.assertEqual(wizard.plain_margin_top, 45)

    def test_save_colors(self):
        wizard = self._wizard(self.partner_a, header_color='#123456', highlight_color='#abcdef',
                              pdf_layout='plain', plain_margin_top=35, save_colors_as_default=True)
        wizard.action_export_excel()
        self.assertEqual(self.env.company.partner_statement_header_color, '#123456')
        self.assertEqual(self.env.company.partner_statement_highlight_color, '#ABCDEF')
        self.assertEqual(self.env.company.partner_statement_pdf_layout, 'plain')
        self.assertEqual(self.env.company.partner_statement_margin_top, 35)

    def test_partner_form_buttons(self):
        action = self.partner_a.action_open_vendor_statement()
        self.assertEqual(action['res_model'], 'partner.statement.wizard')
        self.assertEqual(action['context']['default_statement_type'], 'vendor')
