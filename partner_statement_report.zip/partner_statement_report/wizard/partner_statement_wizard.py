import base64
import io
import itertools
import re

import xlsxwriter
from xlsxwriter.utility import xl_col_to_name
from dateutil.relativedelta import relativedelta
from markupsafe import Markup

from odoo import api, fields, models
from odoo.exceptions import UserError
from odoo.tools import date_utils
from odoo.tools.misc import format_date, formatLang

from ..models.res_company import contrast_text, lighten, normalize_hex

ACCOUNT_TYPES = {
    'customer': ('asset_receivable',),
    'vendor': ('liability_payable',),
    'both': ('asset_receivable', 'liability_payable'),
}

# Rows shown in the on-screen preview (PDF and Excel always contain every line).
PREVIEW_LINE_LIMIT = 200

# strftime -> Excel number-format tokens
_DATE_TOKENS = {
    '%d': 'dd', '%e': 'd', '%m': 'mm', '%Y': 'yyyy', '%y': 'yy',
    '%b': 'mmm', '%B': 'mmmm', '%a': 'ddd', '%A': 'dddd',
}


class PartnerStatementWizard(models.TransientModel):
    _name = 'partner.statement.wizard'
    _description = 'Partner Statement of Account'

    # ------------------------------------------------------------------
    # Fields
    # ------------------------------------------------------------------
    partner_ids = fields.Many2many(
        'res.partner', string="Partners", required=True,
        default=lambda self: self._default_partner_ids(),
    )
    statement_type = fields.Selection(
        [
            ('customer', "Customer Statement"),
            ('vendor', "Vendor Statement"),
            ('both', "Customer & Vendor"),
        ],
        string="Report Type", required=True, default='customer',
    )
    period = fields.Selection(
        [
            ('this_month', "This Month"),
            ('last_month', "Last Month"),
            ('this_quarter', "This Quarter"),
            ('last_quarter', "Last Quarter"),
            ('this_year', "This Financial Year"),
            ('last_year', "Last Financial Year"),
            ('all', "All Dates"),
            ('custom', "Custom Range"),
        ],
        string="Period", required=True, default='this_year',
    )
    date_from = fields.Date(
        string="From", compute='_compute_dates', store=True, readonly=False, precompute=True,
        help="Leave empty to start from the very first transaction (no opening balance).",
    )
    date_to = fields.Date(
        string="To", compute='_compute_dates', store=True, readonly=False, precompute=True,
        required=True,
    )
    include_draft = fields.Boolean(
        string="Include Draft Entries",
        help="Also include journal entries that are not posted yet.",
    )
    unreconciled_only = fields.Boolean(
        string="Only Unreconciled",
        help="Show only transactions that are still open (not fully reconciled) on the end date. "
             "Open items dated before the start date are included in the opening balance.",
    )
    amount_basis = fields.Selection(
        [
            ('full', "Full Amount"),
            ('residual', "Residual Amount"),
        ],
        string="Amount", required=True,
        compute='_compute_amount_basis', store=True, readonly=False, precompute=True,
        help="Full Amount: the original amount of each transaction.\n"
             "Residual Amount: the amount still open - Residual for the company currency and "
             "Residual in Currency for other currencies, as at the end date. "
             "Fully reconciled transactions are not shown.",
    )
    currency_mode = fields.Selection(
        [
            ('company', "Company Currency"),
            ('by_currency', "Separate by Currency"),
        ],
        string="Report Currency", required=True, default='company',
        help="Company Currency: every transaction in the company currency, in one table.\n"
             "Separate by Currency: one section per transaction currency, with amounts and "
             "running balance in that currency.",
    )
    currency_ids = fields.Many2many(
        'res.currency', string="Currencies",
        help="Only include transactions in these currencies. Leave empty for all currencies.",
    )
    show_amount_currency = fields.Boolean(
        string="Show Amount in Currency",
        help="Add an \"Amount in Currency\" column with the amount in the transaction currency "
             "(shown for transactions that are not in the company currency).",
    )
    company_id = fields.Many2one(
        'res.company', string="Company", required=True,
        default=lambda self: self.env.company,
    )
    currency_id = fields.Many2one(related='company_id.currency_id')

    header_color = fields.Char(
        string="Header Colour",
        default=lambda self: self.env.company._get_partner_statement_colors()[0],
    )
    highlight_color = fields.Char(
        string="Highlight Colour",
        default=lambda self: self.env.company._get_partner_statement_colors()[1],
    )
    pdf_layout = fields.Selection(
        [
            ('company', "With Logo & Company Layout"),
            ('plain', "Plain (No Logo)"),
        ],
        string="PDF Layout", required=True,
        default=lambda self: self.env.company.partner_statement_pdf_layout or 'company',
        help="With Logo & Company Layout: logo, header, footer and font from the company document layout.\n"
             "Plain: no logo, header or footer, only page numbers - e.g. for pre-printed letterhead paper.",
    )
    plain_margin_top = fields.Integer(
        string="Top Margin (mm)",
        default=lambda self: self.env.company.partner_statement_margin_top or 12,
        help="Space above the statement on the plain PDF. Increase it for pre-printed letterhead paper.",
    )
    save_colors_as_default = fields.Boolean(
        string="Save Design as Company Default",
        help="Store these colours and the PDF layout in the company settings so they are used next time.",
    )

    preview_html = fields.Html(
        string="Preview", compute='_compute_preview_html', sanitize=False,
    )
    excel_file = fields.Binary(string="Excel File", attachment=False, readonly=True)
    excel_filename = fields.Char(string="Excel Filename", readonly=True)

    # ------------------------------------------------------------------
    # Defaults / computes
    # ------------------------------------------------------------------
    @api.model
    def _default_partner_ids(self):
        ctx = self.env.context
        if ctx.get('active_model') == 'res.partner' and ctx.get('active_ids'):
            partners = self.env['res.partner'].browse(ctx['active_ids'])
            return partners.commercial_partner_id.ids
        return []

    @api.depends('period', 'company_id')
    def _compute_dates(self):
        today = fields.Date.context_today(self)
        for wizard in self:
            company = wizard.company_id or self.env.company
            period = wizard.period
            if period == 'custom':
                # keep what the user typed; just make sure "To" is filled
                wizard.date_to = wizard.date_to or today
                continue
            if period == 'this_month':
                date_from, date_to = date_utils.get_month(today)
            elif period == 'last_month':
                date_from, date_to = date_utils.get_month(today - relativedelta(months=1))
            elif period == 'this_quarter':
                date_from, date_to = date_utils.get_quarter(today)
            elif period == 'last_quarter':
                date_from, date_to = date_utils.get_quarter(today - relativedelta(months=3))
            elif period == 'this_year':
                fiscal_year = company.compute_fiscalyear_dates(today)
                date_from, date_to = fiscal_year['date_from'], fiscal_year['date_to']
            elif period == 'last_year':
                current = company.compute_fiscalyear_dates(today)
                previous = company.compute_fiscalyear_dates(current['date_from'] - relativedelta(days=1))
                date_from, date_to = previous['date_from'], previous['date_to']
            else:  # 'all'
                date_from, date_to = False, today
            wizard.date_from = date_from
            wizard.date_to = date_to

    @api.depends('unreconciled_only')
    def _compute_amount_basis(self):
        # unreconciled statements show the open (residual) amount by default
        for wizard in self:
            wizard.amount_basis = 'residual' if wizard.unreconciled_only else 'full'

    @api.depends(
        'partner_ids', 'statement_type', 'date_from', 'date_to', 'include_draft',
        'unreconciled_only', 'amount_basis', 'currency_mode', 'currency_ids', 'show_amount_currency',
        'company_id', 'header_color', 'highlight_color',
    )
    def _compute_preview_html(self):
        for wizard in self:
            partners = wizard.partner_ids._origin
            if not partners or not wizard.date_to:
                wizard.preview_html = False
                continue
            if wizard.date_from and wizard.date_from > wizard.date_to:
                wizard.preview_html = Markup('<div class="alert alert-warning">%s</div>') % self.env._(
                    "The start date must be before the end date."
                )
                continue
            statement = wizard._get_statement_data(partners[0])
            wizard.preview_html = self.env['ir.qweb']._render(
                'partner_statement_report.statement_preview',
                {
                    'st': statement,
                    'preview_limit': PREVIEW_LINE_LIMIT,
                    'other_partner_count': len(partners) - 1,
                },
            )

    # ------------------------------------------------------------------
    # Statement data (shared by preview, PDF and Excel)
    # ------------------------------------------------------------------
    def _check_dates(self):
        for wizard in self:
            if not wizard.partner_ids:
                raise UserError(self.env._("Please select at least one partner."))
            if wizard.date_from and wizard.date_to and wizard.date_from > wizard.date_to:
                raise UserError(self.env._("The start date must be before the end date."))
            if wizard.pdf_layout == 'plain' and not 0 <= wizard.plain_margin_top <= 150:
                raise UserError(self.env._("The top margin must be between 0 and 150 mm."))

    def _get_colors(self):
        self.ensure_one()
        company_header, company_highlight = self.company_id._get_partner_statement_colors()
        header = normalize_hex(self.header_color, fallback=company_header)
        highlight = normalize_hex(self.highlight_color, fallback=lighten(header))
        return {
            'header': header,
            'header_text': contrast_text(header),
            'highlight': highlight,
            'highlight_text': contrast_text(highlight),
            'stripe': lighten(header, 0.95),
        }

    def _get_statement_title(self):
        self.ensure_one()
        return {
            'customer': self.env._("Customer Statement"),
            'vendor': self.env._("Vendor Statement"),
        }.get(self.statement_type, self.env._("Statement of Account"))

    def _get_statement_domain(self, partner):
        self.ensure_one()
        states = ('posted', 'draft') if self.include_draft else ('posted',)
        return [
            ('partner_id', 'child_of', partner.commercial_partner_id.id),
            ('account_id.account_type', 'in', ACCOUNT_TYPES[self.statement_type]),
            ('company_id', 'child_of', self.company_id.id),
            ('parent_state', 'in', states),
        ] + ([('currency_id', 'in', self.currency_ids.ids)] if self.currency_ids else [])

    def _get_open_items_domain(self):
        """Lines not fully reconciled on the end date (later reconciliations are ignored)."""
        self.ensure_one()
        return [
            '|', '|',
            ('reconciled', '=', False),
            ('matched_debit_ids.max_date', '>', self.date_to),
            ('matched_credit_ids.max_date', '>', self.date_to),
        ]

    def _get_open_amounts(self, lines):
        """Residual of each line as at the end date: {line_id: (residual, residual_in_currency)}.

        Same formula as Odoo's ``amount_residual`` / ``amount_residual_currency``
        (line amount minus its partial reconciliations), but only counting
        reconciliations dated on or before the end date. For a statement ending
        today the result is exactly the Residual / Residual in Currency of the line.
        """
        self.ensure_one()
        open_amounts = {line.id: [line.balance, line.amount_currency] for line in lines}
        if lines:
            partials = self.env['account.partial.reconcile'].search_fetch(
                [
                    '|', ('debit_move_id', 'in', lines.ids), ('credit_move_id', 'in', lines.ids),
                    ('max_date', '<=', self.date_to),
                ],
                ['debit_move_id', 'credit_move_id', 'amount', 'debit_amount_currency', 'credit_amount_currency'],
            )
            for partial in partials:
                if partial.debit_move_id.id in open_amounts:
                    values = open_amounts[partial.debit_move_id.id]
                    values[0] -= partial.amount
                    values[1] -= partial.debit_amount_currency
                if partial.credit_move_id.id in open_amounts:
                    values = open_amounts[partial.credit_move_id.id]
                    values[0] += partial.amount
                    values[1] += partial.credit_amount_currency
        return {
            line.id: (
                line.company_currency_id.round(open_amounts[line.id][0]),
                line.currency_id.round(open_amounts[line.id][1]),
            )
            for line in lines
        }

    def _get_sign(self):
        """Customer statements show what the partner owes us as positive,
        vendor statements show what we owe the vendor as positive."""
        self.ensure_one()
        return -1 if self.statement_type == 'vendor' else 1

    def _get_move_kind(self, move, type_labels):
        if move.move_type != 'entry':
            return type_labels.get(move.move_type, move.move_type)
        if move.origin_payment_id:
            return self.env._("Payment")
        if move.statement_line_id:
            return self.env._("Bank Transaction")
        return type_labels.get('entry', self.env._("Journal Entry"))

    def _get_move_description(self, move, lines, type_labels):
        kind = self._get_move_kind(move, type_labels)
        details = []

        def add(value):
            value = (value or '').strip()
            if value and value != '/' and value != move.name and value not in details:
                details.append(value)

        add(move.ref)
        if move.is_invoice(include_receipts=True):
            add(move.invoice_origin)
        elif not details:
            for name in lines.mapped('name'):
                add(name)
        details = [d.replace('\n', ' ') for d in details[:3]]
        return f"{kind} - {' | '.join(details)}" if details else kind

    def _get_filter_labels(self):
        self.ensure_one()
        labels = []
        if self.unreconciled_only or self.amount_basis == 'residual':
            labels.append(self.env._("Unreconciled transactions only"))
        if self.amount_basis == 'residual':
            labels.append(self.env._("Residual amounts"))
        if self.currency_ids:
            labels.append(self.env._(
                "Currencies: %(currencies)s", currencies=', '.join(self.currency_ids.mapped('name')),
            ))
        return labels

    def _get_statement_data(self, partner):
        """Compute one partner statement. Labels are rendered in the partner's language.

        The statement is made of one or more sections. With "Company Currency" there is a
        single section in the company currency; with "Separate by Currency" there is one
        section per transaction currency, each with its own opening, running and closing
        balance in that currency.
        """
        self.ensure_one()
        partner = partner.commercial_partner_id
        lang = partner.lang or self.env.lang or 'en_US'
        wizard = self.with_context(lang=lang)
        env = wizard.env
        company = wizard.company_id
        company_currency = company.currency_id
        sign = wizard._get_sign()
        by_currency = wizard.currency_mode == 'by_currency'
        residual = wizard.amount_basis == 'residual'
        open_only = wizard.unreconciled_only or residual
        show_amount_currency = wizard.show_amount_currency and not by_currency
        AccountMoveLine = env['account.move.line']
        domain = wizard._get_statement_domain(partner)
        date_from, date_to = wizard.date_from, wizard.date_to
        order = 'date, move_name, move_id, id'

        # --- fetch lines + opening balances (per section currency)
        opening = {}  # section currency -> unsigned opening amount
        if open_only:
            # every line still open on the end date; older ones go into the opening balance
            move_lines = AccountMoveLine.search(
                domain + [('date', '<=', date_to)] + wizard._get_open_items_domain(), order=order,
            )
            open_amounts = wizard._get_open_amounts(move_lines)
        else:
            open_amounts = {}
            period_domain = domain + [('date', '<=', date_to)]
            if date_from:
                period_domain.append(('date', '>=', date_from))
            move_lines = AccountMoveLine.search(period_domain, order=order)
            if date_from:
                before = domain + [('date', '<', date_from)]
                if by_currency:
                    for cur, amount in AccountMoveLine._read_group(
                        before, groupby=['currency_id'], aggregates=['amount_currency:sum'],
                    ):
                        opening[cur] = amount or 0.0
                else:
                    [(amount,)] = AccountMoveLine._read_group(before, aggregates=['balance:sum'])
                    opening[company_currency] = amount or 0.0

        def values(line):
            """(full company, full currency, open company, open currency) for a line"""
            res = open_amounts.get(line.id)
            return (
                line.balance, line.amount_currency,
                res[0] if res else line.balance, res[1] if res else line.amount_currency,
            )

        def main_values(line):
            """(shown amount, other basis amount) in the section currency"""
            full_comp, full_cur, open_comp, open_cur = values(line)
            full, open_ = (full_cur, open_cur) if by_currency else (full_comp, open_comp)
            return (open_, full) if residual else (full, open_)

        def section_currency(line):
            return line.currency_id if by_currency else company_currency

        if open_only and date_from:
            older = move_lines.filtered(lambda line: line.date < date_from)
            for line in older:
                cur = section_currency(line)
                opening[cur] = opening.get(cur, 0.0) + main_values(line)[0]
            move_lines -= older

        # --- rows: one per journal entry and currency (installments show once)
        type_labels = dict(env['account.move']._fields['move_type']._description_selection(env))
        rows_by_currency = {}
        key = lambda line: (line.move_id, line.currency_id)  # noqa: E731
        for (move, line_currency), group in itertools.groupby(move_lines, key=key):
            lines = AccountMoveLine.union(*group)
            cur = section_currency(lines[:1])
            shown = cur.round(sum(main_values(line)[0] for line in lines))
            other = cur.round(sum(main_values(line)[1] for line in lines))
            amount_currency = None
            if show_amount_currency and line_currency != company_currency:
                index = 3 if residual else 1
                amount_currency = line_currency.round(sum(values(line)[index] for line in lines))
            if cur.is_zero(shown) and (amount_currency is None or line_currency.is_zero(amount_currency)):
                continue
            rows_by_currency.setdefault(cur, []).append({
                'date': move.date,
                'date_str': format_date(env, move.date),
                'move': move,
                'sequence': move.name if move.name and move.name != '/' else env._("Draft"),
                'description': wizard._get_move_description(move, lines, type_labels),
                'is_draft': move.state == 'draft',
                'net': shown,
                'amount': sign * shown,
                'currency': line_currency,
                'amount_currency': sign * amount_currency if amount_currency is not None else None,
                # partly reconciled: show the other figure (original or residual) as a note
                'is_partial': open_only and cur.compare_amounts(shown, other) != 0,
                'other_amount': sign * other,
            })

        # --- sections
        currencies = set(rows_by_currency) | {c for c, amount in opening.items() if not c.is_zero(amount)}
        if not currencies:
            currencies = {wizard.currency_ids[:1] if by_currency and wizard.currency_ids else company_currency}
        ordered = sorted(currencies, key=lambda c: (c != company_currency, c.name))
        sections = []
        for cur in ordered:
            opening_balance = cur.round(sign * opening.get(cur, 0.0))
            running = opening_balance
            total_debit = total_credit = 0.0
            rows = rows_by_currency.get(cur, [])
            for row in rows:
                running = cur.round(running + row['amount'])
                row['balance'] = running
                total_debit += max(row['net'], 0.0)
                total_credit += max(-row['net'], 0.0)
            sections.append({
                'currency': cur,
                'opening_balance': opening_balance,
                'closing_balance': running,
                'total_debit': cur.round(total_debit),
                'total_credit': cur.round(total_credit),
                'net_movement': cur.round(running - opening_balance),
                'lines': rows,
            })

        if date_from:
            period_label = env._(
                "From %(date_from)s to %(date_to)s",
                date_from=format_date(env, date_from), date_to=format_date(env, date_to),
            )
        else:
            period_label = env._("Up to %(date_to)s", date_to=format_date(env, date_to))

        return {
            'wizard': wizard,
            'partner': partner.with_context(lang=lang),
            'company': company,
            'currency': company_currency,
            'currency_label': ', '.join(section['currency'].name for section in sections),
            'lang': lang,
            'title': wizard._get_statement_title(),
            'date_from': date_from,
            'date_to': date_to,
            'date_from_str': format_date(env, date_from) if date_from else '',
            'date_to_str': format_date(env, date_to),
            'period_label': period_label,
            'print_date_str': format_date(env, fields.Date.context_today(wizard)),
            'sections': sections,
            'by_currency': by_currency,
            'show_amount_currency': show_amount_currency,
            'open_only': open_only,
            'residual': residual,
            'unreconciled_only': open_only,
            'filter_labels': wizard._get_filter_labels(),
            'colors': wizard._get_colors(),
        }

    def _get_all_statements(self):
        self.ensure_one()
        return [self._get_statement_data(partner) for partner in self.partner_ids.commercial_partner_id]

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------
    def _save_colors_if_requested(self):
        self.ensure_one()
        if self.save_colors_as_default and self.env.user.has_group('account.group_account_manager'):
            self.company_id.sudo().write({
                'partner_statement_header_color': normalize_hex(self.header_color),
                'partner_statement_highlight_color': normalize_hex(self.highlight_color),
                'partner_statement_pdf_layout': self.pdf_layout,
                'partner_statement_margin_top': self.plain_margin_top,
            })

    def action_print_pdf(self):
        self.ensure_one()
        self._check_dates()
        self._save_colors_if_requested()
        if self.pdf_layout == 'plain':
            # no company header/footer -> no need for the document layout configurator
            return self.env.ref(
                'partner_statement_report.action_report_partner_statement_plain'
            ).report_action(self, config=False)
        return self.env.ref('partner_statement_report.action_report_partner_statement').report_action(self)

    def action_export_excel(self):
        self.ensure_one()
        self._check_dates()
        self._save_colors_if_requested()
        statements = self._get_all_statements()
        content = self._generate_xlsx(statements)
        self.write({
            'excel_file': base64.b64encode(content),
            'excel_filename': self._get_export_filename(statements, 'xlsx'),
        })
        return {
            'type': 'ir.actions.act_url',
            'url': (
                f'/web/content/?model={self._name}&id={self.id}'
                '&field=excel_file&filename_field=excel_filename&download=true'
            ),
            'target': 'download',
        }

    def _get_export_filename(self, statements, extension):
        self.ensure_one()
        if len(statements) == 1:
            name = f"{statements[0]['title']} - {statements[0]['partner'].name}"
        else:
            name = self._get_statement_title()
        period = (
            f"{self.date_from} to {self.date_to}" if self.date_from else f"to {self.date_to}"
        )
        if self.unreconciled_only:
            name = f"{name} - {self.env._('Unreconciled')}"
        if self.amount_basis == 'residual':
            name = f"{name} - {self.env._('Residual')}"
        if self.currency_mode == 'by_currency':
            name = f"{name} - {self.env._('By Currency')}"
        name = re.sub(r'[\\/:*?"<>|]+', '-', f"{name} ({period})")
        return f"{name}.{extension}"

    # ------------------------------------------------------------------
    # Excel export
    # ------------------------------------------------------------------
    def _excel_date_format(self, lang):
        date_format = self.env['res.lang']._get_data(code=lang).date_format or '%Y-%m-%d'
        return re.sub(r'%[a-zA-Z]', lambda m: _DATE_TOKENS.get(m.group(0), ''), date_format)

    def _generate_xlsx(self, statements):
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        used_names = set()
        for statement in statements:
            self._write_statement_sheet(workbook, statement, used_names)
        workbook.close()
        return output.getvalue()

    @staticmethod
    def _excel_number_format(currency, with_code=False):
        decimals = currency.decimal_places
        number = '#,##0' + ('.' + '0' * decimals if decimals else '')
        if with_code:
            number = f'{number} "{currency.name}"'
        return f'{number};[Red]-{number}'

    def _write_statement_sheet(self, workbook, st, used_names):
        env = st['wizard'].env
        _ = env._
        colors = st['colors']
        date_format = self._excel_date_format(st['lang'])
        is_rtl = env['res.lang']._get_data(code=st['lang']).direction == 'rtl'
        show_cur = st['show_amount_currency']

        # columns: Date | Sequence | Reference / Description | [Amount in Currency] | Amount | Balance
        c_cur = 3 if show_cur else None
        c_amt = 4 if show_cur else 3
        c_bal = c_amt + 1
        last_col = c_bal
        amt_col = xl_col_to_name(c_amt)
        bal_col = xl_col_to_name(c_bal)

        # sheet name: max 31 chars, no []:*?/\ , unique
        base_name = re.sub(r'[\[\]:*?/\\]', ' ', st['partner'].name or 'Statement').strip()[:28] or 'Statement'
        sheet_name, index = base_name, 2
        while sheet_name.lower() in used_names:
            sheet_name = f"{base_name[:26]} {index}"
            index += 1
        used_names.add(sheet_name.lower())
        sheet = workbook.add_worksheet(sheet_name)
        if is_rtl:
            sheet.right_to_left()

        border_color = colors['header']
        grid = {'border': 1, 'border_color': '#D9D9D9'}
        head = {
            'bold': True, 'bg_color': colors['header'], 'font_color': colors['header_text'],
            'border': 1, 'border_color': border_color, 'valign': 'vcenter',
        }
        hl = {
            'bold': True, 'bg_color': colors['highlight'], 'font_color': colors['highlight_text'],
            'border': 1, 'border_color': border_color,
        }
        fmt = {
            'company': workbook.add_format({'bold': True, 'font_size': 14}),
            'title': workbook.add_format({**head, 'font_size': 16, 'border': 0}),
            'period': workbook.add_format({**head, 'border': 0, 'align': 'right'}),
            'label': workbook.add_format({'bold': True}),
            'value': workbook.add_format({}),
            'section': workbook.add_format({
                'bold': True, 'font_size': 12, 'font_color': colors['header'],
                'bottom': 2, 'bottom_color': border_color,
            }),
            'th': workbook.add_format(head),
            'th_num': workbook.add_format({**head, 'align': 'right'}),
            'date': workbook.add_format({**grid, 'num_format': date_format, 'align': 'left'}),
            'text': workbook.add_format(grid),
            'wrap': workbook.add_format({**grid, 'text_wrap': True, 'valign': 'top'}),
            'hl_date': workbook.add_format({**hl, 'num_format': date_format, 'align': 'left'}),
            'hl_text': workbook.add_format(hl),
            'sum_label': workbook.add_format({'bold': True, 'align': 'right'}),
            'sum_total_label': workbook.add_format({
                'bold': True, 'align': 'right', 'top': 2, 'top_color': border_color, 'font_color': colors['header'],
            }),
        }
        number_formats = {}

        def num_fmt(kind, currency, with_code=False):
            key = (kind, currency.id, with_code)
            if key not in number_formats:
                base = {'num_format': self._excel_number_format(currency, with_code)}
                extra = {
                    'num': grid,
                    'hl': hl,
                    'sum': {'bold': True},
                    'total': {'bold': True, 'top': 2, 'top_color': border_color, 'font_color': colors['header']},
                }[kind]
                number_formats[key] = workbook.add_format({**extra, **base})
            return number_formats[key]

        sheet.set_column(0, 0, 13)
        sheet.set_column(1, 1, 20)
        sheet.set_column(2, 2, 52)
        if show_cur:
            sheet.set_column(c_cur, c_cur, 20)
        sheet.set_column(c_amt, c_bal, 18)

        row = 0
        sheet.write(row, 0, st['company'].name, fmt['company'])
        row += 1
        sheet.set_row(row, 26)
        sheet.merge_range(row, 0, row, last_col - 2, st['title'], fmt['title'])
        sheet.merge_range(row, last_col - 1, row, last_col, st['period_label'], fmt['period'])
        row += 2
        info = [
            (_("Partner"), st['partner'].name),
            (_("Period"), st['period_label']),
            (_("Currencies") if st['by_currency'] else _("Currency"), st['currency_label']),
            (_("Printed on"), st['print_date_str']),
        ]
        if st['partner'].vat:
            info.insert(1, (_("Tax ID"), st['partner'].vat))
        info += [(_("Filter"), label) for label in st['filter_labels']]
        for label, value in info:
            sheet.write(row, 0, label, fmt['label'])
            sheet.write(row, 1, value, fmt['value'])
            row += 1
        row += 1

        first_header_row = None
        for section in st['sections']:
            cur = section['currency']
            if st['by_currency']:
                sheet.merge_range(row, 0, row, last_col, _("Currency: %(currency)s", currency=cur.name), fmt['section'])
                row += 1

            header_row = row
            first_header_row = header_row if first_header_row is None else first_header_row
            sheet.set_row(row, 20)
            sheet.write(row, 0, _("Date"), fmt['th'])
            sheet.write(row, 1, _("Sequence"), fmt['th'])
            sheet.write(row, 2, _("Reference / Description"), fmt['th'])
            if show_cur:
                sheet.write(row, c_cur, _("Amount in Currency"), fmt['th_num'])
            sheet.write(row, c_amt, _("Amount"), fmt['th_num'])
            sheet.write(row, c_bal, _("Balance"), fmt['th_num'])
            row += 1

            # opening balance
            opening_row = row
            if st['date_from']:
                sheet.write_datetime(row, 0, st['date_from'], fmt['hl_date'])
            else:
                sheet.write_blank(row, 0, None, fmt['hl_text'])
            sheet.write_blank(row, 1, None, fmt['hl_text'])
            sheet.write(row, 2, _("Opening Balance"), fmt['hl_text'])
            if show_cur:
                sheet.write_blank(row, c_cur, None, fmt['hl_text'])
            sheet.write_blank(row, c_amt, None, num_fmt('hl', cur))
            sheet.write_number(row, c_bal, section['opening_balance'], num_fmt('hl', cur))
            row += 1

            first_line_row = row
            for line in section['lines']:
                sheet.write_datetime(row, 0, line['date'], fmt['date'])
                sheet.write(row, 1, line['sequence'], fmt['text'])
                description = line['description']
                if line['is_partial']:
                    label = _("original amount") if st['residual'] else _("residual amount")
                    description += ' (%s: %s)' % (
                        label, formatLang(env, line['other_amount'], currency_obj=cur),
                    )
                sheet.write(row, 2, description, fmt['wrap'])
                if show_cur:
                    if line['amount_currency'] is None:
                        sheet.write_blank(row, c_cur, None, fmt['text'])
                    else:
                        sheet.write_number(
                            row, c_cur, line['amount_currency'], num_fmt('num', line['currency'], with_code=True),
                        )
                sheet.write_number(row, c_amt, line['amount'], num_fmt('num', cur))
                # live running balance: previous balance + amount
                sheet.write_formula(
                    row, c_bal, f'={bal_col}{row}+{amt_col}{row + 1}', num_fmt('num', cur), line['balance'],
                )
                row += 1
            last_line_row = row - 1

            # closing balance
            sheet.write_datetime(row, 0, st['date_to'], fmt['hl_date'])
            sheet.write_blank(row, 1, None, fmt['hl_text'])
            sheet.write(row, 2, _("Closing Balance"), fmt['hl_text'])
            if show_cur:
                sheet.write_blank(row, c_cur, None, fmt['hl_text'])
            if section['lines']:
                sheet.write_formula(
                    row, c_amt, f'=SUM({amt_col}{first_line_row + 1}:{amt_col}{last_line_row + 1})',
                    num_fmt('hl', cur), section['net_movement'],
                )
            else:
                sheet.write_number(row, c_amt, 0, num_fmt('hl', cur))
            sheet.write_formula(
                row, c_bal, f'={bal_col}{opening_row + 1}+{amt_col}{row + 1}', num_fmt('hl', cur),
                section['closing_balance'],
            )
            row += 2

            # summary
            for label, value, label_fmt, kind in (
                (_("Opening Balance"), section['opening_balance'], 'sum_label', 'sum'),
                (_("Total Debit"), section['total_debit'], 'sum_label', 'sum'),
                (_("Total Credit"), section['total_credit'], 'sum_label', 'sum'),
                (_("Closing Balance") + f" ({cur.name})", section['closing_balance'], 'sum_total_label', 'total'),
            ):
                sheet.merge_range(row, c_amt - 2, row, c_amt, label, fmt[label_fmt])
                sheet.write_number(row, c_bal, value, num_fmt(kind, cur))
                row += 1
            row += 1

        if len(st['sections']) == 1:
            sheet.freeze_panes(first_header_row + 1, 0)
            sheet.repeat_rows(first_header_row)
        sheet.set_paper(9)  # A4
        sheet.fit_to_pages(1, 0)
        if show_cur:
            sheet.set_landscape()
        sheet.set_margins(left=0.4, right=0.4, top=0.5, bottom=0.5)
